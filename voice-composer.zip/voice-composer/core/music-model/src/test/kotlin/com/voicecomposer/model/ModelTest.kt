package com.voicecomposer.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private fun note(id: String, midi: Int, startBeat: Double, dur: Double, map: TempoMap = TempoMap.constant(120.0)) = MusicalEvent(
    id = id, type = EventType.NOTE, midiPitch = midi, frequencyHz = Pitch.midiToHz(midi),
    startSec = map.beatToSec(startBeat), endSec = map.beatToSec(startBeat + dur),
    startBeat = startBeat, durationBeats = dur, confidence = 0.9, source = EventSource.DETECTED,
)

private fun transcription(vararg n: MusicalEvent, ts: TimeSignature = TimeSignature.FOUR_FOUR, map: TempoMap = TempoMap.constant(120.0)) =
    Transcription(n.toList(), map, ts, KeySignature(0, Mode.MAJOR)).normalized()

class PitchTest {
    @Test fun hzMidiRoundTrip() {
        assertEquals(69.0, Pitch.hzToMidi(440.0), 1e-9)
        assertEquals(261.6256, Pitch.midiToHz(60), 1e-3)
    }

    @Test fun spellingFollowsKey() {
        assertEquals(Spelling('F', 1, 4), Pitch.spell(66, 2))
        assertEquals(Spelling('G', -1, 4), Pitch.spell(66, -6))
        assertEquals(66, Spelling('F', 1, 4).toMidi())
    }

    @Test fun keySignatures() {
        assertEquals(0, KeySignature(0, Mode.MAJOR).fifths)
        assertEquals(0, KeySignature(9, Mode.MINOR).fifths)
        assertEquals(1, KeySignature(7, Mode.MAJOR).fifths)
        assertEquals(-3, KeySignature(0, Mode.MINOR).fifths)
        assertEquals(listOf('F', 'C'), KeySignature.signatureSteps(2))
        assertEquals("D major", KeySignature(2, Mode.MAJOR).name)
    }
}

class TempoMapTest {
    @Test fun constantMap() {
        val m = TempoMap.constant(120.0, 1.0)
        assertEquals(1.5, m.beatToSec(1.0), 1e-9)
        assertEquals(2.0, m.secToBeat(2.0), 1e-9)
    }

    @Test fun piecewiseMapIsExactAtAnchors() {
        val m = TempoMap(listOf(TempoPoint(0.0, 0.5), TempoPoint(8.0, 5.5), TempoPoint(16.0, 10.0)), 100.0)
        assertEquals(5.5, m.beatToSec(8.0), 1e-9)
        assertEquals(8.0, m.secToBeat(5.5), 1e-9)
        assertEquals(96.0, m.bpmAtBeat(2.0), 1e-9)
        assertTrue(m.bpmAtBeat(10.0) > m.bpmAtBeat(2.0))
        assertEquals(100.0, m.bpmAtBeat(20.0), 1e-9)
        assertFalse(m.isConstant)
    }
}

class NotationTest {
    @Test fun decompositionAlwaysSumsToLength() {
        for (pos in 0 until 16) for (len in 1..(16 - pos)) {
            val chunks = NotationBuilder.decompose(pos, len)
            assertEquals("pos=$pos len=$len", len, chunks.sumOf { it.second.ticks })
            var p = pos
            for ((cp, v) in chunks) { assertEquals(p, cp); p += v.ticks }
        }
    }

    @Test fun noteCrossingBarlineIsTied() {
        val t = transcription(note("a", 60, 3.0, 2.0))
        val n = NotationBuilder.build(t)
        val notes = n.measures.flatMap { it.items }.filterIsInstance<NotationNote>()
        assertEquals(2, notes.size)
        assertTrue(notes[0].tieToNext)
        assertTrue(notes[1].tieFromPrevious)
        assertFalse(notes[1].tieToNext)
        assertEquals(2, n.measures.size)
        for (m in n.measures) assertEquals(m.lengthTicks, m.items.sumOf { it.ticks })
    }

    @Test fun everyMeasureIsFilledWithRests() {
        val t = transcription(note("a", 60, 1.0, 1.0), note("b", 62, 2.5, 0.5))
        val n = NotationBuilder.build(t)
        for (m in n.measures) assertEquals(m.lengthTicks, m.items.sumOf { it.ticks })
        assertTrue(n.measures[0].items.first() is NotationRest)
    }

    @Test fun threeFourMeasure() {
        val t = transcription(note("a", 60, 0.0, 3.0), note("b", 62, 3.0, 3.0), ts = TimeSignature.THREE_FOUR)
        val n = NotationBuilder.build(t)
        assertEquals(2, n.measures.size)
        assertEquals(12, n.measures[0].lengthTicks)
        val first = n.measures[0].items.single() as NotationNote
        assertEquals(1, first.dots)
        assertEquals(NoteType.HALF, first.type)
    }
}

class EditingTest {
    private fun base() = transcription(note("a", 60, 0.0, 1.0), note("b", 62, 1.0, 1.0), note("c", 64, 3.0, 1.0))

    @Test fun editMarksProvenanceAndKeepsRealTimeOfOthers() {
        val t = base()
        val e = TranscriptionEditor.setPitch(t, "b", 65)
        val b = e.events.first { it.id == "b" }
        assertEquals(65, b.midiPitch)
        assertEquals(EventSource.USER, b.source)
        assertEquals(EventSource.DETECTED, e.events.first { it.id == "a" }.source)
        assertEquals(t.events.first { it.id == "a" }, e.events.first { it.id == "a" })
    }

    @Test fun restsAreRegeneratedFromGaps() {
        val t = base()
        assertEquals(1, t.events.count { it.isRest })
        val d = TranscriptionEditor.deleteNote(t, "b")
        assertEquals(listOf("a", "c"), d.notes.map { it.id })
        val r = d.events.single { it.isRest }
        assertEquals(1.0, r.startBeat, 1e-9)
        assertEquals(2.0, r.durationBeats, 1e-9)
    }

    @Test fun splitAndMerge() {
        val t = base()
        val s = TranscriptionEditor.splitNote(t, "a")
        assertEquals(4, s.notes.size)
        assertEquals(0.5, s.notes[0].durationBeats, 1e-9)
        val m = TranscriptionEditor.mergeWithNext(s, s.notes[0].id)
        assertEquals(3, m.notes.size)
        assertEquals(1.0, m.notes[0].durationBeats, 1e-9)
    }

    @Test fun addNoteTrimsPreviousNoteAndClampsToNext() {
        val t = base()
        val a = TranscriptionEditor.addNote(t, 1.5, 4.0, 70)
        val b = a.notes.first { it.id == "b" }
        assertEquals(0.5, b.durationBeats, 1e-9)
        val added = a.notes.first { it.midiPitch == 70 }
        assertEquals(1.5, added.durationBeats, 1e-9)
    }

    @Test fun durationCannotOverlapNextNote() {
        val t = base()
        val d = TranscriptionEditor.setDuration(t, "b", 5.0)
        assertEquals(2.0, d.notes.first { it.id == "b" }.durationBeats, 1e-9)
    }

    @Test fun tempoChangeRepositionsDetectedNotesFromRealTime() {
        val t = base() // 120 bpm, notes at 0, 0.5s, 1.5s
        val slower = TranscriptionEditor.setTempo(t, 60.0)
        // At 60 bpm the same real time spans half the beats.
        assertEquals(0.5, slower.notes[1].startBeat, 1e-9)
        assertEquals(1.5, slower.notes[2].startBeat, 1e-9)
    }

    @Test fun undoRedo() {
        val s = EditSession(base())
        val original = s.current
        s.apply("pitch") { TranscriptionEditor.setPitch(it, "a", 61) }
        s.apply("delete") { TranscriptionEditor.deleteNote(it, "c") }
        assertTrue(s.canUndo)
        s.undo()
        assertEquals(3, s.current.notes.size)
        s.undo()
        assertEquals(original, s.current)
        assertFalse(s.canUndo)
        s.redo()
        assertEquals(61, s.current.notes.first().midiPitch)
        assertEquals(listOf("pitch", "delete"), s.history + "delete")
    }

    @Test fun restLengthRipples() {
        val t = base()
        val rest = t.events.single { it.isRest }
        assertEquals(1.0, rest.durationBeats, 1e-9)
        val r = TranscriptionEditor.setRestLength(t, rest.id, 3.0)
        assertEquals(5.0, r.notes.first { it.id == "c" }.startBeat, 1e-9)
    }

    @Test fun lyricsFollowNotes() {
        var t = TranscriptionEditor.setLyric(base(), "a", "la")
        assertEquals("la", t.lyricFor("a")?.text)
        t = TranscriptionEditor.moveLyric(t, t.lyricFor("a")!!.id, "c")
        assertEquals(null, t.lyricFor("a"))
        assertEquals("la", t.lyricFor("c")?.text)
        t = TranscriptionEditor.deleteNote(t, "c")
        assertTrue(t.lyrics.isEmpty())
    }
}

class JsonTest {
    @Test fun transcriptionRoundTrip() {
        val map = TempoMap(listOf(TempoPoint(0.0, 0.25), TempoPoint(8.0, 4.0)), 130.0)
        var t = Transcription(
            listOf(note("a", 60, 0.0, 1.0, map), note("b", 62, 1.0, 2.0, map)), map, TimeSignature.THREE_FOUR,
            KeySignature(2, Mode.MINOR, 0.7), QuantizationMode.SOFT,
            analysis = AnalysisInfo("test-1", 0.8, 0.6, 0.7, 0.7, listOf("a \"quoted\" warning")),
        ).normalized()
        t = TranscriptionEditor.setLyric(t, "a", "ha\nllo")
        val back = ModelJson.decodeTranscription(ModelJson.encode(t))
        assertEquals(t, back)
    }

    @Test fun arrangementRoundTrip() {
        val a = Arrangement(
            "arr1", 3, ArrangementStyle.FOLK, 2, listOf(ChordSegment(0.0, 4.0, 7, minor = false)),
            listOf(Track("t1", "Bass", Instrument.ELECTRIC_BASS, TrackRole.BASS, listOf(note("x", 40, 0.0, 1.0)), 0.5f, -0.2f, false)),
        )
        assertEquals(a, ModelJson.decodeArrangement(ModelJson.encode(a)))
    }

    @Test fun parserRejectsGarbage() {
        try {
            Json.parse("{\"a\": ")
            org.junit.Assert.fail("expected failure")
        } catch (_: Exception) {
        }
    }
}
