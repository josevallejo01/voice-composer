package com.voicecomposer.model

import com.voicecomposer.model.layout.ScoreLayoutEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LayoutTest {
    private fun melody(count: Int, key: KeySignature = KeySignature(0, Mode.MAJOR)): Transcription {
        val map = TempoMap.constant(100.0)
        val pcs = intArrayOf(60, 62, 64, 65, 67, 69, 71, 72)
        val ev = (0 until count).map { i ->
            MusicalEvent("n$i", EventType.NOTE, pcs[i % 8], Pitch.midiToHz(pcs[i % 8]), map.beatToSec(i.toDouble()), map.beatToSec(i + 1.0), i.toDouble(), 1.0, 1.0, EventSource.USER)
        }
        return Transcription(ev, map, TimeSignature.FOUR_FOUR, key).normalized()
    }

    @Test fun systemsWrapAndStayInsideWidth() {
        val n = NotationBuilder.build(melody(40))
        val layout = ScoreLayoutEngine.layout(n, 900f, 10f)
        assertTrue(layout.systems.size > 1)
        for (s in layout.systems) {
            val last = s.measures.last()
            assertTrue("system ${s.index} ends at ${last.x + last.width}", last.x + last.width <= 900f + 0.5f)
            for (m in s.measures) for (it in m.items) assertTrue(it.x >= m.x && it.x <= m.x + m.width)
        }
        assertEquals(n.measures.size, layout.systems.sumOf { it.measures.size })
        assertTrue(layout.height > layout.systems.last().top)
    }

    @Test fun noteHeightsFollowDiatonicPosition() {
        val layout = ScoreLayoutEngine.layout(NotationBuilder.build(melody(8)), 1200f, 10f)
        val sys = layout.systems[0]
        val boxes = layout.noteBoxes
        // E4 sits on the bottom line of the treble staff, C4 is one ledger line below it
        val e4 = boxes.first { it.eventId == "n2" }
        assertEquals(layout.staffBottom(sys), e4.y, 0.01f)
        val c4 = boxes.first { it.eventId == "n0" }
        assertEquals(layout.staffBottom(sys) + 10f, c4.y, 0.01f)
        assertEquals(sys.top, layout.noteBoxes.first { it.eventId == "n7" }.y - 0f - (boxes.first { it.eventId == "n7" }.y - sys.top), 0.01f)
    }

    @Test fun hitTestingAndPositionRoundTrip() {
        val layout = ScoreLayoutEngine.layout(NotationBuilder.build(melody(8)), 1200f, 10f)
        val b = layout.noteBoxes[3]
        assertEquals(b.eventId, layout.hitNote(b.x + 2, b.y - 3)?.eventId)
        assertNull(layout.hitNote(b.x + 200, b.y))
        val pos = layout.positionAt(b.x, b.y)!!
        assertEquals(b.staffPos, pos.staffPos)
        assertEquals(3 * 4, pos.measure * 16 + pos.tickInMeasure)
        val (sys, x) = layout.locate(3.0)!!
        assertEquals(b.system, sys.index)
        assertEquals(b.x, x, 0.5f)
    }

    @Test fun accidentalsOnlyWhereNeeded() {
        val map = TempoMap.constant(100.0)
        fun ev(id: String, midi: Int, beat: Double) = MusicalEvent(id, EventType.NOTE, midi, 0.0, 0.0, 0.0, beat, 1.0, 1.0, EventSource.USER)
        // G major: F# is in the key signature (no accidental), F natural needs one, then repeats stay natural
        val t = Transcription(listOf(ev("a", 66, 0.0), ev("b", 65, 1.0), ev("c", 65, 2.0), ev("d", 66, 3.0)), map, TimeSignature.FOUR_FOUR, KeySignature(7, Mode.MAJOR)).normalized()
        val layout = ScoreLayoutEngine.layout(NotationBuilder.build(t), 800f, 10f)
        val items = layout.systems[0].measures[0].items
        assertNull(items[0].accidental)
        assertEquals(0, items[1].accidental)
        assertNull(items[2].accidental)
        assertEquals(1, items[3].accidental)
    }

    @Test fun tiesPointToTheirContinuation() {
        val map = TempoMap.constant(100.0)
        val e = MusicalEvent("a", EventType.NOTE, 60, 0.0, 0.0, 0.0, 3.0, 2.0, 1.0, EventSource.USER)
        val layout = ScoreLayoutEngine.layout(NotationBuilder.build(Transcription(listOf(e), map, TimeSignature.FOUR_FOUR, KeySignature(0, Mode.MAJOR)).normalized()), 800f, 10f)
        val first = layout.systems[0].measures.first().items.filter { it.item is NotationNote }.last()
        assertNotNull(first.tieEndX)
        assertTrue(first.tieEndX!! > first.x)
    }

    @Test fun emptyScoreStillHasOneMeasure() {
        val t = Transcription(emptyList(), TempoMap.constant(100.0), TimeSignature.FOUR_FOUR, KeySignature(0, Mode.MAJOR))
        val layout = ScoreLayoutEngine.layout(NotationBuilder.build(t), 600f, 10f)
        assertEquals(1, layout.systems.size)
    }
}
