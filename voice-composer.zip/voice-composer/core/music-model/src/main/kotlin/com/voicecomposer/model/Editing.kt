package com.voicecomposer.model

import kotlin.math.roundToInt

/**
 * Pure editing operations on a [Transcription]. Every touch method of the editor (note selection, staff
 * drawing, virtual keyboard) ends up calling these functions, so there is a single model (spec 3.5).
 *
 * Rules:
 *  - an edited note becomes [EventSource.USER] and [ValidationState.VALIDATED];
 *  - user notes are positioned by beats, their real time is derived from the tempo map;
 *  - detected notes keep their real recorded time when the tempo or quantization changes.
 */
object TranscriptionEditor {
    private const val GRID = 0.25

    private fun snap(beat: Double) = (beat / GRID).roundToInt() * GRID

    private fun MusicalEvent.userEdited(map: TempoMap, pitch: Int? = midiPitch, startBeat: Double = this.startBeat, durationBeats: Double = this.durationBeats): MusicalEvent =
        copy(
            midiPitch = pitch,
            frequencyHz = pitch?.let { Pitch.midiToHz(it) },
            startBeat = startBeat,
            durationBeats = durationBeats,
            startSec = map.beatToSec(startBeat),
            endSec = map.beatToSec(startBeat + durationBeats),
            source = EventSource.USER,
            validation = ValidationState.VALIDATED,
            confidence = 1.0,
        )

    private fun Transcription.replace(id: String, f: (MusicalEvent) -> MusicalEvent): Transcription =
        copy(events = events.map { if (it.id == id) f(it) else it }).normalized()

    fun setPitch(t: Transcription, id: String, midi: Int): Transcription =
        t.replace(id) { it.userEdited(t.tempoMap, pitch = midi.coerceIn(21, 108)) }

    fun shiftPitch(t: Transcription, id: String, semitones: Int): Transcription {
        val n = t.events.firstOrNull { it.id == id && it.isNote } ?: return t
        return setPitch(t, id, (n.midiPitch ?: return t) + semitones)
    }

    fun setDuration(t: Transcription, id: String, beats: Double): Transcription {
        val n = t.events.firstOrNull { it.id == id && it.isNote } ?: return t
        val next = t.notes.filter { it.startBeat > n.startBeat + Transcription.EPS }.minByOrNull { it.startBeat }
        var d = snap(beats).coerceAtLeast(GRID)
        if (next != null) d = d.coerceAtMost(next.startBeat - n.startBeat)
        return t.replace(id) { it.userEdited(t.tempoMap, durationBeats = d) }
    }

    fun moveNote(t: Transcription, id: String, newStartBeat: Double): Transcription {
        val n = t.events.firstOrNull { it.id == id && it.isNote } ?: return t
        return t.replace(id) { it.userEdited(t.tempoMap, startBeat = snap(newStartBeat).coerceAtLeast(0.0), durationBeats = n.durationBeats) }
    }

    fun addNote(t: Transcription, startBeat: Double, durationBeats: Double, midi: Int): Transcription {
        val start = snap(startBeat).coerceAtLeast(0.0)
        // Shorten the note sounding at the insertion point and clamp to the next note.
        val before = t.notes.filter { it.startBeat < start - Transcription.EPS && it.endBeat > start + Transcription.EPS }
        val atSame = t.notes.filter { kotlin.math.abs(it.startBeat - start) < Transcription.EPS }.map { it.id }.toSet()
        val next = t.notes.filter { it.startBeat > start + Transcription.EPS }.minByOrNull { it.startBeat }
        var d = snap(durationBeats).coerceAtLeast(GRID)
        if (next != null) d = d.coerceAtMost(next.startBeat - start).coerceAtLeast(GRID)
        val note = MusicalEvent(
            id = Ids.newId("n"), type = EventType.NOTE, midiPitch = midi.coerceIn(21, 108),
            frequencyHz = Pitch.midiToHz(midi.coerceIn(21, 108)),
            startSec = t.tempoMap.beatToSec(start), endSec = t.tempoMap.beatToSec(start + d),
            startBeat = start, durationBeats = d, confidence = 1.0,
            source = EventSource.USER, validation = ValidationState.VALIDATED,
        )
        val rebuilt = t.events.filter { it.isNote && it.id !in atSame }.map { e ->
            if (before.any { it.id == e.id }) e.userEdited(t.tempoMap, durationBeats = start - e.startBeat) else e
        } + note
        return t.copy(events = rebuilt).normalized()
    }

    fun deleteNote(t: Transcription, id: String): Transcription =
        t.copy(events = t.events.filter { it.id != id }).normalized()

    /** Splits a note in two halves (at [atBeat] if given, otherwise in the middle on the grid). */
    fun splitNote(t: Transcription, id: String, atBeat: Double? = null): Transcription {
        val n = t.events.firstOrNull { it.id == id && it.isNote } ?: return t
        if (n.durationBeats < 2 * GRID - Transcription.EPS) return t
        val at = snap(atBeat ?: (n.startBeat + n.durationBeats / 2)).coerceIn(n.startBeat + GRID, n.endBeat - GRID)
        val first = n.userEdited(t.tempoMap, durationBeats = at - n.startBeat)
        val second = n.userEdited(t.tempoMap, startBeat = at, durationBeats = n.endBeat - at).copy(id = Ids.newId("n"))
        return t.copy(events = t.events.filter { it.id != id } + first + second).normalized()
    }

    /** Merges a note with the note that directly follows it (same or different pitch: the first pitch is kept). */
    fun mergeWithNext(t: Transcription, id: String): Transcription {
        val ns = t.notes.sortedBy { it.startBeat }
        val i = ns.indexOfFirst { it.id == id }
        if (i < 0 || i >= ns.size - 1) return t
        val a = ns[i]
        val b = ns[i + 1]
        val merged = a.userEdited(t.tempoMap, durationBeats = b.endBeat - a.startBeat)
        return t.copy(
            events = t.events.filter { it.id != a.id && it.id != b.id && it.isNote } + merged,
            lyrics = t.lyrics.map { if (it.noteId == b.id) it.copy(noteId = null) else it },
        ).normalized()
    }

    /** Changes the length of a rest; later events are shifted accordingly (ripple edit). */
    fun setRestLength(t: Transcription, restId: String, beats: Double): Transcription {
        val r = t.events.firstOrNull { it.id == restId && it.isRest } ?: return t
        val newLen = snap(beats).coerceAtLeast(0.0)
        val delta = newLen - r.durationBeats
        if (kotlin.math.abs(delta) < Transcription.EPS) return t
        val shifted = t.notes.map { n ->
            if (n.startBeat >= r.endBeat - Transcription.EPS) n.userEdited(t.tempoMap, startBeat = (n.startBeat + delta).coerceAtLeast(0.0)) else n
        }
        return t.copy(events = shifted).normalized()
    }

    fun setLyric(t: Transcription, noteId: String, text: String, syllabic: Syllabic = Syllabic.SINGLE): Transcription {
        val others = t.lyrics.filter { it.noteId != noteId }
        if (text.isBlank()) return t.copy(lyrics = others)
        val note = t.events.firstOrNull { it.id == noteId } ?: return t
        return t.copy(lyrics = others + LyricSegment(Ids.newId("l"), text.trim(), syllabic, note.startSec, noteId))
    }

    fun moveLyric(t: Transcription, lyricId: String, toNoteId: String): Transcription {
        val note = t.events.firstOrNull { it.id == toNoteId && it.isNote } ?: return t
        val lyric = t.lyrics.firstOrNull { it.id == lyricId } ?: return t
        val rest = t.lyrics.filter { it.id != lyricId && it.noteId != toNoteId }
        return t.copy(lyrics = rest + lyric.copy(noteId = toNoteId, startSec = note.startSec))
    }

    fun validate(t: Transcription, id: String): Transcription =
        t.replace(id) { it.copy(validation = ValidationState.VALIDATED) }

    fun setKey(t: Transcription, key: KeySignature): Transcription = t.copy(key = key)

    fun setTimeSignature(t: Transcription, ts: TimeSignature): Transcription = t.copy(timeSignature = ts)

    /**
     * Sets a constant tempo. Detected notes keep their recorded time and are re-positioned on the new beat grid,
     * edited notes keep their beat positions and receive new real times.
     */
    fun setTempo(t: Transcription, bpm: Double): Transcription {
        val newMap = TempoMap.constant(bpm.coerceIn(20.0, 300.0), t.tempoMap.originSec)
        return rebuild(t.copy(tempoMap = newMap))
    }

    fun setQuantization(t: Transcription, mode: QuantizationMode): Transcription = rebuild(t.copy(quantization = mode))

    /** Re-derives the beat position of detected notes from their real time, and the real time of edited notes. */
    private fun rebuild(t: Transcription): Transcription {
        val fixed = t.events.filter { it.isNote }.map { e ->
            when (e.source) {
                EventSource.DETECTED -> requantize(e, t.tempoMap, t.quantization)
                else -> e.copy(startSec = t.tempoMap.beatToSec(e.startBeat), endSec = t.tempoMap.beatToSec(e.endBeat))
            }
        }
        return t.copy(events = fixed).normalized()
    }

    fun requantize(e: MusicalEvent, map: TempoMap, mode: QuantizationMode): MusicalEvent {
        val rawStart = map.secToBeat(e.startSec)
        val rawEnd = map.secToBeat(e.endSec)
        val (s, d) = when (mode) {
            QuantizationMode.FREE -> rawStart to (rawEnd - rawStart).coerceAtLeast(0.05)
            QuantizationMode.AUTOMATIC -> {
                val s = snap(rawStart)
                s to (snap(rawEnd) - s).coerceAtLeast(GRID)
            }
            QuantizationMode.SOFT -> {
                val s = snap(rawStart)
                val en = snap(rawEnd).coerceAtLeast(s + GRID)
                val ss = (rawStart + s) / 2
                ss to ((rawEnd + en) / 2 - ss).coerceAtLeast(GRID)
            }
        }
        return e.copy(startBeat = s.coerceAtLeast(0.0), durationBeats = d)
    }
}

/** Undo/redo history and autosave hook around a [Transcription] (spec 7.5). */
class EditSession(initial: Transcription, private val maxHistory: Int = 200) {
    private data class Entry(val label: String, val state: Transcription)

    private val undoStack = ArrayDeque<Entry>()
    private val redoStack = ArrayDeque<Entry>()

    var current: Transcription = initial
        private set

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** Labels of the history, oldest first. */
    val history: List<String> get() = undoStack.map { it.label }

    fun apply(label: String, op: (Transcription) -> Transcription): Transcription {
        val next = op(current)
        if (next === current || next == current) return current
        undoStack.addLast(Entry(label, current))
        while (undoStack.size > maxHistory) undoStack.removeFirst()
        redoStack.clear()
        current = next
        return current
    }

    fun undo(): Transcription {
        val e = undoStack.removeLastOrNull() ?: return current
        redoStack.addLast(Entry(e.label, current))
        current = e.state
        return current
    }

    fun redo(): Transcription {
        val e = redoStack.removeLastOrNull() ?: return current
        undoStack.addLast(Entry(e.label, current))
        current = e.state
        return current
    }

    /** Replaces the state without recording history (e.g. after a re-analysis the caller has confirmed). */
    fun reset(state: Transcription) {
        undoStack.clear()
        redoStack.clear()
        current = state
    }
}
