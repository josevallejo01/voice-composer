package com.voicecomposer.model

import kotlin.math.roundToInt

/** Rhythmic grid used for notation: 4 ticks per quarter note, i.e. the smallest written value is a sixteenth. */
const val TICKS_PER_QUARTER = 4

enum class NoteType(val ticks: Int, val xmlName: String) {
    WHOLE(16, "whole"), HALF(8, "half"), QUARTER(4, "quarter"), EIGHTH(2, "eighth"), SIXTEENTH(1, "16th")
}

sealed class NotationItem {
    abstract val startTick: Int
    abstract val ticks: Int
    abstract val type: NoteType
    abstract val dots: Int
}

data class NotationNote(
    val eventId: String,
    val midi: Int,
    val spelling: Spelling,
    override val startTick: Int,
    override val ticks: Int,
    override val type: NoteType,
    override val dots: Int,
    val tieToNext: Boolean,
    val tieFromPrevious: Boolean,
    val uncertain: Boolean,
    val lyric: LyricSegment?,
) : NotationItem()

data class NotationRest(
    override val startTick: Int,
    override val ticks: Int,
    override val type: NoteType,
    override val dots: Int,
) : NotationItem()

data class Measure(val index: Int, val lengthTicks: Int, val items: List<NotationItem>)

enum class Clef { TREBLE, BASS }

data class Notation(
    val measures: List<Measure>,
    val timeSignature: TimeSignature,
    val key: KeySignature,
    val clef: Clef,
    val bpm: Double,
    val tempoChanges: List<Pair<Double, Double>>,
) {
    val measureTicks: Int get() = measures.firstOrNull()?.lengthTicks ?: 16
}

/**
 * Converts the musical model to a readable notation: quantized to sixteenths, split at barlines with ties,
 * decomposed into standard note values and dotted values. The real time of events is never touched.
 */
object NotationBuilder {
    data class Value(val ticks: Int, val type: NoteType, val dots: Int, val align: Int)

    private val VALUES = listOf(
        Value(16, NoteType.WHOLE, 0, 16),
        Value(12, NoteType.HALF, 1, 8),
        Value(8, NoteType.HALF, 0, 8),
        Value(6, NoteType.QUARTER, 1, 4),
        Value(4, NoteType.QUARTER, 0, 4),
        Value(3, NoteType.EIGHTH, 1, 2),
        Value(2, NoteType.EIGHTH, 0, 2),
        Value(1, NoteType.SIXTEENTH, 0, 1),
    )

    /** Splits [length] ticks starting at [pos] (inside a measure) into written values. */
    fun decompose(pos: Int, length: Int): List<Pair<Int, Value>> {
        val out = ArrayList<Pair<Int, Value>>()
        var p = pos
        var remaining = length
        while (remaining > 0) {
            val v = VALUES.first { it.ticks <= remaining && p % it.align == 0 }
            out.add(p to v)
            p += v.ticks
            remaining -= v.ticks
        }
        return out
    }

    fun measureTicks(ts: TimeSignature): Int = (ts.beatsPerMeasure * TICKS_PER_QUARTER).roundToInt()

    fun build(t: Transcription): Notation {
        val mTicks = measureTicks(t.timeSignature)
        val fifths = t.key.fifths
        val notes = t.notes.sortedBy { it.startBeat }

        // Snap to the notation grid and keep monotonic, non overlapping tick ranges.
        data class Placed(val e: MusicalEvent, val start: Int, val end: Int)
        val placed = ArrayList<Placed>()
        var cursor = 0
        for ((i, n) in notes.withIndex()) {
            var s = (n.startBeat * TICKS_PER_QUARTER).roundToInt().coerceAtLeast(cursor)
            var e = ((n.startBeat + n.durationBeats) * TICKS_PER_QUARTER).roundToInt().coerceAtLeast(s + 1)
            val nextStart = notes.getOrNull(i + 1)?.let { (it.startBeat * TICKS_PER_QUARTER).roundToInt() }
            if (nextStart != null && e > nextStart && nextStart > s) e = nextStart
            if (e <= s) e = s + 1
            placed.add(Placed(n, s, e))
            cursor = e
            s = e
        }

        val totalTicks = maxOf(placed.lastOrNull()?.end ?: 0, mTicks)
        val measureCount = (totalTicks + mTicks - 1) / mTicks
        val items = Array(measureCount) { ArrayList<NotationItem>() }

        fun addRest(absStart: Int, absEnd: Int) {
            var s = absStart
            while (s < absEnd) {
                val m = s / mTicks
                val localStart = s - m * mTicks
                val len = minOf(absEnd - s, mTicks - localStart)
                for ((p, v) in decompose(localStart, len)) {
                    items[m].add(NotationRest(p, v.ticks, v.type, v.dots))
                }
                s += len
            }
        }

        var pos = 0
        for (pl in placed) {
            if (pl.start > pos) addRest(pos, pl.start)
            var s = pl.start
            val uncertain = pl.e.validation == ValidationState.UNCERTAIN
            val midi = pl.e.midiPitch ?: continue
            val spelling = Pitch.spell(midi, fifths)
            var first = true
            val lyric = t.lyricFor(pl.e.id)
            while (s < pl.end) {
                val m = s / mTicks
                val localStart = s - m * mTicks
                val len = minOf(pl.end - s, mTicks - localStart)
                val chunks = decompose(localStart, len)
                for ((ci, c) in chunks.withIndex()) {
                    val (p, v) = c
                    val lastChunkOfMeasure = ci == chunks.size - 1
                    val endsNote = s + len >= pl.end && lastChunkOfMeasure
                    items[m].add(
                        NotationNote(
                            eventId = pl.e.id, midi = midi, spelling = spelling,
                            startTick = p, ticks = v.ticks, type = v.type, dots = v.dots,
                            tieToNext = !endsNote,
                            tieFromPrevious = !(first && ci == 0),
                            uncertain = uncertain,
                            lyric = if (first && ci == 0) lyric else null,
                        )
                    )
                }
                first = false
                s += len
            }
            pos = pl.end
        }
        val paddedEnd = measureCount * mTicks
        if (pos < paddedEnd) addRest(pos, paddedEnd)

        val measures = items.mapIndexed { i, list -> Measure(i, mTicks, list.sortedBy { it.startTick }) }
        val medianMidi = notes.mapNotNull { it.midiPitch }.sorted().let { if (it.isEmpty()) 69 else it[it.size / 2] }
        return Notation(
            measures = measures,
            timeSignature = t.timeSignature,
            key = t.key,
            clef = if (medianMidi < 53) Clef.BASS else Clef.TREBLE,
            bpm = t.tempoMap.averageBpm,
            tempoChanges = t.tempoMap.changes,
        )
    }
}
