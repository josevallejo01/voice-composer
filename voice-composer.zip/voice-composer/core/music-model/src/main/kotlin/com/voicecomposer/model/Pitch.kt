package com.voicecomposer.model

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow

/** Pitch helpers. MIDI note 69 = A4 = 440 Hz. */
object Pitch {
    fun midiToHz(midi: Double): Double = 440.0 * 2.0.pow((midi - 69.0) / 12.0)
    fun midiToHz(midi: Int): Double = midiToHz(midi.toDouble())
    fun hzToMidi(hz: Double): Double = 69.0 + 12.0 * ln(hz / 440.0) / ln(2.0)

    private val SHARP_NAMES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val FLAT_NAMES = arrayOf("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")

    fun pitchClass(midi: Int): Int = ((midi % 12) + 12) % 12

    fun name(midi: Int, preferFlats: Boolean = false): String {
        val n = if (preferFlats) FLAT_NAMES else SHARP_NAMES
        return n[pitchClass(midi)] + (Math.floorDiv(midi, 12) - 1)
    }

    /** Spells a MIDI pitch for a key signature given as a count of sharps (+) or flats (-). */
    fun spell(midi: Int, fifths: Int): Spelling {
        val pc = pitchClass(midi)
        val octave = Math.floorDiv(midi, 12) - 1
        val flats = fifths < 0
        val names = if (flats) FLAT_NAMES else SHARP_NAMES
        val s = names[pc]
        val step = s[0]
        val alter = when {
            s.length == 1 -> 0
            s[1] == '#' -> 1
            else -> -1
        }
        return Spelling(step, alter, octave)
    }
}

/** A spelled pitch: step A..G, chromatic alteration (-1, 0, +1) and scientific octave (C4 = middle C). */
data class Spelling(val step: Char, val alter: Int, val octave: Int) {
    /** Diatonic index on the staff: C0 = 0, D0 = 1, ... */
    val diatonicIndex: Int get() = octave * 7 + STEP_INDEX.getValue(step)

    fun toMidi(): Int = 12 * (octave + 1) + STEP_SEMITONE.getValue(step) + alter

    companion object {
        val STEP_INDEX: Map<Char, Int> = mapOf('C' to 0, 'D' to 1, 'E' to 2, 'F' to 3, 'G' to 4, 'A' to 5, 'B' to 6)
        val STEP_SEMITONE: Map<Char, Int> = mapOf('C' to 0, 'D' to 2, 'E' to 4, 'F' to 5, 'G' to 7, 'A' to 9, 'B' to 11)
        val INDEX_STEP = charArrayOf('C', 'D', 'E', 'F', 'G', 'A', 'B')

        /** Spelling for a diatonic index, with the alteration implied by [fifths] for that step. */
        fun fromDiatonicIndex(index: Int, fifths: Int): Spelling {
            val octave = Math.floorDiv(index, 7)
            val step = INDEX_STEP[Math.floorMod(index, 7)]
            return Spelling(step, KeySignature.alterForStep(step, fifths), octave)
        }
    }
}

enum class Mode { MAJOR, MINOR }

/** Tonic pitch class (0 = C) and mode; [confidence] is 0..1 and only meaningful for estimated keys. */
data class KeySignature(val tonic: Int, val mode: Mode, val confidence: Double = 1.0) {
    /** Number of sharps (positive) or flats (negative) in the key signature. */
    val fifths: Int
        get() {
            val majorTonic = if (mode == Mode.MAJOR) tonic else Pitch.pitchClass(tonic + 3)
            return MAJOR_FIFTHS[majorTonic]
        }

    val name: String
        get() {
            val names = if (fifths < 0) FLAT_TONICS else SHARP_TONICS
            return names[tonic] + if (mode == Mode.MAJOR) " major" else " minor"
        }

    /** Pitch classes of the diatonic scale (natural minor for minor keys). */
    val scalePitchClasses: Set<Int>
        get() {
            val steps = if (mode == Mode.MAJOR) MAJOR_STEPS else MINOR_STEPS
            return steps.map { Pitch.pitchClass(tonic + it) }.toSet()
        }

    companion object {
        private val MAJOR_FIFTHS = intArrayOf(0, -5, 2, -3, 4, -1, 6, 1, -4, 3, -2, 5)
        private val SHARP_TONICS = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
        private val FLAT_TONICS = arrayOf("C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B")
        val MAJOR_STEPS = intArrayOf(0, 2, 4, 5, 7, 9, 11)
        val MINOR_STEPS = intArrayOf(0, 2, 3, 5, 7, 8, 10)
        private val SHARP_ORDER = charArrayOf('F', 'C', 'G', 'D', 'A', 'E', 'B')
        private val FLAT_ORDER = charArrayOf('B', 'E', 'A', 'D', 'G', 'C', 'F')

        /** Alteration (-1, 0, +1) the key signature applies to the given note letter. */
        fun alterForStep(step: Char, fifths: Int): Int {
            if (fifths > 0) {
                val idx = SHARP_ORDER.indexOf(step)
                if (idx in 0 until fifths) return 1
            } else if (fifths < 0) {
                val idx = FLAT_ORDER.indexOf(step)
                if (idx in 0 until -fifths) return -1
            }
            return 0
        }

        /** Letters carrying an accidental in the signature, in engraving order. */
        fun signatureSteps(fifths: Int): List<Char> =
            if (fifths >= 0) SHARP_ORDER.take(fifths) else FLAT_ORDER.take(-fifths)
    }
}

/** Simple meters only (2/4, 3/4, 4/4, 6/8). Measure length is expressed in quarter-note beats. */
data class TimeSignature(val numerator: Int, val denominator: Int) {
    val beatsPerMeasure: Double get() = numerator * 4.0 / denominator
    override fun toString(): String = "$numerator/$denominator"

    companion object {
        val FOUR_FOUR = TimeSignature(4, 4)
        val THREE_FOUR = TimeSignature(3, 4)
        val TWO_FOUR = TimeSignature(2, 4)
        val SIX_EIGHT = TimeSignature(6, 8)
    }
}

object Ids {
    fun newId(prefix: String = "e"): String =
        prefix + java.util.UUID.randomUUID().toString().replace("-", "").take(10)
}

fun Double.approxEquals(other: Double, eps: Double = 1e-9): Boolean = abs(this - other) <= eps
