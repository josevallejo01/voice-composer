package com.voicecomposer.model

enum class EventType { NOTE, REST, SPECIAL }

/** Provenance of an event (spec 6.3). It survives edits and exports. */
enum class EventSource { DETECTED, USER, ARRANGEMENT, IMPORTED }

enum class ValidationState { AUTO, UNCERTAIN, VALIDATED }

enum class QuantizationMode { AUTOMATIC, SOFT, FREE }

enum class Syllabic { SINGLE, BEGIN, MIDDLE, END }

/**
 * A musical event with its two time representations (spec 6.2):
 * real time on the audio timeline ([startSec], [endSec]) and musical position in quarter-note beats
 * ([startBeat], [durationBeats]).
 */
data class MusicalEvent(
    val id: String,
    val type: EventType,
    val midiPitch: Int?,
    val frequencyHz: Double?,
    val startSec: Double,
    val endSec: Double,
    val startBeat: Double,
    val durationBeats: Double,
    val confidence: Double,
    val source: EventSource,
    val validation: ValidationState = ValidationState.AUTO,
) {
    val durationSec: Double get() = endSec - startSec
    val endBeat: Double get() = startBeat + durationBeats
    val isNote: Boolean get() = type == EventType.NOTE
    val isRest: Boolean get() = type == EventType.REST
}

/** A syllable attached to a note. Lyrics live next to the melody, never inside it (spec 2.1.A). */
data class LyricSegment(
    val id: String,
    val text: String,
    val syllabic: Syllabic = Syllabic.SINGLE,
    val startSec: Double = 0.0,
    val noteId: String?,
    val confidence: Double = 1.0,
)

/**
 * Instruments a track can be played by. [gmProgram] is the General MIDI program used for MIDI export; the sound engine
 * has its own table of patches (layers, vibrato, reverb) for each of them.
 */
enum class Instrument(val label: String, val gmProgram: Int, val family: Family = Family.OTHER) {
    LEAD("Lead", 80, Family.SYNTH),
    PIANO("Piano", 0, Family.KEYS),
    ACOUSTIC_GUITAR("Acoustic guitar", 25, Family.PLUCKED),
    ELECTRIC_BASS("Bass", 33, Family.BASS),
    STRINGS("Strings", 48, Family.STRINGS),
    PAD("Pad", 89, Family.SYNTH),
    FLUTE("Flute", 73, Family.WOODWIND),
    VIOLIN("Violin", 40, Family.STRINGS),
    VIOLA("Viola", 41, Family.STRINGS),
    CELLO("Cello", 42, Family.STRINGS),
    DOUBLE_BASS("Double bass", 43, Family.BASS),
    HARP("Harp", 46, Family.PLUCKED),
    NYLON_GUITAR("Nylon guitar", 24, Family.PLUCKED),
    UPRIGHT_BASS("Upright bass", 32, Family.BASS),
    OBOE("Oboe", 68, Family.WOODWIND),
    CLARINET("Clarinet", 71, Family.WOODWIND),
    FRENCH_HORN("French horn", 60, Family.BRASS),
    TRUMPET("Trumpet", 56, Family.BRASS),
    CHOIR("Choir", 52, Family.VOICE),
    ;

    enum class Family { KEYS, PLUCKED, STRINGS, WOODWIND, BRASS, VOICE, BASS, SYNTH, OTHER }

    companion object {
        /** Reads a stored name; an unknown one (a file from a newer version) falls back to the piano instead of failing. */
        fun parse(name: String): Instrument = entries.firstOrNull { it.name == name } ?: PIANO

        /** The instruments offered for a melody, most natural first. */
        val melodyChoices: List<Instrument> = listOf(VIOLIN, FLUTE, OBOE, CLARINET, CELLO, TRUMPET, FRENCH_HORN, PIANO, NYLON_GUITAR, ACOUSTIC_GUITAR, CHOIR, VIOLA, HARP, LEAD)
    }
}

enum class TrackRole { MELODY, HARMONY, BASS, RHYTHM, OTHER }

data class Track(
    val id: String,
    val name: String,
    val instrument: Instrument,
    val role: TrackRole,
    val events: List<MusicalEvent>,
    val volume: Float = 0.8f,
    val pan: Float = 0f,
    val enabled: Boolean = true,
)

enum class ArrangementStyle(val label: String) {
    POP("Pop"),
    FOLK("Folk"),
    CLASSICAL("Classical"),
    ORCHESTRAL("Orchestral"),
}

data class Arrangement(
    val id: String,
    val sourceVersion: Int,
    val style: ArrangementStyle,
    val complexity: Int,
    val chords: List<ChordSegment>,
    val tracks: List<Track>,
)

/** One chord of the generated progression, positioned in beats. */
data class ChordSegment(val startBeat: Double, val durationBeats: Double, val rootPitchClass: Int, val minor: Boolean, val diminished: Boolean = false) {
    val symbol: String
        get() {
            val names = arrayOf("C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
            return names[rootPitchClass] + if (diminished) "dim" else if (minor) "m" else ""
        }
}
