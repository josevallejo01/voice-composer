package com.voicecomposer.model

enum class EventType { NOTE, REST, SPECIAL }

/** Provenance of an event (spec 6.3). It survives edits and exports. */
enum class EventSource { DETECTED, USER, ARRANGEMENT, IMPORTED }

enum class ValidationState { AUTO, UNCERTAIN, VALIDATED }

enum class QuantizationMode { AUTOMATIC, SOFT, FREE }

enum class Syllabic { SINGLE, BEGIN, MIDDLE, END }

/**
 * A musical event with its two time representations (spec 6.2):
 * real time on the audio timeline ([startSec], [endSec]) and musical position in quarter-note beats
 * ([startBeat], [durationBeats]).
 */
data class MusicalEvent(
    val id: String,
    val type: EventType,
    val midiPitch: Int?,
    val frequencyHz: Double?,
    val startSec: Double,
    val endSec: Double,
    val startBeat: Double,
    val durationBeats: Double,
    val confidence: Double,
    val source: EventSource,
    val validation: ValidationState = ValidationState.AUTO,
) {
    val durationSec: Double get() = endSec - startSec
    val endBeat: Double get() = startBeat + durationBeats
    val isNote: Boolean get() = type == EventType.NOTE
    val isRest: Boolean get() = type == EventType.REST
}

/** A syllable attached to a note. Lyrics live next to the melody, never inside it (spec 2.1.A). */
data class LyricSegment(
    val id: String,
    val text: String,
    val syllabic: Syllabic = Syllabic.SINGLE,
    val startSec: Double = 0.0,
    val noteId: String?,
    val confidence: Double = 1.0,
)

enum class Instrument(val label: String, val gmProgram: Int) {
    LEAD("Lead", 80),
    PIANO("Piano", 0),
    ACOUSTIC_GUITAR("Acoustic guitar", 25),
    ELECTRIC_BASS("Bass", 33),
    STRINGS("Strings", 48),
    PAD("Pad", 89),
    FLUTE("Flute", 73),
}

enum class TrackRole { MELODY, HARMONY, BASS, RHYTHM, OTHER }

data class Track(
    val id: String,
    val name: String,
    val instrument: Instrument,
    val role: TrackRole,
    val events: List<MusicalEvent>,
    val volume: Float = 0.8f,
    val pan: Float = 0f,
    val enabled: Boolean = true,
)

enum class ArrangementStyle(val label: String) {
    POP("Pop"),
    FOLK("Folk"),
    CLASSICAL("Classical"),
}

data class Arrangement(
    val id: String,
    val sourceVersion: Int,
    val style: ArrangementStyle,
    val complexity: Int,
    val chords: List<ChordSegment>,
    val tracks: List<Track>,
)

/** One chord of the generated progression, positioned in beats. */
data class ChordSegment(val startBeat: Double, val durationBeats: Double, val rootPitchClass: Int, val minor: Boolean, val diminished: Boolean = false) {
    val symbol: String
        get() {
            val names = arrayOf("C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
            return names[rootPitchClass] + if (diminished) "dim" else if (minor) "m" else ""
        }
}
