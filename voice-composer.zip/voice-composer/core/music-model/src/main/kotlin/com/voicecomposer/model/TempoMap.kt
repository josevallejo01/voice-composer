package com.voicecomposer.model

/**
 * A point of the tempo map: the position [beat] (quarter notes) occurs at [timeSec] on the audio timeline.
 * Between two points the map is linear, after the last point the tempo is [TempoMap.tailBpm].
 *
 * The map is exact at its anchors, so notation positions never drift from the recording
 * even when the performer speeds up or slows down.
 */
data class TempoPoint(val beat: Double, val timeSec: Double)

class TempoMap(points: List<TempoPoint>, val tailBpm: Double) {
    val points: List<TempoPoint> = points.sortedBy { it.beat }

    init {
        require(this.points.isNotEmpty()) { "A tempo map needs at least one point" }
        require(tailBpm > 0.0) { "BPM must be positive" }
        for (i in 1 until this.points.size) {
            require(this.points[i].timeSec > this.points[i - 1].timeSec) { "Tempo map must be strictly increasing in time" }
            require(this.points[i].beat > this.points[i - 1].beat) { "Tempo map must be strictly increasing in beats" }
        }
    }

    override fun equals(other: Any?): Boolean = other is TempoMap && other.points == points && other.tailBpm == tailBpm
    override fun hashCode(): Int = 31 * points.hashCode() + tailBpm.hashCode()
    override fun toString(): String = "TempoMap(points=$points, tailBpm=$tailBpm)"

    val originSec: Double get() = points.first().timeSec
    val isConstant: Boolean get() = points.size == 1

    private fun segmentBpm(i: Int): Double =
        if (i >= points.size - 1) tailBpm
        else 60.0 * (points[i + 1].beat - points[i].beat) / (points[i + 1].timeSec - points[i].timeSec)

    fun beatToSec(beat: Double): Double {
        var i = points.indexOfLast { it.beat <= beat }
        if (i < 0) i = 0
        val bpm = segmentBpm(i)
        return points[i].timeSec + (beat - points[i].beat) * 60.0 / bpm
    }

    fun secToBeat(sec: Double): Double {
        var i = points.indexOfLast { it.timeSec <= sec }
        if (i < 0) i = 0
        val bpm = segmentBpm(i)
        return points[i].beat + (sec - points[i].timeSec) * bpm / 60.0
    }

    fun bpmAtBeat(beat: Double): Double {
        var i = points.indexOfLast { it.beat <= beat }
        if (i < 0) i = 0
        return segmentBpm(i)
    }

    fun bpmAtSec(sec: Double): Double {
        var i = points.indexOfLast { it.timeSec <= sec }
        if (i < 0) i = 0
        return segmentBpm(i)
    }

    /** Tempo changes as (beat, bpm); the first entry is always at the first point. */
    val changes: List<Pair<Double, Double>>
        get() {
            val out = ArrayList<Pair<Double, Double>>()
            for (i in points.indices) {
                val bpm = segmentBpm(i)
                if (out.isEmpty() || kotlin.math.abs(out.last().second - bpm) > 0.01) out.add(points[i].beat to bpm)
            }
            return out
        }

    /** Representative tempo shown to the user: duration-weighted mean over the mapped part. */
    val averageBpm: Double
        get() {
            if (points.size == 1) return tailBpm
            val db = points.last().beat - points.first().beat
            val ds = points.last().timeSec - points.first().timeSec
            return 60.0 * db / ds
        }

    companion object {
        fun constant(bpm: Double, originSec: Double = 0.0): TempoMap =
            TempoMap(listOf(TempoPoint(0.0, originSec)), bpm)
    }
}
