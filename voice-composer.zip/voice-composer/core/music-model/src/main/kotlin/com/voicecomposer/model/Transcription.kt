package com.voicecomposer.model

/** Quality indicators of an analysis run (spec 5.11: uncertainty is always reported, never hidden). */
data class AnalysisInfo(
    val engineVersion: String,
    val tempoConfidence: Double,
    val meterConfidence: Double,
    val keyConfidence: Double,
    val overallConfidence: Double,
    val warnings: List<String> = emptyList(),
)

/**
 * "Result A" of the spec: the faithful transcription of what the user performed.
 * It is the reference version; arrangements are stored separately and never modify it.
 *
 * Invariants maintained by [normalized]: events sorted by start, notes never overlap in beats,
 * rests fill every gap between notes.
 */
data class Transcription(
    val events: List<MusicalEvent>,
    val tempoMap: TempoMap,
    val timeSignature: TimeSignature,
    val key: KeySignature,
    val quantization: QuantizationMode = QuantizationMode.AUTOMATIC,
    val lyrics: List<LyricSegment> = emptyList(),
    val analysis: AnalysisInfo? = null,
) {
    val notes: List<MusicalEvent> get() = events.filter { it.isNote }
    val uncertainNotes: List<MusicalEvent> get() = notes.filter { it.validation == ValidationState.UNCERTAIN }
    val totalBeats: Double get() = events.maxOfOrNull { it.endBeat } ?: 0.0
    fun lyricFor(noteId: String): LyricSegment? = lyrics.firstOrNull { it.noteId == noteId }

    /** Sorts notes, removes overlaps, regenerates rests from gaps and drops lyrics of deleted notes. */
    fun normalized(): Transcription {
        val ns = events.filter { it.isNote }.sortedBy { it.startBeat }.toMutableList()
        for (i in 0 until ns.size - 1) {
            val a = ns[i]
            val b = ns[i + 1]
            if (a.endBeat > b.startBeat + EPS) {
                val newDur = (b.startBeat - a.startBeat).coerceAtLeast(MIN_BEATS)
                ns[i] = a.copy(
                    durationBeats = newDur,
                    endSec = tempoMap.beatToSec(a.startBeat + newDur).coerceAtLeast(a.startSec + 0.001),
                )
            }
        }
        val out = ArrayList<MusicalEvent>(ns.size * 2)
        var cursor = 0.0
        for (n in ns) {
            if (n.startBeat - cursor >= MIN_BEATS - EPS) out.add(rest(cursor, n.startBeat))
            out.add(n)
            cursor = maxOf(cursor, n.endBeat)
        }
        val ids = ns.map { it.id }.toSet()
        return copy(events = out, lyrics = lyrics.filter { it.noteId == null || it.noteId in ids })
    }

    private fun rest(fromBeat: Double, toBeat: Double) = MusicalEvent(
        id = "r" + Math.round(fromBeat * 1000),
        type = EventType.REST,
        midiPitch = null,
        frequencyHz = null,
        startSec = tempoMap.beatToSec(fromBeat),
        endSec = tempoMap.beatToSec(toBeat),
        startBeat = fromBeat,
        durationBeats = toBeat - fromBeat,
        confidence = 1.0,
        source = EventSource.DETECTED,
    )

    companion object {
        const val MIN_BEATS = 0.25
        const val EPS = 1e-6
    }
}
