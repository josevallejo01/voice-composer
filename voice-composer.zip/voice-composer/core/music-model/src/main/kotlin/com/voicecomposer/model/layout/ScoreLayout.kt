package com.voicecomposer.model.layout

import com.voicecomposer.model.Clef
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Measure
import com.voicecomposer.model.Notation
import com.voicecomposer.model.NotationItem
import com.voicecomposer.model.NotationNote
import com.voicecomposer.model.NotationRest
import kotlin.math.abs
import kotlin.math.ln

/**
 * Renderer independent engraving layout: where every measure, note, rest and accidental goes. The Compose screen and
 * the PDF export both paint the same layout, and touch coordinates are converted back to musical positions with it,
 * so notes are never stored as screen coordinates (spec 6 / 7.4).
 *
 * Units are pixels (or points for PDF); [staffSpace] is the distance between two staff lines.
 */
data class ItemLayout(
    val item: NotationItem,
    val x: Float,
    val width: Float,
    /** Vertical centre of the note head (null for rests). */
    val y: Float?,
    val staffPos: Int?,
    /** -1 flat, 0 natural, +1 sharp, null = no accidental drawn. */
    val accidental: Int?,
    val stemUp: Boolean,
    /** For tied notes: x where the tie ends (next note, or the end of the system). */
    val tieEndX: Float?,
)

data class MeasureLayout(val index: Int, val x: Float, val width: Float, val items: List<ItemLayout>)

data class SystemLayout(
    val index: Int,
    /** y of the top staff line. */
    val top: Float,
    val regionTop: Float,
    val regionBottom: Float,
    val prefixWidth: Float,
    val showTimeSignature: Boolean,
    val measures: List<MeasureLayout>,
    val isLast: Boolean,
)

data class NoteBox(val eventId: String, val system: Int, val measure: Int, val x: Float, val y: Float, val staffPos: Int)

data class AddPosition(val measure: Int, val tickInMeasure: Int, val staffPos: Int, val system: Int)

class ScoreLayout(
    val systems: List<SystemLayout>,
    val width: Float,
    val height: Float,
    val staffSpace: Float,
    val clef: Clef,
    val key: KeySignature,
    val measureTicks: Int,
) {
    val bottomLinePos: Int get() = if (clef == Clef.TREBLE) 30 else 18
    val noteBoxes: List<NoteBox> by lazy {
        val out = ArrayList<NoteBox>()
        for (s in systems) for (m in s.measures) for (it in m.items) {
            val n = it.item as? NotationNote ?: continue
            if (n.tieFromPrevious) continue
            out.add(NoteBox(n.eventId, s.index, m.index, it.x, it.y!!, it.staffPos!!))
        }
        out
    }

    fun staffBottom(system: SystemLayout) = system.top + 4 * staffSpace

    fun yForPos(system: SystemLayout, staffPos: Int): Float = staffBottom(system) - (staffPos - bottomLinePos) * staffSpace / 2f

    fun posForY(system: SystemLayout, y: Float): Int = bottomLinePos + Math.round((staffBottom(system) - y) / (staffSpace / 2f))

    fun systemAt(y: Float): SystemLayout? = systems.firstOrNull { y >= it.regionTop && y < it.regionBottom } ?: systems.lastOrNull()?.takeIf { y >= it.regionTop }

    /** Nearest note head to a touch point, within [slop] pixels. */
    fun hitNote(x: Float, y: Float, slop: Float = staffSpace * 1.6f): NoteBox? =
        noteBoxes.filter { abs(it.x - x) < slop && abs(it.y - y) < slop }.minByOrNull { abs(it.x - x) + abs(it.y - y) }

    /** Converts a touch on empty staff space into a musical position (drawing mode). */
    fun positionAt(x: Float, y: Float): AddPosition? {
        val sys = systemAt(y) ?: return null
        val measure = sys.measures.firstOrNull { x >= it.x && x < it.x + it.width } ?: sys.measures.lastOrNull() ?: return null
        val candidates = measure.items
        if (candidates.isEmpty()) return null
        // Nearest item boundary: the tapped note starts where the closest item starts.
        val nearest = candidates.minByOrNull { abs(it.x - x) } ?: return null
        var tick = nearest.item.startTick
        val last = candidates.last()
        if (x > last.x + last.width * 0.6f) tick = last.item.startTick + last.item.ticks
        tick = tick.coerceAtMost(measureTicks - 1)
        return AddPosition(measure.index, tick, posForY(sys, y), sys.index)
    }

    /** x and system of a beat position, used for the playback cursor. */
    fun locate(beat: Double): Pair<SystemLayout, Float>? {
        val tick = beat * 4.0
        val mIdx = Math.floor(tick / measureTicks).toInt()
        for (s in systems) {
            val m = s.measures.firstOrNull { it.index == mIdx } ?: continue
            val local = tick - mIdx * measureTicks
            val items = m.items
            val hit = items.firstOrNull { local >= it.item.startTick && local < it.item.startTick + it.item.ticks }
            if (hit != null) {
                val frac = ((local - hit.item.startTick) / hit.item.ticks).toFloat()
                return s to (hit.x + frac * hit.width * 0.85f)
            }
            return s to (m.x + m.width * (local / measureTicks).toFloat())
        }
        return systems.lastOrNull()?.let { s -> s to (s.measures.last().x + s.measures.last().width) }
    }
}

object ScoreLayoutEngine {
    fun layout(notation: Notation, width: Float, staffSpace: Float): ScoreLayout {
        val s = staffSpace
        val fifths = notation.key.fifths
        val clefW = 3.4f * s
        val keyW = if (fifths == 0) 0f else (kotlin.math.abs(fifths) * 1.15f + 0.8f) * s
        val timeW = 2.6f * s
        val bottomPos = if (notation.clef == Clef.TREBLE) 30 else 18
        val midPos = bottomPos + 4

        // Measure content with accidental state.
        val rawMeasures = notation.measures.map { m -> rawItems(m, fifths, s, bottomPos) }

        // Break into systems.
        val systems = ArrayList<List<Int>>()
        var cur = ArrayList<Int>()
        var curW = 0f
        for ((i, raw) in rawMeasures.withIndex()) {
            val mw = raw.sumOf { it.w.toDouble() }.toFloat() + 1.6f * s
            val prefix = clefW + keyW + (if (systems.isEmpty()) timeW else 0f) + 0.6f * s
            val avail = width - prefix
            if (cur.isNotEmpty() && curW + mw > avail) {
                systems.add(cur); cur = ArrayList(); curW = 0f
            }
            cur.add(i); curW += mw
        }
        if (cur.isNotEmpty()) systems.add(cur)

        val pitch = 17f * s
        val out = ArrayList<SystemLayout>()
        for ((si, idxs) in systems.withIndex()) {
            val first = si == 0
            val prefix = clefW + keyW + (if (first) timeW else 0f) + 0.6f * s
            val natural = idxs.map { i -> rawMeasures[i].sumOf { it.w.toDouble() }.toFloat() + 1.6f * s }
            val sum = natural.sum()
            val avail = width - prefix
            val isLast = si == systems.size - 1
            val stretch = if (!isLast || sum > 0.6f * avail) avail / sum else 1f
            val top = si * pitch + 7f * s
            var x = prefix
            val measures = ArrayList<MeasureLayout>()
            for ((k, i) in idxs.withIndex()) {
                val mw = natural[k] * stretch
                var ix = x + 0.8f * s * stretch
                val items = ArrayList<ItemLayout>()
                val raws = rawMeasures[i]
                for (r in raws) {
                    val w = r.w * stretch
                    val noteX = ix + (if (r.acc != null) 1.5f * s * stretch else 0f) + 0.9f * s
                    val y = r.pos?.let { top + 4 * s - (it - bottomPos) * s / 2f }
                    val stemUp = (r.pos ?: midPos) < midPos
                    items.add(ItemLayout(r.item, noteX, w, y, r.pos, r.acc, stemUp, null))
                    ix += w
                }
                measures.add(MeasureLayout(i, x, mw, items))
                x += mw
            }
            out.add(SystemLayout(si, top, si * pitch, (si + 1) * pitch, prefix, first, measures, isLast))
        }

        // Resolve tie end positions now that every note has its final x.
        val resolved = out.map { sys ->
            val flat = sys.measures.flatMap { it.items }
            val endX = sys.measures.last().let { it.x + it.width }
            sys.copy(
                measures = sys.measures.map { m ->
                    m.copy(items = m.items.map { it2 ->
                        val n = it2.item as? NotationNote
                        if (n != null && n.tieToNext) {
                            val pos = flat.indexOf(it2)
                            val next = flat.drop(pos + 1).firstOrNull { f -> (f.item as? NotationNote)?.eventId == n.eventId }
                            it2.copy(tieEndX = next?.x ?: endX)
                        } else it2
                    })
                },
            )
        }
        val height = systems.size * pitch + 2f * s
        return ScoreLayout(resolved, width, height, s, notation.clef, notation.key, notation.measureTicks)
    }

    private fun rawItems(m: Measure, fifths: Int, s: Float, bottomPos: Int): List<RawItemHolder> {
        val state = HashMap<Int, Int>() // staff position -> current alteration within the measure
        val out = ArrayList<RawItemHolder>()
        for (item in m.items) {
            val base = s * (2.0f + 1.6f * ln(1.0 + item.ticks).toFloat())
            when (item) {
                is NotationNote -> {
                    val pos = item.spelling.diatonicIndex
                    val current = state[pos] ?: KeySignature.alterForStep(item.spelling.step, fifths)
                    var acc: Int? = null
                    if (!item.tieFromPrevious && item.spelling.alter != current) {
                        acc = item.spelling.alter
                    }
                    if (!item.tieFromPrevious) state[pos] = item.spelling.alter
                    val lyricW = item.lyric?.let { (it.text.length * 0.62f + 0.9f) * s } ?: 0f
                    out.add(RawItemHolder(item, maxOf(base + (if (acc != null) 1.5f * s else 0f), lyricW), acc, pos))
                }
                is NotationRest -> out.add(RawItemHolder(item, base, null, null))
            }
        }
        return out
    }

    private class RawItemHolder(val item: NotationItem, val w: Float, val acc: Int?, val pos: Int?)
}
