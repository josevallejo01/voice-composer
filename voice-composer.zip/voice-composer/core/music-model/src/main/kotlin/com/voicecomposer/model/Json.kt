package com.voicecomposer.model

/**
 * Tiny dependency-free JSON reader/writer. Values are Map<String, Any?>, List<Any?>, String, Double, Boolean or null.
 * Used to persist transcriptions and arrangements (versioned analysis results) without a serialization plugin.
 */
object Json {
    fun write(value: Any?): String = StringBuilder().also { write(value, it) }.toString()

    private fun write(v: Any?, sb: StringBuilder) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(v)
            is Int -> sb.append(v)
            is Long -> sb.append(v)
            is Double -> sb.append(if (v.isNaN() || v.isInfinite()) "0" else v.toString())
            is Float -> sb.append(v.toDouble().toString())
            is String -> quote(v, sb)
            is Map<*, *> -> {
                sb.append('{')
                var first = true
                for ((k, x) in v) {
                    if (!first) sb.append(',')
                    first = false
                    quote(k.toString(), sb)
                    sb.append(':')
                    write(x, sb)
                }
                sb.append('}')
            }
            is List<*> -> {
                sb.append('[')
                v.forEachIndexed { i, x ->
                    if (i > 0) sb.append(',')
                    write(x, sb)
                }
                sb.append(']')
            }
            else -> quote(v.toString(), sb)
        }
    }

    private fun quote(s: String, sb: StringBuilder) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }

    fun parse(text: String): Any? {
        val p = Parser(text)
        val v = p.value()
        p.skipWs()
        require(p.pos == text.length) { "Trailing characters in JSON at ${p.pos}" }
        return v
    }

    private class Parser(val s: String) {
        var pos = 0

        fun skipWs() {
            while (pos < s.length && s[pos].isWhitespace()) pos++
        }

        fun value(): Any? {
            skipWs()
            require(pos < s.length) { "Unexpected end of JSON" }
            return when (val c = s[pos]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw IllegalArgumentException("Unexpected '$c' at $pos")
            }
        }

        private fun lit(word: String, v: Any?): Any? {
            require(s.startsWith(word, pos)) { "Bad literal at $pos" }
            pos += word.length
            return v
        }

        private fun obj(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>()
            pos++
            skipWs()
            if (s[pos] == '}') { pos++; return m }
            while (true) {
                skipWs()
                val k = str()
                skipWs()
                require(s[pos] == ':') { "Expected ':' at $pos" }
                pos++
                m[k] = value()
                skipWs()
                when (s[pos++]) {
                    ',' -> continue
                    '}' -> return m
                    else -> throw IllegalArgumentException("Expected ',' or '}' at ${pos - 1}")
                }
            }
        }

        private fun arr(): List<Any?> {
            val l = ArrayList<Any?>()
            pos++
            skipWs()
            if (s[pos] == ']') { pos++; return l }
            while (true) {
                l.add(value())
                skipWs()
                when (s[pos++]) {
                    ',' -> continue
                    ']' -> return l
                    else -> throw IllegalArgumentException("Expected ',' or ']' at ${pos - 1}")
                }
            }
        }

        private fun str(): String {
            require(s[pos] == '"') { "Expected string at $pos" }
            pos++
            val sb = StringBuilder()
            while (true) {
                val c = s[pos++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> when (val e = s[pos++]) {
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        'b' -> sb.append('\b')
                        'f' -> sb.append('\u000c')
                        'u' -> { sb.append(s.substring(pos, pos + 4).toInt(16).toChar()); pos += 4 }
                        else -> sb.append(e)
                    }
                    else -> sb.append(c)
                }
            }
        }

        private fun num(): Double {
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] in "+-.eE")) pos++
            return s.substring(start, pos).toDouble()
        }
    }
}

/** Versioned JSON persistence of the musical model. */
object ModelJson {
    const val SCHEMA_VERSION = 1

    @Suppress("UNCHECKED_CAST")
    private fun Any?.m() = this as Map<String, Any?>

    @Suppress("UNCHECKED_CAST")
    private fun Any?.l() = this as List<Any?>
    private fun Any?.d() = (this as Number).toDouble()
    private fun Any?.i() = (this as Number).toInt()

    private fun eventToMap(e: MusicalEvent) = mapOf(
        "id" to e.id, "type" to e.type.name, "midi" to e.midiPitch, "hz" to e.frequencyHz,
        "startSec" to e.startSec, "endSec" to e.endSec, "startBeat" to e.startBeat, "durBeats" to e.durationBeats,
        "conf" to e.confidence, "source" to e.source.name, "validation" to e.validation.name,
    )

    private fun eventFromMap(m: Map<String, Any?>) = MusicalEvent(
        id = m["id"] as String,
        type = EventType.valueOf(m["type"] as String),
        midiPitch = (m["midi"] as Number?)?.toInt(),
        frequencyHz = (m["hz"] as Number?)?.toDouble(),
        startSec = m["startSec"].d(), endSec = m["endSec"].d(),
        startBeat = m["startBeat"].d(), durationBeats = m["durBeats"].d(),
        confidence = m["conf"].d(),
        source = EventSource.valueOf(m["source"] as String),
        validation = ValidationState.valueOf(m["validation"] as String),
    )

    private fun tempoToMap(t: TempoMap) = mapOf(
        "points" to t.points.map { mapOf("beat" to it.beat, "sec" to it.timeSec) },
        "tailBpm" to t.tailBpm,
    )

    private fun tempoFromMap(m: Map<String, Any?>) =
        TempoMap(m["points"].l().map { TempoPoint(it.m()["beat"].d(), it.m()["sec"].d()) }, m["tailBpm"].d())

    fun encode(t: Transcription): String = Json.write(
        mapOf(
            "schema" to SCHEMA_VERSION,
            "events" to t.events.map(::eventToMap),
            "tempo" to tempoToMap(t.tempoMap),
            "timeSig" to listOf(t.timeSignature.numerator, t.timeSignature.denominator),
            "key" to mapOf("tonic" to t.key.tonic, "mode" to t.key.mode.name, "conf" to t.key.confidence),
            "quantization" to t.quantization.name,
            "lyrics" to t.lyrics.map {
                mapOf("id" to it.id, "text" to it.text, "syllabic" to it.syllabic.name, "startSec" to it.startSec, "noteId" to it.noteId, "conf" to it.confidence)
            },
            "analysis" to t.analysis?.let {
                mapOf(
                    "engine" to it.engineVersion, "tempoConf" to it.tempoConfidence, "meterConf" to it.meterConfidence,
                    "keyConf" to it.keyConfidence, "overall" to it.overallConfidence, "warnings" to it.warnings,
                )
            },
        )
    )

    fun decodeTranscription(json: String): Transcription {
        val m = Json.parse(json).m()
        val ts = m["timeSig"].l()
        val k = m["key"].m()
        return Transcription(
            events = m["events"].l().map { eventFromMap(it.m()) },
            tempoMap = tempoFromMap(m["tempo"].m()),
            timeSignature = TimeSignature(ts[0].i(), ts[1].i()),
            key = KeySignature(k["tonic"].i(), Mode.valueOf(k["mode"] as String), k["conf"].d()),
            quantization = QuantizationMode.valueOf(m["quantization"] as String),
            lyrics = m["lyrics"].l().map {
                val x = it.m()
                LyricSegment(x["id"] as String, x["text"] as String, Syllabic.valueOf(x["syllabic"] as String), x["startSec"].d(), x["noteId"] as String?, x["conf"].d())
            },
            analysis = (m["analysis"] as Map<*, *>?)?.let { a ->
                val x = a.m()
                AnalysisInfo(
                    x["engine"] as String, x["tempoConf"].d(), x["meterConf"].d(), x["keyConf"].d(), x["overall"].d(),
                    x["warnings"].l().map { w -> w as String },
                )
            },
        )
    }

    fun encode(a: Arrangement): String = Json.write(
        mapOf(
            "schema" to SCHEMA_VERSION, "id" to a.id, "sourceVersion" to a.sourceVersion,
            "style" to a.style.name, "complexity" to a.complexity,
            "chords" to a.chords.map {
                mapOf("start" to it.startBeat, "dur" to it.durationBeats, "root" to it.rootPitchClass, "minor" to it.minor, "dim" to it.diminished)
            },
            "tracks" to a.tracks.map { t ->
                mapOf(
                    "id" to t.id, "name" to t.name, "instrument" to t.instrument.name, "role" to t.role.name,
                    "volume" to t.volume, "pan" to t.pan, "enabled" to t.enabled, "events" to t.events.map(::eventToMap),
                )
            },
        )
    )

    fun decodeArrangement(json: String): Arrangement {
        val m = Json.parse(json).m()
        return Arrangement(
            id = m["id"] as String, sourceVersion = m["sourceVersion"].i(),
            style = ArrangementStyle.valueOf(m["style"] as String), complexity = m["complexity"].i(),
            chords = m["chords"].l().map {
                val c = it.m()
                ChordSegment(c["start"].d(), c["dur"].d(), c["root"].i(), c["minor"] as Boolean, c["dim"] as Boolean)
            },
            tracks = m["tracks"].l().map {
                val t = it.m()
                Track(
                    t["id"] as String, t["name"] as String, Instrument.valueOf(t["instrument"] as String),
                    TrackRole.valueOf(t["role"] as String), t["events"].l().map { e -> eventFromMap(e.m()) },
                    t["volume"].d().toFloat(), t["pan"].d().toFloat(), t["enabled"] as Boolean,
                )
            },
        )
    }
}
