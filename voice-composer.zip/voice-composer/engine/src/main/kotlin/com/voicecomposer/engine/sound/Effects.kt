package com.voicecomposer.engine.sound

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.exp

/** Two-pole filter section (RBJ cookbook); used for the master EQ and to keep rumble out of the reverb. */
class Biquad private constructor(private val b0: Double, private val b1: Double, private val b2: Double, private val a1: Double, private val a2: Double) {
    private var z1 = 0.0
    private var z2 = 0.0
    fun process(x: Float): Float {
        val xd = x.toDouble()
        val y = b0 * xd + z1
        z1 = b1 * xd - a1 * y + z2
        z2 = b2 * xd - a2 * y
        return y.toFloat()
    }
    fun run(a: FloatArray) { for (i in a.indices) a[i] = process(a[i]) }

    companion object {
        private fun make(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) = Biquad(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
        fun highPass(sr: Int, hz: Double, q: Double = 0.707): Biquad {
            val w = 2 * PI * hz / sr; val c = cos(w); val al = sin(w) / (2 * q)
            return make((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
        }
        fun lowPass(sr: Int, hz: Double, q: Double = 0.707): Biquad {
            val w = 2 * PI * hz / sr; val c = cos(w); val al = sin(w) / (2 * q)
            return make((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
        }
        fun lowShelf(sr: Int, hz: Double, gainDb: Double): Biquad {
            val a = 10.0.pow(gainDb / 40); val w = 2 * PI * hz / sr; val c = cos(w); val s = sin(w)
            val al = s / 2 * sqrt(2.0)
            return make(
                a * ((a + 1) - (a - 1) * c + 2 * sqrt(a) * al), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - 2 * sqrt(a) * al),
                (a + 1) + (a - 1) * c + 2 * sqrt(a) * al, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - 2 * sqrt(a) * al,
            )
        }
        fun highShelf(sr: Int, hz: Double, gainDb: Double): Biquad {
            val a = 10.0.pow(gainDb / 40); val w = 2 * PI * hz / sr; val c = cos(w); val s = sin(w)
            val al = s / 2 * sqrt(2.0)
            return make(
                a * ((a + 1) + (a - 1) * c + 2 * sqrt(a) * al), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - 2 * sqrt(a) * al),
                (a + 1) - (a - 1) * c + 2 * sqrt(a) * al, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - 2 * sqrt(a) * al,
            )
        }
        fun peak(sr: Int, hz: Double, gainDb: Double, q: Double): Biquad {
            val a = 10.0.pow(gainDb / 40); val w = 2 * PI * hz / sr; val c = cos(w); val al = sin(w) / (2 * q)
            return make(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
        }
    }
}

class ReverbParams(
    /** Time for the tail to fall by 60 dB at low frequencies. */
    val rt60: Double = 1.9,
    val predelayMs: Double = 20.0,
    /** 0 = bright tail, 1 = very dark. High frequencies die faster than lows in real rooms. */
    val damping: Double = 0.45,
    /** Scales the delay lines: room size. */
    val size: Double = 1.0,
    val earlyLevel: Float = 0.55f,
    val tailLevel: Float = 0.5f,
)

/**
 * Stereo feedback-delay-network reverb: input diffusion, a set of early reflections, then eight delay lines mixed by an
 * orthogonal Hadamard matrix with frequency-dependent damping, so the tail is smooth (no flutter), dense and warm.
 * It works on whole buffers (offline); the caller leaves room for the tail at the end of the arrays.
 */
class StereoReverb(private val sr: Int, private val p: ReverbParams = ReverbParams()) {
    private class Allpass(val buf: FloatArray, val g: Float) {
        var i = 0
        fun process(x: Float): Float {
            val d = buf[i]
            val v = x - g * d
            buf[i] = v
            i++; if (i == buf.size) i = 0
            return d + g * v
        }
    }

    /** Adds the wet signal of [inL]/[inR] into [outL]/[outR] (same length). */
    fun process(inL: FloatArray, inR: FloatArray, outL: FloatArray, outR: FloatArray) {
        val n = inL.size
        val k = sr / 44100.0
        val pre = (p.predelayMs * sr / 1000).toInt()
        // Early reflections: (ms, gain to L, gain to R). Alternating sides make the room feel wide.
        val taps = arrayOf(
            doubleArrayOf(7.3, 0.70, 0.0), doubleArrayOf(11.9, 0.0, 0.66), doubleArrayOf(17.3, 0.55, 0.22), doubleArrayOf(23.1, 0.22, 0.55),
            doubleArrayOf(29.9, 0.46, 0.0), doubleArrayOf(37.7, 0.0, 0.42), doubleArrayOf(46.3, 0.30, 0.20), doubleArrayOf(55.1, 0.14, 0.30),
        )
        val base = doubleArrayOf(29.7, 37.1, 41.1, 43.7, 53.3, 59.9, 67.3, 73.1)
        val lens = IntArray(8) { oddPrimeNear((base[it] * p.size * sr / 1000.0).toInt()) }
        val bufs = Array(8) { FloatArray(lens[it]) }
        val idx = IntArray(8)
        val gain = FloatArray(8) { 10.0.pow(-3.0 * lens[it] / sr / (p.rt60 * 1.2)).toFloat() }
        val lp = FloatArray(8)
        val damp = (p.damping * 0.8).toFloat().coerceIn(0f, 0.95f)
        val ap = arrayOf(
            Allpass(FloatArray((142 * k).toInt()), 0.62f), Allpass(FloatArray((107 * k).toInt()), 0.62f),
            Allpass(FloatArray((379 * k).toInt()), 0.6f), Allpass(FloatArray((277 * k).toInt()), 0.6f),
        )
        val y = FloatArray(8)
        val inv = 1f / sqrt(8f)
        val hpL = Biquad.highPass(sr, 180.0); val hpR = Biquad.highPass(sr, 180.0)
        for (t in 0 until n) {
            val s = t - pre
            val xl = if (s >= 0) inL[s] else 0f
            val xr = if (s >= 0) inR[s] else 0f
            // Early reflections read the un-delayed input.
            var el = 0f; var er = 0f
            for (tp in taps) {
                val tt = t - (tp[0] * sr / 1000).toInt()
                if (tt >= 0) { val m = (inL[tt] + inR[tt]) * 0.5f; el += m * tp[1].toFloat(); er += m * tp[2].toFloat() }
            }
            // Diffused mono injection plus a little of the side signal.
            var inj = ap[3].process(ap[2].process(ap[1].process(ap[0].process((xl + xr) * 0.5f))))
            val side = (xl - xr) * 0.5f
            for (i in 0 until 8) {
                val d = bufs[i][idx[i]]
                lp[i] = d * (1 - damp) + lp[i] * damp
                y[i] = lp[i] * gain[i]
            }
            // Orthogonal 8x8 Hadamard (fast Walsh-Hadamard).
            var h = 1
            while (h < 8) {
                var j = 0
                while (j < 8) {
                    for (m in j until j + h) { val a = y[m]; val b = y[m + h]; y[m] = a + b; y[m + h] = a - b }
                    j += h * 2
                }
                h *= 2
            }
            for (i in 0 until 8) {
                val inject = inj * 0.35f + (if (i % 2 == 0) side else -side) * 0.25f
                bufs[i][idx[i]] = y[i] * inv + inject
                idx[i]++; if (idx[i] == lens[i]) idx[i] = 0
            }
            // Outputs from the delay-line outputs (before they were fed back).
            var tl = 0f; var tr = 0f
            for (i in 0 until 8) {
                val prev = lp[i] * gain[i]
                if (i % 2 == 0) tl += if ((i / 2) % 2 == 0) prev else -prev else tr += if ((i / 2) % 2 == 0) prev else -prev
            }
            outL[t] += hpL.process(tl * 0.5f * p.tailLevel + el * p.earlyLevel * 0.5f)
            outR[t] += hpR.process(tr * 0.5f * p.tailLevel + er * p.earlyLevel * 0.5f)
        }
    }

    private fun oddPrimeNear(x: Int): Int {
        var v = max(x, 11) or 1
        while (!isPrime(v)) v += 2
        return v
    }
    private fun isPrime(v: Int): Boolean { var d = 3; while (d * d <= v) { if (v % d == 0) return false; d += 2 }; return v > 2 }
}

/** String / choir ensemble effect: several slightly detuned, slowly moving copies that widen the sound. */
class Ensemble(private val sr: Int, private val rateHz: Double = 0.42, private val baseMs: Double = 17.0, private val depthMs: Double = 2.6) {
    fun process(l: FloatArray, r: FloatArray, mix: Float) {
        if (mix <= 0f) return
        val n = l.size
        val size = ((baseMs + depthMs + 4) * sr / 1000).toInt() + 4
        val bl = FloatArray(size); val br = FloatArray(size)
        var w = 0
        val phases = doubleArrayOf(0.0, 1.0 / 3, 2.0 / 3)
        for (t in 0 until n) {
            bl[w] = l[t]; br[w] = r[t]
            var wl = 0f; var wr = 0f
            for (v in 0 until 3) {
                val ph = 2 * PI * (rateHz * t / sr + phases[v])
                val dl = (baseMs + depthMs * sin(ph)) * sr / 1000
                val dr = (baseMs + depthMs * sin(ph + PI / 2 + 0.7)) * sr / 1000
                wl += read(bl, w, dl, size) * (if (v == 0) 0.45f else 0.275f)
                wr += read(br, w, dr, size) * (if (v == 2) 0.45f else 0.275f)
            }
            l[t] = l[t] * (1 - 0.35f * mix) + wl * mix * 0.9f
            r[t] = r[t] * (1 - 0.35f * mix) + wr * mix * 0.9f
            w++; if (w == size) w = 0
        }
    }
    private fun read(b: FloatArray, w: Int, delay: Double, size: Int): Float {
        var pos = w - delay
        while (pos < 0) pos += size
        val i = pos.toInt(); val f = (pos - i).toFloat()
        val a = b[i % size]; val c = b[(i + 1) % size]
        return a + (c - a) * f
    }
}

/**
 * The mixing desk's last stage: rumble filter, a touch of tone shaping, glue compression, loudness matching and a
 * look-ahead limiter. The result peaks at the ceiling and has a consistent loudness whatever the arrangement.
 */
object MasterBus {
    fun process(l: FloatArray, r: FloatArray, sr: Int, targetRmsDb: Double = -19.0, ceilingDb: Double = -1.0) {
        val n = l.size
        if (n == 0) return
        val hp = arrayOf(Biquad.highPass(sr, 28.0), Biquad.highPass(sr, 28.0))
        val ls = arrayOf(Biquad.lowShelf(sr, 140.0, 0.8), Biquad.lowShelf(sr, 140.0, 0.8))
        val hs = arrayOf(Biquad.highShelf(sr, 8500.0, -1.5), Biquad.highShelf(sr, 8500.0, -1.5))
        for (i in 0 until n) {
            l[i] = hs[0].process(ls[0].process(hp[0].process(l[i])))
            r[i] = hs[1].process(ls[1].process(hp[1].process(r[i])))
        }
        compress(l, r, sr, thresholdDb = -22.0, ratio = 2.0, kneeDb = 8.0, attackMs = 25.0, releaseMs = 260.0)
        // Loudness: RMS of the frames that are not near-silent, in 50 ms blocks.
        val blk = sr / 20
        var sum = 0.0; var cnt = 0L
        var i = 0
        while (i + blk <= n) {
            var e = 0.0
            for (k in i until i + blk) e += (l[k] * l[k] + r[k] * r[k]) * 0.5
            e /= blk
            if (e > 1e-7) { sum += e; cnt++ }
            i += blk
        }
        if (cnt > 0) {
            val rmsDb = 10 * log10(sum / cnt)
            // Raise quiet material up to the target but never push a hot mix further; the limiter handles the peaks.
            val gDb = (targetRmsDb - rmsDb).coerceIn(-24.0, 18.0)
            val g = 10.0.pow(gDb / 20).toFloat()
            for (k in 0 until n) { l[k] *= g; r[k] *= g }
        }
        limit(l, r, sr, ceilingDb)
    }

    fun compress(l: FloatArray, r: FloatArray, sr: Int, thresholdDb: Double, ratio: Double, kneeDb: Double, attackMs: Double, releaseMs: Double) {
        val aA = exp(-1.0 / (attackMs * sr / 1000)); val aR = exp(-1.0 / (releaseMs * sr / 1000))
        var env = 0.0 // smoothed gain reduction in dB (>= 0)
        for (t in l.indices) {
            val peak = max(abs(l[t]), abs(r[t])).toDouble()
            val lvl = if (peak < 1e-9) -180.0 else 20 * log10(peak)
            val over = lvl - thresholdDb
            val target = when {
                2 * over < -kneeDb -> 0.0
                2 * abs(over) <= kneeDb -> (1 - 1 / ratio) * (over + kneeDb / 2).pow(2) / (2 * kneeDb)
                else -> (1 - 1 / ratio) * over
            }
            env = if (target > env) aA * env + (1 - aA) * target else aR * env + (1 - aR) * target
            val g = 10.0.pow(-env / 20).toFloat()
            l[t] *= g; r[t] *= g
        }
    }

    /** Look-ahead peak limiter: the gain is the running minimum of what each upcoming sample needs, smoothed over the look-ahead. */
    fun limit(l: FloatArray, r: FloatArray, sr: Int, ceilingDb: Double) {
        val n = l.size
        val ceil = 10.0.pow(ceilingDb / 20).toFloat()
        val look = max(8, (0.005 * sr).toInt())
        val need = FloatArray(n) { val p = max(abs(l[it]), abs(r[it])); if (p > ceil) ceil / p else 1f }
        // Sliding minimum over [t, t+look).
        val mn = FloatArray(n)
        val dq = IntArray(n + 1); var head = 0; var tail = 0
        for (t in n - 1 downTo 0) {
            while (tail > head && need[dq[tail - 1]] >= need[t]) tail--
            dq[tail++] = t
            while (dq[head] >= t + look) head++
            mn[t] = need[dq[head]]
        }
        // Gain at t = average of the minima of the `look` windows that contain t: never above what sample t needs.
        var run = 0.0
        val relCoef = exp(-1.0 / (0.08 * sr)).toFloat()
        var gSlow = 1f
        for (t in 0 until n) {
            run += mn[t]
            if (t >= look) run -= mn[t - look]
            val g = (run / min(t + 1, look)).toFloat()
            gSlow = if (g < gSlow) g else g + (gSlow - g) * relCoef
            val gg = min(gSlow, g)
            l[t] *= gg; r[t] *= gg
            if (abs(l[t]) > ceil) l[t] = ceil * Math.signum(l[t])
            if (abs(r[t]) > ceil) r[t] = ceil * Math.signum(r[t])
        }
    }
}
