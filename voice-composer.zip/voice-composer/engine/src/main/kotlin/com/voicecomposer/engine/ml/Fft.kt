package com.voicecomposer.engine.ml

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Minimal in-place radix-2 FFT, used for the spectral features of detected notes. */
class Fft(val n: Int) {
    private val cosT = DoubleArray(n / 2) { cos(-2 * PI * it / n) }
    private val sinT = DoubleArray(n / 2) { sin(-2 * PI * it / n) }
    private val rev = IntArray(n).also { r ->
        val bits = Integer.numberOfTrailingZeros(n)
        for (i in 0 until n) r[i] = Integer.reverse(i) ushr (32 - bits)
    }

    init { require(n >= 2 && n and (n - 1) == 0) { "n must be a power of two" } }

    fun transform(re: DoubleArray, im: DoubleArray) {
        for (i in 0 until n) { val j = rev[i]; if (j > i) { val a = re[i]; re[i] = re[j]; re[j] = a; val b = im[i]; im[i] = im[j]; im[j] = b } }
        var size = 2
        while (size <= n) {
            val half = size / 2; val step = n / size
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val tr = re[j + half] * cosT[k] - im[j + half] * sinT[k]
                    val ti = re[j + half] * sinT[k] + im[j + half] * cosT[k]
                    re[j + half] = re[j] - tr; im[j + half] = im[j] - ti
                    re[j] += tr; im[j] += ti
                    k += step
                }
                i += size
            }
            size *= 2
        }
    }
}
