package com.voicecomposer.engine.score

import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Key as a ranking problem over the 24 major and minor keys. The forest sees the pitch-class distribution relative to the
 * candidate tonic (by duration and by count), how the melody opens and ends, and the Krumhansl-Schmuckler correlation as
 * one more piece of evidence, not as the decision.
 */
object KeyModel {
    val NAMES = listOf("minor") + (0 until 12).map { "h$it" } + (0 until 12).map { "c$it" } + listOf(
        "firstDeg", "lastDeg", "lastDur", "r", "rRank", "rGap", "inScale", "inTriad", "leading", "fifthsMajor", "fifthsAbs",
    )
    val DIM = NAMES.size
    private val MAJOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
    private val MAJOR_STEPS = setOf(0, 2, 4, 5, 7, 9, 11)
    private val MINOR_STEPS = setOf(0, 2, 3, 5, 7, 8, 10)
    private val FIFTHS = intArrayOf(0, -5, 2, -3, 4, -1, 6, 1, -4, 3, -2, 5)

    class Cand(val key: KeySignature, val features: DoubleArray)

    fun candidates(midi: IntArray, durBeats: DoubleArray): List<Cand> {
        val n = midi.size
        if (n == 0) return emptyList()
        val hist = DoubleArray(12); val cnt = DoubleArray(12)
        for (i in 0 until n) { val pc = Math.floorMod(midi[i], 12); hist[pc] += min(durBeats[i], 4.0); cnt[pc] += 1.0 }
        val sh = hist.sum().coerceAtLeast(1e-9); val sc = cnt.sum().coerceAtLeast(1e-9)
        val rs = ArrayList<Triple<Int, Boolean, Double>>()
        for (tonic in 0 until 12) for (minor in listOf(false, true)) {
            val rot = DoubleArray(12) { hist[(it + tonic) % 12] }
            rs.add(Triple(tonic, minor, correlation(rot, if (minor) MINOR else MAJOR)))
        }
        val sorted = rs.sortedByDescending { it.third }
        val lastDur = min(durBeats[n - 1], 4.0)
        return rs.map { (tonic, minor, r) ->
            val x = DoubleArray(DIM)
            x[0] = if (minor) 1.0 else 0.0
            for (k in 0 until 12) { x[1 + k] = hist[(k + tonic) % 12] / sh; x[13 + k] = cnt[(k + tonic) % 12] / sc }
            x[25] = Math.floorMod(midi[0] - tonic, 12).toDouble()
            x[26] = Math.floorMod(midi[n - 1] - tonic, 12).toDouble()
            x[27] = lastDur
            x[28] = r
            x[29] = sorted.indexOfFirst { it.first == tonic && it.second == minor }.toDouble()
            x[30] = r - sorted[0].third
            val steps = if (minor) MINOR_STEPS else MAJOR_STEPS
            var inScale = 0.0; for (k in steps) inScale += hist[(k + tonic) % 12] / sh
            x[31] = inScale
            val triad = if (minor) intArrayOf(0, 3, 7) else intArrayOf(0, 4, 7)
            x[32] = triad.sumOf { hist[(it + tonic) % 12] / sh }
            x[33] = hist[(tonic + 11) % 12] / sh
            val majorTonic = if (minor) (tonic + 3) % 12 else tonic
            x[34] = FIFTHS[majorTonic].toDouble(); x[35] = kotlin.math.abs(x[34])
            Cand(KeySignature(tonic, if (minor) Mode.MINOR else Mode.MAJOR, 0.0), x)
        }
    }

    private fun correlation(a: DoubleArray, b: DoubleArray): Double {
        val ma = a.average(); val mb = b.average()
        var num = 0.0; var da = 0.0; var db = 0.0
        for (i in a.indices) { num += (a[i] - ma) * (b[i] - mb); da += (a[i] - ma) * (a[i] - ma); db += (b[i] - mb) * (b[i] - mb) }
        return if (da == 0.0 || db == 0.0) 0.0 else num / sqrt(da * db)
    }
}
