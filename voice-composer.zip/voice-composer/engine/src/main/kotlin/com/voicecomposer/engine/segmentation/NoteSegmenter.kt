package com.voicecomposer.engine.segmentation

import com.voicecomposer.engine.pitch.PitchFrame
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** A note found in the recording, on the audio timeline, before any rhythmic interpretation. */
data class DetectedNote(
    val startSec: Double,
    val endSec: Double,
    val midi: Int,
    /** Median pitch in fractional semitones after tuning compensation. */
    val pitch: Double,
    val confidence: Double,
    /** 1 = steady pitch, 0 = very unstable (glissando, wobble). */
    val stability: Double,
    val level: Double,
)

/** Energy gate that keeps musical silences intact: it only flags frames, it never removes time. */
object EnergyVad {
    fun thresholdDb(frames: List<PitchFrame>): Double {
        if (frames.isEmpty()) return -60.0
        val sorted = frames.map { it.rmsDb }.sorted()
        val floor = sorted[(sorted.size * 0.05).toInt()]
        val peak = sorted[(sorted.size * 0.95).toInt().coerceAtMost(sorted.size - 1)]
        // 10 dB above the noise floor, but never above "12 dB under the peak" (a long sung phrase may contain
        // almost no silence, which would push a percentile based floor into the signal itself).
        return (floor + 10.0).coerceIn(peak - 40.0, peak - 12.0)
    }
}

/**
 * Turns frame-wise pitch into notes. A new note starts when
 *  - the pitch leaves the current note's median by more than [Params.splitSemitones] for [Params.splitFrames] frames,
 *  - the signal is interrupted for [Params.gapFrames] frames or more (breath, consonant),
 *  - the energy dips and rises again (a repeated note sung legato, e.g. "la-la" or a re-attacked hum).
 * Vibrato stays inside the tolerance band, so a vibrato note is not split.
 */
class NoteSegmenter(private val p: Params = Params()) {
    data class Params(
        val minConfidence: Double = 0.6,
        val splitSemitones: Double = 0.8,
        val splitFrames: Int = 4,
        val minNoteFrames: Int = 6,
        val gapFrames: Int = 3,
        val dipDb: Double = 6.0,
        val riseDb: Double = 4.5,
        val minFramesBetweenAttacks: Int = 8,
        val referenceWindow: Int = 40,
        val edgeSec: Double = 0.012,
    )

    private class Builder(val first: Int) {
        val idx = ArrayList<Int>()
        val midi = ArrayList<Double>()
        val conf = ArrayList<Double>()
        val db = ArrayList<Double>()
        fun add(i: Int, m: Double, c: Double, d: Double) { idx.add(i); midi.add(m); conf.add(c); db.add(d) }
        val size get() = idx.size
    }

    fun segment(frames: List<PitchFrame>, tuningCompensation: Boolean = true): List<DetectedNote> {
        val n = frames.size
        if (n == 0) return emptyList()
        val thr = EnergyVad.thresholdDb(frames)
        val smooth = DoubleArray(n) { i ->
            var s = 0.0; var c = 0
            for (k in (i - 1)..(i + 1)) if (k in 0 until n) { s += frames[k].rmsDb; c++ }
            s / c
        }
        val ok = BooleanArray(n) { frames[it].voiced && frames[it].confidence >= p.minConfidence && smooth[it] >= thr }

        val raw = ArrayList<Builder>()
        var cur: Builder? = null
        var gap = 0
        var pending = 0
        var peakDb = -200.0
        var dipMin = 1e9
        var dipIdx = -1
        var inDip = false
        var noteStartFrame = 0

        fun startNote(i: Int): Builder {
            peakDb = smooth[i]; dipMin = 1e9; dipIdx = -1; inDip = false; pending = 0; noteStartFrame = i
            return Builder(i)
        }

        fun finish(b: Builder?) { if (b != null && b.size >= p.minNoteFrames) raw.add(b) }

        for (i in 0 until n) {
            if (!ok[i]) { gap++; continue }
            val f = frames[i]
            var b = cur
            if (b != null && gap >= p.gapFrames) { finish(b); b = null }
            gap = 0
            if (b == null) {
                b = startNote(i); b.add(i, f.midi, f.confidence, smooth[i]); cur = b; continue
            }
            // Pitch change detection against the median of the stable part of the note.
            val stableCount = b.size - pending
            val from = maxOf(0, stableCount - p.referenceWindow)
            val ref = median(b.midi.subList(from, stableCount))
            b.add(i, f.midi, f.confidence, smooth[i])
            pending = if (abs(f.midi - ref) > p.splitSemitones) pending + 1 else 0
            if (pending >= p.splitFrames) {
                val keep = b.size - pending
                val nb = Builder(b.idx[keep])
                for (k in keep until b.size) nb.add(b.idx[k], b.midi[k], b.conf[k], b.db[k])
                while (b.size > keep) { b.idx.removeLast(); b.midi.removeLast(); b.conf.removeLast(); b.db.removeLast() }
                finish(b)
                cur = nb
                peakDb = smooth[i]; dipMin = 1e9; inDip = false; pending = 0; noteStartFrame = nb.first
                continue
            }
            // Energy attack (same pitch re-articulated without an unvoiced gap).
            val d = smooth[i]
            if (d > peakDb && !inDip) peakDb = d
            else if (d < peakDb - p.dipDb) {
                inDip = true
                if (d < dipMin) { dipMin = d; dipIdx = i }
            }
            if (inDip && d > dipMin + p.riseDb && dipIdx - noteStartFrame >= p.minFramesBetweenAttacks) {
                val nb = Builder(dipIdx)
                val keep = b.idx.indexOfFirst { it >= dipIdx }
                for (k in keep until b.size) nb.add(b.idx[k], b.midi[k], b.conf[k], b.db[k])
                while (b.size > keep) { b.idx.removeLast(); b.midi.removeLast(); b.conf.removeLast(); b.db.removeLast() }
                finish(b)
                cur = nb
                peakDb = d; dipMin = 1e9; inDip = false; pending = 0; noteStartFrame = dipIdx
            }
        }
        finish(cur)

        // Build notes.
        val medians = raw.map { median(it.midi) }
        var offset = 0.0
        if (tuningCompensation && raw.size >= 3) {
            var sx = 0.0; var sy = 0.0
            for (m in medians) { val th = 2 * PI * (m - Math.floor(m)); sx += cos(th); sy += sin(th) }
            val r = sqrt(sx * sx + sy * sy) / medians.size
            if (r > 0.4) {
                var o = atan2(sy, sx) / (2 * PI) // in (-0.5, 0.5]
                // The grid sits at integer semitones, so the offset is relative to the nearest integer.
                if (o > 0.5) o -= 1.0
                offset = o
            }
        }
        return raw.mapIndexed { k, b ->
            val med = medians[k] - offset
            val mean = b.midi.average()
            val sd = sqrt(b.midi.sumOf { (it - mean) * (it - mean) } / b.size)
            DetectedNote(
                startSec = frames[b.idx.first()].timeSec - p.edgeSec,
                endSec = frames[b.idx.last()].timeSec + p.edgeSec,
                midi = med.roundToInt(),
                pitch = med,
                confidence = b.conf.average(),
                stability = (1.0 - sd / 0.6).coerceIn(0.0, 1.0),
                level = b.db.average(),
            )
        }
    }

    private fun median(v: List<Double>): Double {
        if (v.isEmpty()) return 0.0
        val s = v.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2
    }
}
