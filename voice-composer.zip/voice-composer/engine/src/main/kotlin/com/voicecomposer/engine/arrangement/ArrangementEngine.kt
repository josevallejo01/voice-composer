package com.voicecomposer.engine.arrangement

import com.voicecomposer.model.Arrangement
import com.voicecomposer.model.ArrangementStyle
import com.voicecomposer.model.ChordSegment
import com.voicecomposer.model.EventSource
import com.voicecomposer.model.EventType
import com.voicecomposer.model.Ids
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.Mode
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.ValidationState
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** The arrangement never modifies the source transcription: it returns new tracks (spec 9.4). */
interface ArrangementEngine {
    fun arrange(source: Transcription, style: ArrangementStyle, complexity: Int, sourceVersion: Int): Arrangement
}

/**
 * First arrangement prototype (spec 9.5): chords, bass and a simple accompaniment.
 *
 * Harmony is chosen by Viterbi decoding over the diatonic triads of the key. The emission score measures how well
 * a chord explains the melody notes of a segment (duration weighted, bonus for chord tones on strong positions) and
 * the transition score encodes common progressions (fifth/fourth motion, cadences). Both scores can later be
 * replaced by a learned model behind this interface.
 */
class HarmonicArrangementEngine : ArrangementEngine {
    private data class Chord(val root: Int, val minor: Boolean, val dim: Boolean) {
        val tones: IntArray get() = intArrayOf(0, if (minor || dim) 3 else 4, if (dim) 6 else 7)
    }

    override fun arrange(source: Transcription, style: ArrangementStyle, complexity: Int, sourceVersion: Int): Arrangement {
        val level = complexity.coerceIn(1, 3)
        val bpm = source.timeSignature.beatsPerMeasure
        val total = max(source.totalBeats, bpm)
        val segLen = if (level == 3 && bpm >= 4.0) bpm / 2 else bpm
        val segCount = kotlin.math.ceil(total / segLen).toInt().coerceAtLeast(1)
        val chordSet = chordsFor(source)
        val notes = source.notes

        // Emission scores.
        val scale = source.key.scalePitchClasses
        val emit = Array(segCount) { s ->
            val a = s * segLen
            val b = a + segLen
            val inSeg = notes.filter { it.startBeat < b && it.endBeat > a }
            val dur = inSeg.sumOf { min(it.endBeat, b) - max(it.startBeat, a) }.coerceAtLeast(1e-3)
            DoubleArray(chordSet.size) { c ->
                val tones = chordSet[c].tones.map { Math.floorMod(chordSet[c].root + it, 12) }.toSet()
                var sc = 0.0
                for (n in inSeg) {
                    val pc = Pitch.pitchClass(n.midiPitch ?: continue)
                    val w = min(n.endBeat, b) - max(n.startBeat, a)
                    sc += w * when {
                        pc in tones -> 1.0
                        pc in scale -> -0.15
                        else -> -0.6
                    }
                    if (n.startBeat >= a && n.startBeat < a + 1e-6 && pc in tones) sc += 0.8
                }
                sc / dur
            }
        }

        // Viterbi.
        val k = chordSet.size
        val best = Array(segCount) { DoubleArray(k) }
        val back = Array(segCount) { IntArray(k) }
        for (c in 0 until k) best[0][c] = emit[0][c] + (if (c == 0) 0.3 else 0.0)
        for (s in 1 until segCount) for (c in 0 until k) {
            var bv = -1e18
            var bi = 0
            for (p in 0 until k) {
                val v = best[s - 1][p] + transition(chordSet[p], chordSet[c])
                if (v > bv) { bv = v; bi = p }
            }
            best[s][c] = bv + emit[s][c]
            back[s][c] = bi
        }
        var last = 0
        var lv = -1e18
        for (c in 0 until k) {
            val end = best[segCount - 1][c] + (if (c == 0) 0.4 else if (c == 4) 0.1 else 0.0)
            if (end > lv) { lv = end; last = c }
        }
        val path = IntArray(segCount)
        path[segCount - 1] = last
        for (s in segCount - 1 downTo 1) path[s - 1] = back[s][path[s]]

        // Merge equal consecutive chords into longer segments.
        val chords = ArrayList<ChordSegment>()
        for (s in 0 until segCount) {
            val ch = chordSet[path[s]]
            val prev = chords.lastOrNull()
            if (prev != null && prev.rootPitchClass == ch.root && prev.minor == ch.minor && prev.diminished == ch.dim) {
                chords[chords.size - 1] = prev.copy(durationBeats = prev.durationBeats + segLen)
            } else chords.add(ChordSegment(s * segLen, segLen, ch.root, ch.minor, ch.dim))
        }

        val tracks = buildTracks(source, chords, style, level, segLen)
        return Arrangement(Ids.newId("a"), sourceVersion, style, level, chords, tracks)
    }

    private fun chordsFor(t: Transcription): List<Chord> {
        val tonic = t.key.tonic
        val raw = if (t.key.mode == Mode.MAJOR) listOf(
            Chord(tonic, false, false), Chord(tonic + 2, true, false), Chord(tonic + 4, true, false),
            Chord(tonic + 5, false, false), Chord(tonic + 7, false, false), Chord(tonic + 9, true, false),
            Chord(tonic + 11, false, true),
        ) else listOf(
            Chord(tonic, true, false), Chord(tonic + 2, false, true), Chord(tonic + 3, false, false),
            Chord(tonic + 5, true, false), Chord(tonic + 7, false, false), Chord(tonic + 8, false, false),
            Chord(tonic + 10, false, false),
        )
        // Index 0 is the tonic chord and index 4 the dominant: the Viterbi priors rely on that order.
        return raw.map { it.copy(root = Math.floorMod(it.root, 12)) }
    }

    private fun transition(a: Chord, b: Chord): Double {
        val motion = Math.floorMod(b.root - a.root, 12)
        var s = when (motion) {
            5 -> 0.35 // up a fourth (down a fifth): V->I, I->IV, ii->V
            2 -> 0.15
            9 -> 0.15 // down a third
            7 -> 0.2 // I->V style leap
            0 -> -0.05
            else -> 0.0
        }
        if (a.dim && motion == 1) s += 0.2
        return s
    }

    private fun buildTracks(source: Transcription, chords: List<ChordSegment>, style: ArrangementStyle, level: Int, segLen: Double): List<Track> {
        val beatsPerMeasure = source.timeSignature.beatsPerMeasure
        val padEvents = ArrayList<MusicalEvent>()
        val bassEvents = ArrayList<MusicalEvent>()
        var prevVoicing: IntArray? = null
        val map = source.tempoMap

        fun ev(midi: Int, start: Double, dur: Double, list: MutableList<MusicalEvent>) {
            list.add(
                MusicalEvent(
                    id = Ids.newId("x"), type = EventType.NOTE, midiPitch = midi, frequencyHz = Pitch.midiToHz(midi),
                    startSec = map.beatToSec(start), endSec = map.beatToSec(start + dur), startBeat = start, durationBeats = dur,
                    confidence = 1.0, source = EventSource.ARRANGEMENT, validation = ValidationState.AUTO,
                )
            )
        }

        for (c in chords) {
            val tones = intArrayOf(0, if (c.minor || c.diminished) 3 else 4, if (c.diminished) 6 else 7)
            val voicing = voice(c.rootPitchClass, tones, prevVoicing)
            prevVoicing = voicing
            val bassRoot = 36 + c.rootPitchClass
            val bassFifth = bassRoot + (if (c.diminished) 6 else 7)
            var offset = 0.0
            while (offset < c.durationBeats - 1e-6) {
                val len = min(beatsPerMeasure, c.durationBeats - offset).coerceAtMost(max(segLen, 1.0))
                val start = c.startBeat + offset
                when (style) {
                    ArrangementStyle.POP -> {
                        when (level) {
                            1 -> voicing.forEach { ev(it, start, len, padEvents) }
                            2 -> { var b = 0.0; while (b < len - 1e-6) { voicing.forEach { ev(it, start + b, min(0.95, len - b), padEvents) }; b += 1.0 } }
                            else -> { var b = 0.0; while (b < len - 1e-6) { voicing.forEach { ev(it, start + b, min(0.45, len - b), padEvents) }; b += 0.5 } }
                        }
                        ev(bassRoot, start, if (level == 1) len else min(len, 2.0), bassEvents)
                        if (level >= 2 && len > 2.0) ev(bassRoot, start + 2.0, min(len - 2.0, 2.0), bassEvents)
                    }
                    ArrangementStyle.FOLK -> {
                        if (level == 3) {
                            val seq = intArrayOf(voicing[0], voicing[2], voicing[1], voicing[2])
                            var b = 0.0; var i = 0
                            while (b < len - 1e-6) { ev(seq[i % 4], start + b, min(0.5, len - b), padEvents); b += 0.5; i++ }
                        } else {
                            var b = if (level == 1) 0.0 else 1.0
                            val step = if (level == 1) 2.0 else 2.0
                            while (b < len - 1e-6) { voicing.forEach { ev(it, start + b, min(1.0, len - b), padEvents) }; b += step }
                        }
                        ev(bassRoot, start, min(len, 2.0), bassEvents)
                        if (len > 2.0) ev(bassFifth, start + 2.0, min(len - 2.0, 2.0), bassEvents)
                    }
                    ArrangementStyle.CLASSICAL -> {
                        if (level == 1) voicing.forEach { ev(it, start, len, padEvents) }
                        else {
                            val seq = if (level == 2) intArrayOf(voicing[0], voicing[1], voicing[2], voicing[1])
                            else intArrayOf(voicing[0], voicing[2], voicing[1], voicing[2])
                            var b = 0.0; var i = 0
                            val step = if (level == 2) 0.5 else 0.25
                            while (b < len - 1e-6) { ev(seq[i % 4], start + b, min(step, len - b), padEvents); b += step; i++ }
                        }
                        ev(bassRoot, start, len, bassEvents)
                    }
                }
                offset += len
            }
        }

        val padInstrument = when (style) {
            ArrangementStyle.POP -> Instrument.PIANO
            ArrangementStyle.FOLK -> Instrument.ACOUSTIC_GUITAR
            ArrangementStyle.CLASSICAL -> Instrument.STRINGS
        }
        return listOf(
            Track("melody", "Melody", Instrument.LEAD, TrackRole.MELODY, source.notes, 0.9f),
            Track("harmony", "Harmony", padInstrument, TrackRole.HARMONY, padEvents, 0.7f),
            Track("bass", "Bass", Instrument.ELECTRIC_BASS, TrackRole.BASS, bassEvents, 0.8f),
        )
    }

    /** Closest inversion to the previous voicing, kept in a comfortable accompaniment register. */
    private fun voice(root: Int, tones: IntArray, prev: IntArray?): IntArray {
        val base = 48 + Math.floorMod(root, 12)
        val candidates = ArrayList<IntArray>()
        for (shift in intArrayOf(-12, 0)) {
            val pos = intArrayOf(base + tones[0] + shift, base + tones[1] + shift, base + tones[2] + shift)
            candidates.add(pos)
            candidates.add(intArrayOf(pos[1], pos[2], pos[0] + 12))
            candidates.add(intArrayOf(pos[2], pos[0] + 12, pos[1] + 12))
        }
        val inRange = candidates.filter { it.all { n -> n in 48..71 } }.ifEmpty { candidates }
        if (prev == null) return inRange.minByOrNull { abs(it.average() - 58.0) }!!.sortedArray()
        return inRange.minByOrNull { c -> c.sorted().zip(prev.sorted()).sumOf { (x, y) -> abs(x - y) } }!!.sortedArray()
    }

    @Suppress("unused")
    private fun unused(m: TempoMap) = m
}
