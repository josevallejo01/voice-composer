package com.voicecomposer.engine.ml

import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** A note decoded from the posteriorgrams, in model frames. */
data class MlNote(
    val startFrame: Int,
    /** Exclusive. */
    val endFrame: Int,
    val midi: Int,
    /** Mean note posterior over the note: how sure the network is that something is sung. */
    val meanActivation: Double,
    /** Onset posterior at the start of the note. */
    val onset: Double,
)

/**
 * Tunable decisions. The defaults were tuned against the real network on synthetic voices; [VoiceProfile] moves them
 * toward what works for one singer.
 */
data class DecoderParams(
    /**
     * Added to the log-score of silence; raise to detect fewer, more certain notes. Real voices excite the network less
     * than clean synthetic ones: at 0 only about half of the voiced time of two real recordings was transcribed, at
     * -0.85 (about the network's usual 0.3 frame threshold) about 78%, with 90% of the note time backed by an independent
     * pitch trace. Notes found on weak evidence get a low confidence and are flagged for review.
     */
    val restBias: Double = -0.85,
    /** Cost of changing pitch when there is no onset evidence. */
    val switchCost: Double = 6.0,
    val switchCostMin: Double = 1.5,
    val onsetGain: Double = 1.2,
    val toRestCost: Double = 1.0,
    /** An onset peak at least this high always starts a new note of the same pitch. */
    val strongOnset: Double = 0.78,
    /** A weaker onset peak starts a new note only together with an energy dip (vibrato makes weak onsets). */
    val weakOnset: Double = 0.45,
    val dipDb: Double = 4.0,
    val minNoteFrames: Int = 5,
    val minFramesBetweenOnsets: Int = 8,
    /** Optional log-prior per piano key (88 values) added to the pitch emission, e.g. the singer's usual range. */
    val keyLogPrior: DoubleArray? = null,
)

object NoteDecoder {
    private const val NEG = -1e18

    /**
     * Monophonic decoding. Singing is one note at a time, so instead of thresholding every key independently (which
     * produces harmonics and octave ghosts) a Viterbi search finds the single best path through
     * {silence, 88 keys}. Changing key is expensive unless the onset head agrees; the same key re-attacked is split
     * afterwards from onset peaks.
     *
     * [rmsDb] is the energy per frame on the same grid and is used to tell a re-sung note from vibrato.
     */
    fun decode(p: Posteriors, rmsDb: DoubleArray, params: DecoderParams = DecoderParams()): List<MlNote> {
        val t = p.frames
        if (t == 0) return emptyList()
        val s = BP.NOTES + 1 // 0 = silence, 1..88 = key + 1
        val back = ShortArray(t * s)
        var delta = DoubleArray(s) { NEG }
        var next = DoubleArray(s)
        delta[0] = 0.0
        val em = DoubleArray(s)
        val cost = DoubleArray(BP.NOTES)

        for (f in 0 until t) {
            var mx = 0.0
            for (k in 0 until BP.NOTES) {
                val v = clamp(p.note(f, k).toDouble(), 0.02, 0.995)
                if (v > mx) mx = v
                em[k + 1] = ln(v) + (params.keyLogPrior?.get(k) ?: 0.0)
            }
            em[0] = ln(clamp(1.0 - mx, 0.01, 1.0)) + params.restBias
            if (f == 0) {
                for (i in 0 until s) delta[i] += em[i]
                continue
            }
            var bestPrev = 0
            var bestVal = delta[0]
            for (i in 1 until s) if (delta[i] > bestVal) { bestVal = delta[i]; bestPrev = i }
            for (k in 0 until BP.NOTES) {
                val o = clamp(p.onset(f, k).toDouble(), 0.02, 0.995)
                val logit = ln(o / (1.0 - o))
                cost[k] = max(params.switchCostMin, params.switchCost - params.onsetGain * max(logit, 0.0))
            }
            for (i in 0 until s) { next[i] = delta[i]; back[f * s + i] = i.toShort() }
            for (k in 0 until BP.NOTES) {
                val i = k + 1
                val cand = bestVal - cost[k]
                if (bestPrev != i && cand > next[i]) { next[i] = cand; back[f * s + i] = bestPrev.toShort() }
            }
            val toRest = bestVal - params.toRestCost
            if (bestPrev != 0 && toRest > next[0]) { next[0] = toRest; back[f * s + 0] = bestPrev.toShort() }
            for (i in 0 until s) next[i] += em[i]
            val tmp = delta; delta = next; next = tmp
        }

        val path = IntArray(t)
        var last = 0
        var lv = delta[0]
        for (i in 1 until s) if (delta[i] > lv) { lv = delta[i]; last = i }
        path[t - 1] = last
        for (f in t - 1 downTo 1) path[f - 1] = back[f * s + path[f]].toInt()

        val notes = ArrayList<MlNote>()
        var f = 0
        while (f < t) {
            val state = path[f]
            var u = f
            while (u + 1 < t && path[u + 1] == state) u++
            if (state > 0 && u - f + 1 >= params.minNoteFrames) splitSegment(p, rmsDb, state - 1, f, u, params, notes)
            f = u + 1
        }
        return notes
    }

    private fun splitSegment(p: Posteriors, rms: DoubleArray, key: Int, a: Int, b: Int, prm: DecoderParams, out: MutableList<MlNote>) {
        val cuts = ArrayList<Int>()
        cuts.add(a)
        for (f in a + 4 until b - 3) {
            val o = p.onset(f, key)
            if (o < p.onset(f - 1, key) || o < p.onset(f + 1, key)) continue
            if (f - cuts.last() < prm.minFramesBetweenOnsets || b - f < prm.minNoteFrames) continue
            var dip = 0.0
            val preFrom = max(a, f - 14); val preTo = max(a + 1, f - 3)
            val postFrom = f + 2; val postTo = min(b + 1, f + 10)
            val midFrom = max(a, f - 3); val midTo = min(b + 1, f + 3)
            if (preTo > preFrom && postTo > postFrom && midTo > midFrom && postTo <= rms.size) {
                var preMax = -1e9; var postMax = -1e9; var midMin = 1e9
                for (i in preFrom until preTo) preMax = max(preMax, rms[i])
                for (i in postFrom until postTo) postMax = max(postMax, rms[i])
                for (i in midFrom until midTo) midMin = min(midMin, rms[i])
                dip = min(preMax, postMax) - midMin
            }
            if (o >= prm.strongOnset || (o >= prm.weakOnset && dip >= prm.dipDb)) cuts.add(f)
        }
        cuts.add(b + 1)
        for (i in 0 until cuts.size - 1) {
            val from = cuts[i]; val to = cuts[i + 1]
            var sum = 0.0
            for (f in from until to) sum += p.note(f, key)
            out.add(MlNote(from, to, key + BP.LOWEST_MIDI, sum / (to - from), p.onset(min(from + 1, p.frames - 1), key).toDouble()))
        }
    }

    private fun clamp(v: Double, lo: Double, hi: Double) = if (v < lo) lo else if (v > hi) hi else v
}

/** Energy per frame (dB) of 22.05 kHz audio on the same grid as [Posteriors]. */
object FrameEnergy {
    fun rmsDb(audio: FloatArray, frames: Int): DoubleArray {
        val out = DoubleArray(frames)
        for (g in 0 until frames) {
            val c = g * BP.HOP
            val from = max(0, c - 256)
            val to = min(audio.size, c + 256)
            var acc = 0.0
            for (i in from until to) acc += audio[i].toDouble() * audio[i]
            val n = max(1, to - from)
            out[g] = 10.0 * kotlin.math.log10(acc / n + 1e-10)
        }
        return out
    }
}

