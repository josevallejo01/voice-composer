package com.voicecomposer.engine.score

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.rhythm.MeterEstimate
import com.voicecomposer.engine.rhythm.TempoEstimate
import com.voicecomposer.engine.rhythm.TempoEstimator
import com.voicecomposer.engine.segmentation.DetectedNote
import com.voicecomposer.model.EventSource
import com.voicecomposer.model.EventType
import com.voicecomposer.model.Ids
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TempoPoint
import com.voicecomposer.model.TimeSignature
import com.voicecomposer.model.TranscriptionEditor
import kotlin.math.floor
import kotlin.math.max

class ScoreResult(
    val tempo: TempoEstimate,
    val meter: MeterEstimate,
    val key: KeySignature,
    val events: List<MusicalEvent>,
    /** Indices (in time order) of notes whose rhythmic position the forest was not sure about. */
    val uncertain: Set<Int>,
)

/**
 * Everything in the score after note detection, decided by the learned models in sequence: tempo and phase, steady or
 * followed tempo, meter and bar lines, rhythmic positions, written lengths, key. Returns null when the models are not
 * all present or the melody is too short (fewer than four notes): the caller then uses the rule-based pipeline.
 */
object MlScorePipeline {
    private fun margin(best: Double, second: Double): Double = ((best - second) / (best + 1e-9)).coerceIn(0.0, 1.0)

    /** Moves beat 0 of [map] to the old beat [b] (which may be negative or beyond the first point). */
    fun shiftMap(map: TempoMap, b: Double): TempoMap {
        if (map.isConstant) return TempoMap.constant(map.tailBpm, map.beatToSec(b))
        val pts = ArrayList<TempoPoint>()
        pts.add(TempoPoint(0.0, map.beatToSec(b)))
        for (p in map.points) if (p.beat - b > 1e-6) pts.add(TempoPoint(p.beat - b, p.timeSec))
        return TempoMap(pts, map.tailBpm)
    }

    fun run(detected: List<DetectedNote>, config: AnalysisConfig, m: ScoreModels): ScoreResult? {
        if (!m.complete) return null
        val notes = detected.sortedBy { it.startSec }
        if (notes.size < 4) return null
        val t = DoubleArray(notes.size) { notes[it].startSec }
        val midi = IntArray(notes.size) { notes[it].midi }

        // 1. tempo and beat phase
        val cands = TempoPhase.candidates(t, config.forcedBpm, config.beatOriginHintSec)
        if (cands.isEmpty()) return null
        val probs = cands.map { m.tempo!!.probability(it.features) }
        val order = probs.indices.sortedByDescending { probs[it] }
        val best = cands[order[0]]
        val tempoConf = (probs[order[0]] * (0.5 + 0.5 * margin(probs[order[0]], probs.getOrElse(order.getOrElse(1) { 0 }) { 0.0 }))).coerceIn(0.05, 1.0)
        var map = TempoMap.constant(best.bpm, best.originSec)

        // 2. steady tempo or followed tempo
        var changes = false
        if (m.drift != null && config.forcedBpm == null) {
            val tracked = TempoEstimator.track(t.toList(), best.bpm, 0.0).map
            if (!tracked.isConstant && m.drift.probability(DriftModel.features(t, map, tracked)) >= 0.5) { map = tracked; changes = true }
        }

        // 3. meter and bar lines
        val r = DoubleArray(notes.size) { map.secToBeat(t[it]) }
        val durB = DoubleArray(notes.size) { max(0.05, map.secToBeat(notes[it].endSec) - map.secToBeat(notes[it].startSec)) }
        val hyps = BarModel.hypotheses(r, durB, midi, config.forcedTimeSignature)
        if (hyps.isEmpty()) return null
        val hp = hyps.map { m.bar!!.probability(it.features) }
        val ho = hp.indices.sortedByDescending { hp[it] }
        val hyp = hyps[ho[0]]
        val meter: TimeSignature = hyp.meter
        val meterConf = (hp[ho[0]] * (0.5 + 0.5 * margin(hp[ho[0]], hp.getOrElse(ho.getOrElse(1) { 0 }) { 0.0 }))).coerceIn(0.05, 1.0)
        val bpb = meter.beatsPerMeasure
        // Beat 0 is the bar line at or before the first note; a pick-up shows as a leading rest.
        val bar = hyp.offsetBeats + bpb * floor((r[0] - hyp.offsetBeats) / bpb)
        map = shiftMap(map, bar)

        // 4. rhythm
        val bpm = map.averageBpm
        val raw = DoubleArray(notes.size) { max(0.0, map.secToBeat(t[it])) }
        val rawEnd = DoubleArray(notes.size) { max(raw[it] + 0.05, map.secToBeat(notes[it].endSec)) }
        val mode = config.quantization
        val slots: IntArray; val prob: DoubleArray; val durSlots: IntArray
        if (mode == QuantizationMode.FREE) {
            slots = IntArray(notes.size) { Math.round(raw[it] / 0.25).toInt() }; prob = DoubleArray(notes.size) { 1.0 }
            durSlots = IntArray(notes.size) { 1 }
        } else {
            val pl = OnsetModel.place(OnsetModel.Ctx(raw, DoubleArray(notes.size) { rawEnd[it] - raw[it] }, bpm, meter), m.onset!!)
            slots = pl.slots; prob = pl.prob
            val dctx = DurationModel.Ctx(raw, rawEnd, slots, bpm, meter)
            durSlots = IntArray(notes.size) { DurationModel.choose(dctx, it, m.duration!!) }
        }

        val events = notes.mapIndexed { i, n ->
            val e = MusicalEvent(
                id = Ids.newId("n"), type = EventType.NOTE, midiPitch = n.midi, frequencyHz = Pitch.midiToHz(n.pitch),
                startSec = n.startSec, endSec = n.endSec, startBeat = 0.0, durationBeats = 0.0,
                confidence = (n.confidence * (0.6 + 0.4 * n.stability)).coerceIn(0.0, 1.0),
                source = EventSource.DETECTED,
            )
            val base = TranscriptionEditor.requantize(e, map, mode)
            when (mode) {
                QuantizationMode.FREE -> base
                QuantizationMode.AUTOMATIC -> base.copy(startBeat = slots[i] * 0.25, durationBeats = durSlots[i] * 0.25)
                QuantizationMode.SOFT -> {
                    val s = (raw[i] + slots[i] * 0.25) / 2
                    val en = (rawEnd[i] + (slots[i] + durSlots[i]) * 0.25) / 2
                    base.copy(startBeat = s, durationBeats = max(0.25, en - s))
                }
            }
        }

        // 5. key
        val kc = KeyModel.candidates(midi, DoubleArray(notes.size) { events[it].durationBeats })
        val kp = kc.map { m.key!!.probability(it.features) }
        val ko = kp.indices.sortedByDescending { kp[it] }
        val kBest = kc[ko[0]].key
        val keyConf = (kp[ko[0]] * (0.5 + 0.5 * margin(kp[ko[0]], kp[ko[1]]))).coerceIn(0.05, 1.0)
        val key = KeySignature(kBest.tonic, kBest.mode, keyConf)

        val tempo = TempoEstimate(map, map.averageBpm, tempoConf, changes)
        val uncertain = prob.indices.filter { prob[it] < 0.4 }.toSet()
        return ScoreResult(tempo, MeterEstimate(meter, meterConf), key, events, uncertain)
    }
}
