package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisCancelled
import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.AnalysisResult
import com.voicecomposer.engine.AnalysisWarning
import com.voicecomposer.engine.DefaultTranscriptionEngine
import com.voicecomposer.engine.PostNotePipeline
import com.voicecomposer.engine.Stage
import com.voicecomposer.engine.TranscriptionEngine
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.pitch.OctaveCorrector
import com.voicecomposer.engine.pitch.PitchFrame
import com.voicecomposer.engine.pitch.YinPitchTracker
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.preprocessing.Preprocessor
import com.voicecomposer.engine.preprocessing.Resampler
import com.voicecomposer.engine.segmentation.DetectedNote
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Neural front end: Basic Pitch posteriorgrams -> monophonic Viterbi decoding -> notes, then the same tempo / rhythm /
 * key pipeline as the classical engine.
 *
 * Where the neural net is strong (which note, when it starts) it decides; where classical DSP is more precise (exact
 * pitch in cents, used for tuning and display) YIN refines. If the model cannot run (no runtime, out of memory,
 * unsupported device) the engine falls back to [fallback] and says so in [AnalysisWarning]-free fashion through
 * [lastRunUsedFallback].
 */
class MlTranscriptionEngine(
    private val model: BasicPitchModel,
    private val fallback: TranscriptionEngine = DefaultTranscriptionEngine(),
    /** Per-key log-prior supplier (singer profile); null for none. */
    private val keyPrior: () -> DoubleArray? = { null },
    /** Clean the signal (DC, rumble, level) before the network. */
    private val cleanForModel: Boolean = true,
    /**
     * Note classifier per kind of sound (shipped random forest, possibly blended with the singer's own). When it returns
     * null the hand-written validation rules decide instead.
     */
    private val classifier: (InputType) -> NoteClassifier? = { null },
    /** Learned score decisions (tempo, meter, rhythm, key); null -> hand-written rules. */
    private val scoreModels: () -> com.voicecomposer.engine.score.ScoreModels? = { null },
    /** Joins the pieces of one note that the detector cut in two (voice wander); null -> notes stay as decoded. */
    private val merger: (InputType) -> RandomForest? = { null },
) : TranscriptionEngine {
    override val version = "ml-2.0"

    /** The classifier in force for this kind of sound (shipped forest, possibly blended with the singer's own), or null. */
    fun classifierFor(type: InputType): NoteClassifier? = classifier(type)

    @Volatile var lastRunUsedFallback = false
        private set
    @Volatile var lastFailure: String? = null
        private set

    override fun analyze(
        audio: AudioBuffer,
        config: AnalysisConfig,
        onProgress: (Stage, Float) -> Unit,
        isCancelled: () -> Boolean,
    ): AnalysisResult {
        lastRunUsedFallback = false
        return try {
            analyzeMl(audio, config, onProgress, isCancelled)
        } catch (c: AnalysisCancelled) {
            throw c
        } catch (e: Throwable) {
            if (e is OutOfMemoryError || e is Exception || e is LinkageError) {
                lastRunUsedFallback = true
                lastFailure = "${e.javaClass.simpleName}: ${e.message ?: "no message"}".take(200)
                val r = fallback.analyze(audio, config, onProgress, isCancelled)
                // Never hide that the neural model did not run: the user sees it, and so can a bug report.
                val a = r.transcription.analysis
                r.copy(transcription = r.transcription.copy(analysis = a?.copy(warnings = a.warnings + "NEURAL_FAILED:$lastFailure")))
            } else throw e
        }
    }

    /** Everything the network and the DSP produce for one recording, before any decision is taken on it. */
    class Prepared(
        val post: Posteriors,
        val rms: DoubleArray,
        val frames: List<PitchFrame>,
        val detune: Double,
        val timeScale: Double,
        val quality: com.voicecomposer.engine.preprocessing.SignalQuality,
        val warnings: List<AnalysisWarning>,
        val inputType: InputType,
        /** The (cleaned, detune-shifted) 22.05 kHz signal the network saw; spectral features are measured on it. */
        val audio: FloatArray = FloatArray(0),
    )

    /** One candidate note with the evidence the classifier sees, and what the hand-written rules would say about it. */
    class Candidate(val note: DetectedNote, val features: DoubleArray, val keepByRules: Boolean)

    private fun analyzeMl(
        audio: AudioBuffer,
        config: AnalysisConfig,
        onProgress: (Stage, Float) -> Unit,
        isCancelled: () -> Boolean,
    ): AnalysisResult {
        val p = prepare(audio, config, onProgress, isCancelled)
        onProgress(Stage.SEGMENTATION, 0f)
        val detected = detect(p, config)
        onProgress(Stage.SEGMENTATION, 1f)
        if (isCancelled()) throw AnalysisCancelled()
        val ver = if (classifier(config.inputType) != null) "$version-rf" else version
        return PostNotePipeline.run(detected, config, p.quality, p.warnings.toMutableList(), ver, onProgress, isCancelled, scoreModels())
    }

    /** Runs the DSP pass and the network once; [detect] can then be repeated with other parameters (calibration). */
    fun prepare(
        audio: AudioBuffer,
        config: AnalysisConfig,
        onProgress: (Stage, Float) -> Unit = { _, _ -> },
        isCancelled: () -> Boolean = { false },
    ): Prepared {
        fun check() { if (isCancelled()) throw AnalysisCancelled() }
        val warnings = ArrayList<AnalysisWarning>()
        val quality = Preprocessor.analyzeQuality(audio.samples, audio.sampleRate)
        if (quality.tooQuiet) warnings.add(AnalysisWarning.TOO_QUIET)
        if (quality.clipped) warnings.add(AnalysisWarning.CLIPPING)
        if (quality.durationSec < 0.5) warnings.add(AnalysisWarning.TOO_SHORT)

        onProgress(Stage.PREPROCESSING, 0f)
        var samples = audio.samples
        if (quality.durationSec > config.maxDurationSec) {
            warnings.add(AnalysisWarning.TOO_LONG)
            samples = samples.copyOf((config.maxDurationSec * audio.sampleRate).toInt())
        }

        // 1. Cheap DSP pass at 16 kHz: pitch frames for fine tuning, and the singer's detuning for the pre-shift.
        val dsp = Resampler.resample(samples, audio.sampleRate, DefaultTranscriptionEngine.ANALYSIS_RATE)
        val clean = Preprocessor.process(dsp, DefaultTranscriptionEngine.ANALYSIS_RATE, config.inputType)
        onProgress(Stage.PREPROCESSING, 1f)
        check()
        onProgress(Stage.PITCH, 0f)
        val yin = YinPitchTracker(DefaultTranscriptionEngine.ANALYSIS_RATE, config.inputType)
        val frames = OctaveCorrector.correct(yin.track(clean, { onProgress(Stage.PITCH, it * 0.2f) }, isCancelled))
        check()
        val detune = if (config.tuningCompensation) estimateDetune(frames) else 0.0

        // 2. Neural pass at 22.05 kHz, shifted so that the singer's own tuning lands on the equal-tempered grid.
        val ratio = 2.0.pow(-detune / 12.0) // pitch factor applied by resampling
        val base0 = Resampler.resample(samples, audio.sampleRate, BP.SAMPLE_RATE)
        val base = if (cleanForModel) Preprocessor.process(base0, BP.SAMPLE_RATE, config.inputType) else base0
        val shifted = if (abs(detune) >= SHIFT_MIN_SEMITONES) shiftPitch(base, ratio) else base
        val timeScale = if (shifted === base) 1.0 else ratio
        val post = BasicPitchRunner.run(shifted, model, { onProgress(Stage.PITCH, 0.2f + 0.8f * it) }, isCancelled)
        onProgress(Stage.PITCH, 1f)
        check()
        val rms = FrameEnergy.rmsDb(shifted, post.frames)
        return Prepared(post, rms, frames, if (shifted === base) 0.0 else detune, timeScale, quality, warnings, config.inputType, shifted)
    }

    /**
     * Decoding and validation: network posteriors -> notes. Besides the Viterbi decoder this
     *  - repairs octave errors using the independent pitch trace,
     *  - drops what is not a pitched sound (no periodicity, below the room's noise floor, too short),
     *  - for whistling adds notes the pitch trace is sure about and the network missed.
     */
    fun detect(p: Prepared, config: AnalysisConfig, params: DecoderParams? = null, classifierOverride: NoteClassifier? = null, merge: Boolean = true): List<DetectedNote> {
        val base = params ?: config.decoder ?: DecoderParams.forInput(p.inputType)
        val prm = if (base.keyLogPrior == null) base.copy(keyLogPrior = keyPrior()) else base
        val kept = detectKept(p, config, prm, classifierOverride)
        val forest = if (merge) merger(p.inputType) else null
        var out = if (forest != null) NoteMerger.merge(kept, p, forest) else kept.map { it.second }
        if (p.inputType == InputType.WHISTLING && prm.fuseDsp) out = fuseWithDsp(out, p, config)
        return out
    }

    /** The notes that survive the note classifier, each with the candidate (evidence) it came from; before any joining. */
    fun detectKept(p: Prepared, config: AnalysisConfig, prm: DecoderParams, classifierOverride: NoteClassifier? = null): List<Pair<Candidate, DetectedNote>> {
        val clf = classifierOverride ?: classifier(p.inputType)
        return if (clf == null) {
            select(toCandidates(NoteDecoder.decode(p.post, p.rms, prm), p, prm).filter { it.keepByRules }, prm)
        } else {
            val all = candidates(p, config, prm)
            config.candidateSink?.invoke(all)
            val keep = all.filter { clf.probability(it.features) >= prm.rfThreshold }
            select(keep, prm, clf)
        }
    }

    /**
     * Permissive decoding (little silence bias, short notes allowed) so that the classifier, not the decoder, decides
     * what is a note. Used both for detection and to build training rows.
     */
    fun candidates(p: Prepared, config: AnalysisConfig, params: DecoderParams? = null): List<Candidate> {
        val base = params ?: config.decoder ?: DecoderParams.forInput(p.inputType)
        val prm = if (base.keyLogPrior == null) base.copy(keyLogPrior = keyPrior()) else base
        val loose = prm.copy(restBias = min(prm.restBias, PERMISSIVE_REST_BIAS), minNoteFrames = min(prm.minNoteFrames, 4), minNoteSec = min(prm.minNoteSec, 0.05))
        val decoded = NoteDecoder.decode(p.post, p.rms, loose)
        return toCandidates(withDspNotes(decoded, p, config), p, prm)
    }

    /**
     * Notes the classical pitch trace sees where the network decoded nothing (typically very high whistles the network
     * only half hears). They enter as ordinary candidates, with the network's own (low) activation at that key, and the
     * classifier decides from the independent evidence.
     */
    private fun withDspNotes(decoded: List<MlNote>, p: Prepared, config: AnalysisConfig): List<MlNote> {
        val extra = ArrayList<MlNote>()
        val dsp = com.voicecomposer.engine.segmentation.NoteSegmenter().segment(p.frames, config.tuningCompensation)
        for (d in dsp) {
            if (d.endSec - d.startSec < 0.08) continue
            val sf = ((d.startSec / p.timeScale) * BP.FPS + ONSET_DELAY_SEC * BP.FPS).toInt().coerceIn(0, max(0, p.post.frames - 1))
            val ef = ((d.endSec / p.timeScale) * BP.FPS).toInt().coerceIn(sf + 1, p.post.frames)
            val dur = ef - sf
            val covered = decoded.sumOf { max(0, min(it.endFrame, ef) - max(it.startFrame, sf)) }
            if (covered > 0.3 * dur) continue
            val midi = Math.round(d.pitch - p.detune).toInt()
            if (midi !in 21..108) continue
            val key = midi - BP.LOWEST_MIDI
            var act = 0.0; var on = 0.0
            for (f in sf until ef) { act += p.post.note(f, key); on = max(on, p.post.onset(f, key).toDouble()) }
            extra.add(MlNote(sf, ef, midi, act / dur, on))
        }
        if (extra.isEmpty()) return decoded
        return (decoded + extra).sortedBy { it.startFrame }
    }

    private fun select(cands: List<Candidate>, prm: DecoderParams, clf: NoteClassifier? = null): List<Pair<Candidate, DetectedNote>> {
        val out = ArrayList<Pair<Candidate, DetectedNote>>(cands.size)
        for (c in cands) {
            var n = c.note
            val prev = out.lastOrNull()
            if (prev != null && n.startSec < prev.second.endSec) out[out.size - 1] = prev.first to prev.second.copy(endSec = max(prev.second.startSec + 0.03, n.startSec))
            if (clf != null) {
                val pr = clf.probability(c.features)
                var conf = 0.6 * pr + 0.4 * n.confidence
                if (pr < prm.rfThreshold + 0.15) conf = min(conf, 0.5)
                n = n.copy(confidence = conf.coerceIn(0.0, 1.0))
            }
            if (n.midi + prm.pitchOffset !in 21..108) continue
            out.add(c to n.copy(midi = n.midi + prm.pitchOffset, pitch = n.pitch + prm.pitchOffset))
        }
        return out
    }

    private fun fuseWithDsp(ml: List<DetectedNote>, p: Prepared, config: AnalysisConfig): List<DetectedNote> {
        val extra = com.voicecomposer.engine.segmentation.NoteSegmenter().segment(p.frames, config.tuningCompensation)
            .filter { d ->
                d.endSec - d.startSec >= 0.12 && d.confidence >= 0.7 &&
                    ml.none { m -> minOf(m.endSec, d.endSec) - maxOf(m.startSec, d.startSec) > 0.3 * (d.endSec - d.startSec) }
            }
            .map { it.copy(confidence = it.confidence * 0.7) } // a single witness: shown, but flagged for review
        return (ml + extra).sortedBy { it.startSec }
    }

    /**
     * Median detuning (in semitones, -0.5..0.5) of the voiced frames, or 0 when the singer is not consistently off
     * the grid (then there is nothing to compensate).
     */
    internal fun estimateDetune(frames: List<PitchFrame>): Double {
        val v = frames.filter { it.voiced && it.confidence >= 0.8 }
        if (v.size < 40) return 0.0
        var sx = 0.0; var sy = 0.0
        for (f in v) { val th = 2 * PI * (f.midi - Math.floor(f.midi)); sx += cos(th); sy += sin(th) }
        val r = sqrt(sx * sx + sy * sy) / v.size
        if (r < 0.5) return 0.0
        return atan2(sy, sx) / (2 * PI)
    }

    /** Multiplies every frequency by [factor] (and compresses time by the same factor; callers map times back). */
    private fun shiftPitch(x: FloatArray, factor: Double): FloatArray {
        // The resampler only uses the ratio of the two rates. 22 050 * 100 000 overflows Int (this used to throw or
        // silently resample by a wrong ratio for detuned voices), so keep the rates well inside the Int range.
        val scale = 10_000L
        val to = BP.SAMPLE_RATE * scale
        return Resampler.resample(x, (to * factor).roundToInt().coerceAtLeast(1), to.toInt())
    }

    /**
     * Neural notes -> candidates. Start times are corrected for the onset head's measured delay; the exact pitch
     * comes from the median of the YIN frames inside the note (when they agree with the decoded key within 1.5
     * semitones), otherwise from the neural contour. Every candidate carries its feature vector, plus whether the
     * hand-written rules (noise-floor gate, periodicity, duration) would keep it.
     */
    private fun toCandidates(notes: List<MlNote>, p: Prepared, prm: DecoderParams): List<Candidate> {
        if (notes.isEmpty()) return emptyList()
        val post = p.post; val rms = p.rms; val yin = p.frames; val timeScale = p.timeScale; val detune = p.detune
        val hop = if (yin.size > 1) yin[1].timeSec - yin[0].timeSec else 0.01
        // Noise floor of this recording: the quiet 10% of frames. Only trusted when the recording really has quiet parts.
        val sorted = rms.sortedArray()
        val floorDb = if (sorted.isEmpty()) -120.0 else sorted[(sorted.size * 0.10).toInt()]
        val topDb = if (sorted.isEmpty()) 0.0 else sorted[(sorted.size * 0.90).toInt()]
        val dyn = topDb - floorDb
        val gateOn = prm.gateMarginDb < 90 && dyn >= 15.0
        val out = ArrayList<Candidate>(notes.size)
        val typeX = DoubleArray(3); NoteFeatures.typeOneHot(p.inputType, typeX, 0)
        for (n in notes) {
            val startSec = max(0.0, (n.startFrame / BP.FPS - ONSET_DELAY_SEC) * timeScale)
            val endSec = max(startSec + 0.03, n.endFrame / BP.FPS * timeScale - END_ADVANCE_SEC)
            val dur = endSec - startSec
            var level = 0.0
            val lf = n.startFrame; val lt = min(n.endFrame, rms.size)
            for (f in lf until lt) level += rms[f]
            level /= max(1, lt - lf)
            var keep = dur >= prm.minNoteSec
            if (gateOn && level < floorDb + prm.gateMarginDb) keep = false

            // YIN frames of the note (original time axis); the detune is subtracted to land on the shifted grid.
            val a = ((startSec + 0.02) / hop).toInt().coerceIn(0, yin.size)
            val b = ((endSec - 0.01) / hop).toInt().coerceIn(a, yin.size)
            fun support(key: Int): ArrayList<Double> {
                val ys = ArrayList<Double>()
                for (k in a until b) {
                    val f = yin[k]
                    if (f.voiced && f.confidence >= 0.6) {
                        val m = f.midi - detune
                        if (abs(m - key) <= 1.5) ys.add(m)
                    }
                }
                return ys
            }
            val total = max(1, b - a)
            var midi = n.midi
            var ys = support(midi)
            var supportFrac = ys.size.toDouble() / total
            if (b - a >= 4 && supportFrac < 0.25) {
                // The network may have locked on a harmonic or an octave ghost: if the pitch trace clearly sits an octave
                // (or a fifth plus an octave) away, trust the trace.
                for (shift in intArrayOf(-12, 12, -19, 19)) {
                    val alt = support(midi + shift)
                    if (midi + shift in 21..108 && alt.size.toDouble() / total >= 0.6) { midi += shift; ys = alt; supportFrac = alt.size.toDouble() / total; break }
                }
            }
            if (b - a >= 4 && supportFrac < prm.dropSupport) keep = false // no periodicity: breath, click, rumble
            var pitch = midi.toDouble()
            var stability = 0.7
            var sd = 1.0
            var delta = 1.5
            if (ys.size >= 3) {
                ys.sort()
                pitch = ys[ys.size / 2]
                val mean = ys.average()
                sd = sqrt(ys.sumOf { (it - mean) * (it - mean) } / ys.size)
                stability = (1.0 - sd / 0.6).coerceIn(0.0, 1.0)
                delta = abs(pitch - midi)
            } else if (midi == n.midi) {
                contourPitch(post, n)?.let { pitch = it }
            }
            if (abs(pitch - midi) > 0.7) pitch = midi.toDouble()
            // Confidence: how sure the network is (activation + onset) and how many frames agree with it.
            var conf = (0.55 * n.meanActivation + 0.2 * min(1.0, n.onset * 1.5) + 0.25 * supportFrac).coerceIn(0.0, 1.0)
            if (b - a >= 4 && supportFrac < prm.flagSupport) conf = min(conf, 0.5)
            if (midi !in 21..108) continue
            val note = DetectedNote(startSec, endSec, midi, pitch, conf, stability, level)

            // ---- features ----
            val key = midi - BP.LOWEST_MIDI
            var maxAct = 0.0; var otherSum = 0.0
            for (f in n.startFrame until min(n.endFrame, post.frames)) {
                maxAct = max(maxAct, post.note(f, key).toDouble())
                var o = 0.0
                for (k in 0 until BP.NOTES) if (abs(k - key) >= 1) o = max(o, post.note(f, k).toDouble())
                otherSum += o
            }
            val nf = max(1, min(n.endFrame, post.frames) - n.startFrame)
            val other = otherSum / nf
            val dominance = n.meanActivation / (n.meanActivation + other + 1e-6)
            var voiced = 0; var confSum = 0.0
            for (k in a until b) { val f = yin[k]; if (f.voiced && f.confidence >= 0.6) voiced++; confSum += f.confidence }
            var octAlt = 0.0
            if (b - a >= 4) for (shift in intArrayOf(-12, 12, -19, 19)) if (midi + shift in 21..108) octAlt = max(octAlt, support(midi + shift).size.toDouble() / total)
            // Level of the room right around the note: quiet 10% of the frames within +-1 s.
            val w0 = max(0, lf - 86); val w1 = min(rms.size, lt + 86)
            val local = if (w1 > w0) rms.copyOfRange(w0, w1).also { it.sort() } else DoubleArray(1) { floorDb }
            val localFloor = local[(local.size * 0.10).toInt()]
            val f0 = 440.0 * 2.0.pow((midi - 69) / 12.0)
            val sp = NoteFeatures.spectral(p.audio, n.startFrame * BP.HOP, n.endFrame * BP.HOP, f0)
            out.add(Candidate(note, DoubleArray(NoteFeatures.DIM).also { x ->
                x[0] = min(2.0, dur); x[1] = n.meanActivation; x[2] = maxAct; x[3] = n.onset; x[4] = dominance
                x[5] = supportFrac; x[6] = voiced.toDouble() / total; x[7] = confSum / total; x[8] = min(1.0, sd)
                x[9] = ((level - floorDb) / 30.0).coerceIn(-1.0, 2.0); x[10] = ((topDb - level) / 30.0).coerceIn(-1.0, 2.0)
                x[11] = (dyn / 60.0).coerceIn(0.0, 2.0); x[12] = ((level - localFloor) / 30.0).coerceIn(-1.0, 2.0)
                x[13] = sp.zcr; x[14] = sp.flatness; x[15] = sp.centroidRatio; x[16] = sp.harmonicity; x[17] = sp.f0Frac
                x[18] = midi / 100.0; x[22] = octAlt; x[23] = min(1.5, delta)
                System.arraycopy(typeX, 0, x, 24, 3)
            }, keep))
        }
        // Neighbour context: interval from the previous candidate and silences around each one.
        for (i in out.indices) {
            val x = out[i].features; val c = out[i].note
            val prev = out.getOrNull(i - 1)?.note; val next = out.getOrNull(i + 1)?.note
            x[19] = if (prev == null) 0.0 else NoteFeatures.clampInterval((c.midi - prev.midi).toDouble())
            x[20] = if (prev == null) 2.0 else NoteFeatures.clampGap(c.startSec - prev.endSec)
            x[21] = if (next == null) 2.0 else NoteFeatures.clampGap(next.startSec - c.endSec)
        }
        return out
    }

    /** Centroid of the 3-bins-per-semitone contour around the note's key; null when the contour is empty there. */
    private fun contourPitch(p: Posteriors, n: MlNote): Double? {
        val center = (n.midi - BP.LOWEST_MIDI) * 3
        var sw = 0.0; var sb = 0.0
        for (f in n.startFrame until min(n.endFrame, p.frames)) {
            for (bin in max(0, center - 4)..min(BP.CONTOUR_BINS - 1, center + 4)) {
                val w = p.contour(f, bin).toDouble()
                if (w > 0.1) { sw += w; sb += w * bin }
            }
        }
        if (sw < 1.0) return null
        return BP.LOWEST_MIDI + sb / sw / 3.0
    }

    companion object {
        /** The onset head peaks about this long after the true attack (measured against synthetic voices). */
        const val ONSET_DELAY_SEC = 0.010
        const val END_ADVANCE_SEC = 0.0
        const val SHIFT_MIN_SEMITONES = 0.25
        const val PERMISSIVE_REST_BIAS = -1.5
    }
}
