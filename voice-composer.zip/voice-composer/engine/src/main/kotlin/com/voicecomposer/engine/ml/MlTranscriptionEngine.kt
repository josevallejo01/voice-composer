package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisCancelled
import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.AnalysisResult
import com.voicecomposer.engine.AnalysisWarning
import com.voicecomposer.engine.DefaultTranscriptionEngine
import com.voicecomposer.engine.PostNotePipeline
import com.voicecomposer.engine.Stage
import com.voicecomposer.engine.TranscriptionEngine
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.pitch.OctaveCorrector
import com.voicecomposer.engine.pitch.PitchFrame
import com.voicecomposer.engine.pitch.YinPitchTracker
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.preprocessing.Preprocessor
import com.voicecomposer.engine.preprocessing.Resampler
import com.voicecomposer.engine.segmentation.DetectedNote
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Neural front end: Basic Pitch posteriorgrams -> monophonic Viterbi decoding -> notes, then the same tempo / rhythm /
 * key pipeline as the classical engine.
 *
 * Where the neural net is strong (which note, when it starts) it decides; where classical DSP is more precise (exact
 * pitch in cents, used for tuning and display) YIN refines. If the model cannot run (no runtime, out of memory,
 * unsupported device) the engine falls back to [fallback] and says so in [AnalysisWarning]-free fashion through
 * [lastRunUsedFallback].
 */
class MlTranscriptionEngine(
    private val model: BasicPitchModel,
    private val fallback: TranscriptionEngine = DefaultTranscriptionEngine(),
    /** Per-key log-prior supplier (singer profile); null for none. */
    private val keyPrior: () -> DoubleArray? = { null },
    /** Clean the signal (DC, rumble, level) before the network. */
    private val cleanForModel: Boolean = true,
) : TranscriptionEngine {
    override val version = "ml-1.0"

    @Volatile var lastRunUsedFallback = false
        private set
    @Volatile var lastFailure: String? = null
        private set

    override fun analyze(
        audio: AudioBuffer,
        config: AnalysisConfig,
        onProgress: (Stage, Float) -> Unit,
        isCancelled: () -> Boolean,
    ): AnalysisResult {
        lastRunUsedFallback = false
        return try {
            analyzeMl(audio, config, onProgress, isCancelled)
        } catch (c: AnalysisCancelled) {
            throw c
        } catch (e: Throwable) {
            if (e is OutOfMemoryError || e is Exception || e is LinkageError) {
                lastRunUsedFallback = true
                lastFailure = "${e.javaClass.simpleName}: ${e.message ?: "no message"}".take(200)
                val r = fallback.analyze(audio, config, onProgress, isCancelled)
                // Never hide that the neural model did not run: the user sees it, and so can a bug report.
                val a = r.transcription.analysis
                r.copy(transcription = r.transcription.copy(analysis = a?.copy(warnings = a.warnings + "NEURAL_FAILED:$lastFailure")))
            } else throw e
        }
    }

    private fun analyzeMl(
        audio: AudioBuffer,
        config: AnalysisConfig,
        onProgress: (Stage, Float) -> Unit,
        isCancelled: () -> Boolean,
    ): AnalysisResult {
        fun check() { if (isCancelled()) throw AnalysisCancelled() }
        val warnings = ArrayList<AnalysisWarning>()
        val quality = Preprocessor.analyzeQuality(audio.samples, audio.sampleRate)
        if (quality.tooQuiet) warnings.add(AnalysisWarning.TOO_QUIET)
        if (quality.clipped) warnings.add(AnalysisWarning.CLIPPING)
        if (quality.durationSec < 0.5) warnings.add(AnalysisWarning.TOO_SHORT)

        onProgress(Stage.PREPROCESSING, 0f)
        var samples = audio.samples
        if (quality.durationSec > config.maxDurationSec) {
            warnings.add(AnalysisWarning.TOO_LONG)
            samples = samples.copyOf((config.maxDurationSec * audio.sampleRate).toInt())
        }

        // 1. Cheap DSP pass at 16 kHz: pitch frames for fine tuning, and the singer's detuning for the pre-shift.
        val dsp = Resampler.resample(samples, audio.sampleRate, DefaultTranscriptionEngine.ANALYSIS_RATE)
        val clean = Preprocessor.process(dsp, DefaultTranscriptionEngine.ANALYSIS_RATE, config.inputType)
        onProgress(Stage.PREPROCESSING, 1f)
        check()
        onProgress(Stage.PITCH, 0f)
        val yin = YinPitchTracker(DefaultTranscriptionEngine.ANALYSIS_RATE, config.inputType)
        val frames = OctaveCorrector.correct(yin.track(clean, { onProgress(Stage.PITCH, it * 0.2f) }, isCancelled))
        check()
        val detune = if (config.tuningCompensation) estimateDetune(frames) else 0.0

        // 2. Neural pass at 22.05 kHz, shifted so that the singer's own tuning lands on the equal-tempered grid.
        val ratio = 2.0.pow(-detune / 12.0) // pitch factor applied by resampling
        val base0 = Resampler.resample(samples, audio.sampleRate, BP.SAMPLE_RATE)
        val base = if (cleanForModel) Preprocessor.process(base0, BP.SAMPLE_RATE, config.inputType) else base0
        val shifted = if (abs(detune) >= SHIFT_MIN_SEMITONES) shiftPitch(base, ratio) else base
        val timeScale = if (shifted === base) 1.0 else ratio
        val post = BasicPitchRunner.run(
            shifted, model,
            { onProgress(Stage.PITCH, 0.2f + 0.8f * it) }, isCancelled,
        )
        onProgress(Stage.PITCH, 1f)
        check()

        onProgress(Stage.SEGMENTATION, 0f)
        val rms = FrameEnergy.rmsDb(shifted, post.frames)
        val prm = config.decoder.let { if (it.keyLogPrior == null) it.copy(keyLogPrior = keyPrior()) else it }
        val mlNotes = NoteDecoder.decode(post, rms, prm)
        val appliedOffset = if (shifted === base) 0.0 else detune
        val detected = toDetected(mlNotes, post, rms, frames, timeScale, appliedOffset)
        onProgress(Stage.SEGMENTATION, 1f)
        check()

        return PostNotePipeline.run(detected, config, quality, warnings, version, onProgress, isCancelled)
    }

    /**
     * Median detuning (in semitones, -0.5..0.5) of the voiced frames, or 0 when the singer is not consistently off
     * the grid (then there is nothing to compensate).
     */
    internal fun estimateDetune(frames: List<PitchFrame>): Double {
        val v = frames.filter { it.voiced && it.confidence >= 0.8 }
        if (v.size < 40) return 0.0
        var sx = 0.0; var sy = 0.0
        for (f in v) { val th = 2 * PI * (f.midi - Math.floor(f.midi)); sx += cos(th); sy += sin(th) }
        val r = sqrt(sx * sx + sy * sy) / v.size
        if (r < 0.5) return 0.0
        return atan2(sy, sx) / (2 * PI)
    }

    /** Multiplies every frequency by [factor] (and compresses time by the same factor; callers map times back). */
    private fun shiftPitch(x: FloatArray, factor: Double): FloatArray {
        val scale = 100_000
        return Resampler.resample(x, (BP.SAMPLE_RATE * scale * factor).roundToInt().coerceAtLeast(1), BP.SAMPLE_RATE * scale)
    }

    /**
     * Neural notes -> [DetectedNote]. Start times are corrected for the onset head's measured delay; the exact pitch
     * comes from the median of the YIN frames inside the note (when they agree with the decoded key within 1.5
     * semitones), otherwise from the neural contour.
     */
    private fun toDetected(
        notes: List<MlNote>,
        post: Posteriors,
        rms: DoubleArray,
        yin: List<PitchFrame>,
        timeScale: Double,
        detune: Double,
    ): List<DetectedNote> {
        if (notes.isEmpty()) return emptyList()
        val hop = if (yin.size > 1) yin[1].timeSec - yin[0].timeSec else 0.01
        val out = ArrayList<DetectedNote>(notes.size)
        for ((i, n) in notes.withIndex()) {
            val startSec = max(0.0, (n.startFrame / BP.FPS - ONSET_DELAY_SEC) * timeScale)
            val endSec = max(startSec + 0.03, n.endFrame / BP.FPS * timeScale - END_ADVANCE_SEC)
            // YIN frames of the note (original time axis); the detune is subtracted to land on the shifted grid.
            val a = ((startSec + 0.02) / hop).toInt().coerceIn(0, yin.size)
            val b = ((endSec - 0.01) / hop).toInt().coerceIn(a, yin.size)
            val ys = ArrayList<Double>()
            for (k in a until b) {
                val f = yin[k]
                if (f.voiced && f.confidence >= 0.6) {
                    val m = f.midi - detune
                    if (abs(m - n.midi) <= 1.5) ys.add(m)
                }
            }
            var pitch = n.midi.toDouble()
            var stability = 0.7
            if (ys.size >= 3) {
                ys.sort()
                pitch = ys[ys.size / 2]
                val mean = ys.average()
                val sd = sqrt(ys.sumOf { (it - mean) * (it - mean) } / ys.size)
                stability = (1.0 - sd / 0.6).coerceIn(0.0, 1.0)
            } else {
                contourPitch(post, n)?.let { pitch = it }
            }
            if (abs(pitch - n.midi) > 0.7) pitch = n.midi.toDouble()
            // Confidence: how sure the network is (activation + onset) and how many frames agree with it.
            val agree = if (b > a) ys.size.toDouble() / (b - a) else 0.0
            val conf = (0.55 * n.meanActivation + 0.2 * min(1.0, n.onset * 1.5) + 0.25 * agree).coerceIn(0.0, 1.0)
            var level = 0.0
            for (f in n.startFrame until min(n.endFrame, rms.size)) level += rms[f]
            level /= max(1, min(n.endFrame, rms.size) - n.startFrame)
            out.add(DetectedNote(startSec, endSec, n.midi, pitch, conf, stability, level))
            if (i > 0 && out[i].startSec < out[i - 1].endSec) out[i - 1] = out[i - 1].copy(endSec = max(out[i - 1].startSec + 0.03, out[i].startSec))
        }
        return out
    }

    /** Centroid of the 3-bins-per-semitone contour around the note's key; null when the contour is empty there. */
    private fun contourPitch(p: Posteriors, n: MlNote): Double? {
        val center = (n.midi - BP.LOWEST_MIDI) * 3
        var sw = 0.0; var sb = 0.0
        for (f in n.startFrame until min(n.endFrame, p.frames)) {
            for (bin in max(0, center - 4)..min(BP.CONTOUR_BINS - 1, center + 4)) {
                val w = p.contour(f, bin).toDouble()
                if (w > 0.1) { sw += w; sb += w * bin }
            }
        }
        if (sw < 1.0) return null
        return BP.LOWEST_MIDI + sb / sw / 3.0
    }

    companion object {
        /** The onset head peaks about this long after the true attack (measured against synthetic voices). */
        const val ONSET_DELAY_SEC = 0.010
        const val END_ADVANCE_SEC = 0.0
        const val SHIFT_MIN_SEMITONES = 0.25
    }
}
