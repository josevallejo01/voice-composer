package com.voicecomposer.engine.sound

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * SoundFont 2 reader (sample banks of real recorded instruments). Pure Kotlin so that it runs on the phone and in the
 * JVM tests. Only what is needed to play a preset is parsed: samples, presets, instruments, their zones, generators and
 * modulators. The sample data is read lazily from [data] (a memory-mapped file on the device), never copied wholesale.
 */
class SoundFont(private val data: ByteBuffer) {
    class Sample(
        val name: String, val start: Int, val end: Int, val startLoop: Int, val endLoop: Int, val rate: Int,
        val rootKey: Int, val correction: Int, val link: Int, val type: Int,
    )

    /** One generator/modulator layer: key and velocity ranges, generator values, modulators, and the sample (instrument zones). */
    class Zone(
        val keyLo: Int, val keyHi: Int, val velLo: Int, val velHi: Int,
        val gens: Map<Int, Int>, val mods: List<Modulator>, val sample: Sample?, val instrument: Instrument?,
    )

    class Instrument(val name: String, val global: Zone?, val zones: List<Zone>)
    class Preset(val name: String, val program: Int, val bank: Int, val global: Zone?, val zones: List<Zone>)

    class Modulator(val src: Int, val dest: Int, val amount: Int, val amtSrc: Int, val trans: Int) {
        /** Two modulators are "the same" (the later replaces the earlier) when source, destination, amount source and transform match. */
        fun sameAs(o: Modulator) = src == o.src && dest == o.dest && amtSrc == o.amtSrc && trans == o.trans
    }

    /** A playable region: one sample with the generators of its preset and instrument zones merged. */
    class Region(val sample: Sample, val gens: IntArray, val mods: List<Modulator>, val keyLo: Int, val keyHi: Int, val velLo: Int, val velHi: Int) {
        fun gen(g: Int) = gens[g]
    }

    val presets: List<Preset>
    val samples: List<Sample>
    val name: String
    private val smplOffset: Int
    private val smplSize: Int
    private val sm24Offset: Int
    private val regionCache = HashMap<Long, List<Region>>()
    private val floatCache = HashMap<Sample, FloatArray>()

    init {
        val b = data.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        require(b.limit() > 12 && tag(b, 0) == "RIFF" && tag(b, 8) == "sfbk") { "not a SoundFont file" }
        var infoName = ""
        var smpl = -1; var smplLen = 0; var sm24 = -1
        var pdta = -1; var pdtaEnd = -1
        var p = 12
        while (p + 8 <= b.limit()) {
            val id = tag(b, p); val sz = b.getInt(p + 4)
            if (id == "LIST") {
                val type = tag(b, p + 8)
                var q = p + 12; val end = p + 8 + sz
                when (type) {
                    "INFO" -> while (q + 8 <= end) {
                        val cid = tag(b, q); val csz = b.getInt(q + 4)
                        if (cid == "INAM") infoName = cstr(b, q + 8, csz)
                        q += 8 + csz + (csz and 1)
                    }
                    "sdta" -> while (q + 8 <= end) {
                        val cid = tag(b, q); val csz = b.getInt(q + 4)
                        if (cid == "smpl") { smpl = q + 8; smplLen = csz }
                        if (cid == "sm24") sm24 = q + 8
                        q += 8 + csz + (csz and 1)
                    }
                    "pdta" -> { pdta = q; pdtaEnd = end }
                }
            }
            p += 8 + sz + (sz and 1)
        }
        require(smpl >= 0 && pdta >= 0) { "SoundFont without sample data or presets" }
        smplOffset = smpl; smplSize = smplLen / 2; sm24Offset = sm24; name = infoName

        // pdta sub-chunks
        val chunks = HashMap<String, Pair<Int, Int>>()
        var q = pdta
        while (q + 8 <= pdtaEnd) {
            val cid = tag(b, q); val csz = b.getInt(q + 4)
            chunks[cid] = (q + 8) to csz
            q += 8 + csz + (csz and 1)
        }
        fun rec(name: String, size: Int): Pair<Int, Int> { val c = chunks[name] ?: error("missing $name"); return c.first to c.second / size }

        val (shOff, shN) = rec("shdr", 46)
        samples = (0 until shN - 1).map { i ->
            val o = shOff + i * 46
            Sample(cstr(b, o, 20), b.getInt(o + 20), b.getInt(o + 24), b.getInt(o + 28), b.getInt(o + 32), b.getInt(o + 36),
                b.get(o + 40).toInt() and 0xFF, b.get(o + 41).toInt(), b.getShort(o + 42).toInt() and 0xFFFF, b.getShort(o + 44).toInt() and 0xFFFF)
        }
        fun gens(off: Int, n: Int): List<Pair<Int, Int>> = (0 until n).map { i ->
            val o = off + i * 4
            val op = b.getShort(o).toInt() and 0xFFFF
            // Range generators carry two bytes (lo, hi); the others a signed 16-bit amount.
            val amt = if (op == 43 || op == 44) (b.get(o + 2).toInt() and 0xFF) or ((b.get(o + 3).toInt() and 0xFF) shl 8) else b.getShort(o + 2).toInt()
            op to amt
        }
        fun mods(off: Int, n: Int): List<Modulator> = (0 until n).map { i ->
            val o = off + i * 10
            Modulator(b.getShort(o).toInt() and 0xFFFF, b.getShort(o + 2).toInt() and 0xFFFF, b.getShort(o + 4).toInt(), b.getShort(o + 6).toInt() and 0xFFFF, b.getShort(o + 8).toInt() and 0xFFFF)
        }
        fun bags(off: Int, n: Int) = (0 until n).map { i -> (b.getShort(off + i * 4).toInt() and 0xFFFF) to (b.getShort(off + i * 4 + 2).toInt() and 0xFFFF) }

        val (pbO, pbN) = rec("pbag", 4); val (pgO, pgN) = rec("pgen", 4); val (pmO, pmN) = rec("pmod", 10)
        val (ibO, ibN) = rec("ibag", 4); val (igO, igN) = rec("igen", 4); val (imO, imN) = rec("imod", 10)
        val pbag = bags(pbO, pbN); val pgen = gens(pgO, pgN); val pmod = mods(pmO, pmN)
        val ibag = bags(ibO, ibN); val igen = gens(igO, igN); val imod = mods(imO, imN)

        fun zone(bag: List<Pair<Int, Int>>, gen: List<Pair<Int, Int>>, mod: List<Modulator>, bi: Int, forInstrument: Boolean, insts: List<Instrument>?): Zone {
            val g0 = bag[bi].first; val g1 = bag[bi + 1].first
            val m0 = bag[bi].second; val m1 = bag[bi + 1].second
            var kLo = 0; var kHi = 127; var vLo = 0; var vHi = 127
            var sample: Sample? = null; var inst: Instrument? = null
            val map = HashMap<Int, Int>()
            for (k in g0 until g1) {
                val (op, amt) = gen[k]
                when (op) {
                    43 -> { kLo = amt and 0xFF; kHi = (amt shr 8) and 0xFF }
                    44 -> { vLo = amt and 0xFF; vHi = (amt shr 8) and 0xFF }
                    53 -> if (forInstrument) sample = samples.getOrNull(amt and 0xFFFF)
                    41 -> if (!forInstrument) inst = insts?.getOrNull(amt and 0xFFFF)
                    else -> map[op] = amt
                }
            }
            return Zone(kLo, kHi, vLo, vHi, map, mod.subList(m0, m1.coerceAtLeast(m0)), sample, inst)
        }

        val (inO, inN) = rec("inst", 22)
        val instruments = (0 until inN - 1).map { i ->
            val o = inO + i * 22
            val name = cstr(b, o, 20); val b0 = b.getShort(o + 20).toInt() and 0xFFFF; val b1 = b.getShort(o + 22 + 20).toInt() and 0xFFFF
            var global: Zone? = null
            val zs = ArrayList<Zone>()
            for (bi in b0 until b1) {
                val z = zone(ibag, igen, imod, bi, true, null)
                if (z.sample == null) { if (bi == b0) global = z } else zs.add(z)
            }
            Instrument(name, global, zs)
        }
        val (phO, phN) = rec("phdr", 38)
        presets = (0 until phN - 1).map { i ->
            val o = phO + i * 38
            val name = cstr(b, o, 20); val prog = b.getShort(o + 20).toInt() and 0xFFFF; val bank = b.getShort(o + 22).toInt() and 0xFFFF
            val b0 = b.getShort(o + 24).toInt() and 0xFFFF; val b1 = b.getShort(o + 38 + 24).toInt() and 0xFFFF
            var global: Zone? = null
            val zs = ArrayList<Zone>()
            for (bi in b0 until b1) {
                val z = zone(pbag, pgen, pmod, bi, false, instruments)
                if (z.instrument == null) { if (bi == b0) global = z } else zs.add(z)
            }
            Preset(name, prog, bank, global, zs)
        }
    }

    fun findPreset(program: Int, bank: Int = 0): Preset? =
        presets.firstOrNull { it.program == program && it.bank == bank } ?: presets.firstOrNull { it.program == program && it.bank == 0 }

    /** The regions sounding for this key and velocity (more than one when layers or stereo pairs overlap). */
    fun regions(preset: Preset, key: Int, vel: Int): List<Region> {
        val ck = (System.identityHashCode(preset).toLong() shl 16) or (key.toLong() shl 8) or vel.toLong()
        return regionCache.getOrPut(ck) { resolve(preset, key, vel) }
    }

    private fun resolve(preset: Preset, key: Int, vel: Int): List<Region> {
        val out = ArrayList<Region>()
        for (pz in preset.zones) {
            if (key !in pz.keyLo..pz.keyHi || vel !in pz.velLo..pz.velHi) continue
            val inst = pz.instrument ?: continue
            for (iz in inst.zones) {
                if (key !in iz.keyLo..iz.keyHi || vel !in iz.velLo..iz.velHi) continue
                val s = iz.sample ?: continue
                if (s.type and 0x8000 != 0) continue // ROM sample
                val g = IntArray(GEN_COUNT) { GEN_DEFAULT[it] }
                // Instrument level: global zone then local zone replace the defaults.
                inst.global?.gens?.forEach { (k, v) -> if (k in g.indices) g[k] = v }
                iz.gens.forEach { (k, v) -> if (k in g.indices) g[k] = v }
                // Preset level: global then local zone are *added* (not for the generators that are not additive).
                val pg = HashMap<Int, Int>()
                preset.global?.gens?.let { pg.putAll(it) }
                pz.gens.forEach { (k, v) -> pg[k] = v }
                for ((k, v) in pg) if (k in g.indices && k !in NON_ADDITIVE) g[k] += v
                // Modulators: defaults, replaced by identical instrument ones, then preset ones added.
                val mods = ArrayList<Modulator>(DEFAULT_MODS)
                fun put(m: Modulator) { val i = mods.indexOfFirst { it.sameAs(m) }; if (i >= 0) mods[i] = m else mods.add(m) }
                inst.global?.mods?.forEach(::put); iz.mods.forEach(::put)
                val pm = ArrayList<Modulator>(); preset.global?.mods?.let { pm.addAll(it) }; pm.addAll(pz.mods)
                out.add(Region(s, g, mods + pm, iz.keyLo, iz.keyHi, iz.velLo, iz.velHi))
            }
        }
        return out
    }

    /** Sample data of [s] as floats in -1..1 (with the 24-bit extension when the file has one); cached. */
    fun floats(s: Sample): FloatArray = floatCache.getOrPut(s) {
        val b = data.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val n = (s.end - s.start).coerceAtLeast(0)
        FloatArray(n + 8).also { a ->
            for (i in 0 until n) {
                val idx = s.start + i
                var v = b.getShort(smplOffset + idx * 2).toInt() * 256
                if (sm24Offset >= 0) v += b.get(sm24Offset + idx).toInt() and 0xFF
                a[i] = v / 8388608f
            }
        }
    }

    companion object {
        const val GEN_COUNT = 64
        // Generators that a preset zone must not add to the instrument's value.
        private val NON_ADDITIVE = setOf(0, 1, 2, 3, 4, 12, 45, 46, 47, 50, 54, 57, 58)

        /** Default generator values (SoundFont 2.01 section 8.1.2); times are in timecents. */
        val GEN_DEFAULT: IntArray = IntArray(GEN_COUNT).also { g ->
            g[8] = 13500; g[17] = 0; g[56] = 100; g[58] = -1; g[46] = -1; g[47] = -1
            for (i in intArrayOf(21, 23, 25, 26, 27, 28, 30, 33, 34, 35, 36, 38)) g[i] = -12000
            g[22] = 0; g[24] = 0
        }

        /** The default modulators of SoundFont 2.01 (section 8.4), the ones that matter for notes played from a score. */
        val DEFAULT_MODS: List<Modulator> = listOf(
            Modulator(0x0502, 48, 960, 0, 0),   // velocity -> initial attenuation (concave, negative)
            Modulator(0x0102, 8, -2400, 0, 0),  // velocity -> filter cutoff (linear, negative)
            Modulator(0x000D, 6, 50, 0, 0),     // channel pressure -> vibrato depth
            Modulator(0x0081, 6, 50, 0, 0),     // mod wheel -> vibrato depth
            Modulator(0x0587, 48, 960, 0, 0),   // volume controller -> attenuation (concave, negative)
            Modulator(0x028A, 17, 1000, 0, 0),  // pan controller -> pan (linear, bipolar)
            Modulator(0x058B, 48, 960, 0, 0),   // expression controller -> attenuation
            Modulator(0x00DB, 16, 200, 0, 0),   // reverb send controller
            Modulator(0x00DD, 15, 200, 0, 0),   // chorus send controller
        )

        private fun tag(b: ByteBuffer, o: Int) = String(ByteArray(4) { b.get(o + it) }, Charsets.US_ASCII)
        private fun cstr(b: ByteBuffer, o: Int, n: Int): String {
            val a = ByteArray(n) { b.get(o + it) }
            val z = a.indexOf(0)
            return String(a, 0, if (z < 0) n else z, Charsets.ISO_8859_1).trim()
        }
    }
}
