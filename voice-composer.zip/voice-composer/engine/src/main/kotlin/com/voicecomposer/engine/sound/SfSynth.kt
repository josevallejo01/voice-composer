package com.voicecomposer.engine.sound

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** What the player asks of the synthesizer for one note. Times are in seconds from the start of the note. */
class NoteEvent(
    val key: Int,
    val velocity: Int,
    /** Time of the note-off from the note start. */
    val duration: Double,
    /** Start in output frames. */
    val startFrame: Int,
    /** Left / right gain (pan and level already applied). */
    val gainL: Float,
    val gainR: Float,
    /** Loudness shape over the note (expression, 100 values per second); null = flat. */
    val expression: FloatArray? = null,
    /** Extra vibrato depth over the note in cents (peak), 100 values per second; null = none beyond the sample's own. */
    val vibrato: FloatArray? = null,
    val vibratoHz: Double = 5.4,
    /** Extra cents of pitch over the note, 100 values per second (scoops, slides between legato notes). */
    val bend: FloatArray? = null,
    /** Extra time the note keeps ringing after note-off, on top of the sample's own release (sustain pedal). */
    val extraRelease: Double = 0.0,
    /** Scales the release time of the volume envelope (shorter for staccato, longer for pedal). */
    val releaseScale: Double = 1.0,
    /** Constant detune in cents (layers of one patch are detuned slightly so they do not phase-lock). */
    val tuneCents: Double = 0.0,
    val cc: IntArray? = null,
)

/**
 * The sampler: plays one note of a SoundFont preset into stereo buffers, with the SoundFont's own envelopes, filter,
 * LFOs, loops and modulators (GeneralUser-style banks rely on them for most of their character). Rendering is offline,
 * so there is no polyphony limit and every voice is computed with high-quality interpolation.
 */
class SfSynth(val font: SoundFont, val sampleRate: Int = 44100) {
    private val CTRL = 32

    private fun tc(cents: Int) = 2.0.pow(cents / 1200.0)
    private fun absHz(cents: Int) = 8.176 * 2.0.pow(cents / 1200.0)

    // ---- modulators (evaluated once per note: velocity, key and controller values do not move during a note) -----------

    private fun srcValue(src: Int, key: Int, vel: Int, cc: IntArray): Double {
        if (src == 0) return 1.0
        val idx = src and 0x7F
        val isCc = src and 0x80 != 0
        val neg = src and 0x100 != 0
        val bipolar = src and 0x200 != 0
        val type = (src shr 10) and 0x3F
        val raw = if (isCc) cc[idx] / 128.0 else when (idx) {
            2 -> vel / 128.0
            3 -> key / 128.0
            10, 13 -> 0.0
            14 -> 0.5
            16 -> 2.0 / 128.0
            else -> 0.0
        }
        var x = raw
        if (bipolar) {
            var v = 2 * x - 1
            if (neg) v = -v
            val y = curve(type, abs(v))
            return if (v < 0) -y else y
        }
        if (neg) x = 1 - x
        return curve(type, x)
    }

    private fun curve(type: Int, x: Double): Double = when (type) {
        1 -> if (x >= 0.99999) 1.0 else (-(40.0 / 96.0) * log10(1 - x)).coerceIn(0.0, 1.0)
        2 -> if (x <= 1e-5) 0.0 else 1 - (-(40.0 / 96.0) * log10(x)).coerceIn(0.0, 1.0)
        3 -> if (x >= 0.5) 1.0 else 0.0
        else -> x
    }

    private fun modulate(r: SoundFont.Region, key: Int, vel: Int, cc: IntArray, g: IntArray) {
        for (m in r.mods) {
            if (m.dest !in g.indices) continue
            val a = srcValue(m.src, key, vel, cc)
            val b = if (m.amtSrc == 0) 1.0 else srcValue(m.amtSrc, key, vel, cc)
            // The transform (absolute value) is not used by any bank I know; the linear case only.
            g[m.dest] += (a * m.amount * b).toInt()
        }
    }

    /**
     * Adds the note to [outL]/[outR]. [sendOut] (optional) receives the same signal scaled by the preset's reverb send
     * (generator 16), so a bank's own idea of what should be wet can be honoured.
     */
    fun render(preset: SoundFont.Preset, e: NoteEvent, outL: FloatArray, outR: FloatArray) {
        val cc = e.cc ?: DEFAULT_CC
        val regions = font.regions(preset, e.key, e.velocity)
        for (r in regions) renderRegion(r, e, cc, outL, outR)
    }

    private fun renderRegion(r: SoundFont.Region, e: NoteEvent, cc: IntArray, outL: FloatArray, outR: FloatArray) {
        val s = r.sample
        val g = r.gens.copyOf()
        val key = if (g[46] >= 0) g[46] else e.key
        val vel = if (g[47] >= 0) g[47] else e.velocity
        modulate(r, key, vel, cc, g)

        val data = font.floats(s)
        val startOff = g[0] + g[4] * 32768
        val endOff = g[1] + g[12] * 32768
        val length = (s.end - s.start) + endOff
        val loopStart = (s.startLoop - s.start) + g[2] + g[45] * 32768
        val loopEnd = (s.endLoop - s.start) + g[3] + g[50] * 32768
        val mode = g[54] and 3
        val looping = (mode == 1 || mode == 3) && loopEnd - loopStart >= 8 && loopEnd <= length + 1
        val root = if (g[58] >= 0) g[58] else if (s.rootKey in 0..127) s.rootKey else 60
        val baseCents = (key - root) * g[56] + g[51] * 100 + g[52] + s.correction + e.tuneCents
        val srcRatio = s.rate.toDouble() / sampleRate

        // Volume envelope.
        val vDelay = tc(g[33]); val vAttack = tc(g[34])
        val vHold = tc(g[35] + g[39] * (60 - key)); val vDecay = tc(g[36] + g[40] * (60 - key))
        val vSustainDb = (g[37] / 10.0).coerceIn(0.0, 144.0)
        val vRelease = tc(g[38]) * e.releaseScale
        // Modulation envelope.
        val mDelay = tc(g[25]); val mAttack = tc(g[26])
        val mHold = tc(g[27] + g[31] * (60 - key)); val mDecay = tc(g[28] + g[32] * (60 - key))
        val mSustain = (1.0 - g[29] / 1000.0).coerceIn(0.0, 1.0)
        val mRelease = tc(g[30])
        val modEnvPitch = g[7]; val modEnvFilter = g[11]
        // LFOs.
        val modLfoDelay = tc(g[21]); val modLfoHz = absHz(g[22])
        val vibLfoDelay = tc(g[23]); val vibLfoHz = absHz(g[24])
        val modLfoPitch = g[5]; val modLfoFilter = g[10]; val modLfoVol = g[13]; val vibLfoPitch = g[6]
        // Filter.
        val fcBase = g[8]
        val filterOn = fcBase < 13400 || modEnvFilter != 0 || modLfoFilter != 0
        val qdb = (g[9] / 10.0).coerceIn(0.0, 96.0)
        val qLin = 10.0.pow((qdb - 3.01) / 20.0).coerceAtLeast(0.5)
        // Level.
        val attenCb = g[48].coerceIn(0, 1440)
        val level = 10.0.pow(-attenCb / 200.0)
        val pan = (g[17] / 1000.0).coerceIn(-0.5, 0.5) * 2
        // Constant-power pan of the region inside the note's own pan.
        val ang = (pan + 1) * PI / 4
        val pl = cos(ang).toFloat() * 1.4142135f; val pr = sin(ang).toFloat() * 1.4142135f

        val noteOffT = e.duration
        val endT = noteOffT + e.extraRelease + vRelease * 0.95 + 0.05
        val frames = min((endT * sampleRate).toInt() + 1, 40 * sampleRate)
        var phase = startOff.toDouble()
        var released = false
        // Biquad state.
        var z1 = 0.0; var z2 = 0.0
        var b0 = 1.0; var b1 = 0.0; var b2 = 0.0; var a1 = 0.0; var a2 = 0.0
        var lastGain = -1.0
        val vibAdd = e.vibrato; val expr = e.expression; val bend = e.bend
        var extraLfo = 0.0

        // Volume level (dB attenuation) at time t.
        fun envDb(t: Double, tOff: Double): Double {
            fun upto(tt: Double): Double {
                val t0 = tt - vDelay
                if (t0 < 0) return 100.0
                if (t0 < vAttack) { val a = t0 / vAttack; return if (a <= 1e-5) 100.0 else min(100.0, -20 * log10(a)) }
                val t1 = t0 - vAttack
                if (t1 < vHold) return 0.0
                val t2 = t1 - vHold
                return min(vSustainDb, t2 * 100.0 / vDecay)
            }
            return if (tOff < 0 || t < tOff) upto(t) else min(144.0, upto(tOff) + (t - tOff) * 100.0 / vRelease)
        }
        fun modEnv(t: Double, tOff: Double): Double {
            fun upto(tt: Double): Double {
                val t0 = tt - mDelay
                if (t0 < 0) return 0.0
                if (t0 < mAttack) return t0 / mAttack
                val t1 = t0 - mAttack
                if (t1 < mHold) return 1.0
                val t2 = t1 - mHold
                return max(mSustain, 1.0 - t2 / mDecay * (1.0 - mSustain))
            }
            return if (tOff < 0 || t < tOff) upto(t) else max(0.0, upto(tOff) * (1.0 - (t - tOff) / mRelease))
        }

        var i = 0
        var gainPrev = 0.0
        val sinceStartFrames = e.startFrame
        while (i < frames) {
            val t = i.toDouble() / sampleRate
            val blk = min(CTRL, frames - i)
            val tOff = noteOffT
                        // Envelope with the pedal's extra ringing: the release starts later.
            val tRel = tOff + e.extraRelease
            released = t >= tRel
            var db = envDb(t, tRel)
            if (db >= 92.0 && t > tRel) break
            // Loudness shape and LFOs.
            val modLfoPhase = if (t < modLfoDelay) 0.0 else tri((t - modLfoDelay) * modLfoHz)
            val vibLfoPhase = if (t < vibLfoDelay) 0.0 else tri((t - vibLfoDelay) * vibLfoHz)
            var cents = baseCents.toDouble() + modLfoPhase * modLfoPitch + vibLfoPhase * vibLfoPitch
            if (modEnvPitch != 0) cents += modEnv(t, tRel) * modEnvPitch
            if (vibAdd != null) {
                val d = interp(vibAdd, t * 100)
                if (d > 0.01f) { extraLfo = tri(t * e.vibratoHz); cents += extraLfo * d }
            }
            if (bend != null) cents += interp(bend, t * 100)
            val ratio = srcRatio * 2.0.pow(cents / 1200.0)
            var amp = level * 10.0.pow(-db / 20.0)
            if (modLfoVol != 0) amp *= 10.0.pow(modLfoPhase * modLfoVol / 200.0)
            if (expr != null) amp *= interp(expr, t * 100)
            if (filterOn) {
                var fc = fcBase.toDouble()
                if (modEnvFilter != 0) fc += modEnv(t, tRel) * modEnvFilter
                if (modLfoFilter != 0) fc += modLfoPhase * modLfoFilter
                val hz = min(absHz(fc.toInt()), sampleRate * 0.45).coerceAtLeast(20.0)
                val w0 = 2 * PI * hz / sampleRate
                val cw = cos(w0); val alpha = sin(w0) / (2 * qLin)
                val a0 = 1 + alpha
                b0 = (1 - cw) / 2 / a0; b1 = (1 - cw) / a0; b2 = b0; a1 = -2 * cw / a0; a2 = (1 - alpha) / a0
            }
            val g0 = if (lastGain < 0) amp else gainPrev
            // Samples of this block.
            for (k in 0 until blk) {
                val idx = i + k
                val fi = phase.toInt()
                val loopNow = looping && !(mode == 3 && released)
                var smp: Double
                if (!loopNow && fi >= length) {
                    smp = 0.0
                } else {
                    val fr = (phase - fi).toFloat()
                    val p0 = sampleAt(data, fi - 1, loopNow, loopStart, loopEnd, length)
                    val p1 = sampleAt(data, fi, loopNow, loopStart, loopEnd, length)
                    val p2 = sampleAt(data, fi + 1, loopNow, loopStart, loopEnd, length)
                    val p3 = sampleAt(data, fi + 2, loopNow, loopStart, loopEnd, length)
                    // 4-point cubic Hermite.
                    val c1 = 0.5f * (p2 - p0)
                    val c2 = p0 - 2.5f * p1 + 2f * p2 - 0.5f * p3
                    val c3 = 0.5f * (p3 - p0) + 1.5f * (p1 - p2)
                    smp = (((c3 * fr + c2) * fr + c1) * fr + p1).toDouble()
                }
                if (filterOn) {
                    val y = b0 * smp + z1
                    z1 = b1 * smp - a1 * y + z2
                    z2 = b2 * smp - a2 * y
                    smp = y
                }
                val gk = g0 + (amp - g0) * (k + 1) / blk
                val v = (smp * gk).toFloat()
                val o = sinceStartFrames + idx
                if (o >= 0 && o < outL.size) { outL[o] += v * e.gainL * pl; outR[o] += v * e.gainR * pr }
                phase += ratio
                if (looping && !(mode == 3 && released) && phase >= loopEnd) phase -= (loopEnd - loopStart)
            }
            gainPrev = amp
            lastGain = amp
            i += blk
            if (!looping && phase >= length + 4) break
        }
    }

    private fun sampleAt(d: FloatArray, i: Int, loop: Boolean, ls: Int, le: Int, len: Int): Float {
        var j = i
        if (loop) {
            if (j >= le) j = ls + (j - le) % (le - ls)
            if (j < 0) j = 0
        } else {
            if (j < 0) j = 0
            if (j >= len) return 0f
        }
        return d[j]
    }

    private fun tri(cycles: Double): Double {
        val f = cycles - Math.floor(cycles)
        return if (f < 0.25) 4 * f else if (f < 0.75) 2 - 4 * f else 4 * f - 4
    }

    private fun interp(a: FloatArray, pos: Double): Float {
        if (a.isEmpty()) return 1f
        val i = pos.toInt()
        if (i >= a.size - 1) return a[a.size - 1]
        if (i < 0) return a[0]
        val f = (pos - i).toFloat()
        return a[i] + (a[i + 1] - a[i]) * f
    }

    companion object {
        /** Controller values of an idle channel: volume 100, expression 127, pan centre, no mod wheel, reverb/chorus send 0. */
        val DEFAULT_CC: IntArray = IntArray(128).also { it[7] = 100; it[10] = 64; it[11] = 127 }
    }
}
