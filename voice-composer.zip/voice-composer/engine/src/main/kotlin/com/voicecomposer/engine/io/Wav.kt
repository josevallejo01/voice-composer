package com.voicecomposer.engine.io

import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Mono audio as floats in -1..1. */
class AudioBuffer(val samples: FloatArray, val sampleRate: Int) {
    val durationSec: Double get() = samples.size.toDouble() / sampleRate
}

object WavIO {
    fun header(dataBytes: Int, sampleRate: Int, channels: Int = 1): ByteArray {
        val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + dataBytes).put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(channels.toShort())
        bb.putInt(sampleRate).putInt(sampleRate * channels * 2).putShort((channels * 2).toShort()).putShort(16)
        bb.put("data".toByteArray()).putInt(dataBytes)
        return bb.array()
    }

    fun encodePcm16(samples: FloatArray, sampleRate: Int): ByteArray {
        val bb = ByteBuffer.allocate(44 + samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put(header(samples.size * 2, sampleRate))
        for (s in samples) bb.putShort((s.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        return bb.array()
    }

    fun write(file: File, samples: FloatArray, sampleRate: Int) = file.writeBytes(encodePcm16(samples, sampleRate))

    fun read(file: File): AudioBuffer = decode(file.readBytes())

    /** Decodes PCM 8/16/24/32-bit and 32-bit float WAV files; multichannel files are mixed down to mono. */
    fun decode(bytes: ByteArray): AudioBuffer {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(bytes.size >= 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") { "Not a WAV file" }
        var pos = 12
        var format = 1
        var channels = 1
        var rate = 44100
        var bits = 16
        var dataStart = -1
        var dataLen = 0
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4)
            val size = bb.getInt(pos + 4)
            val body = pos + 8
            if (id == "fmt ") {
                format = bb.getShort(body).toInt() and 0xFFFF
                channels = bb.getShort(body + 2).toInt()
                rate = bb.getInt(body + 4)
                bits = bb.getShort(body + 14).toInt()
                if (format == 0xFFFE && size >= 26) format = bb.getShort(body + 24).toInt() and 0xFFFF
            } else if (id == "data") {
                dataStart = body
                // A recording interrupted before the header was patched may carry a bogus size.
                dataLen = if (size <= 0 || body + size > bytes.size) bytes.size - body else size
                break
            }
            pos = body + size + (size and 1)
        }
        require(dataStart >= 0) { "WAV has no data chunk" }
        require(channels >= 1) { "Invalid channel count" }
        val bytesPer = bits / 8
        val frames = dataLen / (bytesPer * channels)
        val out = FloatArray(frames)
        var p = dataStart
        for (i in 0 until frames) {
            var acc = 0f
            for (c in 0 until channels) {
                acc += when {
                    format == 3 && bits == 32 -> bb.getFloat(p)
                    bits == 16 -> bb.getShort(p) / 32768f
                    bits == 8 -> ((bytes[p].toInt() and 0xFF) - 128) / 128f
                    bits == 24 -> ((bytes[p].toInt() and 0xFF) or ((bytes[p + 1].toInt() and 0xFF) shl 8) or (bytes[p + 2].toInt() shl 16)) / 8388608f
                    bits == 32 -> bb.getInt(p) / 2147483648f
                    else -> throw IllegalArgumentException("Unsupported WAV bit depth $bits")
                }
                p += bytesPer
            }
            out[i] = acc / channels
        }
        return AudioBuffer(out, rate)
    }
}

/**
 * Streams 16-bit mono PCM to disk while recording. The header is patched on [close] (and on [flushHeader]),
 * so the file is always decodable even if the app is killed mid-recording ([WavIO.decode] tolerates a stale size).
 */
class StreamingWavWriter(file: File, private val sampleRate: Int) : Closeable {
    private val raf = RandomAccessFile(file, "rw")
    var dataBytes: Long = 0
        private set

    init {
        raf.setLength(0)
        raf.write(WavIO.header(0, sampleRate))
    }

    fun write(pcm: ShortArray, count: Int) {
        val bb = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until count) bb.putShort(pcm[i])
        raf.write(bb.array())
        dataBytes += count * 2L
    }

    fun flushHeader() {
        val pos = raf.filePointer
        raf.seek(0)
        raf.write(WavIO.header(dataBytes.toInt(), sampleRate))
        raf.seek(pos)
    }

    override fun close() {
        flushHeader()
        raf.close()
    }
}
