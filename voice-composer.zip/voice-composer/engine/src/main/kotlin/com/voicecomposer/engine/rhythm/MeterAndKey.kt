package com.voicecomposer.engine.rhythm

import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Mode
import com.voicecomposer.model.TimeSignature
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

data class MeterEstimate(val timeSignature: TimeSignature, val confidence: Double)

/**
 * Meter from accent patterns: long notes and notes after a rest are perceived as accented. The candidate meter
 * whose downbeat carries the most accent compared with the other beats wins. 4/4 is the default when evidence is weak.
 */
object MeterEstimator {
    fun estimate(notes: List<MusicalEvent>): MeterEstimate {
        val sorted = notes.filter { it.isNote }.sortedBy { it.startBeat }
        val onBeat = ArrayList<Pair<Int, Double>>() // (beat index, accent)
        for ((i, n) in sorted.withIndex()) {
            val b = n.startBeat
            if (abs(b - Math.round(b)) > 0.12) continue
            var accent = minOf(n.durationBeats, 3.0)
            val prev = sorted.getOrNull(i - 1)
            if (prev != null && n.startBeat - prev.endBeat > 0.45) accent += 0.5
            onBeat.add(Math.round(b).toInt() to accent)
        }
        val candidates = listOf(TimeSignature.FOUR_FOUR to 1.0, TimeSignature.THREE_FOUR to 0.92, TimeSignature.TWO_FOUR to 0.85)
        var best = TimeSignature.FOUR_FOUR
        var bestStrength = 0.0
        var bestScore = -1e9
        for ((ts, prior) in candidates) {
            val n = ts.numerator
            val strong = onBeat.filter { it.first % n == 0 }.map { it.second }
            val weak = onBeat.filter { it.first % n != 0 }.map { it.second }
            if (strong.size < 2 || weak.isEmpty()) continue
            val strength = strong.average() - weak.average()
            val score = strength * prior
            if (score > bestScore) { bestScore = score; best = ts; bestStrength = strength }
        }
        if (bestScore < 0.25) return MeterEstimate(TimeSignature.FOUR_FOUR, 0.3)
        return MeterEstimate(best, (bestStrength / 1.5).coerceIn(0.3, 1.0))
    }
}

/** Krumhansl-Schmuckler key finding on a duration weighted pitch class histogram. */
object KeyEstimator {
    private val MAJOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

    fun estimate(notes: List<MusicalEvent>): KeySignature {
        val ns = notes.filter { it.isNote && it.midiPitch != null }.sortedBy { it.startBeat }
        if (ns.isEmpty()) return KeySignature(0, Mode.MAJOR, 0.0)
        val hist = DoubleArray(12)
        for ((i, n) in ns.withIndex()) {
            var w = minOf(n.durationBeats, 4.0)
            // Phrase endings and the opening note are usually tonally important.
            if (i == 0 || i == ns.size - 1) w *= 1.5
            hist[Math.floorMod(n.midiPitch!!, 12)] += w
        }
        data class Cand(val tonic: Int, val mode: Mode, val r: Double)
        val cands = ArrayList<Cand>()
        for (tonic in 0 until 12) {
            val rotated = DoubleArray(12) { hist[(it + tonic) % 12] }
            cands.add(Cand(tonic, Mode.MAJOR, correlation(rotated, MAJOR)))
            cands.add(Cand(tonic, Mode.MINOR, correlation(rotated, MINOR)))
        }
        cands.sortByDescending { it.r }
        val best = cands[0]
        val second = cands[1]
        val conf = (0.5 * best.r + 4.0 * (best.r - second.r)).coerceIn(0.0, 1.0)
        return KeySignature(best.tonic, best.mode, conf)
    }

    private fun correlation(a: DoubleArray, b: DoubleArray): Double {
        val ma = a.average()
        val mb = b.average()
        var num = 0.0; var da = 0.0; var db = 0.0
        for (i in a.indices) {
            num += (a[i] - ma) * (b[i] - mb)
            da += (a[i] - ma) * (a[i] - ma)
            db += (b[i] - mb) * (b[i] - mb)
        }
        return if (da == 0.0 || db == 0.0) 0.0 else num / sqrt(da * db)
    }

    @Suppress("unused")
    private fun frac(x: Double) = x - floor(x)
}
