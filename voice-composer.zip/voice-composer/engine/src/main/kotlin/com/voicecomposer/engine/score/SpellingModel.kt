package com.voicecomposer.engine.score

import com.voicecomposer.engine.ml.NoteClassifier
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.NoteSpeller
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.Spelling
import kotlin.math.max
import kotlin.math.min

/**
 * Sharp or flat for the five chromatic pitch classes, from the key and the melodic context: a note approached and left
 * upwards is usually a raised note, downwards a lowered one. Natural notes have one spelling.
 */
object SpellingModel {
    val NAMES = listOf("pc", "fifths", "minor", "degree", "prev", "next", "prev2", "next2", "monotone", "prevInKey", "nextInKey", "inKey", "fifthsAbs")
    val DIM = NAMES.size
    private val NATURAL = mapOf(0 to 'C', 2 to 'D', 4 to 'E', 5 to 'F', 7 to 'G', 9 to 'A', 11 to 'B')
    private val SHARP = mapOf(1 to 'C', 3 to 'D', 6 to 'F', 8 to 'G', 10 to 'A')
    private val FLAT = mapOf(1 to 'D', 3 to 'E', 6 to 'G', 8 to 'A', 10 to 'B')
    fun isChromatic(midi: Int) = Math.floorMod(midi, 12) in SHARP

    /** Feature row for note [i]; null when the note is not chromatic. */
    fun row(midi: IntArray, i: Int, key: KeySignature): DoubleArray? {
        val pc = Math.floorMod(midi[i], 12)
        if (pc !in SHARP) return null
        fun iv(k: Int, dir: Int): Double { val j = i + dir * k; return if (j in midi.indices) max(-12, min(12, (midi[j] - midi[i]) * dir)).toDouble() else 0.0 }
        val scale = key.scalePitchClasses
        fun inKey(j: Int) = if (j in midi.indices && Math.floorMod(midi[j], 12) in scale) 1.0 else 0.0
        val x = DoubleArray(DIM)
        x[0] = pc.toDouble(); x[1] = key.fifths.toDouble(); x[2] = if (key.mode == com.voicecomposer.model.Mode.MINOR) 1.0 else 0.0
        x[3] = Math.floorMod(pc - key.tonic, 12).toDouble()
        x[4] = if (i > 0) (midi[i - 1] - midi[i]).toDouble().coerceIn(-12.0, 12.0) else 0.0   // previous relative to this one
        x[5] = if (i + 1 < midi.size) (midi[i + 1] - midi[i]).toDouble().coerceIn(-12.0, 12.0) else 0.0
        x[6] = if (i > 1) (midi[i - 2] - midi[i]).toDouble().coerceIn(-12.0, 12.0) else 0.0
        x[7] = if (i + 2 < midi.size) (midi[i + 2] - midi[i]).toDouble().coerceIn(-12.0, 12.0) else 0.0
        x[8] = if (x[4] < 0 && x[5] > 0) 1.0 else if (x[4] > 0 && x[5] < 0) -1.0 else 0.0   // approached from below and left upwards => +1
        x[9] = inKey(i - 1); x[10] = inKey(i + 1); x[11] = if (pc in scale) 1.0 else 0.0
        x[12] = kotlin.math.abs(key.fifths).toDouble()
        return x
    }

    /** Spelling of a whole melody; [forest] gives P(flat) for chromatic notes. */
    fun spell(midi: List<Int>, key: KeySignature, forest: NoteClassifier?): List<Spelling> {
        val arr = midi.toIntArray()
        return arr.indices.map { i ->
            val m = arr[i]; val pc = Math.floorMod(m, 12)
            val octave = Math.floorDiv(m, 12) - 1
            NATURAL[pc]?.let { return@map Spelling(it, 0, octave) }
            val x = row(arr, i, key)
            val flat = if (forest != null && x != null) forest.probability(x) >= 0.5 else key.fifths < 0
            if (flat) Spelling(FLAT.getValue(pc), -1, octave) else Spelling(SHARP.getValue(pc), 1, octave)
        }
    }
}

/** Speller backed by the learned model; installed on [NoteSpeller] by the engine. */
class MlSpeller(private val forest: NoteClassifier?) : NoteSpeller {
    override fun spell(midis: List<Int>, key: KeySignature): List<Spelling> = SpellingModel.spell(midis, key, forest)
}
