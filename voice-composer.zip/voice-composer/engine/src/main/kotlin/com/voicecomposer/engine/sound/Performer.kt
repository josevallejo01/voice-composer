package com.voicecomposer.engine.sound

import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.PI

/** A note as a player would actually play it: placed in time, with dynamics, vibrato, scoop and pedal decided. */
class PerformedNote(
    val startSec: Double,
    val durationSec: Double,
    val key: Int,
    val velocity: Int,
    val expression: FloatArray?,
    val vibrato: FloatArray?,
    val vibratoHz: Double,
    val bend: FloatArray?,
    val extraRelease: Double,
    val releaseScale: Double,
)

/**
 * Turns the notes of a track into a performance. A score says what to play; the difference between a MIDI box and a
 * musician is everything this class decides: loudness follows the metre and the shape of the phrase, long notes swell
 * and taper, wind and strings add vibrato after a moment, repeated notes are separated and legato notes joined, chords on
 * guitar and piano are not struck at the very same instant, a pedal lets the piano ring. It is deterministic: the same
 * track always gives the same performance, so renders are repeatable.
 */
object Performer {
    fun perform(track: Track, patch: Patch, map: TempoMap, beatsPerMeasure: Double): List<PerformedNote> {
        val notes = track.events.filter { it.isNote && it.midiPitch != null }.sortedWith(compareBy({ it.startBeat }, { it.midiPitch }))
        if (notes.isEmpty()) return emptyList()
        val rnd = java.util.Random(track.id.hashCode().toLong() * 7919 + notes.size)
        val melodic = track.role == TrackRole.MELODY
        val baseVel = when (track.role) { TrackRole.MELODY -> 88; TrackRole.HARMONY -> 70; TrackRole.BASS -> 82; else -> 66 } + patch.velocityBias
        val out = ArrayList<PerformedNote>(notes.size)

        // Chord groups (same onset) for strums.
        val groupIndex = IntArray(notes.size)
        var gi = 0
        for (i in notes.indices) {
            if (i > 0 && abs(notes[i].startBeat - notes[i - 1].startBeat) < 1e-6) gi++ else gi = 0
            groupIndex[i] = gi
        }

        for (i in notes.indices) {
            val n = notes[i]
            val pitch = n.midiPitch!!
            val s0 = map.beatToSec(n.startBeat)
            var dur = map.beatToSec(n.endBeat) - s0
            if (dur <= 0.0) continue
            // The next and previous notes of the same line (not of the same chord).
            val next = (i + 1 until notes.size).firstOrNull { notes[it].startBeat > n.startBeat + 1e-6 }?.let { notes[it] }
            val prev = (i - 1 downTo 0).firstOrNull { notes[it].startBeat < n.startBeat - 1e-6 }?.let { notes[it] }
            val gapNext = if (next != null) map.beatToSec(next.startBeat) - map.beatToSec(n.endBeat) else 9.0
            val gapPrev = if (prev != null) s0 - map.beatToSec(prev.endBeat) else 9.0
            val contiguousNext = gapNext < 0.12
            val contiguousPrev = gapPrev < 0.12 && prev != null
            val sustained = patch.articulation == Articulation.SUSTAINED

            // ---- dynamics -----------------------------------------------------------------------------------
            val pos = Math.floorMod((n.startBeat / beatsPerMeasure * 1000).toLong(), 1000L) / 1000.0 * beatsPerMeasure
            val accent = when {
                pos < 1e-3 -> 9.0
                abs(pos - beatsPerMeasure / 2) < 1e-3 && beatsPerMeasure >= 4 -> 4.0
                abs(pos - Math.round(pos)) < 1e-3 -> 2.0
                else -> -3.0
            } * (if (melodic) 1.0 else 0.5)
            var contour = 0.0
            if (melodic) {
                val lo = max(0, i - 4); val hi = min(notes.size - 1, i + 4)
                val med = (lo..hi).map { notes[it].midiPitch!! }.sorted().let { it[it.size / 2] }
                contour = ((pitch - med) * 0.9).coerceIn(-6.0, 6.0)
                if (n.durationBeats >= 2.0) contour += 3.0
            }
            val phraseEnd = next == null || gapNext > 0.25
            var vel = baseVel + accent + contour - (if (phraseEnd && melodic) 5.0 else 0.0) + rnd.nextGaussian() * 2.5
            // Higher notes of wind and strings are naturally a little louder, low notes of bass instruments softer.
            if (patch.articulation == Articulation.PLUCKED && dur < 0.3) vel += 3
            val velocity = vel.toInt().coerceIn(30, 122)

            // ---- timing and length --------------------------------------------------------------------------
            var start = s0
            if (!melodic) start += (rnd.nextGaussian() * 0.004).coerceIn(-0.01, 0.01)
            if (patch.strumMs > 0f && groupIndex[i] > 0) start += groupIndex[i] * patch.strumMs / 1000.0
            if (start < 0) start = 0.0
            var releaseScale = 1.0
            if (sustained) {
                if (contiguousNext) {
                    val samePitch = next != null && next.midiPitch == pitch
                    if (samePitch) dur -= min(0.05, dur * 0.25) else { dur += 0.03; releaseScale = 0.55 }
                } else if (!melodic) dur -= min(0.02, dur * 0.1)
                if (dur < 0.06) dur = 0.06
            } else {
                if (dur < 0.3) releaseScale = 0.7
            }
            val pedal = if (patch.pedalSec > 0f) patch.pedalSec * (if (melodic) 0.4 else 1.0) else 0.0

            // ---- expression, vibrato, scoop -----------------------------------------------------------------
            var expr: FloatArray? = null
            var vib: FloatArray? = null
            var vibHz = patch.vibratoHz + rnd.nextGaussian() * 0.25
            var bend: FloatArray? = null
            if (sustained && dur >= 0.22) {
                val m = (dur * 100).toInt() + 30
                val swellT = min(0.32, max(0.08, dur * 0.3)) * (if (dur > 1.5) 1.8 else 1.0)
                val taper = if (phraseEnd) 0.88f else 1f
                expr = FloatArray(m) { k ->
                    val t = k / 100.0
                    val up = (0.76 + 0.24 * min(1.0, t / swellT)).toFloat()
                    val tt = t - (dur - 0.14)
                    val down = if (tt > 0) (1 - (1 - taper) * min(1.0, tt / 0.14)).toFloat() else 1f
                    up * down
                }
            }
            if (sustained && patch.vibratoCents > 0f && dur >= 0.45) {
                val m = (dur * 100).toInt() + 30
                val depth = patch.vibratoCents * (0.85 + rnd.nextDouble() * 0.3) * min(1.0, 0.55 + dur / 1.6)
                val delay = patch.vibratoDelaySec + rnd.nextDouble() * 0.08
                vib = FloatArray(m) { k ->
                    val t = k / 100.0 - delay
                    (if (t <= 0) 0.0 else depth * min(1.0, t / 0.4)).toFloat()
                }
            }
            if (sustained && patch.scoop && contiguousPrev && prev != null) {
                val interval = pitch - prev.midiPitch!!
                if (abs(interval) >= 2) {
                    val c0 = (if (interval > 0) -22.0 else 16.0)
                    bend = FloatArray(14) { k -> (c0 * exp(-k / 100.0 / 0.028)).toFloat() }
                }
            }
            out.add(PerformedNote(start, dur, pitch, velocity, expr, vib, vibHz, bend, pedal, releaseScale))
        }
        return out
    }

    @Suppress("unused") private fun unusedSin() = sin(PI)
}
