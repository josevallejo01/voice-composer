package com.voicecomposer.engine.sound

import com.voicecomposer.model.Instrument
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

class StereoBuffer(val left: FloatArray, val right: FloatArray, val sampleRate: Int) {
    val frames get() = left.size
    val durationSec get() = left.size.toDouble() / sampleRate

    /** Interleaved L R L R 16-bit samples, ready for a stereo AudioTrack. */
    fun toPcm16Interleaved(): ShortArray {
        val out = ShortArray(left.size * 2)
        for (i in left.indices) {
            out[2 * i] = (left[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            out[2 * i + 1] = (right[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        return out
    }

    /** Mono mix (for analysis and for the old mono code paths). */
    fun toMono(): FloatArray = FloatArray(left.size) { (left[it] + right[it]) * 0.5f }
}

/**
 * The orchestra: SoundFont sampler + performance + mixing desk. Each track is played by the [Performer] through the
 * presets of its [Patch], mixed on a stereo stage, sent to a hall reverb, and finished by the master bus. Everything is
 * rendered offline, so there is no polyphony limit and quality never depends on the phone's speed in real time.
 *
 * Stems (a track's own audio, before volume and pan) are cached: moving a fader or a pan re-mixes without re-playing.
 */
class SoundEngine(val font: SoundFont, val sampleRate: Int = 44100, private val stemCacheBytes: Long = 96L * 1024 * 1024) {
    private val synth = SfSynth(font, sampleRate)
    private val calibration = HashMap<Instrument, Float>()

    private class Stem(val l: FloatArray, val r: FloatArray)
    private val stems = object : LinkedHashMap<String, Stem>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Stem>): Boolean = false
    }
    private var stemBytes = 0L

    private fun presetFor(layer: Layer): SoundFont.Preset? =
        font.findPreset(layer.program, layer.bank) ?: font.findPreset(layer.program, 0)

    /** True when the bank has what this instrument needs (a user-supplied bank may be partial). */
    fun supports(i: Instrument) = Patches.of(i).layers.all { presetFor(it) != null }

    // ---- loudness matching ---------------------------------------------------------------------------------------

    /** Linear gain that brings one mezzo-forte note of the patch to a common reference loudness, whatever the bank. */
    private fun calibratedGain(inst: Instrument): Float = synchronized(calibration) {
        calibration.getOrPut(inst) {
            val patch = Patches.of(inst)
            val n = (1.4 * sampleRate).toInt()
            val l = FloatArray(n); val r = FloatArray(n)
            playLayers(patch, PerformedNote(0.0, 0.9, patch.refKey, 90, null, null, 5.0, null, patch.pedalSec.toDouble(), 1.0), l, r, 1f, 1f)
            var e = 0.0
            for (i in 0 until n) e += (l[i] * l[i] + r[i] * r[i]) * 0.5
            val rms = sqrt(e / n)
            val target = 0.045
            val dbTrim = patch.trimDb
            if (rms < 1e-6) 1f else (target / rms * 10.0.pow(dbTrim / 20.0)).coerceIn(0.1, 12.0).toFloat()
        }
    }

    private fun playLayers(patch: Patch, pn: PerformedNote, l: FloatArray, r: FloatArray, gl: Float, gr: Float) {
        val start = (pn.startSec * sampleRate).toInt()
        for (layer in patch.layers) {
            val preset = presetFor(layer) ?: continue
            val g = 10.0.pow(layer.gainDb / 20.0).toFloat()
            val (pl, pr) = panGains(layer.pan + patch.pan)
            val key = (pn.key + 12 * layer.octave).coerceIn(0, 127)
            synth.render(
                preset,
                NoteEvent(
                    key = key, velocity = pn.velocity, duration = pn.durationSec, startFrame = start,
                    gainL = gl * g * pl, gainR = gr * g * pr,
                    expression = pn.expression, vibrato = pn.vibrato, vibratoHz = pn.vibratoHz, bend = pn.bend,
                    extraRelease = pn.extraRelease, releaseScale = pn.releaseScale, tuneCents = layer.detuneCents,
                ),
                l, r,
            )
        }
    }

    private fun panGains(p: Float): Pair<Float, Float> {
        val a = (p.coerceIn(-1f, 1f) + 1f) * (PI / 4).toFloat()
        return cos(a) * 1.4142135f to sin(a) * 1.4142135f
    }

    // ---- rendering -----------------------------------------------------------------------------------------------

    private fun signature(t: Track, map: TempoMap, bpm: Double, frames: Int): String {
        var h = 17L
        for (e in t.events) {
            if (!e.isNote) continue
            h = h * 31 + (e.midiPitch ?: -1)
            h = h * 31 + java.lang.Double.doubleToLongBits(e.startBeat)
            h = h * 31 + java.lang.Double.doubleToLongBits(e.durationBeats)
        }
        h = h * 31 + map.hashCode()
        return "${t.id}|${t.instrument}|${t.role}|$h|$bpm|$frames|$sampleRate"
    }

    private fun renderStem(t: Track, map: TempoMap, bpm: Double, frames: Int, isCancelled: () -> Boolean): Stem {
        val key = signature(t, map, bpm, frames)
        synchronized(stems) { stems[key]?.let { return it } }
        val patch = Patches.of(t.instrument)
        val cal = calibratedGain(t.instrument)
        val l = FloatArray(frames); val r = FloatArray(frames)
        for (pn in Performer.perform(t, patch, map, bpm)) {
            if (isCancelled()) break
            if ((pn.startSec * sampleRate).toInt() >= frames) continue
            playLayers(patch, pn, l, r, cal, cal)
        }
        if (patch.ensemble > 0f) Ensemble(sampleRate).process(l, r, patch.ensemble)
        val stem = Stem(l, r)
        if (!isCancelled()) synchronized(stems) {
            val bytes = frames * 8L
            if (bytes <= stemCacheBytes) {
                while (stemBytes + bytes > stemCacheBytes && stems.isNotEmpty()) {
                    val eldest = stems.entries.first(); stemBytes -= eldest.value.l.size * 8L; stems.remove(eldest.key)
                }
                stems[key] = stem; stemBytes += bytes
            }
        }
        return stem
    }

    fun clearCache() = synchronized(stems) { stems.clear(); stemBytes = 0 }

    private fun roleWeight(r: TrackRole) = when (r) { TrackRole.MELODY -> 1.0f; TrackRole.HARMONY -> 0.62f; TrackRole.BASS -> 0.8f; else -> 0.55f }
    private fun volumeCurve(v: Float) = v.coerceIn(0f, 1.5f).pow(1.6f)

    /**
     * Renders [tracks] positioned by [map]. Disabled or silent tracks are skipped. The result is mastered (loudness and
     * peak ceiling) and has its silence trimmed, but keeps the reverb tail.
     */
    fun render(
        tracks: List<Track>, map: TempoMap, beatsPerMeasure: Double = 4.0, minLengthSec: Double = 0.0,
        reverb: ReverbParams? = ReverbParams(), isCancelled: () -> Boolean = { false }, onProgress: (Float) -> Unit = {},
    ): StereoBuffer {
        val active = tracks.filter { it.enabled && it.volume > 0f && it.events.any { e -> e.isNote } && supports(it.instrument) }
        var endSec = minLengthSec
        for (t in active) for (e in t.events) if (e.isNote) endSec = max(endSec, map.beatToSec(e.endBeat))
        val tail = 2.5 + (reverb?.rt60 ?: 0.0)
        val frames = ceil((endSec + tail) * sampleRate).toInt()
        val dryL = FloatArray(frames); val dryR = FloatArray(frames)
        val busL = if (reverb != null) FloatArray(frames) else FloatArray(0)
        val busR = if (reverb != null) FloatArray(frames) else FloatArray(0)
        for ((idx, t) in active.withIndex()) {
            if (isCancelled()) break
            val stem = renderStem(t, map, beatsPerMeasure, frames, isCancelled)
            val patch = Patches.of(t.instrument)
            val g = roleWeight(t.role) * volumeCurve(t.volume)
            // Balance: panning a stereo stem attenuates the opposite side.
            val bal = t.pan.coerceIn(-1f, 1f)
            val gl = g * (if (bal > 0) 1f - bal else 1f)
            val gr = g * (if (bal < 0) 1f + bal else 1f)
            val send = patch.reverbSend
            for (i in 0 until frames) {
                val a = stem.l[i] * gl; val b = stem.r[i] * gr
                dryL[i] += a; dryR[i] += b
                if (reverb != null) { busL[i] += a * send; busR[i] += b * send }
            }
            onProgress((idx + 1f) / (active.size + 1f) * 0.9f)
        }
        if (reverb != null && !isCancelled()) StereoReverb(sampleRate, reverb).process(busL, busR, dryL, dryR)
        if (!isCancelled()) MasterBus.process(dryL, dryR, sampleRate)
        onProgress(1f)
        return trim(StereoBuffer(dryL, dryR, sampleRate), max(minLengthSec, 0.0))
    }

    /** Cuts the near-silent end (the reverb's last millionth) so the player does not play seconds of nothing. */
    private fun trim(b: StereoBuffer, minSec: Double): StereoBuffer {
        var last = b.frames - 1
        val thr = 3e-5f
        while (last > 0 && abs(b.left[last]) < thr && abs(b.right[last]) < thr) last--
        val keep = min(b.frames, max(last + sampleRate / 4, (minSec * sampleRate).toInt()))
        if (keep >= b.frames) return b
        return StereoBuffer(b.left.copyOf(keep), b.right.copyOf(keep), sampleRate)
    }

    /** One note for the virtual keyboard / instrument chooser, with a touch of room. */
    fun renderNote(instrument: Instrument, midi: Int, durationSec: Double = 1.0, velocity: Int = 90): StereoBuffer {
        if (!supports(instrument)) return StereoBuffer(FloatArray(0), FloatArray(0), sampleRate)
        val patch = Patches.of(instrument)
        val frames = ((durationSec + 3.0) * sampleRate).toInt()
        val l = FloatArray(frames); val r = FloatArray(frames)
        val cal = calibratedGain(instrument)
        val pn = PerformedNote(0.0, durationSec, midi, velocity, null, null, patch.vibratoHz.toDouble(), null, patch.pedalSec * 0.4, 1.0)
        playLayers(patch, pn, l, r, cal, cal)
        if (patch.ensemble > 0f) Ensemble(sampleRate).process(l, r, patch.ensemble)
        val bl = FloatArray(frames); val br = FloatArray(frames)
        for (i in 0 until frames) { bl[i] = l[i] * patch.reverbSend; br[i] = r[i] * patch.reverbSend }
        StereoReverb(sampleRate, ReverbParams(rt60 = 1.6)).process(bl, br, l, r)
        MasterBus.limit(l, r, sampleRate, -1.0)
        return trim(StereoBuffer(l, r, sampleRate), 0.0)
    }
}
