package com.voicecomposer.engine.score

import com.voicecomposer.model.TimeSignature
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Time signature and bar lines (including an anacrusis) as a ranking problem. A hypothesis is a meter plus the beat
 * (in half-beat steps) at which bars start. The forest sees how onset density, note length and accent (long note, note
 * after a rest, leap) distribute over the eighth-note slots of the hypothesised bar, and where the melody starts and ends
 * in it. Beats are those of the tempo/phase decision; beat 0 is arbitrary there.
 */
object BarModel {
    val METERS = listOf(TimeSignature.TWO_FOUR, TimeSignature.THREE_FOUR, TimeSignature.FOUR_FOUR, TimeSignature.SIX_EIGHT)
    val NAMES = listOf(
        "m24", "m34", "m44", "m68", "bpb", "offset", "offsetFrac",
        "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7",
        "w0", "w1", "w2", "w3", "w4", "w5", "w6", "w7",
        "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7",
        "accDown", "accStrong2", "accBeat", "accOff", "contrast", "densDownRatio", "fracDown",
        "pFirst", "pLast", "lastOnDown", "lastEndsBar", "lastDurBeats", "bars", "firstAccent",
    )
    val DIM = NAMES.size

    class Hyp(val meter: TimeSignature, val offsetBeats: Double, val features: DoubleArray)

    /** Beat positions [r] of the note starts, their lengths [dur] in beats, and pitches. */
    fun hypotheses(r: DoubleArray, dur: DoubleArray, midi: IntArray, only: TimeSignature? = null): List<Hyp> {
        val n = r.size
        // Accent of every note: long, after a silence, or approached by a leap.
        val accent = DoubleArray(n) { i ->
            var a = min(dur[i], 3.0)
            if (i > 0 && r[i] - (r[i - 1] + dur[i - 1]) > 0.45) a += 0.5
            if (i > 0 && abs(midi[i] - midi[i - 1]) >= 3) a += 0.4
            a
        }
        val out = ArrayList<Hyp>()
        for (ts in METERS) {
            if (only != null && ts != only) continue
            val bpb = ts.beatsPerMeasure
            val slots = (bpb * 2).toInt()
            var d = 0.0
            while (d < bpb - 1e-9) {
                val x = DoubleArray(DIM)
                x[METERS.indexOf(ts)] = 1.0; x[4] = bpb; x[5] = d; x[6] = d / bpb
                val dens = DoubleArray(8); val dw = DoubleArray(8); val ac = DoubleArray(8)
                var down = 0.0; var downN = 0; var strong2 = 0.0; var strong2N = 0; var onB = 0.0; var onBN = 0; var off = 0.0; var offN = 0
                val strong2Slot = if (ts == TimeSignature.FOUR_FOUR) 4 else if (ts == TimeSignature.SIX_EIGHT) 3 else -1
                for (i in 0 until n) {
                    val p = Math.floorMod(Math.round((r[i] - d) * 2).toInt(), slots)
                    dens[p] += 1.0; dw[p] += min(dur[i], 3.0); ac[p] += accent[i]
                    if (p == 0) { down += accent[i]; downN++ }
                    else if (p == strong2Slot) { strong2 += accent[i]; strong2N++ }
                    else if ((ts == TimeSignature.SIX_EIGHT && false) || (ts != TimeSignature.SIX_EIGHT && p % 2 == 0)) { onB += accent[i]; onBN++ }
                    else { off += accent[i]; offN++ }
                }
                val sd = dens.sum().coerceAtLeast(1.0); val sw = dw.sum().coerceAtLeast(1e-9); val sa = ac.sum().coerceAtLeast(1e-9)
                for (k in 0 until 8) { x[7 + k] = dens[k] / sd; x[15 + k] = dw[k] / sw; x[23 + k] = ac[k] / sa }
                val mDown = if (downN > 0) down / downN else 0.0
                val mStrong2 = if (strong2N > 0) strong2 / strong2N else mDown
                val mBeat = if (onBN > 0) onB / onBN else 0.0
                val mOff = if (offN > 0) off / offN else 0.0
                x[31] = mDown; x[32] = mStrong2; x[33] = mBeat; x[34] = mOff
                x[35] = mDown - (if (onBN + offN > 0) (onB + off) / (onBN + offN) else 0.0)
                x[36] = (dens[0] / sd) * slots
                x[37] = downN.toDouble() / n
                fun fm(v: Double) = ((v % bpb) + bpb) % bpb
                val pFirst = fm(r[0] - d)
                val pLast = fm(r[n - 1] - d)
                val lastEnd = fm(r[n - 1] + dur[n - 1] - d)
                x[38] = pFirst; x[39] = pLast
                x[40] = if (pLast < 0.2 || pLast > bpb - 0.2) 1.0 else 0.0
                x[41] = if (lastEnd < 0.25 || lastEnd > bpb - 0.25) 1.0 else 0.0
                x[42] = min(dur[n - 1], 4.0)
                x[43] = (r[n - 1] - r[0]) / bpb
                x[44] = accent[0]
                out.add(Hyp(ts, d, x))
                d += 0.5
            }
        }
        return out
    }
}
