package com.voicecomposer.engine.ml

import com.voicecomposer.model.Json

/** Probability that a candidate note is a real, correctly pitched note. */
interface NoteClassifier {
    fun probability(x: DoubleArray): Double
}

/**
 * Random forest trained offline with scikit-learn (tools/train_note_forest.py) and exported to JSON, or trained on the
 * device by [ForestTrainer]. Trees are flat arrays: node i is a leaf when feature[i] < 0, otherwise it goes left when
 * the (float32) feature value is <= threshold[i].
 */
class RandomForest(val dim: Int, private val trees: List<Tree>) : NoteClassifier {
    class Tree(val feature: IntArray, val threshold: DoubleArray, val left: IntArray, val right: IntArray, val value: DoubleArray)

    val size get() = trees.size

    override fun probability(x: DoubleArray): Double {
        var s = 0.0
        for (t in trees) {
            var i = 0
            while (t.feature[i] >= 0) i = if (x[t.feature[i]].toFloat() <= t.threshold[i].toFloat()) t.left[i] else t.right[i]
            s += t.value[i]
        }
        return s / trees.size
    }

    fun toJson(): String = Json.write(
        mapOf(
            "dim" to dim,
            "trees" to trees.map {
                mapOf("f" to it.feature.toList(), "t" to it.threshold.toList(), "l" to it.left.toList(), "r" to it.right.toList(), "v" to it.value.toList())
            },
        )
    )

    companion object {
        @Suppress("UNCHECKED_CAST")
        fun fromJson(s: String): RandomForest {
            val m = Json.parse(s) as Map<String, Any?>
            val dim = (m["dim"] as Number).toInt()
            val trees = (m["trees"] as List<Map<String, Any?>>).map { t ->
                fun ints(k: String) = (t[k] as List<Any?>).map { (it as Number).toInt() }.toIntArray()
                fun dbls(k: String) = (t[k] as List<Any?>).map { (it as Number).toDouble() }.toDoubleArray()
                Tree(ints("f"), dbls("t"), ints("l"), ints("r"), dbls("v"))
            }
            return RandomForest(dim, trees)
        }
    }
}

/** Mix of the shipped forest and one trained on the user's own confirmed takes and corrections. */
class BlendedClassifier(private val base: NoteClassifier, private val user: NoteClassifier?, private val userWeight: Double) : NoteClassifier {
    override fun probability(x: DoubleArray): Double {
        val b = base.probability(x)
        val u = user ?: return b
        return (1 - userWeight) * b + userWeight * u.probability(x)
    }
}
