package com.voicecomposer.engine.ml

import com.voicecomposer.engine.segmentation.DetectedNote
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Decides, for each pair of neighbouring notes, whether they are really one note that the detector cut in two.
 * A human voice never holds a pitch still (slow drift, scoops, loudness flutter, vibrato), and the decoder reads every
 * wander across a semitone boundary as a new note: a long note comes out as a string of short ones. A random forest
 * looks at the evidence at each joint (is there a loudness dip, a new onset, a step in the pitch trace, voicing
 * through the gap, how long the pieces are against the rest of the recording) and joins the pieces it believes belong
 * together. The same feature code produces the training rows and the rows used on the device.
 */
object NoteMerger {
    val NAMES = listOf(
        "gap", "durA", "durB", "dPitch", "dKey", "onsetA", "onsetB", "actA", "actB", "dipDb", "step", "slopeA", "slopeB",
        "slopeAgree", "voicedGap", "sdA", "sdB", "medDur", "relA", "relB", "supportA", "supportB", "confA", "confB",
        "stepIdx", "isSing", "isHum", "isWhistle",
    )
    val DIM = NAMES.size
    private const val MAX_GAP = 0.4
    private const val MAX_KEY_DIFF = 3

    /** A neighbouring pair is only worth asking about when it could plausibly be one note. */
    fun eligible(a: DetectedNote, b: DetectedNote) = b.startSec - a.endSec < MAX_GAP && abs(a.midi - b.midi) <= MAX_KEY_DIFF

    /** Feature vector of the joint between [ca] and [cb] (two candidates that are neighbours in the kept list). */
    fun features(ca: MlTranscriptionEngine.Candidate, cb: MlTranscriptionEngine.Candidate, p: MlTranscriptionEngine.Prepared, medDur: Double): DoubleArray {
        val a = ca.note; val b = cb.note
        val yin = p.frames
        val hop = if (yin.size > 1) yin[1].timeSec - yin[0].timeSec else 0.01
        fun trace(from: Double, to: Double): List<Pair<Double, Double>> { // (time, midi) of good voiced frames
            val i0 = (from / hop).toInt().coerceIn(0, yin.size); val i1 = (to / hop).toInt().coerceIn(i0, yin.size)
            val out = ArrayList<Pair<Double, Double>>()
            for (k in i0 until i1) { val f = yin[k]; if (f.voiced && f.confidence >= 0.6) out.add(f.timeSec to f.midi - p.detune) }
            return out
        }
        fun median(v: List<Double>) = if (v.isEmpty()) Double.NaN else v.sorted()[v.size / 2]
        fun slope(t: List<Pair<Double, Double>>): Double {
            if (t.size < 4) return 0.0
            val mt = t.map { it.first }.average(); val mm = t.map { it.second }.average()
            var num = 0.0; var den = 0.0
            for ((x, y) in t) { num += (x - mt) * (y - mm); den += (x - mt) * (x - mt) }
            return if (den < 1e-9) 0.0 else (num / den).coerceIn(-12.0, 12.0)
        }
        val tailA = trace(a.endSec - 0.15, a.endSec)
        val headB = trace(b.startSec, b.startSec + 0.15)
        val mA = median(trace(a.endSec - 0.08, a.endSec).map { it.second })
        val mB = median(trace(b.startSec, b.startSec + 0.08).map { it.second })
        val haveStep = !mA.isNaN() && !mB.isNaN()
        val step = if (haveStep) abs(mB - mA) else abs(b.pitch - a.pitch)
        val sA = slope(tailA); val sB = slope(headB)

        // Loudness dip at the joint, in dB relative to the quieter side (rms has the network's frame rate).
        val fps = BP.FPS / p.timeScale
        fun fr(sec: Double) = (sec * fps).toInt().coerceIn(0, max(0, p.rms.size - 1))
        fun meanRms(from: Double, to: Double): Double {
            val i0 = fr(from); val i1 = max(i0 + 1, fr(to)).coerceAtMost(p.rms.size)
            var s = 0.0; for (k in i0 until i1) s += p.rms[k]; return s / max(1, i1 - i0)
        }
        val levelA = meanRms(a.endSec - 0.2, a.endSec); val levelB = meanRms(b.startSec, b.startSec + 0.2)
        var low = Double.MAX_VALUE
        run { val i0 = fr(a.endSec - 0.05); val i1 = max(i0 + 1, fr(b.startSec + 0.05)).coerceAtMost(p.rms.size); for (k in i0 until i1) low = min(low, p.rms[k]) }
        if (low == Double.MAX_VALUE) low = min(levelA, levelB)
        val dip = ((min(levelA, levelB) - low) / 30.0).coerceIn(-0.5, 2.0)

        val gap = b.startSec - a.endSec
        val gapTrace = if (gap > 0.02) trace(a.endSec, b.startSec).size.toDouble() / max(1.0, gap / hop) else 1.0
        val durA = a.endSec - a.startSec; val durB = b.endSec - b.startSec
        val typeX = DoubleArray(3); NoteFeatures.typeOneHot(p.inputType, typeX, 0)
        val fa = ca.features; val fb = cb.features
        val x = doubleArrayOf(
            gap.coerceIn(-0.2, MAX_GAP), min(3.0, durA), min(3.0, durB), min(2.0, abs(a.pitch - b.pitch)), abs(a.midi - b.midi).toDouble(),
            fa[3], fb[3], fa[1], fb[1], dip, min(3.0, step), sA, sB, (if (sA * sB > 0) 1.0 else if (sA * sB < 0) -1.0 else 0.0),
            gapTrace.coerceIn(0.0, 1.0), fa[8], fb[8], min(2.0, medDur), (durA / max(0.05, medDur)).coerceIn(0.0, 8.0), (durB / max(0.05, medDur)).coerceIn(0.0, 8.0),
            fa[5], fb[5], a.confidence, b.confidence, if (haveStep) 1.0 else 0.0, typeX[0], typeX[1], typeX[2],
        )
        for (i in x.indices) if (!x[i].isFinite()) x[i] = 0.0 // a pitch frame without a value must not poison the forest
        return x
    }

    /** Median length of the kept notes: how long the pieces of this recording are, which tells splitting from short singing. */
    fun medianDuration(notes: List<DetectedNote>): Double =
        if (notes.isEmpty()) 0.3 else notes.map { it.endSec - it.startSec }.sorted().let { it[it.size / 2] }

    /** Rows for every eligible joint of [kept] (index i = joint between kept[i] and kept[i+1]). */
    fun jointRows(kept: List<Pair<MlTranscriptionEngine.Candidate, DetectedNote>>, p: MlTranscriptionEngine.Prepared): List<Pair<Int, DoubleArray>> {
        val med = medianDuration(kept.map { it.second })
        val out = ArrayList<Pair<Int, DoubleArray>>()
        for (i in 0 until kept.size - 1) {
            val (ca, na) = kept[i]; val (cb, nb) = kept[i + 1]
            if (!eligible(na, nb)) continue
            // The candidates carry the pre-selection notes; the features need the notes as they will be kept.
            out.add(i to features(MlTranscriptionEngine.Candidate(na, ca.features, ca.keepByRules), MlTranscriptionEngine.Candidate(nb, cb.features, cb.keepByRules), p, med))
        }
        return out
    }

    /** Joins the notes whose joint the forest believes is not a note boundary. */
    fun merge(kept: List<Pair<MlTranscriptionEngine.Candidate, DetectedNote>>, p: MlTranscriptionEngine.Prepared, forest: RandomForest, threshold: Double = 0.5): List<DetectedNote> {
        if (kept.size < 2) return kept.map { it.second }
        val join = BooleanArray(kept.size - 1)
        for ((i, x) in jointRows(kept, p)) join[i] = forest.probability(x) >= threshold
        val out = ArrayList<DetectedNote>()
        var i = 0
        while (i < kept.size) {
            var j = i
            while (j < join.size && join[j]) j++
            out.add(combine(kept.subList(i, j + 1).map { it.second }))
            i = j + 1
        }
        return out
    }

    /** One note from several pieces: the key most of the time was spent on, its exact pitch from the pieces on that key. */
    fun combine(parts: List<DetectedNote>): DetectedNote {
        if (parts.size == 1) return parts[0]
        val timeOn = HashMap<Int, Double>()
        for (n in parts) timeOn.merge(n.midi, n.endSec - n.startSec, Double::plus)
        val key = timeOn.maxByOrNull { it.value }!!.key
        val onKey = parts.filter { it.midi == key }
        val w = onKey.sumOf { it.endSec - it.startSec }
        val pitch = onKey.sumOf { it.pitch * (it.endSec - it.startSec) } / w
        val total = parts.sumOf { it.endSec - it.startSec }
        return DetectedNote(
            parts.first().startSec, parts.last().endSec, key, if (abs(pitch - key) > 0.7) key.toDouble() else pitch,
            parts.sumOf { it.confidence * (it.endSec - it.startSec) } / total,
            parts.sumOf { it.stability * (it.endSec - it.startSec) } / total,
            parts.maxOf { it.level },
        )
    }
}
