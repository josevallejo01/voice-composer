package com.voicecomposer.engine.profile

import com.voicecomposer.engine.ml.DecoderParams
import com.voicecomposer.engine.ml.forInput
import com.voicecomposer.model.Json
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.ValidationState
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Personalization without cloud and without opaque training: every corrected score teaches the engine something about
 * one singer, and all of it is plain statistics that can be inspected and reset.
 *
 *  - which detected notes the singer deletes or keeps -> a small logistic model of "is this a real note" (also used to
 *    calibrate the confidence shown to the user), and the bias of silence vs. note in the decoder;
 *  - how often notes are merged or split by hand -> how eagerly repeated notes are cut;
 *  - which pitches the singer actually uses -> a pitch-range prior that removes octave ghosts and out-of-range notes.
 *
 * Each project writes one [Contribution], recomputed from "what the engine found" versus "what the user kept", so
 * re-saving the same project never counts twice, and deleting a project can remove what it taught.
 */
object ProfileFeatures {
    const val DIM = 7

    /** Same features computed from a raw detection (calibration), consistent with the confidence the quantizer stores. */
    fun ofDetected(d: com.voicecomposer.engine.segmentation.DetectedNote, prev: com.voicecomposer.engine.segmentation.DetectedNote?, next: com.voicecomposer.engine.segmentation.DetectedNote?): DoubleArray {
        val gapBefore = if (prev == null) 1.5 else (d.startSec - prev.endSec).coerceIn(0.0, 1.5)
        val gapAfter = if (next == null) 1.5 else (next.startSec - d.endSec).coerceIn(0.0, 1.5)
        val p = (d.midi - 60) / 12.0
        val conf = (d.confidence * (0.6 + 0.4 * d.stability)).coerceIn(0.0, 1.0)
        return doubleArrayOf(1.0, conf, ln(max(0.03, d.endSec - d.startSec)), gapBefore, gapAfter, p, p * p)
    }

    /** Features of a detected note known at analysis time and recoverable from the stored transcription. */
    fun of(e: MusicalEvent, prev: MusicalEvent?, next: MusicalEvent?): DoubleArray {
        val gapBefore = if (prev == null) 1.5 else (e.startSec - prev.endSec).coerceIn(0.0, 1.5)
        val gapAfter = if (next == null) 1.5 else (next.startSec - e.endSec).coerceIn(0.0, 1.5)
        val p = ((e.midiPitch ?: 60) - 60) / 12.0
        return doubleArrayOf(1.0, e.confidence, ln(max(0.03, e.durationSec)), gapBefore, gapAfter, p, p * p)
    }
}

class NoteRow(val x: DoubleArray, val label: Double, val weight: Double)

class Contribution(
    val projectId: String,
    val rows: List<NoteRow>,
    /** How often each piano key (index 0 = A0) appears in the final score. */
    val pitchCounts: IntArray,
    val engineNotes: Int,
    val falsePositives: Int,
    val missed: Int,
    val merges: Int,
    val splits: Int,
    val finalNotes: Int,
    /** InputType name the notes were sung/hummed/whistled with; profiles are kept separate per kind of sound. */
    val inputType: String = "SINGING",
) {
    fun toJson(): String = Json.write(
        mapOf(
            "v" to 1, "project" to projectId, "engineNotes" to engineNotes, "fp" to falsePositives, "missed" to missed,
            "merges" to merges, "splits" to splits, "finalNotes" to finalNotes, "type" to inputType,
            "pitch" to pitchCounts.toList(),
            "rows" to rows.map { listOf(it.label, it.weight) + it.x.toList() },
        )
    )

    companion object {
        @Suppress("UNCHECKED_CAST")
        fun fromJson(s: String): Contribution? = runCatching {
            val m = Json.parse(s) as Map<String, Any?>
            fun i(k: String) = (m[k] as Number).toInt()
            val pitch = (m["pitch"] as List<Any?>).map { (it as Number).toInt() }.toIntArray()
            val rows = (m["rows"] as List<Any?>).map { r ->
                val l = (r as List<Any?>).map { (it as Number).toDouble() }
                NoteRow(l.subList(2, 2 + ProfileFeatures.DIM).toDoubleArray(), l[0], l[1])
            }
            Contribution(m["project"] as String, rows, pitch, i("engineNotes"), i("fp"), i("missed"), i("merges"), i("splits"), i("finalNotes"), (m["type"] as? String) ?: "SINGING")
        }.getOrNull()
    }
}

object ContributionBuilder {
    private const val UNREVIEWED_WEIGHT = 0.3

    private fun overlap(a: MusicalEvent, b: MusicalEvent): Double = min(a.endSec, b.endSec) - max(a.startSec, b.startSec)

    private fun touches(a: MusicalEvent, b: MusicalEvent): Boolean {
        val o = overlap(a, b)
        return o >= 0.04 && o >= 0.3 * min(a.durationSec, b.durationSec)
    }

    /** [engine] is what the engine proposed, [final] what the user ended up with. */
    fun build(projectId: String, engine: Transcription, final: Transcription, inputType: String = "SINGING"): Contribution {
        val e = engine.notes.sortedBy { it.startSec }
        val f = final.notes.sortedBy { it.startSec }
        val rows = ArrayList<NoteRow>()
        var fp = 0; var merges = 0; var splits = 0; var missed = 0
        for ((i, n) in e.withIndex()) {
            val x = ProfileFeatures.of(n, e.getOrNull(i - 1), e.getOrNull(i + 1))
            val hits = f.filter { touches(n, it) }
            val same = hits.filter { it.midiPitch == n.midiPitch }
            when {
                same.isNotEmpty() -> {
                    val reviewed = same.any { it.validation == ValidationState.VALIDATED }
                    rows.add(NoteRow(x, 1.0, if (reviewed) 1.0 else UNREVIEWED_WEIGHT))
                    if (same.size >= 2) splits += same.size - 1
                }
                hits.isNotEmpty() -> rows.add(NoteRow(x, 1.0, 0.6)) // right place, wrong pitch: it was a note
                else -> { rows.add(NoteRow(x, 0.0, 1.0)); fp++ }
            }
        }
        for (n in f) {
            val hits = e.filter { touches(n, it) }
            if (hits.isEmpty()) missed++
            else {
                val same = hits.filter { it.midiPitch == n.midiPitch }
                if (same.size >= 2) merges += same.size - 1
            }
        }
        val counts = IntArray(88)
        for (n in f) n.midiPitch?.let { p -> if (p in 21..108) counts[p - 21]++ }
        return Contribution(projectId, rows, counts, e.size, fp, missed, merges, splits, f.size, inputType)
    }
}

/** The aggregated knowledge about one singer. */
class VoiceProfile(
    val engineNotes: Int,
    val projects: Int,
    val decoder: DecoderParams,
    val weights: DoubleArray?,
) {
    /** 0 for a new user, approaching 1 as evidence accumulates (about 200 notes for half way). */
    val maturity: Double get() = engineNotes / (engineNotes + 200.0)

    fun acceptProbability(x: DoubleArray): Double? = weights?.let { sigmoid(dot(it, x)) }

    /** Blends the engine's own confidence with what was learned from this singer's corrections. */
    fun calibrate(e: MusicalEvent, prev: MusicalEvent?, next: MusicalEvent?): Double {
        val p = acceptProbability(ProfileFeatures.of(e, prev, next)) ?: return e.confidence
        val m = maturity.coerceAtMost(0.8)
        return ((1 - m) * e.confidence + m * p).coerceIn(0.0, 1.0)
    }

    companion object {
        private val PRIOR = doubleArrayOf(-2.0, 4.0, 0.5, 0.0, 0.0, 0.0, -0.3)
        private fun sigmoid(z: Double) = 1.0 / (1.0 + exp(-z))
        private fun dot(a: DoubleArray, b: DoubleArray): Double { var s = 0.0; for (i in a.indices) s += a[i] * b[i]; return s }

        val EMPTY = VoiceProfile(0, 0, DecoderParams(), null)

        /**
         * [type] selects the contributions of that kind of sound only; [base] is the starting point (defaults for the
         * type, or what the calibration measured on the user's own voice).
         */
        fun build(
            all: List<Contribution>,
            type: com.voicecomposer.engine.preprocessing.InputType = com.voicecomposer.engine.preprocessing.InputType.SINGING,
            base: DecoderParams = DecoderParams.forInput(type),
        ): VoiceProfile {
            val key = if (type == com.voicecomposer.engine.preprocessing.InputType.VOCALISE) "SINGING" else type.name
            val contribs = all.filter { it.inputType == key }
            if (contribs.isEmpty()) return VoiceProfile(0, 0, base, null)
            val n = contribs.sumOf { it.engineNotes }
            if (n == 0) return VoiceProfile(0, contribs.size, base, null)
            val maturity = n / (n + 200.0)
            val fpRate = contribs.sumOf { it.falsePositives }.toDouble() / n
            val finals = max(1, contribs.sumOf { it.finalNotes })
            val fnRate = contribs.sumOf { it.missed }.toDouble() / finals
            val over = contribs.sumOf { it.merges }.toDouble() / n
            val under = contribs.sumOf { it.splits }.toDouble() / n
            val d0 = base

            val restBias = (8.0 * (fpRate - fnRate)).coerceIn(-1.0, 1.5) * maturity
            val cutDelta = (over - under) * 1.2
            val strong = d0.strongOnset + maturity * ((d0.strongOnset + cutDelta).coerceIn(0.6, 0.95) - d0.strongOnset)
            val weak = d0.weakOnset + maturity * ((d0.weakOnset + cutDelta).coerceIn(0.3, 0.8) - d0.weakOnset)
            val dip = d0.dipDb + maturity * ((d0.dipDb + 8.0 * (over - under)).coerceIn(2.0, 8.0) - d0.dipDb)

            val decoder = d0.copy(
                restBias = d0.restBias + restBias, strongOnset = strong, weakOnset = weak.coerceAtMost(strong - 0.1), dipDb = dip,
                keyLogPrior = pitchPrior(contribs),
            )
            return VoiceProfile(n, contribs.size, decoder, fitLogistic(contribs))
        }

        /** Smoothed log-frequency of the pitches used, relative to uniform; null until the singer's range is known. */
        private fun pitchPrior(contribs: List<Contribution>): DoubleArray? {
            val counts = DoubleArray(88)
            for (c in contribs) for (k in 0 until 88) counts[k] += c.pitchCounts[k].toDouble()
            val total = counts.sum()
            if (total < 30) return null
            val smooth = DoubleArray(88)
            val kernel = doubleArrayOf(0.1, 0.25, 1.0, 0.25, 0.1)
            for (k in 0 until 88) for (j in -2..2) if (k + j in 0 until 88) smooth[k] += counts[k + j] * kernel[j + 2]
            val ssum = smooth.sum()
            val strength = min(1.0, total / 120.0) * 0.5
            return DoubleArray(88) { k ->
                val p = (smooth[k] / ssum * 0.95 + 0.05 / 88)
                (strength * ln(p * 88)).coerceIn(-1.5, 0.3)
            }
        }

        private fun fitLogistic(contribs: List<Contribution>): DoubleArray? {
            val rows = contribs.flatMap { it.rows }
            val wsum = rows.sumOf { it.weight }
            if (rows.size < 20 || rows.none { it.label < 0.5 }) return if (rows.size >= 20) PRIOR.copyOf() else null
            val w = PRIOR.copyOf()
            val lambda = 5.0 / wsum
            repeat(300) {
                val g = DoubleArray(ProfileFeatures.DIM)
                for (r in rows) {
                    val err = sigmoid(dot(w, r.x)) - r.label
                    for (i in g.indices) g[i] += r.weight * err * r.x[i] / wsum
                }
                for (i in w.indices) w[i] -= 0.5 * (g[i] + lambda * (w[i] - PRIOR[i]))
            }
            return w
        }
    }
}

/** Convenience used by tests and the app: is [e] more likely a real note than not, according to the singer's history. */
fun VoiceProfile.looksReal(e: MusicalEvent, prev: MusicalEvent? = null, next: MusicalEvent? = null): Boolean =
    (acceptProbability(ProfileFeatures.of(e, prev, next)) ?: 1.0) >= 0.5

