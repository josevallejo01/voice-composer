package com.voicecomposer.engine.pitch

import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.preprocessing.Resampler
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Reads the one note a person sings, hums or whistles to correct a note of the score ("sing the right note").
 * Takes the steadiest voiced stretch of the take (not the first or last sounds, which glide), returns its median pitch.
 * Returns null when nothing steady was heard.
 */
object SungNoteReader {
    private const val RATE = 16000

    fun read(samples: FloatArray, sampleRate: Int, type: InputType = InputType.SINGING): Int? {
        if (samples.size < sampleRate / 5) return null
        val x = Resampler.resample(samples, sampleRate, RATE)
        val frames = YinPitchTracker(RATE, type).track(x)
        val voiced = frames.map { it.voiced && it.confidence >= 0.6 && it.midi > 0 }
        // The pitch that most voiced frames agree on (within half a semitone): the held note, not the glide into it.
        val mids = frames.indices.filter { voiced[it] }.map { frames[it].midi }
        if (mids.size < 8) return null
        var bestCount = 0
        var bestCenter = 0.0
        for (c in mids) {
            val n = mids.count { abs(it - c) < 0.5 }
            if (n > bestCount) { bestCount = n; bestCenter = c }
        }
        if (bestCount < 8) return null
        val group = mids.filter { abs(it - bestCenter) < 0.5 }.sorted()
        return group[group.size / 2].roundToInt()
    }
}
