package com.voicecomposer.engine.score

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Tempo and beat phase as a ranking problem. Candidates: peaks of the onset comb alignment and their metrical relatives
 * (half, double, 2/3, 3/2), each refined and given its best beat phases. The forest scores every (tempo, phase)
 * candidate from how the onsets sit on its grid, what the inter-onset intervals look like in beats, and the tempo itself.
 */
object TempoPhase {
    val NAMES = listOf(
        "log2Bpm", "absLog2Bpm", "alignBeat", "alignEighth", "align16th", "alignBar2", "log2MedIoi",
        "ioi025", "ioi05", "ioi075", "ioi1", "ioi15", "ioi2", "ioi3", "ioi4", "ioiOff",
        "onBeat60", "onEighth60", "err16", "costPerNote", "phaseRank", "costGap", "alignRank", "log2RatioBest",
        "logN", "firstFrac", "durBeats",
    )
    val DIM = NAMES.size
    const val MIN_BPM = 40.0
    const val MAX_BPM = 220.0

    class Cand(val bpm: Double, val originSec: Double, val features: DoubleArray)

    private fun log2(x: Double) = ln(x) / ln(2.0)

    private fun alignment(t: DoubleArray, period: Double): Double {
        var c = 0.0; var s = 0.0
        for (x in t) { val th = 2 * PI * x / period; c += cos(th); s += sin(th) }
        return sqrt(c * c + s * s) / t.size
    }

    private fun combAlign(t: DoubleArray, bpm: Double): Double {
        val beat = 60.0 / bpm
        return 0.4 * alignment(t, beat) + 0.6 * alignment(t, beat / 2)
    }

    /** Placement cost of the onsets on a beat grid whose beat 0 is at [origin] (beat and subdivision levels only). */
    private fun gridCost(t: DoubleArray, bpm: Double, origin: Double): Double {
        val beat = 60.0 / bpm
        val sigma = max(0.045, 0.1 * beat)
        var total = 0.0
        for (x in t) {
            val g = (x - origin) / beat / 0.25
            val base = Math.round(g).toInt()
            var best = Double.MAX_VALUE
            for (k in base - 1..base + 1) {
                val d = (x - (origin + k * 0.25 * beat)) / sigma
                val level = if (Math.floorMod(k, 4) == 0) 0.0 else if (Math.floorMod(k, 2) == 0) 0.5 else 1.1
                val c = min(0.5 * d * d, 6.0) + level
                if (c < best) best = c
            }
            total += best
        }
        return total
    }

    /** Tempo candidates (BPM) from the comb alignment curve. */
    fun bpmCandidates(t: DoubleArray): List<Double> {
        val curve = ArrayList<Pair<Double, Double>>()
        var b = MIN_BPM
        while (b <= MAX_BPM) { curve.add(b to combAlign(t, b)); b += 0.5 }
        val peaks = ArrayList<Pair<Double, Double>>()
        for (i in 1 until curve.size - 1) if (curve[i].second >= curve[i - 1].second && curve[i].second > curve[i + 1].second) peaks.add(curve[i])
        peaks.sortByDescending { it.second }
        val chosen = ArrayList<Double>()
        for (p in peaks) { if (chosen.size >= 5) break; if (chosen.none { abs(it / p.first - 1) < 0.05 }) chosen.add(p.first) }
        val out = ArrayList<Double>()
        for (p in chosen) for (r in doubleArrayOf(1.0, 0.5, 2.0, 2.0 / 3, 1.5)) {
            val v = p * r
            if (v < MIN_BPM || v > MAX_BPM) continue
            // Refine around the candidate with the comb alignment.
            var best = v; var bs = -1.0
            var x = v * 0.97
            while (x <= v * 1.03) { val s = combAlign(t, x); if (s > bs) { bs = s; best = x }; x += v * 0.002 }
            if (out.none { abs(it / best - 1) < 0.03 }) out.add(best)
            if (out.size >= 12) break
        }
        return out
    }

    /**
     * Candidates for the given onsets (seconds, sorted). With [knownBpm] only the phase is searched, inside a window
     * around [originHint] when there is one (metronome count-in).
     */
    fun candidates(t: DoubleArray, knownBpm: Double? = null, originHint: Double? = null): List<Cand> {
        if (t.size < 2) return emptyList()
        val bpms = if (knownBpm != null) listOf(knownBpm) else bpmCandidates(t)
        val iois = (1 until t.size).map { t[it] - t[it - 1] }.filter { it > 0.06 }.sorted()
        val medIoi = if (iois.isEmpty()) 0.5 else iois[iois.size / 2]
        val alignBest = bpms.maxOfOrNull { combAlign(t, it) } ?: 0.0
        val alignRanks = bpms.sortedByDescending { combAlign(t, it) }
        val bestBpm = alignRanks.firstOrNull() ?: 100.0
        class Raw(val bpm: Double, val origin: Double, val cost: Double, val phaseRank: Int)
        val raws = ArrayList<Raw>()
        for (bpm in bpms) {
            val beat = 60.0 / bpm
            val lo: Double; val hi: Double; val step: Double
            if (originHint != null) { val w = min(0.25, 0.4 * beat); lo = originHint - w; hi = originHint + w; step = 0.004 }
            else { lo = t[0] - beat; hi = t[0]; step = max(0.002, beat / 48) }
            val xs = ArrayList<Double>(); val cs = ArrayList<Double>()
            var o = lo
            while (o <= hi + 1e-9) { xs.add(o); cs.add(gridCost(t, bpm, o)); o += step }
            // local minima, best first, at least 0.15 beat apart
            val idx = (0 until xs.size).filter { i -> (i == 0 || cs[i] <= cs[i - 1]) && (i == xs.size - 1 || cs[i] < cs[i + 1]) }.sortedBy { cs[it] }
            val picked = ArrayList<Int>()
            for (i in idx) { if (picked.size >= (if (originHint != null) 3 else 2)) break; if (picked.none { abs(xs[it] - xs[i]) < 0.15 * beat }) picked.add(i) }
            if (picked.isEmpty()) picked.add(cs.indices.minByOrNull { cs[it] } ?: 0)
            for ((rank, i) in picked.withIndex()) raws.add(Raw(bpm, xs[i], cs[i], rank))
        }
        val minCost = raws.minOfOrNull { it.cost / t.size } ?: 0.0
        val total = t.last() - t.first()
        return raws.map { r ->
            val beat = 60.0 / r.bpm
            val pos = DoubleArray(t.size) { (t[it] - r.origin) / beat }
            fun near(x: Double, tolBeats: Double) = abs(x - Math.round(x)) <= tolBeats
            var onBeat = 0; var onEighth = 0; var err16 = 0.0
            for (p in pos) {
                if (near(p, 0.06 / beat)) onBeat++
                if (near(p * 2, 0.06 / beat * 2)) onEighth++
                err16 += abs(p * 4 - Math.round(p * 4)) / 4.0
            }
            val ioiB = iois.map { it / beat }
            fun frac(v: Double) = if (ioiB.isEmpty()) 0.0 else ioiB.count { abs(it - v) <= max(0.06, 0.12 * v) }.toDouble() / ioiB.size
            val offGrid = if (ioiB.isEmpty()) 0.0 else ioiB.count { abs(it * 4 - Math.round(it * 4)) / 4.0 > 0.1 }.toDouble() / ioiB.size
            val x = DoubleArray(DIM)
            x[0] = log2(r.bpm / 100.0); x[1] = abs(x[0])
            x[2] = alignment(t, beat); x[3] = alignment(t, beat / 2); x[4] = alignment(t, beat / 4); x[5] = alignment(t, beat * 2)
            x[6] = log2(medIoi / beat)
            x[7] = frac(0.25); x[8] = frac(0.5); x[9] = frac(0.75); x[10] = frac(1.0); x[11] = frac(1.5); x[12] = frac(2.0); x[13] = frac(3.0); x[14] = frac(4.0); x[15] = offGrid
            x[16] = onBeat.toDouble() / t.size; x[17] = onEighth.toDouble() / t.size; x[18] = err16 / t.size
            x[19] = r.cost / t.size; x[20] = r.phaseRank.toDouble(); x[21] = r.cost / t.size - minCost
            x[22] = alignRanks.indexOf(bpms.minByOrNull { abs(it - r.bpm) }).toDouble().coerceAtLeast(0.0)
            x[23] = log2(r.bpm / bestBpm)
            x[24] = ln(t.size.toDouble()); x[25] = pos[0] - floor(pos[0]); x[26] = total / beat / 100.0
            Cand(r.bpm, r.origin, x)
        }
    }
}
