package com.voicecomposer.engine.sound

import com.voicecomposer.model.Instrument

enum class Articulation { SUSTAINED, PLUCKED, STRUCK }

/** One SoundFont preset inside a patch. Stacking two presets (slow + fast strings, choir + oohs) gives a fuller, less synthetic section. */
class Layer(val program: Int, val gainDb: Float = 0f, val detuneCents: Double = 0.0, val pan: Float = 0f, val octave: Int = 0, val bank: Int = 0)

/**
 * How an instrument is played and placed: which presets, how it is articulated, how much vibrato a player would add,
 * where it sits on the stage and how much hall it gets. All loudness is matched automatically (see SoundEngine), so
 * these numbers describe character, not level.
 */
class Patch(
    val layers: List<Layer>,
    val articulation: Articulation = Articulation.SUSTAINED,
    val pan: Float = 0f,
    val reverbSend: Float = 0.2f,
    val ensemble: Float = 0f,
    val vibratoCents: Float = 0f,
    val vibratoDelaySec: Float = 0.3f,
    val vibratoHz: Float = 5.3f,
    val scoop: Boolean = false,
    /** The sustain pedal / natural ringing added after note-off, in seconds. */
    val pedalSec: Float = 0f,
    /** Delay between the notes of one chord (a strum, a rolled chord). */
    val strumMs: Float = 0f,
    val velocityBias: Int = 0,
    /** Level trim on top of the automatic matching, in dB. */
    val trimDb: Float = 0f,
    /** Reference key used to measure loudness. */
    val refKey: Int = 60,
)

object Patches {
    fun of(i: Instrument): Patch = table.getValue(i)

    private val table: Map<Instrument, Patch> = mapOf(
        Instrument.LEAD to Patch(listOf(Layer(80)), reverbSend = 0.15f),
        Instrument.PAD to Patch(listOf(Layer(89)), reverbSend = 0.35f, ensemble = 0.4f),
        Instrument.PIANO to Patch(listOf(Layer(0)), Articulation.STRUCK, pan = 0f, reverbSend = 0.22f, pedalSec = 0.35f, strumMs = 6f, refKey = 60),
        Instrument.ACOUSTIC_GUITAR to Patch(listOf(Layer(25)), Articulation.PLUCKED, pan = -0.3f, reverbSend = 0.2f, strumMs = 13f),
        Instrument.NYLON_GUITAR to Patch(listOf(Layer(24)), Articulation.PLUCKED, pan = -0.3f, reverbSend = 0.22f, strumMs = 16f),
        Instrument.ELECTRIC_BASS to Patch(listOf(Layer(33)), Articulation.PLUCKED, reverbSend = 0.04f, refKey = 40),
        Instrument.UPRIGHT_BASS to Patch(listOf(Layer(32)), Articulation.PLUCKED, reverbSend = 0.08f, refKey = 40),
        Instrument.DOUBLE_BASS to Patch(listOf(Layer(43)), Articulation.SUSTAINED, reverbSend = 0.12f, vibratoCents = 5f, vibratoDelaySec = 0.5f, refKey = 40),
        Instrument.CELLO to Patch(listOf(Layer(42)), pan = 0.25f, reverbSend = 0.3f, vibratoCents = 13f, vibratoDelaySec = 0.3f, vibratoHz = 5.0f, scoop = true, refKey = 48),
        Instrument.VIOLIN to Patch(listOf(Layer(40)), pan = -0.2f, reverbSend = 0.3f, vibratoCents = 16f, vibratoDelaySec = 0.25f, vibratoHz = 5.6f, scoop = true, refKey = 67),
        Instrument.VIOLA to Patch(listOf(Layer(41)), pan = 0.15f, reverbSend = 0.3f, vibratoCents = 13f, vibratoDelaySec = 0.28f, vibratoHz = 5.2f, scoop = true, refKey = 57),
        Instrument.STRINGS to Patch(
            listOf(Layer(49, 0f, -3.0, -0.2f), Layer(48, -4f, 4.0, 0.25f)),
            ensemble = 0.5f, reverbSend = 0.36f, vibratoCents = 6f, vibratoDelaySec = 0.5f, vibratoHz = 5.0f, refKey = 60,
        ),
        Instrument.HARP to Patch(listOf(Layer(46)), Articulation.PLUCKED, pan = 0.3f, reverbSend = 0.36f, pedalSec = 0.7f, refKey = 72),
        Instrument.FLUTE to Patch(listOf(Layer(73)), reverbSend = 0.26f, vibratoCents = 9f, vibratoDelaySec = 0.35f, vibratoHz = 5.1f, refKey = 76),
        Instrument.OBOE to Patch(listOf(Layer(68)), reverbSend = 0.26f, vibratoCents = 7f, vibratoDelaySec = 0.35f, vibratoHz = 5.4f, refKey = 72),
        Instrument.CLARINET to Patch(listOf(Layer(71)), reverbSend = 0.24f, vibratoCents = 3f, vibratoDelaySec = 0.5f, refKey = 67),
        Instrument.FRENCH_HORN to Patch(listOf(Layer(60)), pan = 0.3f, reverbSend = 0.32f, vibratoCents = 4f, vibratoDelaySec = 0.45f, vibratoHz = 4.8f, refKey = 60),
        Instrument.TRUMPET to Patch(listOf(Layer(56)), pan = 0.05f, reverbSend = 0.2f, vibratoCents = 6f, vibratoDelaySec = 0.4f, vibratoHz = 5.2f, scoop = true, refKey = 72),
        Instrument.CHOIR to Patch(
            listOf(Layer(52), Layer(53, -3f, 5.0, 0.15f)),
            ensemble = 0.3f, reverbSend = 0.42f, vibratoCents = 7f, vibratoDelaySec = 0.4f, vibratoHz = 5.0f, refKey = 64,
        ),
    )
}
