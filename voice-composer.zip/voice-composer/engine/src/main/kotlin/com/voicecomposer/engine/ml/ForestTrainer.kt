package com.voicecomposer.engine.ml

import java.util.Random
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Small CART random forest trainer that runs on the phone. The shipped forest (scikit-learn, trained on thousands of
 * synthetic noisy clips) knows noise in general; this one learns from the singer's own confirmed notes and corrections
 * what *their* room and voice look like, and is blended with the shipped one (see [BlendedClassifier]).
 *
 * Regularisation against noisy labels and tiny data: bootstrap per tree, sqrt(features) per split, depth and leaf-size
 * limits, class-balanced weights, and Gaussian feature jitter on the training rows.
 */
object ForestTrainer {
    fun train(
        x: List<DoubleArray>,
        y: IntArray,
        trees: Int = 40,
        maxDepth: Int = 7,
        minLeaf: Int = 3,
        jitter: Double = 0.05,
        seed: Long = 11,
    ): RandomForest? {
        val n = x.size
        if (n < 12 || y.sum() < 4 || y.sum() > n - 4) return null // needs both classes
        val dim = x[0].size
        val rnd = Random(seed)
        val sd = DoubleArray(dim) { f ->
            val m = x.sumOf { it[f] } / n
            sqrt(x.sumOf { (it[f] - m) * (it[f] - m) } / n) + 1e-9
        }
        val pos = y.sum().toDouble(); val neg = n - pos
        val wPos = n / (2 * pos); val wNeg = n / (2 * neg)
        val out = ArrayList<RandomForest.Tree>(trees)
        repeat(trees) {
            val rows = IntArray(n) { rnd.nextInt(n) }
            val xs = Array(n) { i -> DoubleArray(dim) { f -> x[rows[i]][f] + rnd.nextGaussian() * sd[f] * jitter } }
            val ys = IntArray(n) { y[rows[it]] }
            out.add(grow(xs, ys, wPos, wNeg, maxDepth, minLeaf, rnd))
        }
        return RandomForest(dim, out)
    }

    private class Builder {
        val f = ArrayList<Int>(); val t = ArrayList<Double>(); val l = ArrayList<Int>(); val r = ArrayList<Int>(); val v = ArrayList<Double>()
        fun node(): Int { f.add(-1); t.add(0.0); l.add(-1); r.add(-1); v.add(0.0); return f.size - 1 }
    }

    private fun grow(x: Array<DoubleArray>, y: IntArray, wPos: Double, wNeg: Double, maxDepth: Int, minLeaf: Int, rnd: Random): RandomForest.Tree {
        val b = Builder()
        val dim = x[0].size
        val mtry = max(1, sqrt(dim.toDouble()).toInt())
        fun build(idx: IntArray, depth: Int): Int {
            val id = b.node()
            var p = 0.0; var q = 0.0
            for (i in idx) if (y[i] == 1) p += wPos else q += wNeg
            b.v[id] = if (p + q > 0) p / (p + q) else 0.0
            if (depth >= maxDepth || idx.size < 2 * minLeaf || p == 0.0 || q == 0.0) return id
            var bestGain = 1e-9; var bestF = -1; var bestT = 0.0
            val parent = gini(p, q) * (p + q)
            val feats = (0 until dim).shuffled(rnd).take(mtry)
            for (f in feats) {
                val order = idx.sortedBy { x[it][f] }
                var lp = 0.0; var lq = 0.0
                for (k in 0 until order.size - 1) {
                    val i = order[k]
                    if (y[i] == 1) lp += wPos else lq += wNeg
                    val a = x[i][f]; val c = x[order[k + 1]][f]
                    if (c <= a || k + 1 < minLeaf || order.size - k - 1 < minLeaf) continue
                    val rp = p - lp; val rq = q - lq
                    val gain = parent - gini(lp, lq) * (lp + lq) - gini(rp, rq) * (rp + rq)
                    if (gain > bestGain) { bestGain = gain; bestF = f; bestT = (a.toFloat() + c.toFloat()) / 2.0 }
                }
            }
            if (bestF < 0) return id
            val left = idx.filter { x[it][bestF].toFloat() <= bestT.toFloat() }.toIntArray()
            val right = idx.filter { x[it][bestF].toFloat() > bestT.toFloat() }.toIntArray()
            if (left.isEmpty() || right.isEmpty()) return id
            b.f[id] = bestF; b.t[id] = bestT
            b.l[id] = build(left, depth + 1)
            b.r[id] = build(right, depth + 1)
            return id
        }
        build(IntArray(x.size) { it }, 0)
        return RandomForest.Tree(b.f.toIntArray(), b.t.toDoubleArray(), b.l.toIntArray(), b.r.toIntArray(), b.v.toDoubleArray())
    }

    private fun gini(p: Double, q: Double): Double { val s = p + q; if (s <= 0) return 0.0; val a = p / s; return 2 * a * (1 - a) }

    /** Weight of the user's forest in the blend: grows with the amount of own data, never above 0.6. */
    fun userWeight(rows: Int): Double = min(0.6, rows / (rows + 60.0))
}
