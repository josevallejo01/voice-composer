package com.voicecomposer.engine.ml

import com.voicecomposer.engine.preprocessing.InputType
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.PI
import kotlin.math.cos

/**
 * What the note classifier looks at. Three groups: what the network says (activation, onset, dominance), what an
 * independent pitch trace says (support, confidence, octave alternatives), and what the signal itself is
 * (level above the room, spectral flatness and harmonicity). Noise is flat, non-harmonic and not above the room; a
 * note is the opposite. The same code produces the training rows and the rows used on the device.
 */
object NoteFeatures {
    val NAMES = listOf(
        "dur", "meanAct", "maxAct", "onset", "dominance", "support", "yinVoiced", "yinConf", "yinSd",
        "aboveFloor", "belowTop", "dynRange", "localSnr", "zcr", "flatness", "centroidRatio", "harmonicity", "f0Frac",
        "midi", "intervalPrev", "gapBefore", "gapAfter", "octAlt", "yinDelta", "isSing", "isHum", "isWhistle",
    )
    val DIM = NAMES.size
    private const val WIN = 2048
    private val fft = ThreadLocal.withInitial { Fft(WIN) }
    private val hann = DoubleArray(WIN) { 0.5 - 0.5 * cos(2 * PI * it / (WIN - 1)) }

    class Spectral(val flatness: Double, val centroidRatio: Double, val harmonicity: Double, val f0Frac: Double, val zcr: Double)

    /** Spectral descriptors of audio between [from] and [to] (samples at 22.05 kHz) for a note whose pitch is [f0] Hz. */
    fun spectral(audio: FloatArray, from: Int, to: Int, f0: Double): Spectral {
        val sr = BP.SAMPLE_RATE.toDouble()
        val a = from.coerceIn(0, audio.size); val b = to.coerceIn(a, audio.size)
        var zc = 0
        for (i in a + 1 until b) if ((audio[i] >= 0) != (audio[i - 1] >= 0)) zc++
        val zcr = zc.toDouble() / max(1, b - a)
        if (b - a < 256) return Spectral(1.0, 40.0, 0.0, 0.0, zcr)
        val frames = min(6, max(1, (b - a) / (WIN / 2)))
        val re = DoubleArray(WIN); val im = DoubleArray(WIN)
        val binHz = sr / WIN
        val lo = max(1, (60.0 / binHz).toInt()); val hi = min(WIN / 2 - 1, (8000.0 / binHz).toInt())
        var flat = 0.0; var cent = 0.0; var harm = 0.0; var fund = 0.0; var used = 0
        for (k in 0 until frames) {
            val center = a + ((b - a) * (k + 0.5) / frames).toInt()
            val s0 = center - WIN / 2
            for (i in 0 until WIN) { val idx = s0 + i; re[i] = if (idx in a until b) audio[idx] * hann[i] else 0.0; im[i] = 0.0 }
            fft.get().transform(re, im)
            var total = 0.0; var logSum = 0.0; var wsum = 0.0; var cnt = 0
            val pw = DoubleArray(hi + 2)
            for (i in lo..hi) { val p = re[i] * re[i] + im[i] * im[i]; pw[i] = p; total += p; logSum += ln(p + 1e-12); wsum += p * i * binHz; cnt++ }
            if (total <= 1e-12) continue
            flat += exp(logSum / cnt) / (total / cnt + 1e-12)
            cent += (wsum / total) / max(f0, 1.0)
            var hEnergy = 0.0
            var h = 1
            while (h * f0 < 9000.0 && h <= 10) {
                val c = (h * f0 / binHz).toInt()
                for (i in max(lo, c - 1)..min(hi, c + 1)) hEnergy += pw[i]
                h++
            }
            harm += min(1.0, hEnergy / total)
            val c0 = (f0 / binHz).toInt()
            var f0e = 0.0
            for (i in max(lo, c0 - 1)..min(hi, c0 + 1)) f0e += pw[i]
            fund += min(1.0, f0e / total)
            used++
        }
        if (used == 0) return Spectral(1.0, 40.0, 0.0, 0.0, zcr)
        return Spectral(flat / used, min(40.0, cent / used), harm / used, fund / used, zcr)
    }

    fun typeOneHot(t: InputType, out: DoubleArray, at: Int) {
        out[at] = if (t == InputType.SINGING || t == InputType.VOCALISE) 1.0 else 0.0
        out[at + 1] = if (t == InputType.HUMMING) 1.0 else 0.0
        out[at + 2] = if (t == InputType.WHISTLING) 1.0 else 0.0
    }

    fun clampGap(x: Double) = min(2.0, max(0.0, x))
    fun clampInterval(x: Double) = min(24.0, abs(x))
}
