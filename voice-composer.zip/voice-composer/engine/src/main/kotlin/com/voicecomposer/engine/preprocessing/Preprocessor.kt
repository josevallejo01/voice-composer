package com.voicecomposer.engine.preprocessing

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/** The four vocal input categories of the spec (2.1). They only change analysis ranges, not the architecture. */
enum class InputType(val minHz: Double, val maxHz: Double, val highPassHz: Double) {
    SINGING(80.0, 1100.0, 60.0),
    HUMMING(70.0, 700.0, 50.0),
    WHISTLING(500.0, 3500.0, 350.0),
    VOCALISE(80.0, 1100.0, 60.0),
}

data class SignalQuality(
    val peak: Float,
    val rmsDb: Double,
    val clippedFraction: Double,
    val tooQuiet: Boolean,
    val clipped: Boolean,
    val durationSec: Double,
)

/** Non destructive preprocessing: always works on a copy, the recorded file is never touched. */
object Preprocessor {
    fun analyzeQuality(x: FloatArray, sampleRate: Int): SignalQuality {
        var peak = 0f
        var sum = 0.0
        var clipped = 0
        for (v in x) {
            val a = abs(v)
            if (a > peak) peak = a
            if (a >= 0.995f) clipped++
            sum += v.toDouble() * v
        }
        val rms = if (x.isEmpty()) 0.0 else sqrt(sum / x.size)
        val clipFrac = if (x.isEmpty()) 0.0 else clipped.toDouble() / x.size
        return SignalQuality(
            peak = peak,
            rmsDb = 20 * log10(rms + 1e-9),
            clippedFraction = clipFrac,
            tooQuiet = peak < 0.01f,
            clipped = clipFrac > 0.005,
            durationSec = x.size.toDouble() / sampleRate,
        )
    }

    /** DC removal, input-dependent high-pass filtering and level normalization (capped gain). */
    fun process(x: FloatArray, sampleRate: Int, type: InputType): FloatArray {
        if (x.isEmpty()) return x
        var mean = 0.0
        for (v in x) mean += v
        mean /= x.size
        val y = FloatArray(x.size) { (x[it] - mean).toFloat() }
        highPass(y, sampleRate, type.highPassHz)
        var peak = 0f
        for (v in y) if (abs(v) > peak) peak = abs(v)
        if (peak > 1e-4f) {
            val gain = (0.9f / peak).coerceIn(0.25f, 30f)
            for (i in y.indices) y[i] *= gain
        }
        return y
    }

    /** Second order Butterworth high-pass (RBJ biquad), in place. */
    private fun highPass(y: FloatArray, sr: Int, fc: Double) {
        val w0 = 2 * PI * fc / sr
        val alpha = sin(w0) / (2 * 0.70710678)
        val c = cos(w0)
        val b0 = (1 + c) / 2
        val b1 = -(1 + c)
        val b2 = (1 + c) / 2
        val a0 = 1 + alpha
        val a1 = -2 * c
        val a2 = 1 - alpha
        var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0
        for (i in y.indices) {
            val xn = y[i].toDouble()
            val yn = (b0 * xn + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0
            x2 = x1; x1 = xn; y2 = y1; y1 = yn
            y[i] = yn.toFloat()
        }
    }
}
