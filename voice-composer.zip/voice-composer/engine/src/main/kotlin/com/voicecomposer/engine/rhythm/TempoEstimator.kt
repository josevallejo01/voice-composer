package com.voicecomposer.engine.rhythm

import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TempoPoint
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

data class TempoEstimate(
    val map: TempoMap,
    /** Representative tempo for display. */
    val bpm: Double,
    val confidence: Double,
    val changesDetected: Boolean,
)

/**
 * Tempo and beat grid from note onsets.
 *
 * 1. Global tempo: comb alignment of the onsets with beat and half-beat grids, weighted by a tempo prior and by how
 *    well the typical inter-onset interval matches one beat (resolves most octave ambiguities).
 * 2. Beat tracking: a phase-locked loop follows the performer, snapping reliable onsets to the half-beat grid.
 * 3. Tempo map: sparse anchors (>= 8 beats apart) so tempo is smooth; if the tempo is steady the map collapses to a
 *    single constant tempo. A song may well start at 90 BPM and drift to 100: the map keeps that (spec 5.7).
 */
object TempoEstimator {
    private const val MIN_BPM = 50.0
    private const val MAX_BPM = 200.0

    /**
     * The tempo is given (metronome, or typed in by the user), so only the phase of the beat grid has to be found:
     * the origin (time of beat 0) minimizing the placement cost of all onsets. With a metronome the count-in tells where
     * the origin roughly is ([originHintSec]); the search stays within a window around it, which also absorbs the
     * latency between the click heard by the singer and the click recorded. The tempo is not tracked: a singer
     * following a click does not change the tempo, and a constant map keeps the score clean.
     */
    fun withKnownTempo(onsets: List<Double>, bpm: Double, originHintSec: Double?, beatsPerBar: Double = 4.0): TempoEstimate {
        val beat = 60.0 / bpm
        if (onsets.isEmpty()) return TempoEstimate(TempoMap.constant(bpm, originHintSec ?: 0.0), bpm, 0.1, false)
        val t = onsets.sorted()
        val sigma = maxOf(0.045, 0.2 * beat / 2)
        fun cost(origin: Double): Double {
            var total = 0.0
            for (x in t) {
                val g = (x - origin) / beat / RhythmGrid.GRID
                val base = Math.round(g).toInt()
                var best = Double.MAX_VALUE
                for (k in base - 1..base + 1) {
                    val d = (x - (origin + k * RhythmGrid.GRID * beat)) / sigma
                    val c = minOf(0.5 * d * d, 6.0) + if (k >= 0) RhythmGrid.levelCost(k, beatsPerBar) else 2.0
                    if (c < best) best = c
                }
                total += best
            }
            return total
        }
        val lo: Double; val hi: Double
        if (originHintSec != null) {
            val w = minOf(0.25, 0.4 * beat)
            lo = originHintSec - w; hi = originHintSec + w
        } else {
            lo = t[0] - beat; hi = t[0]
        }
        var bestO = originHintSec ?: t[0]
        var bestC = Double.MAX_VALUE
        var o = lo
        while (o <= hi + 1e-9) {
            val c = cost(o) + if (originHintSec != null) 0.5 * sq((o - originHintSec) / 0.12) else 0.0
            if (c < bestC) { bestC = c; bestO = o }
            o += 0.004
        }
        var origin = bestO
        if (originHintSec == null) {
            // Keep the first onset inside the first beat (a pick-up is impossible to tell from here).
            origin += beat * Math.floor((t[0] - origin) / beat + 0.15)
        }
        val inGrid = t.count { x ->
            val g = (x - origin) / beat / RhythmGrid.GRID
            abs(g - Math.round(g)) * RhythmGrid.GRID * beat < 0.07
        }.toDouble() / t.size
        val confidence = if (originHintSec != null) maxOf(0.75, inGrid) else (inGrid * 0.9).coerceIn(0.2, 0.9)
        return TempoEstimate(TempoMap.constant(bpm, origin), bpm, confidence, false)
    }

    fun estimate(onsets: List<Double>, forcedBpm: Double? = null): TempoEstimate {
        if (forcedBpm != null && onsets.size >= 2) return withKnownTempo(onsets, forcedBpm, null)
        if (onsets.size < 3) {
            val bpm = forcedBpm ?: 100.0
            return TempoEstimate(TempoMap.constant(bpm, onsets.firstOrNull() ?: 0.0), bpm, 0.1, false)
        }
        val t = onsets.sorted()
        val iois = (1 until t.size).map { t[it] - t[it - 1] }.filter { it > 0.08 }.sorted()
        val medIoi = if (iois.isEmpty()) 0.5 else iois[iois.size / 2]

        var bestBpm = forcedBpm ?: 100.0
        var bestAlign = 0.0
        if (forcedBpm == null) {
            var bestScore = -1.0
            var bpm = MIN_BPM
            while (bpm <= MAX_BPM) {
                val (score, align) = score(t, bpm, medIoi)
                if (score > bestScore) { bestScore = score; bestBpm = bpm; bestAlign = align }
                bpm += 0.5
            }
            // Local refinement.
            var b = bestBpm - 1.0
            var refined = bestBpm
            var rs = -1.0
            while (b <= bestBpm + 1.0) {
                val a = score(t, b, medIoi, usePrior = false).second
                if (a > rs) { rs = a; refined = b }
                b += 0.05
            }
            bestBpm = refined
            bestAlign = rs
        } else {
            bestAlign = score(t, bestBpm, medIoi, usePrior = false).second
        }
        val confidence = ((bestAlign - 0.35) / 0.55).coerceIn(0.0, 1.0)
        return track(t, bestBpm, confidence)
    }

    /** Returns (score, alignment) of a tempo candidate. */
    private fun score(t: List<Double>, bpm: Double, medIoi: Double, usePrior: Boolean = true): Pair<Double, Double> {
        val beat = 60.0 / bpm
        val ab = alignment(t, beat)
        val ae = alignment(t, beat / 2)
        val align = 0.4 * ab + 0.6 * ae
        if (!usePrior) return align to align
        val prior = exp(-sq(log2(bpm / 100.0)) / (2 * 0.7 * 0.7))
        val ioiTerm = exp(-sq(log2(medIoi / beat)) / (2 * 1.0 * 1.0))
        return align * prior * ioiTerm to align
    }

    private fun alignment(t: List<Double>, period: Double): Double {
        var c = 0.0
        var s = 0.0
        for (x in t) {
            val th = 2 * PI * x / period
            c += cos(th); s += sin(th)
        }
        return sqrt(c * c + s * s) / t.size
    }

    private data class Anchor(val beat: Double, val sec: Double)

    /** Tempo of the opening notes only: the global tempo can differ a lot from the starting tempo when the performer drifts. */
    private fun localStartBpm(t: List<Double>, globalBpm: Double): Double {
        val head = t.filter { it - t[0] < 7.0 }.take(12)
        if (head.size < 5) return globalBpm
        var best = globalBpm
        var bestScore = -1.0
        var b = globalBpm * 0.65
        while (b <= globalBpm * 1.4) {
            val beat = 60.0 / b
            val s = 0.4 * alignment(head, beat) + 0.6 * alignment(head, beat / 2)
            if (s > bestScore + 1e-9) { bestScore = s; best = b }
            b += 0.5
        }
        return best
    }

    private fun track(t: List<Double>, bpm: Double, confidence: Double): TempoEstimate {
        var period = 60.0 / localStartBpm(t, bpm)
        val anchors = ArrayList<Anchor>()
        anchors.add(Anchor(0.0, t[0]))
        var lastAcceptedIdx = 0
        for (i in 1 until t.size) {
            val a = anchors.last()
            val expected = (t[i] - a.sec) / period
            val steps = Math.round(expected * 2.0) / 2.0
            if (steps <= 0.0) continue
            val tolerance = if (i - lastAcceptedIdx > 6) 0.2 else 0.12
            if (abs(expected - steps) > tolerance) continue
            val local = (t[i] - a.sec) / steps
            period = (0.7 * period + 0.3 * local).coerceIn(period * 0.85, period * 1.18).coerceIn(60.0 / 220, 60.0 / 40)
            anchors.add(Anchor(a.beat + steps, t[i]))
            lastAcceptedIdx = i
        }
        val first = anchors.first()
        val last = anchors.last()
        if (anchors.size < 2 || last.beat - first.beat < 2.0) {
            return TempoEstimate(TempoMap.constant(bpm, t[0]), bpm, confidence, false)
        }
        val overall = 60.0 * (last.beat - first.beat) / (last.sec - first.sec)

        // Sparse anchors.
        val sparse = ArrayList<Anchor>()
        sparse.add(first)
        for (a in anchors) if (a.beat - sparse.last().beat >= 8.0) sparse.add(a)
        val segBpms = ArrayList<Double>()
        for (k in 1 until sparse.size) segBpms.add(60.0 * (sparse[k].beat - sparse[k - 1].beat) / (sparse[k].sec - sparse[k - 1].sec))
        val tailBeats = last.beat - sparse.last().beat
        if (tailBeats >= 4.0) segBpms.add(60.0 * tailBeats / (last.sec - sparse.last().sec))

        val steady = segBpms.isEmpty() || segBpms.all { abs(it - overall) / overall < 0.045 }
        if (steady) {
            val rounded = Math.round(overall * 10) / 10.0
            val origin = anchors.map { it.sec - it.beat * 60.0 / rounded }.average()
            return TempoEstimate(TempoMap.constant(rounded, origin), rounded, confidence, false)
        }
        val pts = ArrayList<TempoPoint>()
        for (a in sparse) {
            if (pts.isEmpty() || (a.beat > pts.last().beat && a.sec > pts.last().timeSec)) pts.add(TempoPoint(a.beat, a.sec))
        }
        val tail = segBpms.lastOrNull() ?: overall
        val map = TempoMap(pts, tail.coerceIn(30.0, 260.0))
        return TempoEstimate(map, map.averageBpm, confidence * 0.9, true)
    }

    private fun sq(x: Double) = x * x
    private fun log2(x: Double) = ln(x) / ln(2.0)
}
