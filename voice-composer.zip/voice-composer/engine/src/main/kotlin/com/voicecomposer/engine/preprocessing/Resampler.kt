package com.voicecomposer.engine.preprocessing

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

/** Band-limited (windowed sinc) resampler. Only the output positions are computed, so it stays cheap on long recordings. */
object Resampler {
    fun resample(x: FloatArray, from: Int, to: Int): FloatArray {
        if (from == to) return x.copyOf()
        val ratio = from.toDouble() / to
        val r = max(1.0, ratio)
        val lobes = 8
        val halfWidth = lobes * r
        val outLen = (x.size / ratio).toInt()
        val out = FloatArray(outLen)
        for (i in 0 until outLen) {
            val t = i * ratio
            val lo = kotlin.math.ceil(t - halfWidth).toInt().coerceAtLeast(0)
            val hi = floor(t + halfWidth).toInt().coerceAtMost(x.size - 1)
            var acc = 0.0
            var norm = 0.0
            for (n in lo..hi) {
                val d = (t - n) / r
                val w = 0.5 * (1.0 + cos(PI * (t - n) / halfWidth))
                val s = if (d == 0.0) 1.0 else sin(PI * d) / (PI * d)
                val k = s * w
                acc += x[n] * k
                norm += k
            }
            out[i] = if (norm > 1e-9) (acc / norm).toFloat() else 0f
        }
        return out
    }
}
