package com.voicecomposer.engine.synth

import com.voicecomposer.model.Instrument
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.sin

/**
 * Small additive synthesizer (wavetable + ADSR). It plays the transcription and the arrangement without any native
 * library or sound bank, which keeps the app light and licence-clean. A SoundFont based renderer (FluidSynth) can
 * replace it behind the same [render] contract once its licence and size have been evaluated (spec 8).
 */
object Synth {
    const val SAMPLE_RATE = 44100
    private const val TABLE = 4096

    private class Voice(val harmonics: DoubleArray, val attack: Double, val decay: Double, val sustain: Double, val release: Double) {
        val table = FloatArray(TABLE + 1).also { t ->
            var peak = 0.0
            val tmp = DoubleArray(TABLE)
            for (i in 0 until TABLE) {
                var v = 0.0
                for (h in harmonics.indices) v += harmonics[h] * sin(2 * PI * (h + 1) * i / TABLE)
                tmp[i] = v
                if (abs(v) > peak) peak = abs(v)
            }
            for (i in 0 until TABLE) t[i] = (tmp[i] / peak).toFloat()
            t[TABLE] = t[0]
        }
    }

    private val voices: Map<Instrument, Voice> by lazy {
        mapOf(
            Instrument.LEAD to Voice(doubleArrayOf(1.0, 0.35, 0.12, 0.05), 0.012, 0.15, 0.8, 0.05),
            Instrument.PIANO to Voice(doubleArrayOf(1.0, 0.5, 0.25, 0.12, 0.06), 0.004, 0.9, 0.25, 0.25),
            Instrument.ACOUSTIC_GUITAR to Voice(doubleArrayOf(1.0, 0.6, 0.35, 0.2, 0.1, 0.05), 0.003, 0.6, 0.2, 0.2),
            Instrument.ELECTRIC_BASS to Voice(doubleArrayOf(1.0, 0.45, 0.2), 0.006, 0.4, 0.6, 0.08),
            Instrument.STRINGS to Voice(doubleArrayOf(1.0, 0.5, 0.33, 0.25, 0.2), 0.12, 0.2, 0.85, 0.35),
            Instrument.PAD to Voice(doubleArrayOf(1.0, 0.2, 0.1), 0.2, 0.3, 0.8, 0.5),
            Instrument.FLUTE to Voice(doubleArrayOf(1.0, 0.15, 0.05), 0.04, 0.1, 0.85, 0.1),
        )
    }

    private fun voice(i: Instrument) = voices.getValue(i)

    /** Renders one note (used for the on-screen keyboard and note preview). */
    fun renderNote(midi: Int, durationSec: Double, instrument: Instrument = Instrument.PIANO, sampleRate: Int = SAMPLE_RATE): FloatArray {
        val v = voice(instrument)
        val n = ceil((durationSec + v.release) * sampleRate).toInt()
        val out = FloatArray(n)
        addNote(out, 0, midi, durationSec, 0.7f, v, sampleRate)
        return out
    }

    /**
     * Renders tracks to mono floats. Positions come from beats through [map], so the playback of a quantized score
     * is rhythmically exact. Disabled tracks are skipped; the result is normalized only downwards.
     */
    fun render(tracks: List<Track>, map: TempoMap, sampleRate: Int = SAMPLE_RATE, minLengthSec: Double = 0.0): FloatArray {
        val active = tracks.filter { it.enabled && it.volume > 0f }
        var endSec = minLengthSec
        for (t in active) for (e in t.events) if (e.isNote) endSec = maxOf(endSec, map.beatToSec(e.endBeat))
        val out = FloatArray(ceil((endSec + 1.0) * sampleRate).toInt())
        for (t in active) {
            val v = voice(t.instrument)
            val role = when (t.role) { TrackRole.MELODY -> 0.55f; TrackRole.BASS -> 0.5f; else -> 0.28f }
            for (e in t.events) {
                if (!e.isNote || e.midiPitch == null) continue
                val s = map.beatToSec(e.startBeat)
                var d = map.beatToSec(e.endBeat) - s
                // Short articulation gap so repeated notes are heard (and re-transcribed) as separate notes.
                if (t.role == TrackRole.MELODY) d -= minOf(0.045, d * 0.3)
                addNote(out, (s * sampleRate).toInt().coerceAtLeast(0), e.midiPitch!!, d, t.volume * role, v, sampleRate)
            }
        }
        var peak = 0f
        for (x in out) if (abs(x) > peak) peak = abs(x)
        if (peak > 0.95f) { val g = 0.95f / peak; for (i in out.indices) out[i] *= g }
        return out
    }

    fun toPcm16(x: FloatArray): ShortArray = ShortArray(x.size) { (x[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }

    private fun addNote(out: FloatArray, start: Int, midi: Int, durSec: Double, gain: Float, v: Voice, sr: Int) {
        if (start >= out.size) return
        val freq = Pitch.midiToHz(midi)
        val inc = freq * TABLE / sr
        val total = ((durSec + v.release) * sr).toInt()
        val noteOn = (durSec * sr).toInt().coerceAtLeast(1)
        // Higher notes decay faster for plucked / struck voices.
        val decayTau = v.decay.coerceAtLeast(0.001)
        var phase = 0.0
        var levelAtRelease = 0.0
        for (i in 0 until total) {
            val idx = start + i
            if (idx >= out.size) break
            val t = i.toDouble() / sr
            val env = if (i < noteOn) {
                val a = if (t < v.attack) t / v.attack else 1.0
                val dcy = v.sustain + (1.0 - v.sustain) * exp(-(t - v.attack).coerceAtLeast(0.0) / decayTau)
                (a * dcy).also { levelAtRelease = it }
            } else {
                val r = (i - noteOn).toDouble() / sr / v.release
                (levelAtRelease * (1.0 - r)).coerceAtLeast(0.0)
            }
            val p = phase.toInt()
            val frac = (phase - p).toFloat()
            val s = v.table[p] + (v.table[p + 1] - v.table[p]) * frac
            out[idx] += s * env.toFloat() * gain
            phase += inc
            if (phase >= TABLE) phase -= TABLE
        }
    }

    /** Melody-only helper for "Mode 2: musical reproduction". */
    fun melodyTrack(events: List<MusicalEvent>, instrument: Instrument = Instrument.LEAD): Track =
        Track("melody", "Melody", instrument, TrackRole.MELODY, events)
}
