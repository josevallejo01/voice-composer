package com.voicecomposer.engine.score

import com.voicecomposer.model.TempoMap
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Steady tempo or a tempo map that follows the performer? The forest compares how well the onsets sit on the sixteenth
 * grid under both maps, and how far the followed tempo wanders.
 */
object DriftModel {
    val NAMES = listOf("resConst", "resTracked", "diff", "ratio", "res8Const", "res8Tracked", "spreadMin", "spreadMax", "points", "bpm", "logN", "durBeats")
    val DIM = NAMES.size

    private fun residual(t: DoubleArray, map: TempoMap, sub: Int): Double {
        var s = 0.0
        for (x in t) { val p = map.secToBeat(x) * sub; s += abs(p - Math.round(p)) / sub }
        return s / t.size
    }

    fun features(t: DoubleArray, constant: TempoMap, tracked: TempoMap): DoubleArray {
        val x = DoubleArray(DIM)
        val rc = residual(t, constant, 4); val rt = residual(t, tracked, 4)
        x[0] = rc; x[1] = rt; x[2] = rc - rt; x[3] = rt / max(rc, 1e-6)
        x[4] = residual(t, constant, 2); x[5] = residual(t, tracked, 2)
        val bpm = constant.averageBpm
        val bpms = tracked.points.map { tracked.bpmAtBeat(it.beat) } + tracked.tailBpm
        x[6] = bpms.min() / bpm; x[7] = bpms.max() / bpm
        x[8] = tracked.points.size.toDouble(); x[9] = bpm / 100.0
        x[10] = ln(t.size.toDouble()); x[11] = constant.secToBeat(t.last()) - constant.secToBeat(t.first())
        return x
    }
}
