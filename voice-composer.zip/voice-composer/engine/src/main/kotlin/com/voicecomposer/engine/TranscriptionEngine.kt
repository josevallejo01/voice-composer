package com.voicecomposer.engine

import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.pitch.OctaveCorrector
import com.voicecomposer.engine.pitch.YinPitchTracker
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.preprocessing.Preprocessor
import com.voicecomposer.engine.preprocessing.Resampler
import com.voicecomposer.engine.preprocessing.SignalQuality
import com.voicecomposer.engine.rhythm.KeyEstimator
import com.voicecomposer.engine.rhythm.MeterEstimator
import com.voicecomposer.engine.rhythm.Quantizer
import com.voicecomposer.engine.rhythm.TempoEstimator
import com.voicecomposer.engine.segmentation.NoteSegmenter
import com.voicecomposer.model.AnalysisInfo
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TimeSignature
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.ValidationState

enum class Stage { PREPROCESSING, PITCH, SEGMENTATION, TEMPO, RHYTHM, KEY, DONE }

enum class AnalysisWarning { TOO_QUIET, CLIPPING, TOO_SHORT, NO_PITCH_FOUND, TOO_LONG }

data class AnalysisConfig(
    val inputType: InputType = InputType.SINGING,
    val quantization: QuantizationMode = QuantizationMode.AUTOMATIC,
    val tuningCompensation: Boolean = true,
    val forcedBpm: Double? = null,
    /** Time on the recording where beat 0 (first bar line after the count-in) was played by the metronome. */
    val beatOriginHintSec: Double? = null,
    /** Meter played by the metronome; when set, it is not guessed. */
    val forcedTimeSignature: TimeSignature? = null,
    val maxDurationSec: Double = 600.0,
    /** Use the neural engine when one is installed (falls back to the classical DSP engine otherwise). */
    val useNeural: Boolean = true,
    /** Decisions of the neural decoder; the singer profile moves them over time. */
    /** Null = defaults for the input type. */
    val decoder: com.voicecomposer.engine.ml.DecoderParams? = null,
    /** What was learned from this singer's corrections; calibrates the confidence of detected notes. */
    val profile: com.voicecomposer.engine.profile.VoiceProfile? = null,
)

data class AnalysisResult(
    val transcription: Transcription,
    val quality: SignalQuality,
    val warnings: List<AnalysisWarning>,
)

class AnalysisCancelled : RuntimeException("Analysis cancelled")

/** Every engine sits behind an interface so a model can be replaced without touching the app (spec 4.3). */
interface TranscriptionEngine {
    val version: String
    fun analyze(
        audio: AudioBuffer,
        config: AnalysisConfig = AnalysisConfig(),
        onProgress: (Stage, Float) -> Unit = { _, _ -> },
        isCancelled: () -> Boolean = { false },
    ): AnalysisResult
}

/**
 * Classical DSP pipeline: resample -> preprocess -> YIN -> octave correction -> segmentation -> tempo/beat tracking
 * -> quantization -> meter -> key. Neural pitch models (CREPE/SPICE style) can be plugged in behind
 * [com.voicecomposer.engine.pitch.PitchTracker]; the benchmark decides (spec 5.4).
 */
class DefaultTranscriptionEngine : TranscriptionEngine {
    override val version = "dsp-1.0"

    override fun analyze(
        audio: AudioBuffer,
        config: AnalysisConfig,
        onProgress: (Stage, Float) -> Unit,
        isCancelled: () -> Boolean,
    ): AnalysisResult {
        fun check() { if (isCancelled()) throw AnalysisCancelled() }
        val warnings = ArrayList<AnalysisWarning>()
        val quality = Preprocessor.analyzeQuality(audio.samples, audio.sampleRate)
        if (quality.tooQuiet) warnings.add(AnalysisWarning.TOO_QUIET)
        if (quality.clipped) warnings.add(AnalysisWarning.CLIPPING)
        if (quality.durationSec < 0.5) warnings.add(AnalysisWarning.TOO_SHORT)

        onProgress(Stage.PREPROCESSING, 0f)
        var samples = audio.samples
        if (quality.durationSec > config.maxDurationSec) {
            warnings.add(AnalysisWarning.TOO_LONG)
            samples = samples.copyOf((config.maxDurationSec * audio.sampleRate).toInt())
        }
        val rate = ANALYSIS_RATE
        val resampled = Resampler.resample(samples, audio.sampleRate, rate)
        check()
        val clean = Preprocessor.process(resampled, rate, config.inputType)
        onProgress(Stage.PREPROCESSING, 1f)
        check()

        onProgress(Stage.PITCH, 0f)
        val tracker = YinPitchTracker(rate, config.inputType)
        val frames = OctaveCorrector.correct(tracker.track(clean, { onProgress(Stage.PITCH, it) }, isCancelled))
        onProgress(Stage.PITCH, 1f)
        check()

        onProgress(Stage.SEGMENTATION, 0f)
        val detected = NoteSegmenter().segment(frames, config.tuningCompensation)
        onProgress(Stage.SEGMENTATION, 1f)
        check()

        return PostNotePipeline.run(detected, config, quality, warnings, version, onProgress, isCancelled)
    }

    companion object {
        const val ANALYSIS_RATE = 16000
        const val UNCERTAIN_BELOW = PostNotePipeline.UNCERTAIN_BELOW
    }
}

/** Everything after note detection: tempo, quantization, meter, key, confidence. Shared by every front end. */
object PostNotePipeline {
    const val UNCERTAIN_BELOW = 0.65

    fun run(
        detected: List<com.voicecomposer.engine.segmentation.DetectedNote>,
        config: AnalysisConfig,
        quality: SignalQuality,
        warnings: MutableList<AnalysisWarning>,
        version: String,
        onProgress: (Stage, Float) -> Unit,
        isCancelled: () -> Boolean,
    ): AnalysisResult {
        fun check() { if (isCancelled()) throw AnalysisCancelled() }
        if (detected.isEmpty()) {
            warnings.add(AnalysisWarning.NO_PITCH_FOUND)
            val empty = Transcription(
                emptyList(), TempoMap.constant(config.forcedBpm ?: 100.0), TimeSignature.FOUR_FOUR,
                KeySignature(0, Mode.MAJOR, 0.0), config.quantization,
                analysis = AnalysisInfo(version, 0.0, 0.0, 0.0, 0.0, warnings.map { it.name }),
            )
            onProgress(Stage.DONE, 1f)
            return AnalysisResult(empty, quality, warnings)
        }

        onProgress(Stage.TEMPO, 0f)
        val bpb = config.forcedTimeSignature?.beatsPerMeasure ?: 4.0
        val tempo = if (config.forcedBpm != null && config.beatOriginHintSec != null) {
            TempoEstimator.withKnownTempo(detected.map { it.startSec }, config.forcedBpm, config.beatOriginHintSec, bpb)
        } else TempoEstimator.estimate(detected.map { it.startSec }, config.forcedBpm)
        onProgress(Stage.TEMPO, 1f)
        check()

        onProgress(Stage.RHYTHM, 0f)
        val events = Quantizer.quantize(detected, tempo.map, config.quantization, bpb)
        val meter = config.forcedTimeSignature?.let { com.voicecomposer.engine.rhythm.MeterEstimate(it, 1.0) } ?: MeterEstimator.estimate(events)
        onProgress(Stage.RHYTHM, 1f)

        onProgress(Stage.KEY, 0f)
        val key = KeyEstimator.estimate(events)
        onProgress(Stage.KEY, 1f)

        // The stored confidence stays the engine's raw one (the learner trains on it); what the singer's history says only
        // decides which notes are flagged for review.
        val prof = config.profile?.takeIf { it.weights != null && it.engineNotes >= 50 }
        val flagged = events.mapIndexed { i, e ->
            val c = prof?.calibrate(e, events.getOrNull(i - 1), events.getOrNull(i + 1)) ?: e.confidence
            if (c < UNCERTAIN_BELOW) e.copy(validation = ValidationState.UNCERTAIN) else e
        }
        val noteConf = flagged.map { it.confidence }.average()
        val overall = (0.4 * noteConf + 0.2 * tempo.confidence + 0.2 * meter.confidence + 0.2 * key.confidence).coerceIn(0.0, 1.0)
        val transcription = Transcription(
            events = flagged,
            tempoMap = tempo.map,
            timeSignature = meter.timeSignature,
            key = key,
            quantization = config.quantization,
            analysis = AnalysisInfo(version, tempo.confidence, meter.confidence, key.confidence, overall, warnings.map { it.name }),
        ).normalized()
        onProgress(Stage.DONE, 1f)
        return AnalysisResult(transcription, quality, warnings)
    }
}


/** Chooses per analysis between the neural engine (when available) and the classical DSP engine. */
class SelectableEngine(
    private val neural: TranscriptionEngine?,
    private val classic: TranscriptionEngine = DefaultTranscriptionEngine(),
) : TranscriptionEngine {
    override val version get() = neural?.version ?: classic.version

    override fun analyze(
        audio: AudioBuffer,
        config: AnalysisConfig,
        onProgress: (Stage, Float) -> Unit,
        isCancelled: () -> Boolean,
    ): AnalysisResult =
        (if (config.useNeural && neural != null) neural else classic).analyze(audio, config, onProgress, isCancelled)
}
