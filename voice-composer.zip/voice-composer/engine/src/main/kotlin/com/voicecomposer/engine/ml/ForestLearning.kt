package com.voicecomposer.engine.ml

import com.voicecomposer.model.Json
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.ValidationState
import kotlin.math.max
import kotlin.math.min

/** A candidate note as kept on the device between the analysis and the user's corrections. */
class CandidateRow(val startSec: Double, val endSec: Double, val midi: Int, val x: DoubleArray)

/**
 * Turns "what the classifier looked at" + "what the user ended up with" into labelled rows for the singer's own forest.
 * A candidate is a real note when a note of the final score with the same pitch overlaps it; otherwise it was noise or
 * a wrong pitch. Nothing is learned from a score the user never touched: that would only teach the forest its own
 * opinion.
 */
object ForestLearning {
    fun toJson(c: List<MlTranscriptionEngine.Candidate>): String = Json.write(
        mapOf("c" to c.map { listOf(it.note.startSec, it.note.endSec, it.note.midi, it.features.toList()) })
    )

    @Suppress("UNCHECKED_CAST")
    fun parse(s: String): List<CandidateRow> = runCatching {
        val m = Json.parse(s) as Map<String, Any?>
        (m["c"] as List<List<Any?>>).map { r ->
            CandidateRow((r[0] as Number).toDouble(), (r[1] as Number).toDouble(), (r[2] as Number).toInt(), (r[3] as List<Any?>).map { (it as Number).toDouble() }.toDoubleArray())
        }
    }.getOrDefault(emptyList())

    private fun touches(aS: Double, aE: Double, bS: Double, bE: Double): Boolean {
        val o = min(aE, bE) - max(aS, bS)
        return o >= 0.04 && o >= 0.3 * min(aE - aS, bE - bS)
    }

    /** True when the user changed or confirmed anything: only then does the final score say something new. */
    fun isReviewed(engineNotes: List<MusicalEvent>, final: List<MusicalEvent>): Boolean {
        if (final.any { it.validation == ValidationState.VALIDATED }) return true
        if (engineNotes.size != final.size) return true
        return engineNotes.sortedBy { it.startSec }.zip(final.sortedBy { it.startSec }).any { (e, f) -> e.midiPitch != f.midiPitch || !touches(e.startSec, e.endSec, f.startSec, f.endSec) }
    }

    fun label(candidates: List<CandidateRow>, final: List<MusicalEvent>): List<Pair<DoubleArray, Int>> =
        candidates.map { c ->
            val real = final.any { it.midiPitch == c.midi && touches(c.startSec, c.endSec, it.startSec, it.endSec) }
            c.x to if (real) 1 else 0
        }

    fun rowsToJson(rows: List<Pair<DoubleArray, Int>>): String = Json.write(mapOf("r" to rows.map { listOf(it.second, it.first.toList()) }))

    @Suppress("UNCHECKED_CAST")
    fun rowsFromJson(s: String): List<Pair<DoubleArray, Int>> = runCatching {
        val m = Json.parse(s) as Map<String, Any?>
        (m["r"] as List<List<Any?>>).map { r -> (r[1] as List<Any?>).map { (it as Number).toDouble() }.toDoubleArray() to (r[0] as Number).toInt() }
    }.getOrDefault(emptyList())
}
