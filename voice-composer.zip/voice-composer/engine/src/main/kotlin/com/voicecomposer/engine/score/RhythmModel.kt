package com.voicecomposer.engine.score

import com.voicecomposer.engine.ml.NoteClassifier
import com.voicecomposer.model.TimeSignature
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Slot arithmetic shared by the onset and duration models (a slot is a sixteenth note, 0.25 beat). */
class MeterGrid(val meter: TimeSignature) {
    val barSlots: Int = (meter.beatsPerMeasure * 4).toInt()
    /** Slots in a felt beat: a quarter in simple meters, a dotted quarter in 6/8. */
    val beatSlots: Int = if (meter == TimeSignature.SIX_EIGHT) 6 else 4
    fun pos(slot: Int) = Math.floorMod(slot, barSlots)
    fun isBar(slot: Int) = pos(slot) == 0
    fun isBeat(slot: Int) = pos(slot) % beatSlots == 0
    fun isHalf(slot: Int) = pos(slot) % 2 == 0
    fun oneHot(out: DoubleArray, at: Int) {
        val i = BarModel.METERS.indexOf(meter)
        for (k in 0 until 4) out[at + k] = if (k == i) 1.0 else 0.0
    }
}

/**
 * Rhythmic position of every note. For each note the candidates are the five sixteenth-note slots around its measured
 * beat; the forest scores every (previous slot, this slot) pair from the timing deviations, the metrical level of both
 * positions, the measured and chosen interval, and the neighbouring intervals. Dynamic programming then picks the best
 * sequence, so a note is read in the context of the rhythm around it.
 */
object OnsetModel {
    val NAMES = listOf(
        "devCur", "absDevCur", "devCurMs", "posCurFrac", "posCur", "isBar", "isBeat", "isHalf", "isSub",
        "m24", "m34", "m44", "m68",
        "devPrev", "absDevPrev", "posPrevFrac", "prevBar", "prevBeat", "prevHalf",
        "dr", "dc", "e", "absE", "dcSlots", "dcStd", "ratio", "drPrev", "drNext", "durCur", "gapAfter",
        "bpm", "kOff", "jOff", "isFirst",
    )
    val DIM = NAMES.size
    const val SPREAD = 2
    const val WIDTH = 2 * SPREAD + 1
    private val STD = setOf(1, 2, 3, 4, 6, 8, 12, 16)

    /** [raw] note starts and [dur] note lengths in beats counted from the bar line, [bpm] quarter notes per minute. */
    class Ctx(val raw: DoubleArray, val dur: DoubleArray, val bpm: Double, val meter: TimeSignature) {
        val grid = MeterGrid(meter)
        val base = IntArray(raw.size) { Math.round(raw[it] / 0.25).toInt() }
        fun slot(i: Int, k: Int) = base[i] + k - SPREAD
    }

    /** Row for note [i] at candidate [k], given the previous note at candidate [j] (-1 for the first note). */
    fun row(c: Ctx, i: Int, j: Int, k: Int): DoubleArray {
        val g = c.slot(i, k); val gr = c.grid
        val spb = 60.0 / c.bpm
        val x = DoubleArray(DIM)
        val dev = g * 0.25 - c.raw[i]
        x[0] = dev; x[1] = abs(dev); x[2] = dev * spb * 10
        x[3] = gr.pos(g).toDouble() / gr.barSlots; x[4] = gr.pos(g).toDouble()
        x[5] = if (gr.isBar(g)) 1.0 else 0.0; x[6] = if (gr.isBeat(g)) 1.0 else 0.0; x[7] = if (gr.isHalf(g)) 1.0 else 0.0; x[8] = if (g % 2 != 0) 1.0 else 0.0
        gr.oneHot(x, 9)
        if (i > 0 && j >= 0) {
            val gp = c.slot(i - 1, j)
            val devP = gp * 0.25 - c.raw[i - 1]
            x[13] = devP; x[14] = abs(devP); x[15] = gr.pos(gp).toDouble() / gr.barSlots
            x[16] = if (gr.isBar(gp)) 1.0 else 0.0; x[17] = if (gr.isBeat(gp)) 1.0 else 0.0; x[18] = if (gr.isHalf(gp)) 1.0 else 0.0
            val dr = c.raw[i] - c.raw[i - 1]; val dc = (g - gp) * 0.25
            x[19] = dr; x[20] = dc; x[21] = dc - dr; x[22] = abs(dc - dr); x[23] = (g - gp).toDouble()
            x[24] = if ((g - gp) in STD) 1.0 else 0.0
            x[25] = if (dr > 1e-6) (dc / dr).coerceIn(0.0, 4.0) else 4.0
            x[32] = (j - SPREAD).toDouble()
            x[33] = 0.0
        } else x[33] = 1.0
        x[26] = if (i > 1) c.raw[i - 1] - c.raw[i - 2] else -1.0
        x[27] = if (i + 1 < c.raw.size) c.raw[i + 1] - c.raw[i] else -1.0
        x[28] = min(c.dur[i], 8.0)
        x[29] = if (i + 1 < c.raw.size) c.raw[i + 1] - c.raw[i] - c.dur[i] else 0.0
        x[30] = c.bpm / 100.0
        x[31] = (k - SPREAD).toDouble()
        return x
    }

    class Placement(val slots: IntArray, /** Probability the forest gave the chosen (previous, this) pair. */ val prob: DoubleArray)

    fun place(c: Ctx, forest: NoteClassifier): Placement {
        val n = c.raw.size
        val cost = Array(n) { DoubleArray(WIDTH) { Double.MAX_VALUE } }
        val from = Array(n) { IntArray(WIDTH) }
        val pr = Array(n) { DoubleArray(WIDTH) }
        fun nll(p: Double) = -ln(max(p, 0.02))
        for (k in 0 until WIDTH) {
            if (c.slot(0, k) < 0) continue
            val p = forest.probability(row(c, 0, -1, k)); cost[0][k] = nll(p); pr[0][k] = p
        }
        for (i in 1 until n) for (k in 0 until WIDTH) {
            val gi = c.slot(i, k)
            if (gi < 0) continue
            var best = Double.MAX_VALUE; var arg = 0; var bp = 0.0
            for (j in 0 until WIDTH) {
                if (cost[i - 1][j] == Double.MAX_VALUE) continue
                val gj = c.slot(i - 1, j)
                val t: Double; val p: Double
                if (gi <= gj) { p = 0.0; t = cost[i - 1][j] + 6.0 + (gj - gi) }  // overlapping order is almost never right
                else { p = forest.probability(row(c, i, j, k)); t = cost[i - 1][j] + nll(p) }
                if (t < best) { best = t; arg = j; bp = p }
            }
            cost[i][k] = best; from[i][k] = arg; pr[i][k] = bp
        }
        var k = (0 until WIDTH).minByOrNull { cost[n - 1][it] } ?: SPREAD
        val slots = IntArray(n); val prob = DoubleArray(n)
        for (i in n - 1 downTo 0) {
            slots[i] = max(0, c.slot(i, k)); prob[i] = pr[i][k]
            k = from[i][k]
        }
        for (i in 1 until n) if (slots[i] <= slots[i - 1]) slots[i] = slots[i - 1] + 1
        return Placement(slots, prob)
    }
}

/** Written length of every note (and so every rest): candidates are the standard values and "up to the next note". */
object DurationModel {
    val NAMES = listOf(
        "meas", "measSlots", "gapAfter", "ioiNext", "cand", "candBeats", "candMinusMeas", "ratio", "legato", "restSlots", "restStd", "candStd",
        "endPosFrac", "endBar", "endBeat", "endHalf", "crossesBar", "startBar", "startBeat", "startHalf",
        "medRatio", "fracLegato", "bpm", "m24", "m34", "m44", "m68", "isLast", "diffMs",
    )
    val DIM = NAMES.size
    val STD = intArrayOf(1, 2, 3, 4, 6, 8, 12, 16)
    private val REST_STD = setOf(0, 1, 2, 3, 4, 6, 8, 12, 16)

    /** [start]/[end] are measured starts and ends in beats from the bar line; [slots] the chosen start slots. */
    class Ctx(val start: DoubleArray, val end: DoubleArray, val slots: IntArray, val bpm: Double, val meter: TimeSignature) {
        val grid = MeterGrid(meter)
        val medRatio: Double
        val fracLegato: Double
        init {
            val r = ArrayList<Double>(); var leg = 0; var m = 0
            for (i in 0 until start.size - 1) {
                val ioi = start[i + 1] - start[i]
                if (ioi > 1e-6) r.add(((end[i] - start[i]) / ioi).coerceIn(0.0, 1.2))
                m++; if (start[i + 1] - end[i] < 0.1) leg++
            }
            medRatio = if (r.isEmpty()) 0.9 else r.sorted()[r.size / 2]
            fracLegato = if (m == 0) 0.0 else leg.toDouble() / m
        }
    }

    class Cand(val slots: Int, val features: DoubleArray)

    fun candidates(c: Ctx, i: Int): List<Cand> {
        val n = c.start.size; val gr = c.grid
        val s = c.slots[i]
        val last = i == n - 1
        val maxSlots = if (last) 16 else max(1, c.slots[i + 1] - s)
        val set = LinkedHashSet<Int>()
        for (d in STD) if (d <= maxSlots) set.add(d)
        if (!last) set.add(maxSlots)
        val meas = max(0.0, c.end[i] - c.start[i])
        val spb = 60.0 / c.bpm
        return set.map { d ->
            val x = DoubleArray(DIM)
            x[0] = min(meas, 8.0); x[1] = min(meas * 4, 32.0)
            x[2] = if (!last) c.start[i + 1] - c.end[i] else 0.0
            x[3] = if (!last) c.start[i + 1] - c.start[i] else 0.0
            x[4] = d.toDouble(); x[5] = d * 0.25; x[6] = d * 0.25 - meas
            x[7] = if (meas > 1e-6) (d * 0.25 / meas).coerceIn(0.0, 6.0) else 6.0
            val legato = !last && d == maxSlots
            x[8] = if (legato) 1.0 else 0.0
            val rest = if (last) 0 else maxSlots - d
            x[9] = rest.toDouble(); x[10] = if (rest in REST_STD) 1.0 else 0.0; x[11] = if (d in STD) 1.0 else 0.0
            val e = s + d
            x[12] = gr.pos(e).toDouble() / gr.barSlots
            x[13] = if (gr.isBar(e)) 1.0 else 0.0; x[14] = if (gr.isBeat(e)) 1.0 else 0.0; x[15] = if (gr.isHalf(e)) 1.0 else 0.0
            x[16] = if (gr.pos(s) + d > gr.barSlots) 1.0 else 0.0
            x[17] = if (gr.isBar(s)) 1.0 else 0.0; x[18] = if (gr.isBeat(s)) 1.0 else 0.0; x[19] = if (gr.isHalf(s)) 1.0 else 0.0
            x[20] = c.medRatio; x[21] = c.fracLegato; x[22] = c.bpm / 100.0
            gr.oneHot(x, 23)
            x[27] = if (last) 1.0 else 0.0
            x[28] = abs(d * 0.25 - meas) * spb * 10
            Cand(d, x)
        }
    }

    fun choose(c: Ctx, i: Int, forest: NoteClassifier): Int {
        val cs = candidates(c, i)
        return cs.maxByOrNull { forest.probability(it.features) }?.slots ?: 1
    }
}
