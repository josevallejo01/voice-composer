package com.voicecomposer.engine.calibration

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.ml.DecoderParams
import com.voicecomposer.engine.ml.forInput
import com.voicecomposer.engine.ml.MlTranscriptionEngine
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.profile.Contribution
import com.voicecomposer.engine.profile.NoteRow
import com.voicecomposer.engine.profile.ProfileFeatures
import com.voicecomposer.engine.segmentation.DetectedNote
import com.voicecomposer.model.Json
import kotlin.math.abs
import kotlin.math.max

/**
 * One guided take of the initial voice setup. [truthMidi] is the note the user confirmed they sang; null is a take of
 * silence (the room as it is), which every detected note makes wrong.
 */
class CalibrationTake(val prepared: MlTranscriptionEngine.Prepared, val truthMidi: Int?)

class CalibrationReport(
    val notesCorrect: Int,
    val notesTotal: Int,
    val silenceTakes: Int,
    val silenceClean: Int,
    val pitchOffset: Int,
    val scoreBefore: Double,
    val scoreAfter: Double,
)

class CalibrationOutcome(val decoder: DecoderParams, val contribution: Contribution, val report: CalibrationReport)

/**
 * Fits the decoder to one person, one microphone and one room using takes whose true content is known: it looks for
 * the thresholds under which the notes the user confirmed are found and the silence is not. The network and the pitch
 * trace run once per take; only the cheap decoding is repeated for every candidate.
 */
object CalibrationTuner {
    private val REST_BIAS = doubleArrayOf(-1.5, -1.1, -0.85, -0.5, -0.2, 0.2, 0.6, 1.0, 1.5)
    private val GATE = doubleArrayOf(6.0, 9.0, 12.0)
    private val SUPPORT = doubleArrayOf(0.15, 0.30, 0.45)

    private fun takeScore(notes: List<DetectedNote>, truth: Int?): Double {
        if (truth == null) return if (notes.isEmpty()) 1.0 else max(0.0, 1.0 - 0.5 * notes.size)
        if (notes.isEmpty()) return 0.0
        var good = 0.0; var bad = 0.0
        for (n in notes) { val d = n.endSec - n.startSec; if (n.midi == truth) good += d else bad += d }
        // Extra fragments are mistakes even when they have the right pitch.
        return good / (good + bad) - 0.12 * max(0, notes.size - 2)
    }

    private fun total(engine: MlTranscriptionEngine, config: AnalysisConfig, takes: List<CalibrationTake>, p: DecoderParams): Double =
        takes.sumOf { takeScore(engine.detect(it.prepared, config, p), it.truthMidi) } / takes.size

    fun tune(engine: MlTranscriptionEngine, config: AnalysisConfig, type: InputType, takes: List<CalibrationTake>): CalibrationOutcome {
        require(takes.isNotEmpty()) { "No takes" }
        val start = DecoderParams.forInput(type)
        val scoreBefore = total(engine, config, takes, start)

        // 1. A systematic key error (typically an octave) seen on most confirmed takes is corrected outright.
        val offsets = takes.filter { it.truthMidi != null }.mapNotNull { t ->
            val d = engine.detect(t.prepared, config, start).maxByOrNull { it.endSec - it.startSec }
            d?.let { it.midi - t.truthMidi!! }
        }
        var offset = 0
        if (offsets.size >= 3) {
            val (mode, count) = offsets.groupingBy { it }.eachCount().maxByOrNull { it.value }!!
            if (mode != 0 && count >= 0.7 * offsets.size) offset = -mode
        }
        val base = start.copy(pitchOffset = offset)

        // 2. Grid search; ties go to the candidate closest to the defaults so that few takes cannot push far.
        var best = base
        var bestScore = -1e9
        for (rb in REST_BIAS) for (g in GATE) for (sup in SUPPORT) {
            val cand = base.copy(restBias = rb, gateMarginDb = g, dropSupport = sup)
            val dist = abs(rb - start.restBias) * 0.02 + abs(g - start.gateMarginDb) * 0.002 + abs(sup - start.dropSupport) * 0.02
            val score = total(engine, config, takes, cand) - dist
            if (score > bestScore) { bestScore = score; best = cand }
        }
        val scoreAfter = total(engine, config, takes, best)

        // 3. Labeled evidence for the "is this a real note" model, and the range actually produced.
        val rows = ArrayList<NoteRow>()
        var correct = 0; var noteTakes = 0; var silence = 0; var clean = 0
        val counts = IntArray(88)
        for (t in takes) {
            val notes = engine.detect(t.prepared, config, best)
            for ((i, n) in notes.withIndex()) {
                val x = ProfileFeatures.ofDetected(n, notes.getOrNull(i - 1), notes.getOrNull(i + 1))
                rows.add(NoteRow(x, if (t.truthMidi != null && n.midi == t.truthMidi) 1.0 else 0.0, 3.0)) // confirmed by the user: strong evidence
            }
            if (t.truthMidi == null) { silence++; if (notes.isEmpty()) clean++ }
            else {
                noteTakes++
                if (takeScore(notes, t.truthMidi) >= 0.6) correct++
                if (t.truthMidi in 21..108) counts[t.truthMidi - 21] += 4
            }
        }
        val fp = rows.count { it.label == 0.0 }
        val contribution = Contribution(
            "calibration-${type.name}", rows, counts, rows.size, fp, 0, 0, 0, noteTakes, if (type == InputType.VOCALISE) "SINGING" else type.name,
        )
        return CalibrationOutcome(best, contribution, CalibrationReport(correct, noteTakes, silence, clean, offset, scoreBefore, scoreAfter))
    }
}

/** Persistence of the calibrated decoder (the contribution is stored like any other). */
object CalibrationJson {
    fun write(p: DecoderParams): String = Json.write(
        mapOf(
            "restBias" to p.restBias, "switchCost" to p.switchCost, "strongOnset" to p.strongOnset, "weakOnset" to p.weakOnset,
            "dropSupport" to p.dropSupport, "flagSupport" to p.flagSupport, "gateMarginDb" to p.gateMarginDb,
            "minNoteSec" to p.minNoteSec, "pitchOffset" to p.pitchOffset,
        )
    )

    @Suppress("UNCHECKED_CAST")
    fun read(s: String, type: InputType): DecoderParams? = runCatching {
        val m = Json.parse(s) as Map<String, Any?>
        fun d(k: String, def: Double) = (m[k] as? Number)?.toDouble() ?: def
        val b = DecoderParams.forInput(type)
        b.copy(
            restBias = d("restBias", b.restBias), switchCost = d("switchCost", b.switchCost), strongOnset = d("strongOnset", b.strongOnset),
            weakOnset = d("weakOnset", b.weakOnset), dropSupport = d("dropSupport", b.dropSupport), flagSupport = d("flagSupport", b.flagSupport),
            gateMarginDb = d("gateMarginDb", b.gateMarginDb), minNoteSec = d("minNoteSec", b.minNoteSec), pitchOffset = d("pitchOffset", 0.0).toInt(),
        )
    }.getOrNull()
}
