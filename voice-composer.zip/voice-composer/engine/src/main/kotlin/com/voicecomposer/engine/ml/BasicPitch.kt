package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisCancelled
import kotlin.math.ceil

/**
 * Constants of the Basic Pitch network (Spotify, Apache-2.0, https://github.com/spotify/basic-pitch).
 * The model takes 2 s windows of 22.05 kHz mono audio and outputs, every 256 samples (11.6 ms), three
 * posteriorgrams: note activity (88 piano keys), note onsets (88) and a pitch contour (264 = 3 bins per semitone).
 */
object BP {
    const val SAMPLE_RATE = 22050
    const val HOP = 256
    const val WINDOW_SAMPLES = 43844
    const val WINDOW_FRAMES = 172
    const val OVERLAP_FRAMES = 30
    const val OVERLAP_SAMPLES = OVERLAP_FRAMES * HOP
    const val STEP_SAMPLES = WINDOW_SAMPLES - OVERLAP_SAMPLES
    const val NOTES = 88
    const val CONTOUR_BINS = 264
    const val LOWEST_MIDI = 21
    const val FPS = SAMPLE_RATE.toDouble() / HOP
}

/** Raw output of one window. Arrays are row major: [frame * bins + bin]. */
class WindowOutput(val note: FloatArray, val onset: FloatArray, val contour: FloatArray)

/** Runs the neural network. The Android implementation uses ONNX Runtime; tests use a recorded or scripted model. */
interface BasicPitchModel {
    /** [windows] are [BP.WINDOW_SAMPLES] samples each. Returns one output per window, in order. */
    fun inferBatch(windows: List<FloatArray>): List<WindowOutput>
}

/** Posteriorgrams of a whole recording on a single time grid: frame g is at g * 256 / 22050 s of the model input. */
class Posteriors(val frames: Int, val note: FloatArray, val onset: FloatArray, val contour: FloatArray) {
    fun note(frame: Int, key: Int) = note[frame * BP.NOTES + key]
    fun onset(frame: Int, key: Int) = onset[frame * BP.NOTES + key]
    fun contour(frame: Int, bin: Int) = contour[frame * BP.CONTOUR_BINS + bin]
    fun timeOf(frame: Int) = frame.toDouble() / BP.FPS
}

object BasicPitchRunner {
    private const val BATCH = 8

    /**
     * Splits [audio] (22.05 kHz mono) into overlapping windows, runs the model and stitches the central part of each
     * window back together. Frames are placed from their true sample position, so alignment does not drift on long
     * recordings.
     */
    fun run(
        audio: FloatArray,
        model: BasicPitchModel,
        onProgress: (Float) -> Unit = {},
        isCancelled: () -> Boolean = { false },
    ): Posteriors {
        val pad = BP.OVERLAP_SAMPLES / 2
        val padded = FloatArray(pad + audio.size)
        System.arraycopy(audio, 0, padded, pad, audio.size)
        val windowStarts = ArrayList<Int>()
        var s = 0
        while (s < padded.size) { windowStarts.add(s); s += BP.STEP_SAMPLES }

        val frames = ceil(audio.size.toDouble() / BP.HOP).toInt() + 1
        val note = FloatArray(frames * BP.NOTES)
        val onset = FloatArray(frames * BP.NOTES)
        val contour = FloatArray(frames * BP.CONTOUR_BINS)
        val skip = BP.OVERLAP_FRAMES / 2

        var done = 0
        for (batchStart in windowStarts.indices step BATCH) {
            if (isCancelled()) throw AnalysisCancelled()
            val idx = batchStart until minOf(windowStarts.size, batchStart + BATCH)
            val windows = idx.map { k ->
                val w = FloatArray(BP.WINDOW_SAMPLES)
                val from = windowStarts[k]
                System.arraycopy(padded, from, w, 0, minOf(BP.WINDOW_SAMPLES, padded.size - from))
                w
            }
            val outs = model.inferBatch(windows)
            for ((i, k) in idx.withIndex()) {
                val o = outs[i]
                for (j in skip until BP.WINDOW_FRAMES - skip) {
                    val pos = k.toLong() * BP.STEP_SAMPLES + j.toLong() * BP.HOP - pad
                    val g = Math.rint(pos.toDouble() / BP.HOP).toInt()
                    if (g < 0 || g >= frames) continue
                    System.arraycopy(o.note, j * BP.NOTES, note, g * BP.NOTES, BP.NOTES)
                    System.arraycopy(o.onset, j * BP.NOTES, onset, g * BP.NOTES, BP.NOTES)
                    System.arraycopy(o.contour, j * BP.CONTOUR_BINS, contour, g * BP.CONTOUR_BINS, BP.CONTOUR_BINS)
                }
            }
            done += idx.count()
            onProgress(done.toFloat() / windowStarts.size)
        }
        return Posteriors(frames, note, onset, contour)
    }
}
