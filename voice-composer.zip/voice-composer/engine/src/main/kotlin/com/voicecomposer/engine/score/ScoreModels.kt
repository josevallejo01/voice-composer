package com.voicecomposer.engine.score

import com.voicecomposer.engine.ml.RandomForest

/**
 * The learned decisions of the score. Every choice the transcription makes about notation is a candidate ranking by a
 * random forest (trained with scikit-learn on notated folk melodies played back with simulated human timing, see
 * tools/train_score_models.py):
 *  - [tempo]    tempo and beat phase
 *  - [bar]      time signature and where the bar lines fall (anacrusis)
 *  - [drift]    steady tempo or a tempo map that follows the performer
 *  - [onset]    rhythmic position of every note (pairwise, joint over the melody)
 *  - [duration] written length of every note, and thereby the rests
 *  - [key]      key signature and mode
 *  - [spell]    sharp or flat spelling of chromatic notes
 * Any missing forest makes the engine use the hand-written rule for that decision, or for the whole score when a
 * core one is missing ([complete]).
 */
class ScoreModels(
    val tempo: RandomForest?,
    val bar: RandomForest?,
    val drift: RandomForest?,
    val onset: RandomForest?,
    val duration: RandomForest?,
    val key: RandomForest?,
    val spell: RandomForest?,
) {
    /** Enough models for the learned pipeline. Drift and spelling alone may be absent. */
    val complete: Boolean get() = tempo != null && bar != null && onset != null && duration != null && key != null

    companion object {
        val FILES = listOf("tempo", "bar", "drift", "onset", "duration", "key", "spell")

        /** [read] returns the JSON text of "score_<name>.json" or null. */
        fun load(read: (String) -> String?): ScoreModels {
            fun f(n: String) = runCatching { read("score_$n.json")?.let { RandomForest.fromJson(it) } }.getOrNull()
            return ScoreModels(f("tempo"), f("bar"), f("drift"), f("onset"), f("duration"), f("key"), f("spell"))
        }
    }
}
