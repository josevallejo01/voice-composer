package com.voicecomposer.engine.pitch

import com.voicecomposer.engine.AnalysisCancelled
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.Pitch
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * One analysis frame. [confidence] is 1 - the YIN aperiodicity value; unvoiced frames have [voiced] = false
 * (the engine prefers saying "unknown" over inventing a pitch, spec 5.4).
 */
data class PitchFrame(
    val timeSec: Double,
    val hz: Double,
    val midi: Double,
    val confidence: Double,
    val rmsDb: Double,
    val voiced: Boolean,
)

interface PitchTracker {
    val hopSec: Double

    /** [onProgress] receives 0..1 while tracking; [isCancelled] is polled and aborts with [AnalysisCancelled]. */
    fun track(samples: FloatArray, onProgress: (Float) -> Unit = {}, isCancelled: () -> Boolean = { false }): List<PitchFrame>
}

/**
 * YIN fundamental frequency estimator (de Cheveigné & Kawahara, 2002) with parabolic interpolation.
 * The CMND "first dip under threshold" rule is what protects against sub-octave errors.
 * Works at [sampleRate] (the engine resamples to 16 kHz before calling it).
 */
class YinPitchTracker(
    private val sampleRate: Int,
    type: InputType,
    private val threshold: Double = 0.15,
    private val hop: Int = sampleRate / 100,
) : PitchTracker {
    private val tauMin = maxOf(2, (sampleRate / type.maxHz).toInt())
    private val tauMax = (sampleRate / type.minHz).toInt() + 1
    private val window = maxOf(256, minOf(768, tauMax * 2 + 32))
    override val hopSec: Double = hop.toDouble() / sampleRate

    override fun track(samples: FloatArray, onProgress: (Float) -> Unit, isCancelled: () -> Boolean): List<PitchFrame> {
        val span = window + tauMax
        val pad = span / 2 + 1
        val x = FloatArray(samples.size + 2 * pad)
        System.arraycopy(samples, 0, x, pad, samples.size)
        val frames = ArrayList<PitchFrame>(samples.size / hop + 1)
        val d = DoubleArray(tauMax + 1)
        val cmnd = DoubleArray(tauMax + 1)
        var c = 0
        while (c < samples.size) {
            val s = c + pad - span / 2 // start of analysis span in padded array
            frames.add(analyze(x, s, c, d, cmnd))
            c += hop
            if (frames.size % 250 == 0) {
                if (isCancelled()) throw AnalysisCancelled()
                onProgress(c.toFloat() / samples.size)
            }
        }
        return frames
    }

    private fun analyze(x: FloatArray, s: Int, centerIdx: Int, d: DoubleArray, cmnd: DoubleArray): PitchFrame {
        val time = centerIdx.toDouble() / sampleRate
        // Energy over the central window.
        val ws = s + (window + tauMax) / 2 - window / 2
        var e = 0.0
        for (j in 0 until window) e += x[ws + j].toDouble() * x[ws + j]
        val rmsDb = 20 * log10(sqrt(e / window) + 1e-9)
        if (rmsDb < -70) return PitchFrame(time, 0.0, 0.0, 0.0, rmsDb, false)

        for (tau in 1..tauMax) {
            var sum = 0.0
            for (j in 0 until window) {
                val diff = x[s + j] - x[s + j + tau]
                sum += diff.toDouble() * diff
            }
            d[tau] = sum
        }
        cmnd[0] = 1.0
        var running = 0.0
        for (tau in 1..tauMax) {
            running += d[tau]
            cmnd[tau] = if (running > 0) d[tau] * tau / running else 1.0
        }

        var tau = -1
        var t = tauMin
        while (t < tauMax) {
            if (cmnd[t] < threshold) {
                while (t + 1 < tauMax && cmnd[t + 1] < cmnd[t]) t++
                tau = t
                break
            }
            t++
        }
        if (tau < 0) {
            var best = tauMin
            for (k in tauMin until tauMax) if (cmnd[k] < cmnd[best]) best = k
            if (cmnd[best] > 0.3) return PitchFrame(time, 0.0, 0.0, 1.0 - cmnd[best], rmsDb, false)
            tau = best
        }
        val conf = (1.0 - cmnd[tau]).coerceIn(0.0, 1.0)
        var refined = tau.toDouble()
        if (tau > 1 && tau < tauMax) {
            val a = cmnd[tau - 1]
            val b = cmnd[tau]
            val cc = cmnd[tau + 1]
            val denom = a - 2 * b + cc
            if (abs(denom) > 1e-12) refined += (a - cc) / (2 * denom)
        }
        val hz = sampleRate / refined
        return PitchFrame(time, hz, Pitch.hzToMidi(hz), conf, rmsDb, true)
    }
}

/** Removes isolated one-octave jumps (a classic pitch tracker failure) without touching real octave leaps. */
object OctaveCorrector {
    fun correct(frames: List<PitchFrame>, maxBlip: Int = 6, context: Int = 5): List<PitchFrame> {
        val out = frames.toMutableList()
        var i = 0
        while (i < out.size) {
            if (!out[i].voiced) { i++; continue }
            val before = medianBefore(out, i, context)
            if (before == null) { i++; continue }
            val dev = out[i].midi - before
            val octaves = Math.round(dev / 12.0).toInt()
            if (octaves != 0 && abs(dev - 12.0 * octaves) < 1.2) {
                // Find the length of the blip and check the signal returns to the previous register.
                var j = i
                while (j < out.size && out[j].voiced && abs(out[j].midi - before - 12.0 * octaves) < 1.5) j++
                val len = j - i
                val after = medianAfter(out, j, context)
                if (len <= maxBlip && after != null && abs(after - before) < 2.0) {
                    for (k in i until j) {
                        val f = out[k]
                        val m = f.midi - 12.0 * octaves
                        out[k] = f.copy(midi = m, hz = Pitch.midiToHz(m))
                    }
                }
                i = maxOf(j, i + 1)
            } else i++
        }
        return out
    }

    private fun medianBefore(f: List<PitchFrame>, i: Int, n: Int): Double? {
        val v = ArrayList<Double>()
        var k = i - 1
        while (k >= 0 && v.size < n) {
            if (f[k].voiced) v.add(f[k].midi) else break
            k--
        }
        return if (v.size >= 3) v.sorted()[v.size / 2] else null
    }

    private fun medianAfter(f: List<PitchFrame>, i: Int, n: Int): Double? {
        val v = ArrayList<Double>()
        var k = i
        while (k < f.size && v.size < n) {
            if (f[k].voiced) v.add(f[k].midi) else break
            k++
        }
        return if (v.size >= 3) v.sorted()[v.size / 2] else null
    }
}
