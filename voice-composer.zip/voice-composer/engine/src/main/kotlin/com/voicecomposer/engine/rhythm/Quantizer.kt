package com.voicecomposer.engine.rhythm

import com.voicecomposer.engine.segmentation.DetectedNote
import com.voicecomposer.model.EventSource
import com.voicecomposer.model.EventType
import com.voicecomposer.model.Ids
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TranscriptionEditor

/**
 * Places detected notes on the beat grid. The real recorded time is always kept next to the musical position,
 * so changing tempo or quantization later never loses the link with the recording (spec 6.2).
 *  - AUTOMATIC: snap to sixteenths (default)
 *  - SOFT: halfway between the performed and the snapped position
 *  - FREE: keep the performed positions
 */
object Quantizer {
    /** Gaps shorter than this (in beats) between consecutive notes are articulation, not a written rest. */
    private const val LEGATO_GAP_BEATS = 0.4

    fun quantize(notes: List<DetectedNote>, map: TempoMap, mode: QuantizationMode): List<MusicalEvent> {
        val events = notes.sortedBy { it.startSec }.map { n ->
            val raw = MusicalEvent(
                id = Ids.newId("n"), type = EventType.NOTE, midiPitch = n.midi, frequencyHz = Pitch.midiToHz(n.pitch),
                startSec = n.startSec, endSec = n.endSec, startBeat = 0.0, durationBeats = 0.0,
                confidence = (n.confidence * (0.6 + 0.4 * n.stability)).coerceIn(0.0, 1.0),
                source = EventSource.DETECTED,
            )
            TranscriptionEditor.requantize(raw, map, mode)
        }.toMutableList()

        if (mode != QuantizationMode.FREE) {
            for (i in 0 until events.size - 1) {
                val a = events[i]
                val b = events[i + 1]
                val rawGap = map.secToBeat(b.startSec) - map.secToBeat(a.endSec)
                if (rawGap < LEGATO_GAP_BEATS && b.startBeat > a.startBeat) {
                    events[i] = a.copy(durationBeats = b.startBeat - a.startBeat)
                }
            }
        }
        return events
    }
}
