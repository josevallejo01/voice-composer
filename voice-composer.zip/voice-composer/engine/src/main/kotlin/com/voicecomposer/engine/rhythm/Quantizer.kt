package com.voicecomposer.engine.rhythm

import com.voicecomposer.engine.segmentation.DetectedNote
import com.voicecomposer.model.EventSource
import com.voicecomposer.model.EventType
import com.voicecomposer.model.Ids
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TranscriptionEditor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Places detected notes on the beat grid. The real recorded time is always kept next to the musical position,
 * so changing tempo or quantization later never loses the link with the recording (spec 6.2).
 *  - AUTOMATIC: snap to sixteenths (default)
 *  - SOFT: halfway between the performed and the snapped position
 *  - FREE: keep the performed positions
 *
 * Snapping is not independent rounding: [RhythmGrid.place] chooses all positions together with dynamic programming,
 * trading timing error against how plausible a rhythmic position is (downbeat > beat > eighth > sixteenth) and against
 * keeping the intervals between consecutive notes, so an off-beat singer is still read as the rhythm they meant.
 */
object Quantizer {
    /** Gaps shorter than this (in beats) between consecutive notes are articulation, not a written rest. */
    private const val LEGATO_GAP_BEATS = 0.4

    fun quantize(notes: List<DetectedNote>, map: TempoMap, mode: QuantizationMode, beatsPerBar: Double = 4.0): List<MusicalEvent> {
        val sorted = notes.sortedBy { it.startSec }
        val raws = sorted.map { map.secToBeat(it.startSec).coerceAtLeast(0.0) }
        val placed = if (mode == QuantizationMode.FREE) raws.toDoubleArray()
        else RhythmGrid.place(raws, map.bpmAtBeat(raws.firstOrNull() ?: 0.0), beatsPerBar)

        val events = sorted.mapIndexed { i, n ->
            val raw = MusicalEvent(
                id = Ids.newId("n"), type = EventType.NOTE, midiPitch = n.midi, frequencyHz = Pitch.midiToHz(n.pitch),
                startSec = n.startSec, endSec = n.endSec, startBeat = 0.0, durationBeats = 0.0,
                confidence = (n.confidence * (0.6 + 0.4 * n.stability)).coerceIn(0.0, 1.0),
                source = EventSource.DETECTED,
            )
            val base = TranscriptionEditor.requantize(raw, map, mode)
            when (mode) {
                QuantizationMode.FREE -> base
                QuantizationMode.AUTOMATIC -> {
                    val end = RhythmGrid.snap(map.secToBeat(n.endSec)).coerceAtLeast(placed[i] + RhythmGrid.GRID)
                    base.copy(startBeat = placed[i], durationBeats = end - placed[i])
                }
                QuantizationMode.SOFT -> {
                    val s = (raws[i] + placed[i]) / 2
                    val end = RhythmGrid.snap(map.secToBeat(n.endSec)).coerceAtLeast(placed[i] + RhythmGrid.GRID)
                    val e = (map.secToBeat(n.endSec) + end) / 2
                    base.copy(startBeat = s, durationBeats = (e - s).coerceAtLeast(RhythmGrid.GRID))
                }
            }
        }.toMutableList()

        if (mode != QuantizationMode.FREE) {
            for (i in 0 until events.size - 1) {
                val a = events[i]
                val b = events[i + 1]
                val rawGap = map.secToBeat(b.startSec) - map.secToBeat(a.endSec)
                if (rawGap < LEGATO_GAP_BEATS && b.startBeat > a.startBeat) {
                    events[i] = a.copy(durationBeats = b.startBeat - a.startBeat)
                } else if (a.endBeat > b.startBeat) {
                    events[i] = a.copy(durationBeats = max(RhythmGrid.GRID, b.startBeat - a.startBeat))
                }
            }
        }
        return events
    }
}

/** Metrical-position model and the joint (Viterbi) placement of note starts on a sixteenth grid. */
object RhythmGrid {
    const val GRID = 0.25

    fun snap(beat: Double) = (beat / GRID).roundToInt() * GRID

    /** How unlikely a position is, as a cost: bar line < beat < eighth < sixteenth. */
    fun levelCost(gridIndex: Int, beatsPerBar: Double): Double {
        val perBar = (beatsPerBar / GRID).roundToInt().coerceAtLeast(1)
        return when {
            gridIndex % perBar == 0 -> 0.0
            gridIndex % 4 == 0 -> 0.15
            gridIndex % 2 == 0 -> 0.5
            else -> 1.1
        }
    }

    /**
     * Joint placement of note starts (beats). Cost of a candidate = timing error (relative to how precise a performer is,
     * about 60 ms) + position plausibility + deviation of the interval to the previous note from the performed one.
     * Positions are strictly increasing by at least one grid step.
     */
    fun place(raw: List<Double>, bpm: Double, beatsPerBar: Double): DoubleArray {
        val n = raw.size
        if (n == 0) return DoubleArray(0)
        val sigma = max(0.08, 0.06 * bpm / 60.0)
        val spread = 2
        val width = 2 * spread + 1
        val base = IntArray(n) { (raw[it] / GRID).roundToInt() }
        val cost = Array(n) { DoubleArray(width) }
        val from = Array(n) { IntArray(width) }
        fun unary(i: Int, k: Int): Double {
            val g = base[i] + k - spread
            if (g < 0) return 1e6
            val c = g * GRID
            val d = (c - raw[i]) / sigma
            return 0.5 * d * d + levelCost(g, beatsPerBar)
        }
        for (k in 0 until width) cost[0][k] = unary(0, k)
        for (i in 1 until n) {
            for (k in 0 until width) {
                val gi = base[i] + k - spread
                var best = Double.MAX_VALUE
                var arg = 0
                for (j in 0 until width) {
                    val gj = base[i - 1] + j - spread
                    var t = cost[i - 1][j]
                    if (gi <= gj) t += 60.0 + (gj - gi) * 5.0 // overlapping order is almost never right
                    else {
                        val dc = (gi - gj) * GRID
                        val dr = raw[i] - raw[i - 1]
                        val e = (dc - dr) / 0.25
                        t += 0.3 * 0.5 * e * e
                    }
                    if (t < best) { best = t; arg = j }
                }
                cost[i][k] = best + unary(i, k)
                from[i][k] = arg
            }
        }
        var k = (0 until width).minByOrNull { cost[n - 1][it] } ?: spread
        val out = DoubleArray(n)
        for (i in n - 1 downTo 0) {
            out[i] = (base[i] + k - spread).coerceAtLeast(0) * GRID
            k = from[i][k]
        }
        // Enforce strictly increasing positions (penalized in the search, repaired here in the rare residual case).
        for (i in 1 until n) if (out[i] < out[i - 1] + GRID) out[i] = out[i - 1] + GRID
        return out
    }
}
