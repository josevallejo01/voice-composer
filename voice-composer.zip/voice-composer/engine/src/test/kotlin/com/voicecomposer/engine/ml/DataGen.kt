package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.SyntheticVoice
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.preprocessing.InputType
import java.io.File
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Training-data generator for the note classifier (not a unit test: run with main, see tools/gen_data.sh).
 *
 * Synthetic sung / hummed / whistled melodies are degraded with the kinds of noise phones meet (room and fan noise,
 * mains hum, babble, breaths, clicks, keyboard, hiss), channel effects (high-pass, low-pass, reverb, AGC compression,
 * clipping, very low gain) and run through the real Basic Pitch network and the engine's candidate generator. Every
 * candidate note is labelled against the known melody. Output: one CSV row per candidate.
 *
 * Splits: "train" and "val" use the same condition ranges with different seeds; "hard" uses conditions never seen in
 * training (lower SNR, other noise types, other timbres) to measure how well the forest generalises.
 */
object DataGen {
    val NOISES = listOf("white", "pink", "fan", "mains50", "mains60", "babble", "breath", "clicks", "keys", "hiss", "street")
    /** Noise types used only by the "hard" split. */
    val HARD_NOISES = listOf("street", "babble", "keys", "breath")

    /** Appends what has been produced so far; a killed run keeps its finished clips. */
    private fun flush(out: File, rows: StringBuilder, truth: StringBuilder) {
        out.appendText(rows.toString()); File(out.path + ".truth").appendText(truth.toString())
        rows.setLength(0); truth.setLength(0)
    }

    class Clip(val audio: AudioBuffer, val truth: List<SyntheticVoice.N>, val tags: String, val snr: Double)

    @JvmStatic
    fun main(args: Array<String>) {
        val out = File(args[0]); val seed0 = args[1].toLong(); val n = args[2].toInt(); val split = args[3]
        val model = PythonOnnxModel.create() ?: error("model/onnxruntime not available")
        val engine = MlTranscriptionEngine(model)
        val rows = StringBuilder()
        val truthRows = StringBuilder()
        out.delete(); File(out.path + ".truth").delete()
        rows.append("clip,split,type,tags,snr,label,ruleKeep,start,midi,").append(NoteFeatures.NAMES.joinToString(",")).append('\n')
        truthRows.append("clip,split,type,tags,snr,midi,found\n")
        for (i in 0 until n) {
            val seed = seed0 + i
            val rnd = Random(seed * 7919 + 13)
            val type = when (rnd.nextInt(10)) { in 0..3 -> InputType.SINGING; in 4..6 -> InputType.HUMMING; else -> InputType.WHISTLING }
            val clip = makeClip(type, rnd, split)
            val cfg = AnalysisConfig(inputType = type)
            val prep = try { engine.prepare(clip.audio, cfg) } catch (e: Throwable) { System.err.println("clip $seed failed: $e"); e.printStackTrace(); continue }
            val cands = engine.candidates(prep, cfg)
            val truth = clip.truth
            val used = BooleanArray(truth.size)
            val name = "$split-$seed"
            for (c in cands) {
                var label = 0
                for ((k, t) in truth.withIndex()) {
                    val ov = min(c.note.endSec, t.start + t.dur) - max(c.note.startSec, t.start)
                    val d = c.note.endSec - c.note.startSec
                    if (c.note.midi == Math.round(t.midi).toInt() && ov >= 0.5 * d) { label = 1; used[k] = true }
                }
                rows.append("$name,$split,${type.name},${clip.tags},${"%.1f".format(clip.snr)},$label,${if (c.keepByRules) 1 else 0},")
                    .append("%.3f,%d".format(c.note.startSec, c.note.midi))
                for (v in c.features) rows.append(',').append("%.5f".format(v))
                rows.append('\n')
            }
            for ((k, t) in truth.withIndex()) truthRows.append("$name,$split,${type.name},${clip.tags},${"%.1f".format(clip.snr)},${Math.round(t.midi)},${if (used[k]) 1 else 0}\n")
            if (i % 20 == 19) { flush(out, rows, truthRows); System.err.println("$split shard $seed0: ${i + 1}/$n") }
        }
        flush(out, rows, truthRows)
        model.close()
    }

    // ------------------------------------------------------------------------------------------------ melody + voice

    /**
     * [wobble]: human-voice instability (slow pitch drift, scoops into notes, loudness flutter, legato dips) and long held
     * notes, for the data that teaches the merger what a note cut in two looks like. Off for the note classifier's data.
     */
    fun makeClip(type: InputType, rnd: Random, split: String, wobble: Boolean = false): Clip {
        val sr = 44100
        val hard = split == "hard"
        val voiced = rnd.nextInt(100) >= 12 // ~12% of the clips contain no voice at all: every candidate there is noise
        val notes = ArrayList<SyntheticVoice.N>()
        val (lo, hi) = when (type) { InputType.WHISTLING -> 70 to 96; InputType.HUMMING -> 45 to 70; else -> 47 to 79 }
        var t = 0.3 + rnd.nextDouble() * 0.7
        var m = lo + rnd.nextInt(hi - lo)
        val count = 5 + rnd.nextInt(9)
        if (voiced) for (k in 0 until count) {
            val step = when (rnd.nextInt(6)) { 0 -> 0; 1, 2 -> 1 + rnd.nextInt(2); 3, 4 -> -(1 + rnd.nextInt(3)); else -> rnd.nextInt(9) - 4 }
            m = (m + step).coerceIn(lo, hi)
            val long = wobble && rnd.nextInt(100) < 55
            val dur = if (long) 0.35 + rnd.nextDouble() * 1.9 else 0.14 + rnd.nextDouble().pow(1.5) * 0.9
            val gap = 0.03 + rnd.nextDouble() * (if (rnd.nextInt(4) == 0) 0.45 else 0.12)
            notes.add(SyntheticVoice.N(m.toDouble(), t, dur, dip = wobble && rnd.nextInt(100) < 25))
            t += dur + gap
        }
        val total = t + 0.6
        val harm: DoubleArray; val vibC: Double; val vibHz = 4.5 + rnd.nextDouble() * 2.0; val breath: Double
        when (type) {
            InputType.WHISTLING -> { harm = doubleArrayOf(1.0, 0.02 + rnd.nextDouble() * 0.06); vibC = rnd.nextDouble() * 25; breath = 0.02 + rnd.nextDouble() * 0.05 }
            InputType.HUMMING -> {
                harm = doubleArrayOf(1.0, 0.45 + rnd.nextDouble() * 0.3, 0.15 + rnd.nextDouble() * 0.2, 0.05 + rnd.nextDouble() * 0.1, 0.03)
                vibC = rnd.nextDouble() * 35; breath = 0.01 + rnd.nextDouble() * 0.04
            }
            else -> {
                harm = DoubleArray(6) { h -> (1.0 / (1 + h * (0.4 + rnd.nextDouble() * 0.8))) * (0.7 + 0.6 * rnd.nextDouble()) }.also { it[0] = 1.0 }
                vibC = if (hard) rnd.nextDouble() * 80 else rnd.nextDouble() * 60; breath = 0.005 + rnd.nextDouble() * 0.03
            }
        }
        val detune = (rnd.nextDouble() * 2 - 1) * 45
        // Wander of a human voice (not for whistling, which is steadier): drawn per clip.
        val whistle = type == InputType.WHISTLING
        val drift = if (wobble && rnd.nextInt(100) < 85) rnd.nextDouble() * (if (whistle) 15.0 else (if (hard) 60.0 else 50.0)) else 0.0
        val flutter = if (wobble && !whistle && rnd.nextInt(100) < 60) rnd.nextDouble() * 0.8 else 0.0
        val scoop = if (wobble && !whistle && rnd.nextInt(100) < 50) rnd.nextDouble() * 90 else 0.0
        val voice = if (notes.isEmpty()) AudioBuffer(FloatArray((total * sr).toInt()), sr)
        else SyntheticVoice.render(notes, sr, harm, vibC, vibHz, 0.0, tailSec = max(0.3, total - (notes.last().start + notes.last().dur)), seed = rnd.nextLong(), detuneCents = detune, driftCents = drift, ampFlutter = flutter, scoopCents = scoop)
        val x = voice.samples.copyOf((total * sr).toInt())
        if (type == InputType.WHISTLING) glideOnsets(x, notes, sr, rnd)
        if (breath > 0) addBreath(x, notes, breath, rnd, sr)
        val voiceRms = rms(x).let { if (it < 1e-6) 0.1 else it }

        // Noise: 0..3 kinds at a random SNR relative to the voice.
        val pool = if (hard) HARD_NOISES else NOISES
        val kinds = ArrayList<String>()
        val nk = rnd.nextInt(100).let { if (it < 8) 0 else if (it < 55) 1 else if (it < 85) 2 else 3 }
        repeat(nk) { kinds.add(pool[rnd.nextInt(pool.size)]) }
        val snr = if (hard) 0.0 + rnd.nextDouble() * 12 else 3.0 + rnd.nextDouble() * 27
        for (k in kinds.distinct()) {
            val nz = noise(k, x.size, sr, rnd)
            val r = rms(nz).let { if (it < 1e-9) 1.0 else it }
            val gain = voiceRms / r * 10.0.pow(-(snr + (if (kinds.size > 1) 3.0 * rnd.nextDouble() else 0.0)) / 20.0)
            for (i in x.indices) x[i] += (nz[i] * gain).toFloat()
        }
        val tags = ArrayList<String>(kinds.distinct().ifEmpty { listOf("clean") })
        if (!voiced) tags.add("novoice")

        // Channel: phone microphone and automatic gain.
        if (rnd.nextInt(100) < 70) highPass(x, 80.0 + rnd.nextDouble() * 80, sr).also { tags.add("hp") }
        if (rnd.nextInt(100) < 50) lowPass(x, 5500.0 + rnd.nextDouble() * 4000, sr).also { tags.add("lp") }
        if (rnd.nextInt(100) < 35) { reverb(x, 0.1 + rnd.nextDouble() * 0.5, 0.1 + rnd.nextDouble() * 0.35, sr, rnd); tags.add("reverb") }
        var peak = 1e-6f; for (v in x) peak = max(peak, abs(v))
        val gainDb = -(rnd.nextDouble() * 38) // very quiet recordings are part of the mix
        val g = (10.0.pow(gainDb / 20.0) / peak).toFloat()
        for (i in x.indices) x[i] *= g
        if (rnd.nextInt(100) < 30) { val k = 1.5 + rnd.nextDouble() * 4; val norm = tanh(k); for (i in x.indices) x[i] = (tanh(x[i] * k * 1.0) / norm).toFloat(); tags.add("agc") }
        if (rnd.nextInt(100) < 8) { for (i in x.indices) x[i] = (x[i] * 6f).coerceIn(-1f, 1f); tags.add("clip") }
        return Clip(AudioBuffer(x, sr), notes, tags.joinToString("+"), if (nk == 0) 99.0 else snr)
    }

    private fun glideOnsets(x: FloatArray, notes: List<SyntheticVoice.N>, sr: Int, rnd: Random) { /* whistle onsets are re-rendered clean; slight pitch scoops are not modelled */ }

    private fun addBreath(x: FloatArray, notes: List<SyntheticVoice.N>, level: Double, rnd: Random, sr: Int) {
        for (n in notes) {
            val s = (n.start * sr).toInt(); val e = min(x.size, ((n.start + n.dur) * sr).toInt())
            var lp = 0.0
            for (i in s until e) { lp += 0.3 * (rnd.nextGaussian() - lp); x[i] += (lp * level * 0.5).toFloat() }
        }
    }

    // ------------------------------------------------------------------------------------------------ noise sources

    fun noise(kind: String, n: Int, sr: Int, rnd: Random): FloatArray {
        val y = FloatArray(n)
        when (kind) {
            "white" -> for (i in 0 until n) y[i] = rnd.nextGaussian().toFloat()
            "pink" -> { var b0 = 0.0; var b1 = 0.0; var b2 = 0.0; for (i in 0 until n) { val w = rnd.nextGaussian(); b0 = 0.99765 * b0 + w * 0.0990460; b1 = 0.96300 * b1 + w * 0.2965164; b2 = 0.57000 * b2 + w * 1.0526913; y[i] = (b0 + b1 + b2 + w * 0.1848).toFloat() } }
            "fan" -> { var a = 0.0; var b = 0.0; val c = 0.004 + rnd.nextDouble() * 0.02; for (i in 0 until n) { a += c * (rnd.nextGaussian() - a); b += 0.05 * (a - b); y[i] = (a * 3 + b * 2).toFloat() }
                val f = 100 + rnd.nextDouble() * 250; val d = rnd.nextDouble() * 0.5; for (i in 0 until n) y[i] += (0.8 * sin(2 * PI * f * i / sr) * (1 + d * sin(2 * PI * 0.3 * i / sr))).toFloat() }
            "mains50", "mains60" -> { val f0 = if (kind == "mains50") 50.0 else 60.0; for (h in 1..8) { val a = 1.0 / h.toDouble().pow(0.8) * (0.5 + rnd.nextDouble()); val ph = rnd.nextDouble() * 6.28; for (i in 0 until n) y[i] += (a * sin(2 * PI * f0 * h * i / sr + ph)).toFloat() } }
            "hiss" -> { var p = 0.0; for (i in 0 until n) { val w = rnd.nextGaussian(); y[i] = (w - p).toFloat(); p = w } }
            "street" -> { var a = 0.0; for (i in 0 until n) { a += 0.01 * (rnd.nextGaussian() - a); y[i] = (a * 8).toFloat() }
                var i = 0; while (i < n) { val len = (sr * (0.5 + rnd.nextDouble() * 2.0)).toInt(); val f = 120 + rnd.nextDouble() * 500; val amp = rnd.nextDouble(); for (j in 0 until min(len, n - i)) { val env = sin(PI * j / len); y[i + j] += (amp * env * (sin(2 * PI * f * j / sr) * 0.7 + rnd.nextGaussian() * 0.3)).toFloat() }; i += len + (rnd.nextDouble() * sr * 3).toInt() } }
            "breath" -> { var i = 0; while (i < n) { val len = (sr * (0.2 + rnd.nextDouble() * 0.5)).toInt(); var lp = 0.0; val a = 0.2 + rnd.nextDouble() * 0.6; for (j in 0 until min(len, n - i)) { lp += 0.25 * (rnd.nextGaussian() - lp); y[i + j] += (lp * a * sin(PI * j / len)).toFloat() }; i += len + (rnd.nextDouble() * sr * 1.5).toInt() } }
            "clicks" -> { var i = (rnd.nextDouble() * sr * 0.5).toInt(); while (i < n) { val a = 2 + rnd.nextDouble() * 6; for (j in 0 until min(60, n - i)) y[i + j] += (a * exp(-j / 8.0) * (rnd.nextGaussian())).toFloat(); i += (sr * (0.1 + rnd.nextDouble() * 1.5)).toInt() } }
            "keys" -> { var i = (rnd.nextDouble() * sr * 0.3).toInt(); while (i < n) { val burst = 2 + rnd.nextInt(6); for (b in 0 until burst) { val a = 1 + rnd.nextDouble() * 3; val len = 400 + rnd.nextInt(500); for (j in 0 until min(len, n - i)) y[i + j] += (a * exp(-j / 120.0) * rnd.nextGaussian()).toFloat(); i += (sr * (0.06 + rnd.nextDouble() * 0.15)).toInt(); if (i >= n) break }; i += (sr * (0.4 + rnd.nextDouble() * 2.0)).toInt() } }
            "babble" -> { // several far-away voices: harmonic tones with wandering pitch and syllable envelopes
                repeat(3 + rnd.nextInt(3)) {
                    var f = 90 + rnd.nextDouble() * 220; var ph = 0.0; var amp = 0.0; var target = 0.0
                    val syl = 0.15 + rnd.nextDouble() * 0.25
                    for (i in 0 until n) {
                        if (i % (sr / 50) == 0) { f *= 1 + (rnd.nextGaussian() * 0.01); f = f.coerceIn(80.0, 400.0); if (i % (max(1, (syl * sr).toInt())) < sr / 50) target = if (rnd.nextInt(3) == 0) 0.0 else rnd.nextDouble() }
                        amp += 0.002 * (target - amp); ph += 2 * PI * f / sr
                        var v = 0.0; for (h in 1..8) v += sin(ph * h) / h
                        y[i] += (v * amp).toFloat()
                    }
                }
            }
        }
        return y
    }

    // ------------------------------------------------------------------------------------------------ channel

    private fun rms(x: FloatArray): Double { var s = 0.0; for (v in x) s += v * v.toDouble(); return sqrt(s / max(1, x.size)) }

    private fun highPass(x: FloatArray, fc: Double, sr: Int) { // 2nd order via two 1-pole sections
        val a = exp(-2 * PI * fc / sr)
        repeat(2) { var px = 0.0; var py = 0.0; for (i in x.indices) { val v = x[i].toDouble(); val y = a * (py + v - px); px = v; py = y; x[i] = y.toFloat() } }
    }

    private fun lowPass(x: FloatArray, fc: Double, sr: Int) {
        val a = 1 - exp(-2 * PI * fc / sr)
        repeat(2) { var y = 0.0; for (i in x.indices) { y += a * (x[i] - y); x[i] = y.toFloat() } }
    }

    private fun reverb(x: FloatArray, rt: Double, wet: Double, sr: Int, rnd: Random) {
        val len = (rt * sr).toInt()
        val ir = FloatArray(len) { (rnd.nextGaussian() * exp(-6.9 * it / len)).toFloat() }
        // Sparse convolution (every 3rd tap) keeps this cheap enough for thousands of clips.
        val dry = x.copyOf()
        var k = 0
        while (k < len) { val g = ir[k] * wet.toFloat() * 0.6f; if (abs(g) > 1e-4f) for (i in 0 until x.size - k) x[i + k] += dry[i] * g; k += 37 }
    }
}
