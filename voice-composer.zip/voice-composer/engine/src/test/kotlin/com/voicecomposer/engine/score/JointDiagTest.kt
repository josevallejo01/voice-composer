package com.voicecomposer.engine.score

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.io.WavIO
import com.voicecomposer.engine.ml.DecoderParams
import com.voicecomposer.engine.ml.forInput
import com.voicecomposer.engine.ml.MlTranscriptionEngine
import com.voicecomposer.engine.ml.NoteMerger
import com.voicecomposer.engine.ml.PythonOnnxModel
import com.voicecomposer.engine.ml.RandomForest
import com.voicecomposer.engine.preprocessing.InputType
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

class JointDiagTest {
    private fun findUp(rel: String): File? { var d: File? = File("").absoluteFile; while (d != null) { val f = File(d, rel); if (f.exists()) return f; d = d.parentFile }; return null }
    @Test fun joints() {
        val net = PythonOnnxModel.create(); val dir = findUp("app/src/main/assets")
        assumeTrue(net != null && dir != null)
        val forest = RandomForest.fromJson(File(dir, "note_rf.json").readText()); val merge = RandomForest.fromJson(File(dir, "note_merge.json").readText())
        val e = MlTranscriptionEngine(net!!, classifier = { forest })
        val f = File("/home/claude/spotify/basic-pitch/tests/resources/vocadito_10.wav"); assumeTrue(f.exists())
        val cfg = AnalysisConfig(InputType.SINGING)
        val p = e.prepare(WavIO.read(f), cfg)
        val kept = e.detectKept(p, cfg, DecoderParams.forInput(InputType.SINGING))
        val rows = NoteMerger.jointRows(kept, p).toMap()
        for (i in kept.indices) {
            val n = kept[i].second
            val x = rows[i - 1]
            val pr = x?.let { merge.probability(it) }
            println("JOINT %5.2f-%5.2f midi %d %s".format(n.startSec, n.endSec, n.midi, if (x == null) "" else "<- gap %.2f dKey %.0f dip %.2f step %.2f p(merge) %.2f".format(x[0], x[4], x[9], x[10], pr)))
        }
    }
}
