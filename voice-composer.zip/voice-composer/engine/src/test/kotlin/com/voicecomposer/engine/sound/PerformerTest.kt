package com.voicecomposer.engine.sound

import com.voicecomposer.model.EventSource
import com.voicecomposer.model.EventType
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PerformerTest {
    private val map = TempoMap.constant(120.0)
    private fun ev(midi: Int, startBeat: Double, beats: Double) = MusicalEvent(
        "e$startBeat-$midi", EventType.NOTE, midi, Pitch.midiToHz(midi), map.beatToSec(startBeat), map.beatToSec(startBeat + beats),
        startBeat, beats, 1.0, EventSource.USER,
    )

    @Test fun everyInstrumentHasAPatch() {
        for (i in Instrument.entries) { val p = Patches.of(i); assertTrue(p.layers.isNotEmpty()); assertNotNull(p.articulation) }
    }

    @Test fun deterministicAndWithinRange() {
        val notes = (0 until 16).map { ev(60 + it % 5, it * 0.5, 0.5) }
        val t = Track("m", "m", Instrument.VIOLIN, TrackRole.MELODY, notes)
        val a = Performer.perform(t, Patches.of(Instrument.VIOLIN), map, 4.0)
        val b = Performer.perform(t, Patches.of(Instrument.VIOLIN), map, 4.0)
        assertEquals(notes.size, a.size)
        assertEquals(a.map { it.velocity }, b.map { it.velocity })
        assertTrue(a.all { it.velocity in 30..122 && it.durationSec > 0 })
        // The note on the bar's first beat is played louder than an off-beat in the same position of the contour.
        val down = a.first { Math.abs(it.startSec) < 1e-6 }.velocity
        val off = a[1].velocity
        assertTrue("downbeat $down off-beat $off", down > off)
    }

    @Test fun repeatedNotesAreSeparatedAndLegatoNotesJoined() {
        val same = Track("s", "s", Instrument.CLARINET, TrackRole.MELODY, listOf(ev(64, 0.0, 1.0), ev(64, 1.0, 1.0)))
        val ps = Performer.perform(same, Patches.of(Instrument.CLARINET), map, 4.0)
        assertTrue("repeated note must end before the next begins", ps[0].startSec + ps[0].durationSec < ps[1].startSec - 0.01)
        val legato = Track("l", "l", Instrument.CLARINET, TrackRole.MELODY, listOf(ev(64, 0.0, 1.0), ev(67, 1.0, 1.0)))
        val pl = Performer.perform(legato, Patches.of(Instrument.CLARINET), map, 4.0)
        assertTrue("different pitches overlap slightly", pl[0].startSec + pl[0].durationSec > pl[1].startSec)
    }

    @Test fun vibratoOnlyOnLongSustainedNotesAndPedalOnPiano() {
        val t = Track("v", "v", Instrument.VIOLIN, TrackRole.MELODY, listOf(ev(69, 0.0, 0.25), ev(71, 4.0, 4.0)))
        val p = Performer.perform(t, Patches.of(Instrument.VIOLIN), map, 4.0)
        assertTrue(p[0].vibrato == null && p[1].vibrato != null)
        val piano = Track("p", "p", Instrument.PIANO, TrackRole.HARMONY, listOf(ev(48, 0.0, 2.0), ev(52, 0.0, 2.0), ev(55, 0.0, 2.0)))
        val pp = Performer.perform(piano, Patches.of(Instrument.PIANO), map, 4.0)
        assertTrue(pp.all { it.extraRelease > 0.1 })
        // A chord is rolled, not struck at the exact same instant.
        assertTrue(pp.map { it.startSec }.distinct().size > 1)
    }
}
