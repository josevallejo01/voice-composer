package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.DefaultTranscriptionEngine
import com.voicecomposer.engine.SyntheticVoice
import com.voicecomposer.engine.SyntheticVoice.N
import com.voicecomposer.engine.TranscriptionEngine
import com.voicecomposer.engine.preprocessing.InputType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeNotNull
import org.junit.Test
import kotlin.math.abs

class MlEngineTest {
    private val model: PythonOnnxModel? by lazy { PythonOnnxModel.create() }

    /** (midi, start, end) truth vs detected; note counts as found if same pitch and start within [tol]. */
    private fun f1(truth: List<N>, est: List<Triple<Int, Double, Double>>, tol: Double = 0.06): Double {
        val used = BooleanArray(est.size)
        var tp = 0
        for (t in truth) {
            val i = est.indices.firstOrNull { !used[it] && est[it].first == Math.round(t.midi).toInt() && abs(est[it].second - t.start) < tol }
            if (i != null) { used[i] = true; tp++ }
        }
        val p = if (est.isEmpty()) 0.0 else tp.toDouble() / est.size
        val r = tp.toDouble() / truth.size
        return if (p + r == 0.0) 0.0 else 2 * p * r / (p + r)
    }

    private val tune = listOf(60 to 1.0, 62 to 1.0, 64 to 1.0, 65 to 1.0, 67 to 2.0, 64 to 1.0, 60 to 1.0, 62 to 1.0, 55 to 2.0)

    private fun voice(detune: Double = 0.0, vib: Double = 0.0) =
        SyntheticVoice.melody(tune.map { it.first to it.second }, 100.0).let { notes ->
            notes to SyntheticVoice.render(notes, vibratoCents = vib, noise = 0.002, detuneCents = detune)
        }

    private fun run(engine: TranscriptionEngine, a: com.voicecomposer.engine.io.AudioBuffer) =
        engine.analyze(a, AnalysisConfig(InputType.SINGING)).transcription.notes.map { Triple(it.midiPitch ?: -1, it.startSec, it.endSec) }

    @Test fun mlFindsTheSungNotes() {
        val m = model; assumeNotNull(m)
        val (notes, audio) = voice(vib = 25.0)
        val est = run(MlTranscriptionEngine(m!!), audio)
        val s = f1(notes, est)
        notes.forEach { println("truth ${it.midi} ${"%.2f".format(it.start)}-${"%.2f".format(it.start+it.dur)}") }
        est.forEach { println("est ${it.first} ${"%.2f".format(it.second)}-${"%.2f".format(it.third)}") }
        println("ML F1 (vibrato 25c) = $s, found ${est.size}/${notes.size}")
        assertTrue("F1 $s", s >= 0.85)
    }

    @Test fun mlSurvivesDetuning() {
        val m = model; assumeNotNull(m)
        val (notes, audio) = voice(detune = 40.0, vib = 15.0)
        val ml = f1(notes, run(MlTranscriptionEngine(m!!), audio))
        val dsp = f1(notes, run(DefaultTranscriptionEngine(), audio))
        println("detune 40 cents: ML F1 = $ml, DSP F1 = $dsp")
        assertTrue("ML F1 $ml", ml >= 0.8)
    }

    @Test fun fallsBackWhenTheModelFails() {
        val broken = object : BasicPitchModel { override fun inferBatch(windows: List<FloatArray>): List<WindowOutput> = error("no runtime") }
        val e = MlTranscriptionEngine(broken)
        val (notes, audio) = voice()
        val est = run(e, audio)
        assertTrue(e.lastRunUsedFallback)
        assertTrue(est.size >= notes.size - 2)
    }

    @Test fun stitchingKeepsTimeAlignmentOnLongAudio() {
        // A scripted model that reports "key 60 sounding" exactly where the input window is non-zero:
        // checks that frames land at the right absolute time over several windows.
        val fake = object : BasicPitchModel {
            override fun inferBatch(windows: List<FloatArray>) = windows.map { w ->
                val note = FloatArray(BP.WINDOW_FRAMES * BP.NOTES); val onset = FloatArray(BP.WINDOW_FRAMES * BP.NOTES)
                for (f in 0 until BP.WINDOW_FRAMES) {
                    var e = 0f
                    for (i in f * BP.HOP until minOf(w.size, f * BP.HOP + BP.HOP)) e += abs(w[i])
                    note[f * BP.NOTES + (60 - BP.LOWEST_MIDI)] = if (e > 1f) 0.9f else 0f
                }
                WindowOutput(note, onset, FloatArray(BP.WINDOW_FRAMES * BP.CONTOUR_BINS))
            }
        }
        val audio = FloatArray(BP.SAMPLE_RATE * 12)
        val from = (BP.SAMPLE_RATE * 7.3).toInt(); val to = (BP.SAMPLE_RATE * 9.1).toInt()
        for (i in from until to) audio[i] = 0.5f
        val p = BasicPitchRunner.run(audio, fake)
        val on = (0 until p.frames).filter { p.note(it, 60 - BP.LOWEST_MIDI) > 0.5f }
        assertEquals(7.3, p.timeOf(on.first()), 0.02)
        assertEquals(9.1, p.timeOf(on.last()), 0.02)
        assertEquals(on.last() - on.first() + 1, on.size) // no holes at window seams
    }
}
