package com.voicecomposer.engine.score

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.segmentation.DetectedNote
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.model.TimeSignature
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File
import kotlin.math.abs

/** What the user or the metronome imposes (tempo, meter, free timing) must be honoured by the learned pipeline. */
class ScoreConstraintsTest {
    private val models: ScoreModels? by lazy {
        var d: File? = File("").absoluteFile
        while (d != null && !File(d, "app/src/main/assets").exists()) d = d.parentFile
        val dir = d?.let { File(it, "app/src/main/assets") } ?: return@lazy null
        ScoreModels.load { n -> File(dir, n).takeIf { it.exists() }?.readText() }.takeIf { it.complete }
    }

    // A simple tune in 3/4 at 90 BPM, sung with a little timing noise.
    private val pitches = intArrayOf(67, 72, 71, 69, 67, 67, 69, 71, 69, 72, 67, 64, 65, 67, 69, 71, 72, 74, 72, 67)
    private val beats = doubleArrayOf(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 20.0)
    private fun notes(bpm: Double, origin: Double): List<DetectedNote> = pitches.indices.map { i ->
        val jitter = ((i * 37) % 7 - 3) * 0.008
        val s = origin + beats[i] * 60.0 / bpm + jitter
        DetectedNote(s, s + 0.85 * 60.0 / bpm, pitches[i], pitches[i].toDouble(), 0.9, 0.9, 0.5)
    }

    @Test fun tooShortFallsBack() {
        assumeTrue(models != null)
        assertNull(MlScorePipeline.run(notes(90.0, 1.0).take(3), AnalysisConfig(), models!!))
    }

    @Test fun forcedTempoAndSignatureAreKept() {
        assumeTrue(models != null)
        val r = MlScorePipeline.run(notes(90.0, 1.0), AnalysisConfig(forcedBpm = 90.0, forcedTimeSignature = TimeSignature.THREE_FOUR), models!!)
        assertNotNull(r)
        assertTrue("tempo ${r!!.tempo.bpm}", abs(r.tempo.bpm - 90.0) < 1.0)
        assertEquals(TimeSignature.THREE_FOUR, r.meter.timeSignature)
        assertEquals(20, r.events.size)
    }

    @Test fun freeModeKeepsPerformedPositions() {
        assumeTrue(models != null)
        val r = MlScorePipeline.run(notes(90.0, 1.0), AnalysisConfig(quantization = QuantizationMode.FREE), models!!)
        assertNotNull(r)
        assertEquals(20, r!!.events.size)
        // Free timing: positions are not all on the sixteenth grid.
        assertTrue(r.events.any { abs(it.startBeat * 4 - Math.round(it.startBeat * 4)) > 0.02 })
        assertTrue(r.events.zipWithNext().all { (a, b) -> b.startBeat >= a.startBeat })
    }
}
