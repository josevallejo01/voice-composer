package com.voicecomposer.engine.pitch

import com.voicecomposer.engine.SyntheticVoice
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SungNoteReaderTest {
    @Test fun readsASungNoteWithAGlideInAndVibrato() {
        for (midi in listOf(48, 57, 62, 69, 74)) {
            // 0.15 s of a glide-in from a semitone and a half below, then the note held 1 s, a little flat
            val v = SyntheticVoice.render(
                listOf(SyntheticVoice.N(midi - 1.5, 0.2, 0.15), SyntheticVoice.N(midi - 0.2, 0.35, 1.0)),
                vibratoCents = 25.0, noise = 0.01, tailSec = 0.3, seed = midi.toLong())
            assertEquals("midi $midi", midi, SungNoteReader.read(v.samples, v.sampleRate))
        }
    }

    @Test fun silenceGivesNothing() {
        assertNull(SungNoteReader.read(FloatArray(44100 * 2), 44100))
        val noise = java.util.Random(3).let { r -> FloatArray(44100 * 2) { (r.nextGaussian() * 0.05).toFloat() } }
        assertNull(SungNoteReader.read(noise, 44100))
    }
}
