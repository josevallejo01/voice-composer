package com.voicecomposer.engine.score

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.SyntheticVoice
import com.voicecomposer.engine.ml.MlTranscriptionEngine
import com.voicecomposer.engine.ml.PythonOnnxModel
import com.voicecomposer.engine.ml.RandomForest
import com.voicecomposer.engine.preprocessing.InputType
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

/** Pauses the singer makes must come out as rests in the score (not as notes stretched over the silence). */
class RestsTest {
    private fun findUp(rel: String): File? {
        var d: File? = File("").absoluteFile
        while (d != null) { val f = File(d, rel); if (f.exists()) return f; d = d.parentFile }
        return null
    }

    @Test fun pausesBecomeRests() {
        val net = PythonOnnxModel.create()
        val dir = findUp("app/src/main/assets")
        assumeTrue(net != null && dir != null)
        val forest = File(dir, "note_rf.json").takeIf { it.exists() }?.let { RandomForest.fromJson(it.readText()) }
        val models = ScoreModels.load { n -> File(dir, n).takeIf { it.exists() }?.readText() }.takeIf { it.complete }
        val bpm = 90.0; val beat = 60.0 / bpm
        // (midi, start beat, length beats): quarter notes with a 1-beat and a 2-beat pause and a pause before the last note
        val tune = listOf(60 to 0.0, 62 to 1.0, 64 to 2.0, 67 to 4.0, 67 to 5.0, 69 to 8.0, 71 to 9.0, 72 to 10.0, 67 to 12.0, 64 to 13.0, 60 to 14.0)
        val lengths = listOf(1.0, 1.0, 1.0, 1.0, 2.0, 1.0, 1.0, 2.0, 1.0, 1.0, 2.0)
        val voice = SyntheticVoice.render(
            tune.mapIndexed { i, (m, s) -> SyntheticVoice.N(m.toDouble(), 1.0 + s * beat, lengths[i] * beat * 0.92) },
            tailSec = 0.6, vibratoCents = 20.0, seed = 4)
        for ((label, e) in listOf(
            "rules" to MlTranscriptionEngine(net!!, classifier = { forest }),
            "learned" to MlTranscriptionEngine(net, classifier = { forest }, scoreModels = { models }),
        )) {
            val tr = e.analyze(voice, AnalysisConfig(InputType.HUMMING)).transcription
            val notes = tr.notes
            println("$label: ${notes.size} notes, bpm ${"%.1f".format(tr.tempoMap.averageBpm)} ${tr.timeSignature}")
            val gaps = notes.zipWithNext().map { (a, b) -> b.startBeat - a.endBeat }
            println("  starts ${notes.map { "%.2f".format(it.startBeat) }}")
            println("  gaps   ${gaps.map { "%.2f".format(it) }}")
            val rests = gaps.count { it >= 0.74 }
            println("  rests found: $rests (expected 3, 2 of them >= 1 beat)")
            if (label == "learned") assertTrue("pauses lost: $gaps", rests >= 2)
        }
    }
}
