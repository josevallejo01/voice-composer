package com.voicecomposer.engine.sound

import com.voicecomposer.engine.pitch.YinPitchTracker
import com.voicecomposer.engine.preprocessing.InputType
import java.io.File
import java.io.RandomAccessFile
import java.nio.channels.FileChannel
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt
import org.junit.Assume
import org.junit.Test

class SfSynthTest {
    private val path = "/home/claude/mrbumpy409/generaluser-gs/GeneralUser-GS.sf2"
    private fun load(): SoundFont? {
        val f = File(path); if (!f.exists()) return null
        val ch = RandomAccessFile(f, "r").channel
        return SoundFont(ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()))
    }

    private fun note(sf: SoundFont, prog: Int, key: Int, vel: Int, dur: Double): Pair<FloatArray, FloatArray> {
        val sr = 44100
        val synth = SfSynth(sf, sr)
        val n = ((dur + 3.0) * sr).toInt()
        val l = FloatArray(n); val r = FloatArray(n)
        val p = sf.findPreset(prog, 0) ?: error("no preset $prog")
        synth.render(p, NoteEvent(key, vel, dur, 0, 1f, 1f), l, r)
        return l to r
    }

    @Test fun listsAndResolves() {
        val sf = load(); Assume.assumeNotNull(sf); sf!!
        for (prog in intArrayOf(0, 24, 32, 40, 41, 42, 43, 46, 48, 52, 56, 57, 60, 68, 71, 73, 80)) {
            val p = sf.findPreset(prog, 0)
            val regs = if (p != null) sf.regions(p, 60, 90) else emptyList()
            println("prog $prog ${p?.name} regions@60=${regs.size} ${regs.firstOrNull()?.sample?.name}")
        }
    }

    @Test fun pitchAccuracy() {
        val sf = load(); Assume.assumeNotNull(sf); sf!!
        val tracker = YinPitchTracker(44100, InputType.SINGING)
        var worst = 0.0; var worstDesc = ""; var count = 0; var bad = 0
        for (prog in intArrayOf(0, 24, 40, 41, 42, 46, 48, 56, 60, 68, 71, 73, 80)) {
            for (key in intArrayOf(48, 55, 60, 67, 72, 79)) {
                val (l, _) = note(sf, prog, key, 90, 1.2)
                val fr = tracker.track(l.copyOfRange(0, 44100 * 2)).filter { it.voiced && it.timeSec in 0.3..0.9 }
                if (fr.size < 10) { println("prog $prog key $key: no pitch (${fr.size} voiced frames)"); continue }
                val med = fr.map { it.midi }.sorted()[fr.size / 2]
                var dev = (med - key) * 100
                if (abs(abs(dev) - 1200) < 60) { println("prog $prog key $key: octave estimate (YIN), folded"); dev -= 1200 * Math.signum(dev) }
                count++
                if (abs(dev) > 25) { bad++; println("prog $prog key $key: ${"%.0f".format(dev)} cents") }
                if (abs(dev) > worst) { worst = abs(dev); worstDesc = "prog $prog key $key" }
            }
        }
        println("pitch: checked=$count, >25c=$bad, worst=${"%.1f".format(worst)} cents ($worstDesc)")
        org.junit.Assert.assertTrue("too many notes out of tune", count >= 70 && bad == 0)
    }

    @Test fun noClicksNoNaNTailsDecay() {
        val sf = load(); Assume.assumeNotNull(sf); sf!!
        for (prog in intArrayOf(0, 24, 40, 42, 48, 56, 60, 68, 71, 73)) {
            val (l, r) = note(sf, prog, 64, 100, 3.0)
            var nan = 0; var peak = 0f
            for (v in l + r) { if (v.isNaN() || v.isInfinite()) nan++ else peak = maxOf(peak, abs(v)) }
            // Largest sample-to-sample jump inside the sustained part, relative to the local level (loop clicks).
            var maxJump = 0f; var rms = 0.0; var cnt = 0
            val a = 44100; val b = (2.5 * 44100).toInt()
            for (i in a until b) { maxJump = maxOf(maxJump, abs(l[i + 1] - l[i])); rms += l[i] * l[i]; cnt++ }
            rms = sqrt(rms / cnt)
            val tailStart = (3.0 * 44100).toInt() + 44100 * 2
            var tail = 0.0; for (i in tailStart until l.size) tail += l[i] * l[i]
            val tailDb = if (tail > 0) 10 * log10(tail / (l.size - tailStart)) else -200.0
            org.junit.Assert.assertEquals(0, nan)
            org.junit.Assert.assertTrue("click in sustained part of prog $prog", maxJump / (rms + 1e-9) < 6f)
            println("prog $prog: nan=$nan peak=${"%.3f".format(peak)} rms(1-2.5s)=${"%.4f".format(rms)} maxJump/rms=${"%.1f".format(maxJump / (rms + 1e-9))} tail(5s+)=${"%.0f".format(tailDb)} dB")
        }
    }
}
