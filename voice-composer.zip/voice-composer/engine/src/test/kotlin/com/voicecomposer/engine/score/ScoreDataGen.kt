package com.voicecomposer.engine.score

import com.voicecomposer.engine.rhythm.TempoEstimator
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TempoPoint
import java.io.File
import java.util.Random
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * Training rows for the score models (not a unit test: run with main, see tools/gen_score_data.sh).
 * Notated tunes (tools/prepare_tunes.py) are excerpted, played back by [PerformanceSim] and pushed through exactly the
 * candidate generators and feature builders the engine uses; every candidate is labelled against the notation.
 * Splits are by tune: "train" and "val" with ordinary performers, "hard" with sloppier ones on unseen tunes.
 */
object ScoreDataGen {
    private class Out(dir: File, name: String, split: String, names: List<String>) {
        val w = File(dir, "score_${name}_$split.csv").bufferedWriter()
        var g = 0
        fun group() { g++ }
        init { w.write("tune,split,perf,grp,label,label2," + names.joinToString(",") + "\n") }
        fun row(tune: String, split: String, perf: Int, label: Int, label2: Int, x: DoubleArray) {
            val sb = StringBuilder(tune.length + 40 + x.size * 8)
            sb.append(tune).append(',').append(split).append(',').append(perf).append(',').append(g).append(',').append(label).append(',').append(label2)
            for (v in x) sb.append(',').append(if (v == Math.rint(v) && abs(v) < 1e9) v.toLong().toString() else "%.5f".format(v))
            sb.append('\n'); w.write(sb.toString())
        }
        fun close() = w.close()
    }

    fun splitOf(id: String): String = when (Math.floorMod(id.hashCode() * 31 + 7, 10)) { 0 -> "val"; 1 -> "hard"; else -> "train" }

    @JvmStatic
    fun main(args: Array<String>) {
        val tunes = Tune.load(File(args[0])); val dir = File(args[1]); val split = args[2]; val perTune = args[3].toInt()
        dir.mkdirs()
        val lv = if (split == "hard") PerformanceSim.HARD else PerformanceSim.NORMAL
        val outs = mapOf(
            "tempo" to Out(dir, "tempo", split, TempoPhase.NAMES), "bar" to Out(dir, "bar", split, BarModel.NAMES),
            "drift" to Out(dir, "drift", split, DriftModel.NAMES), "onset" to Out(dir, "onset", split, OnsetModel.NAMES),
            "duration" to Out(dir, "duration", split, DurationModel.NAMES), "key" to Out(dir, "key", split, KeyModel.NAMES),
            "spell" to Out(dir, "spell", split, SpellingModel.NAMES),
        )
        var perfs = 0
        for (tune in tunes) {
            if (splitOf(tune.id) != split) continue
            for (pi in 0 until perTune) {
                val rnd = Random(tune.id.hashCode().toLong() * 1_000_003L + pi * 7919L + (if (split == "hard") 99 else 0))
                val perf = PerformanceSim.perform(tune, rnd, lv) ?: continue
                perfs++
                rows(perf, rnd, tune.id, split, pi, outs, rich = pi < 3)
            }
        }
        outs.values.forEach { it.close() }
        System.err.println("$split: $perfs performances")
    }

    private fun circ(a: Double, b: Double, period: Double): Double { val d = abs(a - b) % period; return min(d, period - d) }
    private fun frac(x: Double) = x - Math.floor(x)

    /** The tempo map the pipeline would be working with: the true curve followed (A) or one constant tempo (B), both a little off. */
    private fun upstream(p: Perf, rnd: Random, tracked: Boolean): TempoMap {
        val labelled = p.notes.filter { it.truthIdx >= 0 && it.slot >= 0 }
        if (tracked) {
            val eps = rnd.nextGaussian() * 0.012
            val ref = p.notes[0].startSec
            val dl = rnd.nextGaussian() * 0.03 * 60.0 / p.bpmAvg
            val pts = p.map.points.map { TempoPoint(it.beat, ref + (it.timeSec - ref) * (1 + eps) + dl) }
            return TempoMap(pts, p.map.tailBpm * (1 - eps))
        }
        val bpm = p.bpmAvg * exp(rnd.nextGaussian() * 0.01)
        val spb = 60.0 / bpm
        val origin = labelled.map { it.startSec - it.slot / 4.0 * spb }.average() + rnd.nextGaussian() * 0.03 * spb
        return TempoMap.constant(bpm, origin)
    }

    private fun correctFraction(p: Perf, map: TempoMap): Double {
        val labelled = p.notes.filter { it.truthIdx >= 0 && it.slot >= 0 }
        if (labelled.isEmpty()) return 0.0
        val shifts = labelled.map { Math.round(map.secToBeat(it.startSec) * 4).toInt() - it.slot }
        val mode = shifts.groupingBy { it }.eachCount().maxByOrNull { it.value }!!
        return mode.value.toDouble() / labelled.size
    }

    private fun rows(p: Perf, rnd: Random, id: String, split: String, pi: Int, o: Map<String, Out>, rich: Boolean) {
        val t = DoubleArray(p.notes.size) { p.notes[it].startSec }
        val midi = IntArray(p.notes.size) { p.notes[it].midi }
        val bpbTrue = p.meter.beatsPerMeasure
        val firstBeatTrue = p.map.secToBeat(t[0])

        // ---- tempo and phase
        run {
            val bpmOk = { b: Double -> abs(b / p.bpmAvg - 1) < 0.04 }
            o.getValue("tempo").group()
            for (c in TempoPhase.candidates(t)) {
                val ph = frac((t[0] - c.originSec) / (60.0 / c.bpm))
                val ok = bpmOk(c.bpm) && circ(ph, frac(firstBeatTrue), 1.0) < 0.12
                o.getValue("tempo").row(id, split, pi, if (ok) 1 else 0, 0, c.features)
            }
            if (rnd.nextInt(4) == 0) {   // metronome: tempo known, phase hinted
                val kb = p.bpmAvg * exp(rnd.nextGaussian() * 0.003)
                val hint = p.map.beatToSec(Math.floor(firstBeatTrue)) + rnd.nextGaussian() * 0.04
                o.getValue("tempo").group()
                for (c in TempoPhase.candidates(t, kb, hint)) {
                    val ph = frac((t[0] - c.originSec) / (60.0 / c.bpm))
                    o.getValue("tempo").row(id, split, pi, if (circ(ph, frac(firstBeatTrue), 1.0) < 0.12) 1 else 0, 1, c.features)
                }
            }
        }

        // ---- meter and bar lines
        run {
            val u = upstream(p, rnd, rnd.nextBoolean())
            val k = rnd.nextInt(8); val eps = rnd.nextGaussian() * 0.05
            val g = com.voicecomposer.engine.score.MlScorePipeline.shiftMap(u, -(k + eps))
            val r = DoubleArray(t.size) { g.secToBeat(t[it]) }
            val durB = DoubleArray(t.size) { max(0.05, g.secToBeat(p.notes[it].endSec) - r[it]) }
            val dTrue = Math.floorMod(((k + eps) * 1000).toInt(), (bpbTrue * 1000).toInt()) / 1000.0
            o.getValue("bar").group()
            for (h in BarModel.hypotheses(r, durB, midi)) {
                val ok = h.meter == p.meter && circ(h.offsetBeats, dTrue, bpbTrue) <= 0.26
                o.getValue("bar").row(id, split, pi, if (ok) 1 else 0, 0, h.features)
            }
        }

        // ---- steady or followed tempo
        run {
            val tracked = TempoEstimator.track(t.toList(), p.bpmAvg * exp(rnd.nextGaussian() * 0.01), 0.0).map
            if (!tracked.isConstant) {
                val c = upstream(p, rnd, false)
                val better = correctFraction(p, tracked) > correctFraction(p, c) + 0.03
                o.getValue("drift").group()
                o.getValue("drift").row(id, split, pi, if (better) 1 else 0, 0, DriftModel.features(t, c, tracked))
            }
        }

        // ---- key
        run {
            val dur = DoubleArray(t.size) { val d = p.notes[it].durSlots; if (d > 0) d * 0.25 else max(0.25, (p.notes[it].endSec - p.notes[it].startSec) * p.bpmAvg / 60.0) }
            val kc = KeyModel.candidates(midi, dur)
            o.getValue("key").group()
            for (c in kc) {
                val exact = c.key.tonic == p.key.first && (c.key.mode == Mode.MINOR) == p.key.second
                val sig = c.key.fifths == KeySignature(p.key.first, if (p.key.second) Mode.MINOR else Mode.MAJOR).fifths
                o.getValue("key").row(id, split, pi, if (exact) 1 else 0, if (sig) 1 else 0, c.features)
            }
        }
        if (!rich) return

        // ---- spelling
        run {
            val key = KeySignature(p.key.first, if (p.key.second) Mode.MINOR else Mode.MAJOR)
            for (i in midi.indices) {
                val n = p.notes[i]
                if (!n.pitchOk || n.truthIdx < 0 || n.alter == 0 || n.alter !in -1..1 || !SpellingModel.isChromatic(n.midi)) continue
                val kk = if (rnd.nextInt(10) == 0) KeySignature((key.tonic + (if (key.mode == Mode.MAJOR) 9 else 3)) % 12, if (key.mode == Mode.MAJOR) Mode.MINOR else Mode.MAJOR) else key
                val x = SpellingModel.row(midi, i, kk) ?: continue
                o.getValue("spell").group()
                o.getValue("spell").row(id, split, pi, if (n.alter < 0) 1 else 0, 0, x)
            }
        }
        if (!p.onGrid) return

        // ---- rhythmic positions and written lengths, on the pipeline's grid (bar line at beat 0)
        val u = upstream(p, rnd, p.map.points.size > 1 && rnd.nextBoolean())
        val raw = DoubleArray(t.size) { max(0.0, u.secToBeat(t[it])) }
        val rawEnd = DoubleArray(t.size) { max(raw[it] + 0.05, u.secToBeat(p.notes[it].endSec)) }
        val bpm = u.averageBpm
        val ctx = OnsetModel.Ctx(raw, DoubleArray(t.size) { rawEnd[it] - raw[it] }, bpm, p.meter)
        for (i in t.indices) {
            val n = p.notes[i]
            if (n.truthIdx < 0 || n.slot < 0) continue
            val kTrue = n.slot - ctx.base[i] + OnsetModel.SPREAD
            o.getValue("onset").group()
            if (kTrue !in 0 until OnsetModel.WIDTH) continue
            val prev = p.notes.getOrNull(i - 1)
            if (i == 0) {
                for (k in 0 until OnsetModel.WIDTH) if (ctx.slot(0, k) >= 0)
                    o.getValue("onset").row(id, split, pi, if (k == kTrue) 1 else 0, 0, OnsetModel.row(ctx, 0, -1, k))
                continue
            }
            if (prev == null || prev.truthIdx < 0 || prev.slot < 0) continue
            val jTrue = prev.slot - ctx.base[i - 1] + OnsetModel.SPREAD
            if (jTrue !in 0 until OnsetModel.WIDTH) continue
            // positive, hard negatives (one of the two slots right), a couple of random others
            val pairs = ArrayList<Pair<Int, Int>>()
            pairs.add(jTrue to kTrue)
            val hard = ArrayList<Pair<Int, Int>>()
            for (j in 0 until OnsetModel.WIDTH) if (j != jTrue) hard.add(j to kTrue)
            for (k in 0 until OnsetModel.WIDTH) if (k != kTrue) hard.add(jTrue to k)
            hard.shuffle(rnd); pairs.addAll(hard.take(3))
            repeat(2) { val j = rnd.nextInt(OnsetModel.WIDTH); val k = rnd.nextInt(OnsetModel.WIDTH); if (j != jTrue && k != kTrue) pairs.add(j to k) }
            for ((j, k) in pairs) {
                if (ctx.slot(i, k) < 0 || ctx.slot(i - 1, j) < 0) continue
                o.getValue("onset").row(id, split, pi, if (j == jTrue && k == kTrue) 1 else 0, 0, OnsetModel.row(ctx, i, j, k))
            }
        }
        val slots = IntArray(t.size)
        for (i in t.indices) {
            val n = p.notes[i]
            var s = if (n.truthIdx >= 0 && n.slot >= 0) n.slot + (if (rnd.nextInt(10) == 0) rnd.nextInt(3) - 1 else 0) else Math.round(raw[i] / 0.25).toInt()
            if (i > 0 && s <= slots[i - 1]) s = slots[i - 1] + 1
            slots[i] = max(0, s)
        }
        val dctx = DurationModel.Ctx(raw, rawEnd, slots, bpm, p.meter)
        for (i in t.indices) {
            val n = p.notes[i]
            if (n.truthIdx < 0 || n.durSlots !in 1..16) continue
            val cs = DurationModel.candidates(dctx, i)
            if (cs.none { it.slots == n.durSlots }) continue
            o.getValue("duration").group()
            for (c in cs) o.getValue("duration").row(id, split, pi, if (c.slots == n.durSlots) 1 else 0, 0, c.features)
        }
    }
}
