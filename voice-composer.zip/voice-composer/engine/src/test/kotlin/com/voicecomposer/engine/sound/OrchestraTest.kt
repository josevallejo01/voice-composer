package com.voicecomposer.engine.sound

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.DefaultTranscriptionEngine
import com.voicecomposer.engine.SyntheticVoice
import com.voicecomposer.engine.arrangement.HarmonicArrangementEngine
import com.voicecomposer.model.ArrangementStyle
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.abs
import org.junit.Assert.assertTrue
import org.junit.Assume
import org.junit.Test

class OrchestraTest {
    private val path = "/home/claude/mrbumpy409/generaluser-gs/GeneralUser-GS.sf2"
    private val outDir = File("/tmp/claude-0/-home-claude/c53a6261-cbe6-5972-a229-ddc506574812/scratchpad/demo").also { it.mkdirs() }
    private fun load(): SoundFont? {
        val f = File(path); if (!f.exists()) return null
        val ch = RandomAccessFile(f, "r").channel
        return SoundFont(ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()))
    }

    private fun wav(b: StereoBuffer, f: File) {
        val pcm = b.toPcm16Interleaved()
        val bb = ByteBuffer.allocate(44 + pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()).putInt(36 + pcm.size * 2).put("WAVEfmt ".toByteArray()).putInt(16).putShort(1).putShort(2)
            .putInt(b.sampleRate).putInt(b.sampleRate * 4).putShort(4).putShort(16).put("data".toByteArray()).putInt(pcm.size * 2)
        for (s in pcm) bb.putShort(s)
        f.writeBytes(bb.array())
    }

    private val src by lazy {
        DefaultTranscriptionEngine().analyze(SyntheticVoice.render(SyntheticVoice.melody(SyntheticVoice.ODE_TO_JOY, 100.0)), AnalysisConfig()).transcription
    }

    private fun check(name: String, b: StereoBuffer) {
        var peak = 0f; var nan = 0; var e = 0.0
        for (i in 0 until b.frames) {
            val a = b.left[i]; val c = b.right[i]
            if (a.isNaN() || c.isNaN() || a.isInfinite() || c.isInfinite()) nan++ else { peak = maxOf(peak, abs(a), abs(c)); e += a * a + c * c }
        }
        println("$name: ${"%.1f".format(b.durationSec)}s peak=${"%.3f".format(peak)} rms=${"%.4f".format(Math.sqrt(e / (2.0 * b.frames)))} nan=$nan")
        assertTrue(nan == 0); assertTrue(peak <= 0.9f); assertTrue(peak > 0.05f)
    }

    @Test fun renderStyles() {
        val sf = load(); Assume.assumeNotNull(sf); sf!!
        val eng = SoundEngine(sf)
        val bpm = src.timeSignature.beatsPerMeasure
        for (style in ArrangementStyle.entries) for (level in intArrayOf(1, 3)) {
            val a = HarmonicArrangementEngine().arrange(src, style, level, 1)
            val t0 = System.nanoTime()
            val buf = eng.render(a.tracks, src.tempoMap, bpm)
            val ms = (System.nanoTime() - t0) / 1_000_000
            check("$style/$level (${a.tracks.joinToString { it.instrument.name }}) in ${ms}ms", buf)
            wav(buf, File(outDir, "${style.name.lowercase()}_$level.wav"))
        }
        // The previous additive synthesizer on the same piece, for an A/B listening comparison.
        run {
            val old = HarmonicArrangementEngine().arrange(src, ArrangementStyle.POP, 2, 1, Instrument.LEAD)
            val m = com.voicecomposer.engine.synth.Synth.render(old.tracks, src.tempoMap, minLengthSec = 1.0)
            wav(StereoBuffer(m, m.copyOf(), 44100), File(outDir, "ancien_synthe.wav"))
        }
        // Moving a fader re-mixes from the cached stems.
        val a = HarmonicArrangementEngine().arrange(src, ArrangementStyle.ORCHESTRAL, 3, 1)
        val t1 = System.nanoTime(); eng.render(a.tracks, src.tempoMap, bpm); val first = (System.nanoTime() - t1) / 1_000_000
        val t2 = System.nanoTime(); eng.render(a.tracks.map { it.copy(volume = it.volume * 0.5f) }, src.tempoMap, bpm); val second = (System.nanoTime() - t2) / 1_000_000
        println("cached render ${first}ms, after a volume change ${second}ms")
    }

    @Test fun soloMelodiesInEveryInstrument() {
        val sf = load(); Assume.assumeNotNull(sf); sf!!
        val eng = SoundEngine(sf)
        val bpm = src.timeSignature.beatsPerMeasure
        for (inst in Instrument.entries) {
            if (!eng.supports(inst)) { println("unsupported $inst"); continue }
            val t = Track("m", "m", inst, TrackRole.MELODY, src.notes)
            val buf = eng.render(listOf(t), src.tempoMap, bpm)
            check("solo ${inst.name}", buf)
            if (inst in listOf(Instrument.VIOLIN, Instrument.FLUTE, Instrument.PIANO, Instrument.CELLO, Instrument.CLARINET)) wav(buf, File(outDir, "solo_${inst.name.lowercase()}.wav"))
        }
    }

    @Test fun roundTripEveryMelodyInstrument() {
        val sf = load(); Assume.assumeNotNull(sf); sf!!
        val eng = SoundEngine(sf)
        val bpm = src.timeSignature.beatsPerMeasure
        val ref = src.notes.filter { it.isNote }
        for (inst in listOf(Instrument.VIOLIN, Instrument.FLUTE, Instrument.OBOE, Instrument.CLARINET, Instrument.CELLO, Instrument.TRUMPET, Instrument.FRENCH_HORN, Instrument.PIANO, Instrument.NYLON_GUITAR, Instrument.ACOUSTIC_GUITAR, Instrument.CHOIR, Instrument.VIOLA, Instrument.HARP)) {
            val buf = eng.render(listOf(Track("m", "m", inst, TrackRole.MELODY, src.notes)), src.tempoMap, bpm)
            val back = DefaultTranscriptionEngine().analyze(
                com.voicecomposer.engine.io.AudioBuffer(buf.toMono(), buf.sampleRate), AnalysisConfig(),
            ).transcription.notes.filter { it.isNote }
            var matched = 0
            for (n in ref) if (back.any { it.midiPitch == n.midiPitch && abs(it.startSec - n.startSec) < 0.12 }) matched++
            println("round trip ${inst.name}: ${back.size} notes back for ${ref.size}, matched pitch+onset ${matched}/${ref.size}")
            if (inst in listOf(Instrument.CELLO, Instrument.OBOE, Instrument.CLARINET, Instrument.TRUMPET, Instrument.VIOLA, Instrument.FRENCH_HORN, Instrument.FLUTE))
                assertTrue("${inst.name} melody not recovered", matched >= ref.size * 0.9)
        }
    }
}
