package com.voicecomposer.engine.sound

import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.PI
import org.junit.Assert.assertTrue
import org.junit.Test

class EffectsTest {
    private val sr = 44100

    /** Reverse-integrated energy decay (Schroeder): time for -5 dB to -35 dB, doubled = RT60. */
    private fun rt60(x: FloatArray): Double {
        val e = DoubleArray(x.size)
        var acc = 0.0
        for (i in x.indices.reversed()) { acc += x[i].toDouble() * x[i]; e[i] = acc }
        val tot = e[0]
        fun at(db: Double): Int { for (i in e.indices) if (10 * log10(e[i] / tot) <= db) return i; return e.size - 1 }
        return (at(-35.0) - at(-5.0)).toDouble() / sr * 2
    }

    @Test fun reverbDecaysAtRequestedRt60() {
        for (target in doubleArrayOf(1.2, 2.0, 3.5)) {
            val n = (target * 2.5 * sr).toInt() + sr
            val inL = FloatArray(n); val inR = FloatArray(n); inL[0] = 1f; inR[0] = 1f
            val oL = FloatArray(n); val oR = FloatArray(n)
            StereoReverb(sr, ReverbParams(rt60 = target, damping = 0.2)).process(inL, inR, oL, oR)
            val m = rt60(oL)
            var nan = 0; for (v in oL + oR) if (v.isNaN() || v.isInfinite()) nan++
            println("reverb target ${target}s measured ${"%.2f".format(m)}s (R: ${"%.2f".format(rt60(oR))}s) nan=$nan")
            assertTrue(nan == 0)
            assertTrue("rt60 $m vs $target", m in target * 0.55..target * 1.35)
            // Left and right must differ (stereo decorrelation).
            var diff = 0.0; for (i in 0 until n step 7) diff += abs(oL[i] - oR[i])
            assertTrue(diff > 0)
        }
    }

    @Test fun reverbIsStableOnLongNoise() {
        val n = 20 * sr
        val rnd = java.util.Random(3)
        val inL = FloatArray(n) { rnd.nextGaussian().toFloat() * 0.3f }; val inR = FloatArray(n) { rnd.nextGaussian().toFloat() * 0.3f }
        val oL = FloatArray(n); val oR = FloatArray(n)
        StereoReverb(sr, ReverbParams(rt60 = 4.0)).process(inL, inR, oL, oR)
        var peak = 0f; for (v in oL) peak = maxOf(peak, abs(v))
        println("reverb noise peak $peak")
        assertTrue(peak < 5f && !peak.isNaN())
    }

    @Test fun masterReachesTargetAndNeverClips() {
        for (amp in floatArrayOf(0.02f, 0.3f, 1.8f)) {
            val n = 6 * sr
            val l = FloatArray(n) { amp * sin(2 * PI * 220 * it / sr).toFloat() * (if (it / sr % 2 == 0) 1f else 0.4f) }
            val r = l.copyOf()
            r[1000] = amp * 3f // a transient well above everything
            MasterBus.process(l, r, sr)
            var peak = 0f; for (v in l + r) peak = maxOf(peak, abs(v))
            println("master amp $amp -> peak ${"%.3f".format(peak)} (${"%.1f".format(20 * log10(peak.toDouble()))} dBFS)")
            assertTrue(peak <= 0.8914f + 1e-4f)
            assertTrue(peak > 0.1f)
        }
    }

    @Test fun ensembleKeepsEnergyAndIsFinite() {
        val n = 3 * sr
        val l = FloatArray(n) { 0.3f * sin(2 * PI * 330 * it / sr).toFloat() }; val r = l.copyOf()
        var e0 = 0.0; for (v in l) e0 += v * v
        Ensemble(sr).process(l, r, 1f)
        var e1 = 0.0; for (v in l) e1 += v * v
        println("ensemble energy ratio ${"%.2f".format(e1 / e0)}")
        assertTrue(e1 / e0 in 0.3..2.0)
        var diff = 0.0; for (i in 0 until n) diff += abs(l[i] - r[i])
        assertTrue(diff > 1.0)
    }
}
