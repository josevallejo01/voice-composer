package com.voicecomposer.engine

import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.model.Pitch
import java.util.Random
import kotlin.math.PI
import kotlin.math.sin

/** Test-only generator of voice-like signals: harmonic tones with vibrato, envelopes, noise and repeated-note gaps. */
object SyntheticVoice {
    data class N(
        val midi: Double,
        val start: Double,
        val dur: Double,
        /** Silence at the end of the note, in seconds (consonant / breath). */
        val gapAfter: Double = 0.0,
        /** Amplitude dip at the end of the note instead of a silent gap (legato re-attack). */
        val dip: Boolean = false,
    )

    fun render(
        notes: List<N>,
        sampleRate: Int = 44100,
        harmonics: DoubleArray = doubleArrayOf(1.0, 0.5, 0.3, 0.15, 0.08),
        vibratoCents: Double = 0.0,
        vibratoHz: Double = 5.5,
        noise: Double = 0.0,
        tailSec: Double = 0.4,
        seed: Long = 1,
        detuneCents: Double = 0.0,
    ): AudioBuffer {
        val total = (notes.maxOf { it.start + it.dur } + tailSec)
        val x = FloatArray((total * sampleRate).toInt())
        val rnd = Random(seed)
        for (n in notes) {
            val s0 = (n.start * sampleRate).toInt()
            val len = (n.dur * sampleRate).toInt()
            var phase = 0.0
            for (i in 0 until len) {
                val idx = s0 + i
                if (idx >= x.size) break
                val t = i.toDouble() / sampleRate
                val vib = if (vibratoCents > 0) vibratoCents / 100.0 * sin(2 * PI * vibratoHz * t) else 0.0
                val f = Pitch.midiToHz(n.midi + vib + detuneCents / 100.0)
                phase += 2 * PI * f / sampleRate
                var v = 0.0
                for (h in harmonics.indices) {
                    if (f * (h + 1) < sampleRate / 2.2) v += harmonics[h] * sin(phase * (h + 1))
                }
                val att = minOf(1.0, t / 0.02)
                val remain = n.dur - t
                var rel = minOf(1.0, remain / 0.02)
                var amp = 0.5 * att * rel
                if (n.dip) {
                    // Dip to ~15% of the level over the last 70 ms of the note.
                    val d = (t - (n.dur - 0.07)) / 0.07
                    if (d > 0) amp *= 1.0 - 0.85 * sin(PI * d.coerceAtMost(1.0) / 2) * 1.0
                }
                x[idx] += (v * amp / harmonics.sum()).toFloat()
            }
        }
        if (noise > 0) for (i in x.indices) x[i] += (rnd.nextGaussian() * noise).toFloat()
        return AudioBuffer(x, sampleRate)
    }

    /** Builds a melody from (midi, beats) pairs at a given tempo. Rests are encoded with midi < 0. */
    fun melody(spec: List<Pair<Int, Double>>, bpm: Double, startSec: Double = 0.3, gap: Double = 0.04, jitterSec: Double = 0.0, seed: Long = 7): List<N> {
        val rnd = Random(seed)
        val beat = 60.0 / bpm
        var t = startSec
        val out = ArrayList<N>()
        for ((m, beats) in spec) {
            val d = beats * beat
            if (m >= 0) {
                val j = if (jitterSec > 0) rnd.nextGaussian() * jitterSec else 0.0
                out.add(N(m.toDouble(), t + j, d - gap, gapAfter = gap))
            }
            t += d
        }
        return out
    }

    /** Tempo ramps linearly from [from] to [to] BPM over the whole melody. */
    fun rampedMelody(spec: List<Pair<Int, Double>>, from: Double, to: Double, startSec: Double = 0.3, gap: Double = 0.04): List<N> {
        val totalBeats = spec.sumOf { it.second }
        var t = startSec
        var b = 0.0
        val out = ArrayList<N>()
        for ((m, beats) in spec) {
            val bpmHere = from + (to - from) * (b + beats / 2) / totalBeats
            val d = beats * 60.0 / bpmHere
            if (m >= 0) out.add(N(m.toDouble(), t, d - gap, gapAfter = gap))
            t += d
            b += beats
        }
        return out
    }

    val ODE_TO_JOY: List<Pair<Int, Double>> = run {
        // E E F G | G F E D | C C D E | E. D D(2) in C major, quarter notes at the beat.
        val m = intArrayOf(64, 64, 65, 67, 67, 65, 64, 62, 60, 60, 62, 64, 64, 62, 62)
        val d = doubleArrayOf(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.5, 0.5, 2.0)
        m.indices.map { m[it] to d[it] } + listOf(64 to 1.0, 64 to 1.0, 65 to 1.0, 67 to 1.0, 67 to 1.0, 65 to 1.0, 64 to 1.0, 62 to 1.0, 60 to 1.0, 60 to 1.0, 62 to 1.0, 64 to 1.0, 62 to 1.5, 60 to 0.5, 60 to 2.0)
    }
}
