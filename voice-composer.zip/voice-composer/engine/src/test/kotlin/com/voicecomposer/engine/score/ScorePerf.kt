package com.voicecomposer.engine.score

import com.voicecomposer.engine.segmentation.DetectedNote
import com.voicecomposer.model.Json
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TempoPoint
import com.voicecomposer.model.TimeSignature
import java.io.File
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class TNote(val midi: Int, val start: Double, val dur: Double, val step: Char, val alter: Int)
class Tune(val id: String, val num: Int, val den: Int, val fifths: Int, val minor: Boolean, val tonic: Int, val pickup: Double, val tuplets: Boolean, val notes: List<TNote>) {
    val barQ: Double get() = num * 4.0 / den
    val simpleMeter: TimeSignature? get() = BarModel.METERS.firstOrNull { it.numerator == num && it.denominator == den }

    companion object {
        @Suppress("UNCHECKED_CAST")
        fun load(f: File): List<Tune> = f.readLines().filter { it.isNotBlank() }.map { line ->
            val m = Json.parse(line) as Map<String, Any?>
            val notes = (m["notes"] as List<List<Any?>>).map { TNote((it[0] as Number).toInt(), (it[1] as Number).toDouble(), (it[2] as Number).toDouble(), (it[3] as String)[0], (it[4] as Number).toInt()) }
            Tune(m["id"] as String, (m["num"] as Number).toInt(), (m["den"] as Number).toInt(), (m["fifths"] as Number).toInt(), m["minor"] as Boolean, (m["tonic"] as Number).toInt(),
                (m["pickup"] as Number).toDouble(), m["tuplets"] as Boolean, notes)
        }
    }
}

/** A performed note (what the note detector would hand over) with its notated truth, when it has one. */
class PNote(
    val startSec: Double, val endSec: Double, val midi: Int,
    /** Index of the notated note this is (start side), or -1 for spurious/split-off notes. */
    val truthIdx: Int,
    /** Truth start slot (sixteenths, app coordinates: beat 0 = start of the first measure); -1 when unknown. */
    val slot: Int,
    /** Truth written length in slots; -1 when the performed note is not exactly one notated note. */
    val durSlots: Int,
    val alter: Int,
    /** Notated pitch equals the performed one. */
    val pitchOk: Boolean,
)

class Perf(
    val tune: Tune, val meter: TimeSignature, val bpmAvg: Double,
    val notes: List<PNote>,
    /** Truth tempo map in app coordinates. */
    val map: TempoMap,
    /** Beats from the start of the first measure to the first note (pick-up length complement). */
    val firstBeat: Double,
    val onGrid: Boolean,
    val key: Triple<Int, Boolean, Int>, // tonic, minor, fifths
) {
    fun detected(): List<DetectedNote> = notes.map { DetectedNote(it.startSec, it.endSec, it.midi, it.midi.toDouble(), 0.9, 0.9, -20.0) }
}

/** Plays notated melodies back the way people do: tempo choice, drift, timing noise, articulation, detector errors. */
object PerformanceSim {
    class Level(
        val onsetSigmaMs: ClosedFloatingPointRange<Double>, val driftStrong: Double, val driftMax: Double, val rubato: Double,
        val artifact: Double,
    )
    val NORMAL = Level(15.0..45.0, 0.20, 0.20, 0.04, 1.0)
    val HARD = Level(40.0..80.0, 0.50, 0.30, 0.07, 2.0)

    fun perform(tune: Tune, rnd: Random, lv: Level): Perf? {
        val ts = tune.simpleMeter
        val bar = tune.barQ
        val barsAll = ((tune.notes.last().start + tune.notes.last().dur) / bar).toInt() + 1
        val nBars = 5 + rnd.nextInt(10)
        val phase0 = if (tune.pickup > 0) tune.pickup else 0.0
        // excerpt: bars [k0, k0+nBars) counted from the first barline
        val k0 = if (rnd.nextInt(4) == 0) 0 else rnd.nextInt(max(1, barsAll - nBars))
        val b0 = phase0 + k0 * bar
        val pickup = when {
            k0 == 0 && tune.pickup > 0 && rnd.nextInt(3) != 0 -> tune.pickup          // the tune's own anacrusis
            rnd.nextInt(2) == 0 -> 0.0
            else -> 0.5 * (1 + rnd.nextInt((bar * 2).toInt() - 1))                       // a pick-up of 0.5 .. bar-0.5 beats
        }
        val e0 = b0 - pickup
        val e1 = b0 + nBars * bar
        val src = tune.notes.withIndex().filter { it.value.start >= e0 - 1e-6 && it.value.start < e1 }
        if (src.size < 8) return null
        // app coordinates: beat 0 = start of the first measure
        val shift = if (pickup > 0) bar - pickup else 0.0
        fun appBeat(q: Double) = q - e0 + shift
        val onGrid = src.all { val s = appBeat(it.value.start) * 4; val d = it.value.dur * 4; Math.abs(s - Math.round(s)) < 1e-6 && Math.abs(d - Math.round(d)) < 1e-6 }

        // tempo
        val felt = Math.exp(ln(55.0) + rnd.nextDouble() * (ln(135.0) - ln(55.0)))
        if (ts == null) return null
        val bpm0 = if (ts == TimeSignature.SIX_EIGHT) felt * 1.5 else felt
        val totalBeats = appBeat(e1 - 0.0) + 2
        val strong = rnd.nextDouble() < lv.driftStrong
        val mild = !strong && rnd.nextDouble() < 0.3
        val a = if (strong) (rnd.nextDouble() * 2 - 1) * lv.driftMax else if (mild) (rnd.nextDouble() * 2 - 1) * 0.06 else 0.0
        val r = if (strong) rnd.nextDouble() * lv.rubato else if (mild) rnd.nextDouble() * 0.015 else 0.0
        val period = 6 + rnd.nextDouble() * 14; val ph = rnd.nextDouble() * 6.28
        fun bpmAt(x: Double) = bpm0 * exp(a * (x / totalBeats - 0.5) + r * sin(2 * PI * x / period + ph))
        // time of every 1/16 beat by integration
        val step = 0.05
        val n = (totalBeats / step).toInt() + 2
        val times = DoubleArray(n)
        val t0 = 0.3 + rnd.nextDouble() * 1.2
        times[0] = t0 - shift * 60.0 / bpm0 * 0.0
        for (i in 1 until n) times[i] = times[i - 1] + step * 60.0 / bpmAt((i - 0.5) * step)
        fun timeOf(beat: Double): Double { val x = beat / step; val i = x.toInt().coerceIn(0, n - 2); return times[i] + (times[i + 1] - times[i]) * (x - i) }
        val pts = ArrayList<TempoPoint>()
        var b = 0.0
        while (b < totalBeats - 1) { pts.add(TempoPoint(b, timeOf(b))); b += 1.0 }
        val map = TempoMap(pts, bpmAt(totalBeats))
        val firstBeat = appBeat(src.first().value.start)
        val lastBeat = appBeat(src.last().value.start)
        val bpmAvg = 60.0 * (lastBeat - firstBeat) / (timeOf(lastBeat) - timeOf(firstBeat))

        // timing and articulation
        val sig = (lv.onsetSigmaMs.start + rnd.nextDouble() * (lv.onsetSigmaMs.endInclusive - lv.onsetSigmaMs.start)) / 1000.0
        val art = if (rnd.nextInt(10) < 3) 0.93 + 0.07 * rnd.nextDouble() else 0.6 + 0.35 * rnd.nextDouble()
        var e = 0.0
        val out = ArrayList<PNote>()
        val ap = lv.artifact
        for ((k, iv) in src.withIndex()) {
            val tn = iv.value
            e = 0.4 * e + rnd.nextGaussian() * sig
            val sBeat = appBeat(tn.start)
            var onset = timeOf(sBeat) + e
            // occasional agogic stretch of a note
            val agogic = if (rnd.nextDouble() < 0.05) (rnd.nextDouble() - 0.4) * 0.15 else 0.0
            val endBeat = sBeat + tn.dur * art + agogic
            var end = timeOf(endBeat) + rnd.nextGaussian() * 0.02
            val next = src.getOrNull(k + 1)
            if (next != null) end = min(end, timeOf(appBeat(next.value.start)) + (e * 0.5) - 0.025)
            if (end < onset + 0.07) end = onset + 0.07
            val slot = Math.round(sBeat * 4).toInt()
            val dSlots = Math.round(tn.dur * 4).toInt()
            out.add(PNote(onset, end, tn.midi, iv.index, slot, dSlots, tn.alter, true))
        }
        // detector artifacts
        val final = ArrayList<PNote>()
        var skip = false
        for ((i, p) in out.withIndex()) {
            if (skip) { skip = false; continue }
            val u = rnd.nextDouble()
            val prev = final.lastOrNull()
            when {
                u < 0.03 * ap -> continue                                          // missed note
                u < 0.06 * ap && i + 1 < out.size && out[i + 1].midi == p.midi -> { // repeated pitch merged into one note
                    final.add(PNote(p.startSec, out[i + 1].endSec, p.midi, p.truthIdx, p.slot, -1, p.alter, true)); skip = true
                }
                u < 0.09 * ap && p.endSec - p.startSec > 0.3 -> {                  // long note split in two
                    val mid = p.startSec + (p.endSec - p.startSec) * (0.35 + 0.3 * rnd.nextDouble())
                    final.add(PNote(p.startSec, mid - 0.02, p.midi, p.truthIdx, p.slot, -1, p.alter, true))
                    final.add(PNote(mid, p.endSec, p.midi, -1, -1, -1, p.alter, true))
                }
                u < 0.10 * ap -> {                                                  // pitch error
                    val m = p.midi + if (rnd.nextInt(5) == 0) (if (rnd.nextBoolean()) 12 else -12) else (if (rnd.nextBoolean()) 1 else -1)
                    final.add(PNote(p.startSec, p.endSec, m, p.truthIdx, p.slot, p.durSlots, p.alter, false))
                }
                else -> final.add(p)
            }
            if (rnd.nextDouble() < 0.02 * ap) {                                    // spurious short note
                val s = p.startSec + (p.endSec - p.startSec) * rnd.nextDouble()
                final.add(PNote(s, s + 0.06 + 0.09 * rnd.nextDouble(), p.midi + rnd.nextInt(15) - 7, -1, -1, -1, 0, false))
            }
            @Suppress("UNUSED_VARIABLE") val unused = prev
        }
        final.sortBy { it.startSec }
        if (final.size < 6) return null
        // the 'whole' flag for durations: only unmodified notes keep durSlots (merged/split set -1 above)
        val ks = Triple(tune.tonic, tune.minor, tune.fifths)
        return Perf(tune, ts, bpmAvg, final, map, firstBeat, onGrid, ks)
    }
}
