package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.io.WavIO
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.score.ScoreModels
import com.voicecomposer.engine.segmentation.DetectedNote
import java.io.File
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Tools that work on REAL recordings with reference notes (humming and singing corpora such as HumTrans, vocadito):
 * they turn them into training rows for the learned note decisions and measure how well the whole detector does.
 *
 * A manifest is a TSV, one clip per line:   id <TAB> wav <TAB> notes <TAB> type <TAB> split <TAB> group
 *   wav    16-bit PCM WAV (the preparation script converts whatever the corpus ships)
 *   notes  text file, one reference note per line: onset_sec,offset_sec,midi
 *   type   HUMMING | SINGING | WHISTLING
 *   split  train | val | test      group  singer / song id (a group never spans two splits)
 *
 * Reference pitches of humming corpora are the intended notes, often an octave away from what the person hummed, so
 * every clip is compared at the octave shift (-3..+3) that explains it best, as the HumTrans benchmark does.
 *
 *   RealTools fake <dir> <clips>                       writes a fake corpus in this format (plumbing tests)
 *   RealTools gen <manifest> <out.csv> <split> [max]   rows for the note forest (same columns as DataGen)
 *   RealTools genmerge <manifest> <out.csv> <split> <note_rf.json> [max]
 *   RealTools eval <manifest> <split> <scoreDir|-> <max|0> <name=noteForest|-:merger|-> ...
 *       one pass over the clips (the network runs once per clip) scores every named model combination; JSON on stdout
 */
object RealTools {
    class Gt(val start: Double, val end: Double, val midi: Double)
    class Clip(val id: String, val wav: File, val notes: File, val type: InputType, val split: String, val group: String) {
        fun gt(): List<Gt> = notes.readLines().mapNotNull { l ->
            val p = l.trim().split(',', '\t', ' ').filter { it.isNotEmpty() }
            if (p.size < 3) null else runCatching { Gt(p[0].toDouble(), p[1].toDouble(), p[2].toDouble()) }.getOrNull()
        }.filter { it.end > it.start }.sortedBy { it.start }
    }

    fun readManifest(f: File, split: String?): List<Clip> = f.readLines().filter { it.isNotBlank() && !it.startsWith("#") }.mapNotNull { l ->
        val p = l.split('\t')
        if (p.size < 6) return@mapNotNull null
        val t = runCatching { InputType.valueOf(p[3]) }.getOrNull() ?: return@mapNotNull null
        if (split != null && p[4] != split) return@mapNotNull null
        Clip(p[0], File(p[1]), File(p[2]), t, p[4], p[5])
    }

    /** Octave shift (in octaves, -3..3) of the reference that makes most detected onsets agree in pitch; 0 on ties. */
    fun bestShift(starts: List<Double>, midis: List<Int>, gt: List<Gt>, tol: Double = 0.15): Int {
        var best = 0; var bestN = -1
        for (o in intArrayOf(0, -1, 1, -2, 2, -3, 3)) {
            var n = 0
            for (i in starts.indices) if (gt.any { abs(it.start - starts[i]) <= tol && Math.round(it.midi).toInt() + 12 * o == midis[i] }) n++
            if (n > bestN) { bestN = n; best = o }
        }
        return best
    }

    @JvmStatic
    fun main(args: Array<String>) {
        when (args[0]) {
            "fake" -> fake(File(args[1]), args[2].toInt())
            "gen" -> gen(readManifest(File(args[1]), args[3]).take(args.getOrNull(4)?.toInt() ?: Int.MAX_VALUE), File(args[2]))
            "genmerge" -> genMerge(readManifest(File(args[1]), args[3]).take(args.getOrNull(5)?.toInt() ?: Int.MAX_VALUE), File(args[2]), File(args[4]))
            "eval" -> {
                val max = args[4].toInt().let { if (it <= 0) Int.MAX_VALUE else it }
                val score = args[3].takeIf { it != "-" }?.let { dir -> ScoreModels.load { n -> File(dir, n).takeIf { it.exists() }?.readText() } }
                val combos = args.drop(5).map { spec ->
                    val name = spec.substringBefore('='); val (f, m) = spec.substringAfter('=').split(':')
                    Combo(name, f.takeIf { it != "-" }?.let { RandomForest.fromJson(File(it).readText()) }, m.takeIf { it != "-" }?.let { RandomForest.fromJson(File(it).readText()) })
                }
                eval(readManifest(File(args[1]), args[2]).take(max), score, combos)
            }
            else -> error("unknown mode ${args[0]}")
        }
    }

    // ---------------------------------------------------------------------------------------------- fake corpus

    private fun fake(dir: File, n: Int) {
        dir.mkdirs()
        val sb = StringBuilder()
        for (i in 0 until n) {
            val rnd = Random(i * 31L + 5)
            val type = if (rnd.nextInt(3) == 0) InputType.SINGING else InputType.HUMMING
            val split = when (i % 10) { 8 -> "val"; 9 -> "test"; else -> "train" }
            val clip = DataGen.makeClip(type, rnd, "train", wobble = true)
            if (clip.truth.isEmpty()) continue
            val wav = File(dir, "c$i.wav"); WavIO.write(wav, clip.audio.samples, clip.audio.sampleRate)
            val nf = File(dir, "c$i.notes.txt")
            // Like a score: pitches an octave down for some humming clips.
            val shift = if (type == InputType.HUMMING && rnd.nextBoolean()) 12 else 0
            nf.writeText(clip.truth.joinToString("\n") { "%.3f,%.3f,%.1f".format(it.start, it.start + it.dur, it.midi + shift) })
            sb.append("c$i\t${wav.path}\t${nf.path}\t${type.name}\t$split\tg${i / 3}\n")
        }
        File(dir, "manifest.tsv").writeText(sb.toString())
    }

    // ---------------------------------------------------------------------------------------------- rows

    private fun withEngine(block: (MlTranscriptionEngine, PythonOnnxModel) -> Unit) {
        val model = PythonOnnxModel.create() ?: error("model/onnxruntime not available")
        try { block(MlTranscriptionEngine(model), model) } finally { model.close() }
    }

    private fun gen(clips: List<Clip>, out: File) {
        out.delete()
        val sb = StringBuilder("clip,split,type,tags,snr,label,ruleKeep,start,midi,${NoteFeatures.NAMES.joinToString(",")}\n")
        withEngine { engine, _ ->
            for ((i, c) in clips.withIndex()) {
                val gt = c.gt(); if (gt.isEmpty()) continue
                val cfg = AnalysisConfig(inputType = c.type)
                val prep = try { engine.prepare(WavIO.read(c.wav), cfg) } catch (e: Throwable) { System.err.println("${c.id}: $e"); continue }
                val cands = engine.candidates(prep, cfg)
                val shift = bestShift(cands.map { it.note.startSec }, cands.map { it.note.midi }, gt)
                for (cd in cands) {
                    var label = 0
                    for (t in gt) {
                        val ov = min(cd.note.endSec, t.end) - max(cd.note.startSec, t.start)
                        if (cd.note.midi == Math.round(t.midi).toInt() + 12 * shift && ov >= 0.5 * (cd.note.endSec - cd.note.startSec)) label = 1
                    }
                    sb.append("${c.id},${c.split},${c.type.name},real,0.0,$label,${if (cd.keepByRules) 1 else 0},${"%.3f".format(cd.note.startSec)},${cd.note.midi}")
                    for (v in cd.features) sb.append(',').append("%.5f".format(v))
                    sb.append('\n')
                }
                if (i % 20 == 19) { out.appendText(sb.toString()); sb.setLength(0); System.err.println("gen ${i + 1}/${clips.size}") }
            }
        }
        out.appendText(sb.toString())
    }

    private fun genMerge(clips: List<Clip>, out: File, forestFile: File) {
        out.delete()
        val forest = RandomForest.fromJson(forestFile.readText())
        val sb = StringBuilder("clip,split,type,tags,snr,label,start,midi,${NoteMerger.NAMES.joinToString(",")}\n")
        val model = PythonOnnxModel.create() ?: error("model/onnxruntime not available")
        val engine = MlTranscriptionEngine(model, classifier = { forest })
        for ((i, c) in clips.withIndex()) {
            val gt = c.gt(); if (gt.isEmpty()) continue
            val cfg = AnalysisConfig(inputType = c.type)
            val prep = try { engine.prepare(WavIO.read(c.wav), cfg) } catch (e: Throwable) { System.err.println("${c.id}: $e"); continue }
            val kept = engine.detectKept(prep, cfg, DecoderParams.forInput(c.type))
            val shift = bestShift(kept.map { it.second.startSec }, kept.map { it.second.midi }, gt)
            fun inside(a: DetectedNote): Int {
                var best = -1; var bestOv = 0.0
                for ((k, t) in gt.withIndex()) {
                    if (a.midi != Math.round(t.midi).toInt() + 12 * shift) continue
                    val ov = min(a.endSec, t.end) - max(a.startSec, t.start)
                    if (ov > bestOv) { bestOv = ov; best = k }
                }
                return if (best >= 0 && bestOv >= 0.5 * (a.endSec - a.startSec)) best else -1
            }
            for ((idx, x) in NoteMerger.jointRows(kept, prep)) {
                val a = kept[idx].second; val b = kept[idx + 1].second
                val ta = inside(a); val tb = inside(b)
                sb.append("${c.id},${c.split},${c.type.name},real,0.0,${if (ta >= 0 && ta == tb) 1 else 0},${"%.3f".format(a.endSec)},${a.midi}")
                for (v in x) sb.append(',').append("%.5f".format(v))
                sb.append('\n')
            }
            if (i % 20 == 19) { out.appendText(sb.toString()); sb.setLength(0); System.err.println("genmerge ${i + 1}/${clips.size}") }
        }
        out.appendText(sb.toString())
        model.close()
    }

    // ---------------------------------------------------------------------------------------------- evaluation

    class Counts { var tp = 0; var est = 0; var ref = 0 }

    /** Note-onset matching: same pitch, onsets within [tol] seconds, one-to-one (closest onset first). */
    fun match(est: List<DetectedNote>, gt: List<Gt>, shift: Int, tol: Double): Int {
        val used = BooleanArray(gt.size)
        var tp = 0
        for (e in est) {
            var bi = -1; var bd = Double.MAX_VALUE
            for ((k, t) in gt.withIndex()) {
                if (used[k] || Math.round(t.midi).toInt() + 12 * shift != e.midi) continue
                val d = abs(t.start - e.startSec)
                if (d <= tol && d < bd) { bd = d; bi = k }
            }
            if (bi >= 0) { used[bi] = true; tp++ }
        }
        return tp
    }

    class Combo(val name: String, val forest: RandomForest?, val merger: RandomForest?)

    private fun eval(clips: List<Clip>, score: ScoreModels?, combos: List<Combo>) {
        val model = PythonOnnxModel.create() ?: error("model/onnxruntime not available")
        val prepper = MlTranscriptionEngine(model)
        val engines = combos.map { it to MlTranscriptionEngine(model, classifier = { _ -> it.forest }, merger = { _ -> it.merger }, scoreModels = { score }) }
        val keys = listOf("on50", "on100", "on50strict")
        // combo -> type -> key -> counts
        val acc = combos.associate { c -> c.name to HashMap<String, MutableMap<String, Counts>>() }
        val noteNum = HashMap<String, Int>(); var noteDen = 0
        for ((i, c) in clips.withIndex()) {
            val gt = c.gt(); if (gt.isEmpty()) continue
            val cfg = AnalysisConfig(inputType = c.type)
            val prep = try { prepper.prepare(WavIO.read(c.wav), cfg) } catch (e: Throwable) { System.err.println("${c.id}: $e"); null }
            noteDen += gt.size
            for ((combo, eng) in engines) {
                val est = if (prep == null) emptyList() else try { eng.detect(prep, cfg) } catch (e: Throwable) { System.err.println("${c.id}/${combo.name}: $e"); emptyList() }
                val shift = bestShift(est.map { it.startSec }, est.map { it.midi }, gt)
                val m = acc.getValue(combo.name).getOrPut(c.type.name) { keys.associateWith { Counts() }.toMutableMap() }
                for ((k, tol, sh) in listOf(Triple("on50", 0.05, shift), Triple("on100", 0.10, shift), Triple("on50strict", 0.05, 0))) {
                    m.getValue(k).also { it.tp += match(est, gt, sh, tol); it.est += est.size; it.ref += gt.size }
                }
                noteNum[combo.name] = (noteNum[combo.name] ?: 0) + est.size
            }
            if (i % 20 == 19) System.err.println("eval ${i + 1}/${clips.size}")
        }
        model.close()
        fun f1(c: Counts): Triple<Double, Double, Double> {
            val p = if (c.est == 0) 0.0 else c.tp.toDouble() / c.est; val r = if (c.ref == 0) 0.0 else c.tp.toDouble() / c.ref
            return Triple(p, r, if (p + r == 0.0) 0.0 else 2 * p * r / (p + r))
        }
        val sb = StringBuilder("{\"clips\":${clips.size},\"refNotes\":$noteDen")
        for (combo in combos) {
            val byType = acc.getValue(combo.name)
            val all = keys.associateWith { Counts() }
            for (m in byType.values) for (k in keys) all.getValue(k).also { a -> m.getValue(k).let { a.tp += it.tp; a.est += it.est; a.ref += it.ref } }
            sb.append(",\"${combo.name}\":{\"noteRatio\":${"%.3f".format(if (noteDen == 0) 0.0 else (noteNum[combo.name] ?: 0).toDouble() / noteDen)}")
            fun block(name: String, m: Map<String, Counts>) {
                sb.append(",\"$name\":{")
                sb.append(keys.joinToString(",") { k -> val (p, r, f) = f1(m.getValue(k)); "\"$k\":{\"p\":${"%.4f".format(p)},\"r\":${"%.4f".format(r)},\"f1\":${"%.4f".format(f)}}" })
                sb.append("}")
            }
            block("all", all)
            for ((t, m) in byType.toSortedMap()) block(t, m)
            sb.append("}")
        }
        sb.append("}")
        println(sb)
    }
}
