package com.voicecomposer.engine.sound
import java.io.File
import java.io.RandomAccessFile
import java.nio.channels.FileChannel
import org.junit.Test
class ListPresetsTest {
    @Test fun list() {
        val f = File("/home/claude/mrbumpy409/generaluser-gs/GeneralUser-GS.sf2"); if (!f.exists()) return
        val ch = RandomAccessFile(f, "r").channel
        val sf = SoundFont(ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()))
        println(sf.presets.filter { it.bank == 0 }.sortedBy { it.program }.joinToString(" | ") { "${it.program}:${it.name}" })
        println("banks: " + sf.presets.map { it.bank }.distinct().sorted())
    }
}
