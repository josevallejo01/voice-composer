package com.voicecomposer.engine

import com.voicecomposer.engine.arrangement.HarmonicArrangementEngine
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.io.StreamingWavWriter
import com.voicecomposer.engine.io.WavIO
import com.voicecomposer.engine.pitch.OctaveCorrector
import com.voicecomposer.engine.pitch.YinPitchTracker
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.preprocessing.Preprocessor
import com.voicecomposer.engine.preprocessing.Resampler
import com.voicecomposer.engine.synth.Synth
import com.voicecomposer.engine.SyntheticVoice.N
import com.voicecomposer.model.ArrangementStyle
import com.voicecomposer.model.Mode
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.model.TimeSignature
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import com.voicecomposer.model.Instrument
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.math.abs
import kotlin.math.sin

private val engine = DefaultTranscriptionEngine()

private fun List<com.voicecomposer.model.MusicalEvent>.pitches() = filter { it.isNote }.map { it.midiPitch!! }

class IoAndDspTest {
    @Test fun wavRoundTrip() {
        val x = FloatArray(1000) { sin(it * 0.1f) * 0.5f }
        val back = WavIO.decode(WavIO.encodePcm16(x, 22050))
        assertEquals(22050, back.sampleRate)
        assertEquals(1000, back.samples.size)
        assertEquals(x[500].toDouble(), back.samples[500].toDouble(), 1e-3)
    }

    @Test fun streamingWriterProducesDecodableFileEvenWithoutClose() {
        val f = File.createTempFile("vcwav", ".wav")
        val w = StreamingWavWriter(f, 16000)
        val pcm = ShortArray(800) { (it * 10).toShort() }
        w.write(pcm, pcm.size)
        // not closed on purpose (killed recording): header still says 0 bytes
        val audio = WavIO.decode(f.readBytes())
        assertEquals(800, audio.samples.size)
        w.close()
        assertEquals(800, WavIO.read(f).samples.size)
        f.delete()
    }

    @Test fun resamplerKeepsFrequency() {
        val a = SyntheticVoice.render(listOf(N(57.0, 0.0, 1.0)), 48000)
        val r = Resampler.resample(a.samples, 48000, 16000)
        assertEquals((a.samples.size / 3).toDouble(), r.size.toDouble(), 2.0)
        val frames = YinPitchTracker(16000, InputType.SINGING).track(r).filter { it.voiced && it.timeSec in 0.2..0.8 }
        assertTrue(frames.isNotEmpty())
        for (f in frames) assertEquals(57.0, f.midi, 0.15)
    }

    @Test fun qualityDetection() {
        val quiet = FloatArray(16000) { 0.001f * sin(it * 0.05f) }
        assertTrue(Preprocessor.analyzeQuality(quiet, 16000).tooQuiet)
        val loud = FloatArray(16000) { if (it % 2 == 0) 1f else -1f }
        assertTrue(Preprocessor.analyzeQuality(loud, 16000).clipped)
    }

    @Test fun pitchTrackerIsAccurateAndOctaveSafe() {
        val notes = listOf(45, 52, 57, 60, 64, 69, 72, 76, 79).mapIndexed { i, m -> N(m.toDouble(), i * 0.6, 0.5) }
        val a = SyntheticVoice.render(notes, 16000, noise = 0.003)
        val x = Preprocessor.process(a.samples, 16000, InputType.SINGING)
        val frames = OctaveCorrector.correct(YinPitchTracker(16000, InputType.SINGING).track(x))
        var total = 0
        var wrongOctave = 0
        var wrong = 0
        for (n in notes) {
            for (f in frames) if (f.voiced && f.timeSec in (n.start + 0.12)..(n.start + n.dur - 0.12)) {
                total++
                val d = f.midi - n.midi
                if (abs(d) > 0.5) wrong++
                if (abs(abs(d) - 12) < 1) wrongOctave++
            }
        }
        assertTrue("frames=$total", total > 200)
        assertTrue("octave errors $wrongOctave/$total", wrongOctave.toDouble() / total < 0.03)
        assertTrue("wrong $wrong/$total", wrong.toDouble() / total < 0.05)
    }

    @Test fun whistleHighRegisterWithoutOctaveErrors() {
        val midis = listOf(84, 88, 91, 96, 100, 91, 84)
        val notes = midis.mapIndexed { i, m -> N(m.toDouble(), i * 0.5, 0.4) }
        val a = SyntheticVoice.render(notes, 48000, harmonics = doubleArrayOf(1.0))
        val res = engine.analyze(a, AnalysisConfig(InputType.WHISTLING))
        assertEquals(midis, res.transcription.events.pitches())
    }
}

class TranscriptionTest {
    private fun accuracy(expected: List<Pair<Int, Double>>, got: List<Int>): Double {
        val exp = expected.map { it.first }
        var hit = 0
        for (i in exp.indices) if (got.getOrNull(i) == exp[i]) hit++
        return hit.toDouble() / exp.size
    }

    @Test fun humSimpleMelodyAtKnownTempo() {
        val spec = SyntheticVoice.ODE_TO_JOY
        val notes = SyntheticVoice.melody(spec, 100.0)
        val res = engine.analyze(SyntheticVoice.render(notes, 48000, noise = 0.004), AnalysisConfig(InputType.HUMMING))
        val t = res.transcription
        assertEquals(spec.size, t.notes.size)
        assertEquals(1.0, accuracy(spec, t.events.pitches()), 0.0)
        assertEquals(100.0, t.tempoMap.averageBpm, 5.0)
        assertEquals(0, t.key.tonic)
        assertEquals(Mode.MAJOR, t.key.mode)
        // Onsets (real time) within 50 ms median
        val errs = t.notes.zip(notes).map { (e, n) -> abs(e.startSec - n.start) }.sorted()
        assertTrue("median onset error ${errs[errs.size / 2]}", errs[errs.size / 2] < 0.05)
        // Rhythm: first note at beat 0, each note on a quarter beat
        assertEquals(0.0, t.notes[0].startBeat, 0.26)
        assertEquals(1.0, t.notes[1].startBeat - t.notes[0].startBeat, 0.01)
        // Exact quantized rhythm of the tune: quarter notes then dotted quarter + eighth then half
        val d = t.notes.take(15).map { it.durationBeats }
        assertEquals(1.0, d[0], 0.01)
        assertEquals(1.5, d[12], 0.01)
        assertEquals(0.5, d[13], 0.01)
    }

    @Test fun tempoIsFoundAtSeveralSpeeds() {
        for (bpm in listOf(75.0, 90.0, 110.0, 130.0)) {
            val notes = SyntheticVoice.melody(SyntheticVoice.ODE_TO_JOY, bpm, jitterSec = 0.012)
            val res = engine.analyze(SyntheticVoice.render(notes, 44100), AnalysisConfig(InputType.SINGING))
            val got = res.transcription.tempoMap.averageBpm
            assertEquals("bpm $bpm", bpm, got, bpm * 0.05)
        }
    }

    @Test fun repeatedNotesStayDistinct() {
        val spec = listOf(60 to 1.0, 60 to 1.0, 60 to 1.0, 62 to 1.0, 62 to 1.0, 64 to 2.0)
        val gap = SyntheticVoice.melody(spec, 100.0, gap = 0.09)
        val r1 = engine.analyze(SyntheticVoice.render(gap), AnalysisConfig())
        assertEquals(listOf(60, 60, 60, 62, 62, 64), r1.transcription.events.pitches())
        // legato re-attack (no silence, energy dip only)
        val d = SyntheticVoice.melody(spec, 100.0, gap = 0.0).map { it.copy(dip = true) }
        val r2 = engine.analyze(SyntheticVoice.render(d), AnalysisConfig(InputType.HUMMING))
        assertEquals(listOf(60, 60, 60, 62, 62, 64), r2.transcription.events.pitches())
    }

    @Test fun vibratoNoteIsNotSplit() {
        val notes = listOf(N(64.0, 0.3, 2.0), N(67.0, 2.5, 1.5))
        val res = engine.analyze(SyntheticVoice.render(notes, vibratoCents = 40.0, noise = 0.003), AnalysisConfig(InputType.SINGING))
        assertEquals(listOf(64, 67), res.transcription.events.pitches())
    }

    @Test fun silencesBecomeRests() {
        val spec = listOf(60 to 1.0, 62 to 1.0, -1 to 2.0, 64 to 1.0, 65 to 1.0, 67 to 2.0)
        val notes = SyntheticVoice.melody(spec, 100.0)
        val t = engine.analyze(SyntheticVoice.render(notes), AnalysisConfig()).transcription
        val rest = t.events.first { it.isRest }
        assertEquals(2.0, rest.startBeat, 0.3)
        assertEquals(2.0, rest.durationBeats, 0.3)
        assertEquals(listOf(60, 62, 64, 65, 67), t.events.pitches())
    }

    @Test fun globalDetuningIsCompensated() {
        val notes = SyntheticVoice.melody(SyntheticVoice.ODE_TO_JOY, 100.0)
        val res = engine.analyze(SyntheticVoice.render(notes, detuneCents = -35.0), AnalysisConfig())
        assertEquals(1.0, accuracyOf(SyntheticVoice.ODE_TO_JOY, res), 0.0)
    }

    private fun accuracyOf(spec: List<Pair<Int, Double>>, r: AnalysisResult) = accuracy(spec, r.transcription.events.pitches())

    @Test fun tempoDriftIsTracked() {
        val spec = SyntheticVoice.ODE_TO_JOY + SyntheticVoice.ODE_TO_JOY
        val notes = SyntheticVoice.rampedMelody(spec, 85.0, 115.0)
        val t = engine.analyze(SyntheticVoice.render(notes), AnalysisConfig()).transcription
        assertEquals(spec.size, t.notes.size)
        assertTrue("tempo map should not be constant", !t.tempoMap.isConstant)
        val early = t.tempoMap.bpmAtBeat(2.0)
        val late = t.tempoMap.bpmAtBeat(t.totalBeats - 2.0)
        assertTrue("early=$early late=$late", late > early + 12)
        assertEquals(85.0, early, 12.0)
        assertEquals(115.0, late, 14.0)
        // Rhythm values stay musical despite the drift: all durations are multiples of an eighth
        assertTrue(t.notes.all { abs(it.durationBeats * 2 - Math.round(it.durationBeats * 2)) < 1e-6 })
    }

    @Test fun waltzIsRecognisedAsThreeFour() {
        // long note on beat 1 of every bar
        val bar = listOf(60 to 2.0, 64 to 1.0, 67 to 2.0, 64 to 1.0, 62 to 2.0, 59 to 1.0, 60 to 2.0, 55 to 1.0)
        val spec = bar + bar
        val notes = SyntheticVoice.melody(spec, 110.0)
        val t = engine.analyze(SyntheticVoice.render(notes), AnalysisConfig()).transcription
        assertEquals(TimeSignature.THREE_FOUR, t.timeSignature)
    }

    @Test fun marchIsFourFour() {
        val bar = listOf(60 to 2.0, 62 to 1.0, 64 to 1.0)
        val spec = bar + bar + bar + bar
        val notes = SyntheticVoice.melody(spec, 100.0)
        val t = engine.analyze(SyntheticVoice.render(notes), AnalysisConfig()).transcription
        assertEquals(TimeSignature.FOUR_FOUR, t.timeSignature)
    }

    @Test fun quantizationModes() {
        val notes = SyntheticVoice.melody(SyntheticVoice.ODE_TO_JOY, 100.0, jitterSec = 0.03, seed = 3)
        val audio = SyntheticVoice.render(notes)
        val auto = engine.analyze(audio, AnalysisConfig(quantization = QuantizationMode.AUTOMATIC)).transcription
        val free = engine.analyze(audio, AnalysisConfig(quantization = QuantizationMode.FREE)).transcription
        assertTrue(auto.notes.all { abs(it.startBeat * 4 - Math.round(it.startBeat * 4)) < 1e-6 })
        assertTrue(free.notes.any { abs(it.startBeat * 4 - Math.round(it.startBeat * 4)) > 0.02 })
    }

    @Test fun silenceAndTooQuietInputAreReportedNotInvented() {
        val silent = AudioBuffer(FloatArray(48000), 48000)
        val r = engine.analyze(silent, AnalysisConfig())
        assertTrue(r.transcription.notes.isEmpty())
        assertTrue(AnalysisWarning.NO_PITCH_FOUND in r.warnings)
        assertTrue(AnalysisWarning.TOO_QUIET in r.warnings)
        val noise = java.util.Random(3)
        val n = AudioBuffer(FloatArray(48000) { (noise.nextGaussian() * 0.05).toFloat() }, 48000)
        assertTrue(engine.analyze(n, AnalysisConfig()).transcription.notes.size <= 2)
    }

    @Test fun cancellationIsHonoured() {
        val a = SyntheticVoice.render(SyntheticVoice.melody(SyntheticVoice.ODE_TO_JOY, 100.0))
        try {
            engine.analyze(a, isCancelled = { true })
            org.junit.Assert.fail("expected cancellation")
        } catch (_: AnalysisCancelled) {
        }
    }

    @Test fun progressIsReported() {
        val stages = ArrayList<Stage>()
        engine.analyze(SyntheticVoice.render(SyntheticVoice.melody(SyntheticVoice.ODE_TO_JOY, 100.0)), onProgress = { s, _ -> stages.add(s) })
        assertEquals(Stage.DONE, stages.last())
        assertTrue(Stage.PITCH in stages && Stage.TEMPO in stages && Stage.KEY in stages)
    }

    @Test fun synthesisedTranscriptionIsTranscribedBackIdentically() {
        val spec = SyntheticVoice.ODE_TO_JOY
        val first = engine.analyze(SyntheticVoice.render(SyntheticVoice.melody(spec, 100.0)), AnalysisConfig()).transcription
        val pcm = Synth.render(listOf(Synth.melodyTrack(first.events)), first.tempoMap, Synth.SAMPLE_RATE)
        assertTrue(pcm.size > 44100)
        val second = engine.analyze(AudioBuffer(pcm, Synth.SAMPLE_RATE), AnalysisConfig(InputType.SINGING)).transcription
        assertEquals(first.events.pitches(), second.events.pitches())
    }
}

class ArrangementTest {
    private val src = engine.analyze(
        SyntheticVoice.render(SyntheticVoice.melody(SyntheticVoice.ODE_TO_JOY, 100.0)), AnalysisConfig(),
    ).transcription

    @Test fun progressionStartsAndEndsOnTonicAndSourceIsUntouched() {
        val before = src.copy()
        for (style in ArrangementStyle.values()) for (level in 1..3) {
            val a = HarmonicArrangementEngine().arrange(src, style, level, 1)
            assertEquals(src, before)
            assertEquals(0, a.chords.first().rootPitchClass)
            assertEquals(0, a.chords.last().rootPitchClass)
            assertTrue(a.chords.all { c -> c.startBeat >= 0 && c.durationBeats > 0 })
            val roles = a.tracks.map { it.role }
            assertTrue(TrackRole.HARMONY in roles && TrackRole.BASS in roles && TrackRole.MELODY in roles)
            // melody track is the unchanged source melody
            assertEquals(src.notes, a.tracks.first { it.role == TrackRole.MELODY }.events)
            assertTrue(a.tracks.first { it.role == TrackRole.BASS }.events.all { (it.midiPitch ?: 0) < 60 })
        }
    }

    @Test fun chordsExplainTheMelody() {
        val a = HarmonicArrangementEngine().arrange(src, ArrangementStyle.POP, 1, 1)
        // The tune spends its first bars on E/G/C tones: the harmony must be I or V, never the unrelated chords.
        val first = a.chords.first()
        assertTrue(first.rootPitchClass == 0 && !first.minor)
        assertTrue(a.chords.any { it.rootPitchClass == 7 })
    }

    @Test fun arrangementRendersAudio() {
        val a = HarmonicArrangementEngine().arrange(src, ArrangementStyle.FOLK, 2, 1)
        val pcm = Synth.render(a.tracks, src.tempoMap, minLengthSec = 1.0)
        assertTrue(pcm.any { abs(it) > 0.05f })
        assertTrue(pcm.all { abs(it) <= 1.0f })
        val onlyBass = Synth.render(a.tracks.map { it.copy(enabled = it.role == TrackRole.BASS) }, src.tempoMap)
        assertTrue(onlyBass.any { abs(it) > 0.01f })
        val none = Synth.render(a.tracks.map { it.copy(enabled = false) }, src.tempoMap, minLengthSec = 0.5)
        assertTrue(none.all { it == 0f })
        assertNotNull(Track("t", "x", Instrument.PIANO, TrackRole.OTHER, emptyList()))
        assertEquals(Pitch.pitchClass(60), 0)
    }
}
