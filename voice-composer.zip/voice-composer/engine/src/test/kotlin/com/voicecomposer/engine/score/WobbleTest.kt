package com.voicecomposer.engine.score

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.SyntheticVoice
import com.voicecomposer.engine.ml.MlTranscriptionEngine
import com.voicecomposer.engine.ml.PythonOnnxModel
import com.voicecomposer.engine.ml.RandomForest
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import kotlin.math.abs
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

/** A held note whose pitch and loudness wander a little must stay one note (and one long written value). */
class WobbleTest {
    private fun findUp(rel: String): File? {
        var d: File? = File("").absoluteFile
        while (d != null) { val f = File(d, rel); if (f.exists()) return f; d = d.parentFile }
        return null
    }

    @Test fun heldNotesStayWhole() {
        val net = PythonOnnxModel.create()
        val dir = findUp("app/src/main/assets")
        assumeTrue(net != null && dir != null)
        val forest = File(dir, "note_rf.json").takeIf { it.exists() }?.let { RandomForest.fromJson(it.readText()) }
        val models = ScoreModels.load { n -> File(dir, n).takeIf { it.exists() }?.readText() }.takeIf { it.complete }
        // Quarter and half notes at 80 BPM (0.75 s per beat): C E G | E C | G(2) | A G E C(2)
        val spec = listOf(60 to 1.0, 64 to 1.0, 67 to 2.0, 64 to 1.0, 60 to 1.0, 67 to 2.0, 69 to 1.0, 67 to 1.0, 64 to 1.0, 60 to 2.0)
        val truth = spec.size
        val merge = findUp("app/src/main/assets/note_merge.json")?.let { RandomForest.fromJson(it.readText()) }
        val before = MlTranscriptionEngine(net!!, classifier = { forest }, scoreModels = { models })
        val e = MlTranscriptionEngine(net, classifier = { forest }, scoreModels = { models }, merger = { merge })
        var worstExtra = 0.0
        for (type in listOf(InputType.HUMMING, InputType.SINGING)) for ((label, drift, flutter, scoop, vib) in listOf(
            listOf("clean", 0.0, 0.0, 0.0, 0.0), listOf("vibrato 35", 0.0, 0.0, 0.0, 35.0), listOf("drift 25", 25.0, 0.0, 0.0, 0.0),
            listOf("drift 40 + flutter", 40.0, 0.5, 0.0, 0.0), listOf("scoop 80 + drift 25", 25.0, 0.0, 80.0, 0.0),
            listOf("all", 30.0, 0.5, 60.0, 30.0)).map { Quint(it[0] as String, it[1] as Double, it[2] as Double, it[3] as Double, it[4] as Double) }) {
            val tr = ArrayList<Int>(); val trBefore = ArrayList<Int>(); val beatsHist = HashMap<String, Int>(); var bpmSum = 0.0
            val seeds = 4
            for (seed in 1..seeds) {
                val voice = SyntheticVoice.render(SyntheticVoice.melody(spec, 80.0, gap = 0.06, jitterSec = 0.02, seed = seed.toLong()),
                    driftCents = drift, ampFlutter = flutter, scoopCents = scoop, vibratoCents = vib, noise = 0.004, seed = seed.toLong(), tailSec = 0.5)
                trBefore.add(before.analyze(voice, AnalysisConfig(type)).transcription.notes.size)
                val out = e.analyze(voice, AnalysisConfig(type)).transcription
                tr.add(out.notes.size); bpmSum += out.tempoMap.averageBpm
                for (n in out.notes) beatsHist.merge("%.2f".format(n.durationBeats), 1, Int::plus)
            }
            worstExtra = maxOf(worstExtra, tr.average() - truth)
            println("WOBBLE $type $label: notes per take before merge $trBefore, after $tr (truth $truth), mean bpm ${"%.0f".format(bpmSum / seeds)}, lengths ${beatsHist.toSortedMap()}")
        }
        assertTrue("notes still cut in pieces: ${worstExtra} too many on average", worstExtra <= 1.0)
    }
    /** Slow and moderate tempi, quarter and half notes: the tempo must not double up (which would write eighths). */
    @Test fun slowTempiAreNotDoubled() {
        val net = PythonOnnxModel.create()
        val dir = findUp("app/src/main/assets")
        assumeTrue(net != null && dir != null)
        val forest = File(dir, "note_rf.json").takeIf { it.exists() }?.let { RandomForest.fromJson(it.readText()) }
        val models = ScoreModels.load { n -> File(dir, n).takeIf { it.exists() }?.readText() }.takeIf { it.complete }
        val merge = findUp("app/src/main/assets/note_merge.json")?.let { RandomForest.fromJson(it.readText()) }
        val e = MlTranscriptionEngine(net!!, classifier = { forest }, scoreModels = { models }, merger = { merge })
        val spec = listOf(60 to 1.0, 62 to 1.0, 64 to 1.0, 65 to 1.0, 67 to 2.0, 65 to 1.0, 64 to 1.0, 62 to 1.0, 60 to 2.0, 67 to 1.0, 67 to 1.0, 69 to 1.0, 71 to 1.0, 72 to 4.0)
        for (bpm in listOf(50.0, 60.0, 72.0, 90.0, 110.0)) {
            val bpms = ArrayList<Double>(); val hist = HashMap<String, Int>()
            for (seed in 1..3) {
                val voice = SyntheticVoice.render(SyntheticVoice.melody(spec, bpm, gap = 0.07, jitterSec = 0.025, seed = seed.toLong()),
                    driftCents = 25.0, ampFlutter = 0.3, scoopCents = 40.0, vibratoCents = 20.0, noise = 0.004, seed = seed.toLong(), tailSec = 0.5)
                val out = e.analyze(voice, AnalysisConfig(InputType.HUMMING)).transcription
                bpms.add(out.tempoMap.averageBpm)
                for (n in out.notes) hist.merge("%.2f".format(n.durationBeats), 1, Int::plus)
            }
            assertTrue("tempo $bpm read as $bpms", bpms.all { abs(it - bpm) / bpm < 0.08 })
            println("SLOW sung at $bpm bpm -> detected ${bpms.map { "%.0f".format(it) }}, written lengths ${hist.toSortedMap()}")
        }
    }

    @Test fun mergerMatchesSklearn() {
        val rf = findUp("app/src/main/assets/note_merge.json")?.let { RandomForest.fromJson(it.readText()) }
        val par = findUp("engine/src/test/resources/merge_parity.json")
        assumeTrue(rf != null && par != null)
        @Suppress("UNCHECKED_CAST")
        val m = Json.parse(par!!.readText()) as Map<String, Any?>
        val xs = (m["x"] as List<List<Number>>).map { r -> r.map { it.toDouble() }.toDoubleArray() }
        val ps = (m["p"] as List<Number>).map { it.toDouble() }
        var worst = 0.0
        for (i in xs.indices) worst = maxOf(worst, abs(rf!!.probability(xs[i]) - ps[i]))
        println("parity merge: ${xs.size} rows, max diff $worst")
        assertTrue("max difference $worst", worst < 2e-3)
        assertEquals(com.voicecomposer.engine.ml.NoteMerger.DIM, rf!!.dim)
    }

    private data class Quint(val label: String, val drift: Double, val flutter: Double, val scoop: Double, val vib: Double)
    private operator fun Quint.component1() = label; private operator fun Quint.component2() = drift; private operator fun Quint.component3() = flutter
    private operator fun Quint.component4() = scoop; private operator fun Quint.component5() = vib
}
