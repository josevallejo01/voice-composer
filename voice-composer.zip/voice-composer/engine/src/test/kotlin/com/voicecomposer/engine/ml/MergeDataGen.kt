package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.SyntheticVoice
import com.voicecomposer.engine.preprocessing.InputType
import java.io.File
import java.util.Random
import kotlin.math.max
import kotlin.math.min

/**
 * Training rows for the note merger (see tools/gen_merge_data.sh and tools/train_merge_model.py).
 * Clips are made like the note classifier's (noise, channel effects) plus the wander of a human voice and long held notes.
 * Notes are detected as on the device (shipped note forest); every eligible joint between two neighbouring notes becomes a
 * row, labelled 1 when both notes lie inside the same sung note (the detector cut one note in two), 0 otherwise.
 *   MergeDataGen <out.csv> <first-seed> <clips> <train|val|hard> <note_rf.json>
 */
object MergeDataGen {
    @JvmStatic
    fun main(args: Array<String>) {
        val out = File(args[0]); val seed0 = args[1].toLong(); val n = args[2].toInt(); val split = args[3]
        val forest = RandomForest.fromJson(File(args[4]).readText())
        val model = PythonOnnxModel.create() ?: error("model/onnxruntime not available")
        val engine = MlTranscriptionEngine(model, classifier = { forest })
        val sb = StringBuilder()
        out.delete()
        sb.append("clip,split,type,tags,snr,label,start,midi,").append(NoteMerger.NAMES.joinToString(",")).append('\n')
        for (i in 0 until n) {
            val seed = seed0 + i
            val rnd = Random(seed * 104729 + 31)
            val type = when (rnd.nextInt(10)) { in 0..3 -> InputType.SINGING; in 4..7 -> InputType.HUMMING; else -> InputType.WHISTLING }
            val clip = DataGen.makeClip(type, rnd, split, wobble = true)
            if (clip.truth.isEmpty()) continue
            val cfg = AnalysisConfig(inputType = type)
            val prep = try { engine.prepare(clip.audio, cfg) } catch (e: Throwable) { System.err.println("clip $seed failed: $e"); continue }
            val prm = DecoderParams.forInput(type)
            val kept = engine.detectKept(prep, cfg, prm)
            // The truth note each kept note lies in (>= 50% of its length), or -1.
            fun inside(a: com.voicecomposer.engine.segmentation.DetectedNote): Int {
                var best = -1; var bestOv = 0.0
                for ((k, t) in clip.truth.withIndex()) {
                    val ov = min(a.endSec, t.start + t.dur) - max(a.startSec, t.start)
                    if (ov > bestOv) { bestOv = ov; best = k }
                }
                return if (best >= 0 && bestOv >= 0.5 * (a.endSec - a.startSec)) best else -1
            }
            for ((idx, x) in NoteMerger.jointRows(kept, prep)) {
                val a = kept[idx].second; val b = kept[idx + 1].second
                val ta = inside(a); val tb = inside(b)
                val label = if (ta >= 0 && ta == tb) 1 else 0
                sb.append("$split-$seed,$split,${type.name},${clip.tags},${"%.1f".format(clip.snr)},$label,${"%.3f".format(a.endSec)},${a.midi}")
                for (v in x) sb.append(',').append("%.5f".format(v))
                sb.append('\n')
            }
            if (i % 20 == 19) { out.appendText(sb.toString()); sb.setLength(0); System.err.println("$split shard $seed0: ${i + 1}/$n") }
        }
        out.appendText(sb.toString())
        model.close()
    }
}
