package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.io.WavIO
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeNotNull
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class ForestTest {
    private val model: PythonOnnxModel? by lazy { PythonOnnxModel.create() }

    private fun findUp(rel: String): File? {
        var d: File? = File("").absoluteFile
        while (d != null) { val f = File(d, rel); if (f.exists()) return f; d = d.parentFile }
        return null
    }

    private val shipped: RandomForest? by lazy { findUp("app/src/main/assets/note_rf.json")?.let { RandomForest.fromJson(it.readText()) } }

    /** The Kotlin reader must give exactly what scikit-learn gives for the same rows. */
    @Test fun kotlinForestMatchesSklearn() {
        val rf = shipped; val par = findUp("engine/src/test/resources/rf_parity.json")
        assumeTrue(rf != null && par != null)
        @Suppress("UNCHECKED_CAST")
        val m = Json.parse(par!!.readText()) as Map<String, Any?>
        val xs = (m["x"] as List<List<Number>>).map { r -> r.map { it.toDouble() }.toDoubleArray() }
        val ps = (m["p"] as List<Number>).map { it.toDouble() }
        var worst = 0.0
        for (i in xs.indices) worst = max(worst, abs(rf!!.probability(xs[i]) - ps[i]))
        println("parity: ${xs.size} rows, ${rf!!.size} trees, max |kotlin - sklearn| = $worst")
        assertTrue("max difference $worst", worst < 2e-3) // leaf values are rounded to 4 decimals in the export
        assertEquals(NoteFeatures.DIM, rf.dim)
    }

    @Test fun jsonRoundTrip() {
        val rnd = Random(1)
        val x = List(300) { DoubleArray(6) { rnd.nextDouble() } }
        val y = IntArray(300) { if (x[it][0] + x[it][1] > 1.0) 1 else 0 }
        val rf = ForestTrainer.train(x, y, trees = 10)!!
        val back = RandomForest.fromJson(rf.toJson())
        for (r in x.take(50)) assertEquals(rf.probability(r), back.probability(r), 1e-9)
    }

    @Test fun onDeviceTrainerLearnsARuleDespiteNoisyLabels() {
        val rnd = Random(3)
        fun make(n: Int) = List(n) { DoubleArray(8) { rnd.nextDouble() } }
        fun truth(r: DoubleArray) = if (r[0] > 0.5 && r[3] < 0.7) 1 else 0
        val xtr = make(400)
        val ytr = IntArray(400) { var l = truth(xtr[it]); if (rnd.nextInt(100) < 8) l = 1 - l; l } // 8% wrong labels
        val rf = ForestTrainer.train(xtr, ytr)!!
        val xte = make(1000)
        val acc = xte.count { (rf.probability(it) >= 0.5) == (truth(it) == 1) } / 1000.0
        println("on-device forest accuracy with 8% label noise: $acc")
        assertTrue("accuracy $acc", acc > 0.85)
        assertTrue(ForestTrainer.train(make(5), IntArray(5)) == null) // too little data: no forest rather than a bad one
    }

    private fun noteF1(truth: List<Triple<Int, Double, Double>>, est: List<Triple<Int, Double, Double>>): Triple<Double, Double, Double> {
        val used = BooleanArray(est.size); var tp = 0
        for (t in truth) {
            val i = est.indices.firstOrNull { k -> !used[k] && est[k].first == t.first && min(est[k].third, t.third) - max(est[k].second, t.second) >= 0.5 * min(est[k].third - est[k].second, t.third - t.second) }
            if (i != null) { used[i] = true; tp++ }
        }
        val p = if (est.isEmpty()) 0.0 else tp.toDouble() / est.size; val r = if (truth.isEmpty()) 1.0 else tp.toDouble() / truth.size
        return Triple(p, r, if (p + r == 0.0) 0.0 else 2 * p * r / (p + r))
    }

    /** Held-out noisy synthetic clips (never seen in training): forest vs hand-written rules, note level. */
    @Test fun forestBeatsRulesOnNoisyClips() {
        val m = model; val rf = shipped
        assumeTrue(m != null && rf != null)
        val rules = MlTranscriptionEngine(m!!)
        val forest = MlTranscriptionEngine(m, classifier = { rf })
        val sums = Array(2) { DoubleArray(3) }
        val perType = HashMap<String, Array<DoubleArray>>()
        var n = 0
        for (seed in 900_001L..900_060L) {
            val rnd = Random(seed)
            val type = listOf(InputType.SINGING, InputType.HUMMING, InputType.WHISTLING)[(seed % 3).toInt()]
            val clip = DataGen.makeClip(type, rnd, "hard")
            val truth = clip.truth.map { Triple(Math.round(it.midi).toInt(), it.start, it.start + it.dur) }
            if (truth.isEmpty()) continue
            val cfg = AnalysisConfig(inputType = type)
            val prep = rules.prepare(clip.audio, cfg)
            fun triples(e: MlTranscriptionEngine) = e.detect(prep, cfg).map { Triple(it.midi, it.startSec, it.endSec) }
            val a = noteF1(truth, triples(rules)); val b = noteF1(truth, triples(forest))
            for (k in 0..2) { sums[0][k] += listOf(a.first, a.second, a.third)[k]; sums[1][k] += listOf(b.first, b.second, b.third)[k] }
            val pt = perType.getOrPut(type.name) { Array(2) { DoubleArray(4) } }
            pt[0][0] += a.third; pt[1][0] += b.third; pt[0][3] += 1.0
            n++
        }
        println("hard noisy clips ($n): rules P %.3f R %.3f F1 %.3f | forest P %.3f R %.3f F1 %.3f".format(
            sums[0][0] / n, sums[0][1] / n, sums[0][2] / n, sums[1][0] / n, sums[1][1] / n, sums[1][2] / n))
        for ((t, v) in perType) println("  $t: rules F1 %.3f forest F1 %.3f (n=%d)".format(v[0][0] / v[0][3], v[1][0] / v[0][3], v[0][3].toInt()))
        assertTrue("forest F1 ${sums[1][2] / n} must not be worse than rules ${sums[0][2] / n}", sums[1][2] / n >= sums[0][2] / n - 0.01)
    }

    /** Real sung audio with noise added: how many of the clean-run notes survive, and how many spurious notes appear. */
    @Test fun realClipsStayStableUnderNoise() {
        val m = model; val rf = shipped
        assumeTrue(m != null && rf != null)
        val rules = MlTranscriptionEngine(m!!)
        val forest = MlTranscriptionEngine(m, classifier = { rf })
        for (name in listOf("vocadito_10.wav", "vocadito_14.wav")) {
            val f = findUp("../spotify/basic-pitch/tests/resources/$name") ?: File("/home/claude/spotify/basic-pitch/tests/resources/$name")
            if (!f.exists()) continue
            val clean = WavIO.read(f)
            val cfg = AnalysisConfig(inputType = InputType.SINGING)
            fun notes(e: MlTranscriptionEngine, a: AudioBuffer) = e.detect(e.prepare(a, cfg), cfg).map { Triple(it.midi, it.startSec, it.endSec) }
            val refR = notes(rules, clean); val refF = notes(forest, clean)
            // Reference = notes both pipelines find on the clean recording.
            val ref = refR.filter { r -> refF.any { noteF1(listOf(r), listOf(it)).third > 0.0 } }
            println("$name clean: rules ${refR.size} notes, forest ${refF.size}, agreed reference ${ref.size}")
            for ((tag, kind, snr) in listOf(Triple("pink 12 dB", "pink", 12.0), Triple("babble 8 dB", "babble", 8.0), Triple("fan+keys 10 dB", "fan", 10.0))) {
                val rnd = Random(5)
                val nz = DataGen.noise(kind, clean.samples.size, clean.sampleRate, rnd)
                val extra = if (tag.startsWith("fan")) DataGen.noise("keys", clean.samples.size, clean.sampleRate, rnd) else null
                val rmsS = Math.sqrt(clean.samples.sumOf { it * it.toDouble() } / clean.samples.size)
                fun rms(x: FloatArray) = Math.sqrt(x.sumOf { it * it.toDouble() } / x.size) + 1e-9
                val g = rmsS / rms(nz) * Math.pow(10.0, -snr / 20)
                val noisy = FloatArray(clean.samples.size) { clean.samples[it] + (nz[it] * g).toFloat() + (extra?.let { e -> e[it] * g * 0.5 } ?: 0.0).toFloat() }
                val a = AudioBuffer(noisy, clean.sampleRate)
                val prepA = rules.prepare(a, cfg)
                val r = noteF1(ref, rules.detect(prepA, cfg).map { Triple(it.midi, it.startSec, it.endSec) })
                val sb = StringBuilder("   $tag: rules P %.2f R %.2f F1 %.2f |".format(r.first, r.second, r.third))
                for (th in listOf(0.25, 0.35, 0.5)) {
                    val fo = noteF1(ref, forest.detect(prepA, cfg, DecoderParams.forInput(InputType.SINGING).copy(rfThreshold = th)).map { Triple(it.midi, it.startSec, it.endSec) })
                    sb.append(" rf@%.2f P %.2f R %.2f F1 %.2f |".format(th, fo.first, fo.second, fo.third))
                }
                println(sb)
            }
        }
    }
}
