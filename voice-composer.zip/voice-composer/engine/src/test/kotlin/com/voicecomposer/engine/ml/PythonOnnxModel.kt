package com.voicecomposer.engine.ml

import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Test helper: runs the real Basic Pitch ONNX model through a Python onnxruntime subprocess, so the JVM tests exercise
 * the actual network without the Android runtime. [available] is false when python/onnxruntime or the model file is
 * missing; tests then skip themselves.
 */
class PythonOnnxModel private constructor(private val proc: Process) : BasicPitchModel, AutoCloseable {
    private val out = proc.outputStream
    private val inp = DataInputStream(BufferedInputStream(proc.inputStream))

    override fun inferBatch(windows: List<FloatArray>): List<WindowOutput> {
        val bb = ByteBuffer.allocate(4 + windows.size * BP.WINDOW_SAMPLES * 4).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(windows.size)
        for (w in windows) for (v in w) bb.putFloat(v)
        out.write(bb.array()); out.flush()
        val perWindow = BP.WINDOW_FRAMES * (BP.NOTES * 2 + BP.CONTOUR_BINS)
        val buf = ByteArray(windows.size * perWindow * 4)
        inp.readFully(buf)
        val fb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        // The script sends all notes of the batch, then all onsets, then all contours.
        val n = windows.size
        val notes = List(n) { FloatArray(BP.WINDOW_FRAMES * BP.NOTES).also { a -> fb.get(a) } }
        val onsets = List(n) { FloatArray(BP.WINDOW_FRAMES * BP.NOTES).also { a -> fb.get(a) } }
        val contours = List(n) { FloatArray(BP.WINDOW_FRAMES * BP.CONTOUR_BINS).also { a -> fb.get(a) } }
        return List(n) { WindowOutput(notes[it], onsets[it], contours[it]) }
    }

    override fun close() { runCatching { out.close() }; proc.destroy() }

    companion object {
        private val SCRIPT = """
import sys, numpy as np, onnxruntime as ort
s = ort.InferenceSession(sys.argv[1], providers=['CPUExecutionProvider'])
name = s.get_inputs()[0].name
outs = [o.name for o in s.get_outputs()]
rd = sys.stdin.buffer; wr = sys.stdout.buffer
def rn(n):
    b = b''
    while len(b) < n:
        c = rd.read(n - len(b))
        if not c: sys.exit(0)
        b += c
    return b
while True:
    h = rd.read(4)
    if len(h) < 4: break
    n = int(np.frombuffer(h, '<i4')[0])
    w = np.frombuffer(rn(n * 43844 * 4), '<f4').reshape(n, 43844, 1)
    r = dict(zip(outs, s.run(None, {name: w})))
    k = sorted(r.keys())  # :0 contour, :1 note, :2 onset
    for key in (k[1], k[2], k[0]):
        wr.write(np.ascontiguousarray(r[key], '<f4').tobytes())
    wr.flush()
""".trimIndent()

        fun modelFile(): File? {
            val rel = "app/src/main/assets/nmp.onnx"
            var d: File? = File("").absoluteFile
            while (d != null) {
                val f = File(d, rel)
                if (f.exists()) return f
                d = d.parentFile
            }
            return (System.getenv("BASIC_PITCH_ONNX"))?.let { File(it) }?.takeIf { it.exists() }
        }

        /** Null when the real model cannot be run in this environment. */
        fun create(): PythonOnnxModel? {
            val model = modelFile() ?: return null
            return try {
                val script = File.createTempFile("bp_ort", ".py").apply { writeText(SCRIPT); deleteOnExit() }
                val pb = ProcessBuilder("python3", "-I", script.path, model.path).redirectError(ProcessBuilder.Redirect.DISCARD)
                val p = pb.start()
                PythonOnnxModel(p).also { it.inferBatch(listOf(FloatArray(BP.WINDOW_SAMPLES))) } // smoke test
            } catch (e: Throwable) { null }
        }
    }
}
