package com.voicecomposer.engine.ml

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.SyntheticVoice
import com.voicecomposer.engine.SyntheticVoice.N
import com.voicecomposer.engine.calibration.CalibrationJson
import com.voicecomposer.engine.calibration.CalibrationTake
import com.voicecomposer.engine.calibration.CalibrationTuner
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.profile.VoiceProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeNotNull
import org.junit.Test
import java.util.Random

class CalibrationTest {
    private val real: PythonOnnxModel? by lazy { PythonOnnxModel.create() }

    /** A network that behaves badly on this user's microphone: weak activations, and hallucinated notes in noise. */
    private class DegradedModel(val inner: BasicPitchModel, val scale: Float, val hallucinate: Boolean) : BasicPitchModel {
        override fun inferBatch(windows: List<FloatArray>): List<WindowOutput> {
            val r = Random(11)
            return inner.inferBatch(windows).mapIndexed { wi, o ->
                val note = o.note.copyOf(); val onset = o.onset.copyOf()
                for (i in note.indices) note[i] *= scale
                if (hallucinate) {
                    var f = 0
                    while (f < BP.WINDOW_FRAMES - 12) {
                        // wherever the signal is quiet, invent a note for ~10 frames
                        var e = 0f
                        for (i in f * BP.HOP until minOf(windows[wi].size, (f + 10) * BP.HOP)) e += Math.abs(windows[wi][i])
                        if (e / (10 * BP.HOP) < 0.01f && r.nextDouble() < 0.25) {
                            val key = r.nextInt(60) + 10
                            for (g in f until f + 10) note[g * BP.NOTES + key] = 0.7f
                            onset[f * BP.NOTES + key] = 0.9f
                        }
                        f += 12
                    }
                }
                WindowOutput(note, onset, o.contour)
            }
        }
    }

    private fun takes(model: BasicPitchModel, type: InputType, cfg: AnalysisConfig): Pair<MlTranscriptionEngine, List<CalibrationTake>> {
        val engine = MlTranscriptionEngine(model)
        val out = ArrayList<CalibrationTake>()
        val room = Random(5)
        for (m in listOf(48, 50, 52, 55, 57, 60, 62, 64)) {
            val a = SyntheticVoice.render(listOf(N(m.toDouble(), 0.5, 2.0)), harmonics = doubleArrayOf(1.0, 0.6, 0.2), vibratoCents = 10.0, noise = 0.003)
            out.add(CalibrationTake(engine.prepare(a, cfg), m))
        }
        for (i in 0 until 2) { // two takes of silence with room noise
            val x = FloatArray(44100 * 3) { (room.nextGaussian() * 0.004).toFloat() }
            out.add(CalibrationTake(engine.prepare(AudioBuffer(x, 44100), cfg), null))
        }
        return engine to out
    }

    @Test fun calibrationRecoversNotesFromAWeakNetwork() {
        val m = real; assumeNotNull(m)
        val cfg = AnalysisConfig(InputType.HUMMING)
        val (engine, tk) = takes(DegradedModel(m!!, 0.30f, false), InputType.HUMMING, cfg)
        val r = CalibrationTuner.tune(engine, cfg, InputType.HUMMING, tk)
        println("weak network: before ${"%.2f".format(r.report.scoreBefore)} after ${"%.2f".format(r.report.scoreAfter)}, restBias ${r.decoder.restBias}, ${r.report.notesCorrect}/${r.report.notesTotal} notes, silence clean ${r.report.silenceClean}/${r.report.silenceTakes}")
        assertTrue("after ${r.report.scoreAfter} before ${r.report.scoreBefore}", r.report.scoreAfter > r.report.scoreBefore + 0.15)
        assertTrue(r.decoder.restBias < InputType.HUMMING.let { DecoderParams.forInput(it).restBias })
    }

    @Test fun calibrationSilencesHallucinationsWithoutLosingNotes() {
        val m = real; assumeNotNull(m)
        val cfg = AnalysisConfig(InputType.HUMMING)
        val (engine, tk) = takes(DegradedModel(m!!, 1f, true), InputType.HUMMING, cfg)
        val r = CalibrationTuner.tune(engine, cfg, InputType.HUMMING, tk)
        println("hallucinating network: before ${"%.2f".format(r.report.scoreBefore)} after ${"%.2f".format(r.report.scoreAfter)}, silence clean ${r.report.silenceClean}/${r.report.silenceTakes}, notes ${r.report.notesCorrect}/${r.report.notesTotal}")
        assertEquals(r.report.silenceTakes, r.report.silenceClean)
        assertTrue(r.report.notesCorrect >= r.report.notesTotal - 1)
        assertTrue(r.report.scoreAfter >= r.report.scoreBefore)
    }

    @Test fun calibrationFeedsTheProfileAndSurvivesJson() {
        val m = real; assumeNotNull(m)
        val cfg = AnalysisConfig(InputType.WHISTLING)
        val engine = MlTranscriptionEngine(m!!)
        val tk = listOf(72, 79, 84, 91).map { n ->
            CalibrationTake(engine.prepare(SyntheticVoice.render(listOf(N(n.toDouble(), 0.4, 1.8)), harmonics = doubleArrayOf(1.0, 0.04), noise = 0.003), cfg), n)
        }
        val r = CalibrationTuner.tune(engine, cfg, InputType.WHISTLING, tk)
        assertEquals(4, r.report.notesCorrect)
        val json = CalibrationJson.write(r.decoder)
        val back = CalibrationJson.read(json, InputType.WHISTLING)
        assertNotNull(back)
        assertEquals(r.decoder.restBias, back!!.restBias, 1e-9)
        assertTrue(back.fuseDsp) // type defaults survive
        val prof = VoiceProfile.build(listOf(r.contribution), InputType.WHISTLING, back)
        assertTrue(prof.engineNotes > 0)
        assertEquals(0, VoiceProfile.build(listOf(r.contribution), InputType.HUMMING).projects) // profiles are per kind of sound
    }
}
