package com.voicecomposer.engine.score

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.io.WavIO
import com.voicecomposer.engine.ml.MlTranscriptionEngine
import com.voicecomposer.engine.ml.PythonOnnxModel
import com.voicecomposer.engine.ml.RandomForest
import com.voicecomposer.engine.preprocessing.InputType
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

class NoteLengthDiagTest {
    private fun findUp(rel: String): File? {
        var d: File? = File("").absoluteFile
        while (d != null) { val f = File(d, rel); if (f.exists()) return f; d = d.parentFile }
        return null
    }

    @Test fun realClips() {
        val net = PythonOnnxModel.create()
        val dir = findUp("app/src/main/assets")
        assumeTrue(net != null && dir != null)
        val forest = File(dir, "note_rf.json").takeIf { it.exists() }?.let { RandomForest.fromJson(it.readText()) }
        val models = ScoreModels.load { n -> File(dir, n).takeIf { it.exists() }?.readText() }.takeIf { it.complete }
        val merge = findUp("app/src/main/assets/note_merge.json")?.let { RandomForest.fromJson(it.readText()) }
        for (name in listOf("vocadito_10.wav", "vocadito_14.wav")) {
            val f = File("/home/claude/spotify/basic-pitch/tests/resources/$name")
            if (!f.exists()) continue
            val audio = WavIO.read(f)
            for ((label, e) in listOf("rules" to MlTranscriptionEngine(net!!, classifier = { forest }), "learned" to MlTranscriptionEngine(net, classifier = { forest }, scoreModels = { models }),
                "learned+merge" to MlTranscriptionEngine(net, classifier = { forest }, scoreModels = { models }, merger = { merge }))) {
                val tr = e.analyze(audio, AnalysisConfig(InputType.SINGING)).transcription
                val n = tr.notes
                val secs = n.map { it.endSec - it.startSec }.sorted()
                val hist = n.groupingBy { "%.2f".format(it.durationBeats) }.eachCount().toSortedMap()
                println("$name $label: ${n.size} notes over ${"%.1f".format(audio.samples.size.toDouble() / audio.sampleRate)} s, bpm ${"%.1f".format(tr.tempoMap.averageBpm)} ${tr.timeSignature}; " +
                    "note seconds median ${"%.2f".format(secs[secs.size / 2])} p10 ${"%.2f".format(secs[secs.size / 10])}; beats $hist")
            }
        }
    }
}
