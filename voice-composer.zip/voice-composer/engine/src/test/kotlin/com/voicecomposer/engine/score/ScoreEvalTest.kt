package com.voicecomposer.engine.score

import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.PostNotePipeline
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.preprocessing.SignalQuality
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import com.voicecomposer.model.Json
import com.voicecomposer.model.Transcription
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File
import java.util.Random
import kotlin.math.abs
import kotlin.math.max

/**
 * Learned score decisions against the hand-written rules, on notated tunes never used for training (split by tune) that
 * were played back by the simulator. Needs the tune file (SCORE_TUNES, written by tools/prepare_tunes.py; the corpus is
 * not shipped) and the exported forests; skipped otherwise.
 */
class ScoreEvalTest {
    private fun findUp(rel: String): File? {
        var d: File? = File("").absoluteFile
        while (d != null) { val f = File(d, rel); if (f.exists()) return f; d = d.parentFile }
        return null
    }

    private val models: ScoreModels? by lazy {
        val dir = findUp("app/src/main/assets") ?: return@lazy null
        ScoreModels.load { n -> File(dir, n).takeIf { it.exists() }?.readText() }.takeIf { it.complete }
    }

    private class Tally { var n = 0; var tempo = 0; var tempoOct = 0; var meter = 0; var keyExact = 0; var keySig = 0
        var notes = 0; var absStart = 0; var relStart = 0; var dur = 0; var durN = 0; var perfsRhythm = 0 }

    private fun evaluate(split: String, perfs: Int, m: ScoreModels?): Tally {
        val tunes = Tune.load(File(System.getenv("SCORE_TUNES"))).filter { ScoreDataGen.splitOf(it.id) == split }
        val lv = if (split == "hard") PerformanceSim.HARD else PerformanceSim.NORMAL
        val t = Tally()
        var count = 0
        for (tune in tunes) {
            val rnd = Random(tune.id.hashCode().toLong() * 31 + 424242)
            val p = PerformanceSim.perform(tune, rnd, lv) ?: continue
            if (count++ >= perfs) break
            val cfg = AnalysisConfig(InputType.HUMMING)
            val q = SignalQuality(0.5f, -20.0, 0.0, false, false, 20.0)
            val res = PostNotePipeline.run(p.detected(), cfg, q, mutableListOf(), "test", { _, _ -> }, { false }, m)
            val tr: Transcription = res.transcription
            t.n++
            val bpm = tr.tempoMap.averageBpm
            if (abs(bpm / p.bpmAvg - 1) < 0.04) t.tempo++
            if (listOf(0.5, 1.0, 2.0).any { abs(bpm / (p.bpmAvg * it) - 1) < 0.04 }) t.tempoOct++
            if (tr.timeSignature == p.meter) t.meter++
            val tk = KeySignature(p.key.first, if (p.key.second) Mode.MINOR else Mode.MAJOR)
            if (tr.key.tonic == tk.tonic && tr.key.mode == tk.mode) t.keyExact++
            if (tr.key.fifths == tk.fifths) t.keySig++
            if (!p.onGrid) continue
            // rhythm: match events to performed notes by start time
            val byStart = tr.notes.associateBy { Math.round(it.startSec * 1000) }
            val pairs = p.notes.mapNotNull { pn -> if (pn.truthIdx < 0 || pn.slot < 0) null else byStart[Math.round(pn.startSec * 1000)]?.let { pn to it } }
            if (pairs.size < 4) continue
            t.perfsRhythm++
            val shifts = pairs.map { (pn, e) -> Math.round(e.startBeat * 4).toInt() - pn.slot }
            val mode = shifts.groupingBy { it }.eachCount().maxByOrNull { it.value }!!.key
            for ((i, pe) in pairs.withIndex()) {
                val (pn, e) = pe
                t.notes++
                if (shifts[i] == 0) t.absStart++
                if (shifts[i] == mode) t.relStart++
                if (pn.durSlots > 0) { t.durN++; if (Math.round(e.durationBeats * 4).toInt() == pn.durSlots) t.dur++ }
            }
        }
        return t
    }

    private fun show(label: String, t: Tally) {
        fun pct(a: Int, b: Int) = "%.1f%%".format(100.0 * a / max(1, b))
        println("  %-6s n=%d  tempo %s (octave-tolerant %s)  meter %s  key exact %s / signature %s  | notes %d: start %s (bar-aligned) %s (up to a shift)  length %s".format(
            label, t.n, pct(t.tempo, t.n), pct(t.tempoOct, t.n), pct(t.meter, t.n), pct(t.keyExact, t.n), pct(t.keySig, t.n), t.notes, pct(t.absStart, t.notes), pct(t.relStart, t.notes), pct(t.dur, t.durN)))
    }

    @Test fun learnedScoreVersusRules() {
        assumeTrue(System.getenv("SCORE_TUNES")?.let { File(it).exists() } == true && models != null)
        for (split in listOf("val", "hard")) {
            println("split $split (tunes not used for training):")
            val rules = evaluate(split, 250, null); val ml = evaluate(split, 250, models)
            show("rules", rules); show("learned", ml)
            if (split == "val") {
                assertTrue("tempo ${ml.tempo} vs ${rules.tempo}", ml.tempo >= rules.tempo)
                assertTrue("meter ${ml.meter} vs ${rules.meter}", ml.meter >= rules.meter)
                assertTrue("key ${ml.keyExact} vs ${rules.keyExact}", ml.keyExact >= rules.keyExact)
                assertTrue("start ${ml.relStart} vs ${rules.relStart}", ml.relStart >= rules.relStart)
            }
        }
    }

    /** The forests must read exactly what scikit-learn computed (rows exported next to the models). */
    @Test fun scoreForestsMatchSklearn() {
        val par = findUp("engine/src/test/resources/score_parity.json"); val dir = findUp("app/src/main/assets")
        assumeTrue(par != null && dir != null)
        @Suppress("UNCHECKED_CAST")
        val m = Json.parse(par!!.readText()) as Map<String, Map<String, Any?>>
        var checked = 0
        for ((name, v) in m) {
            val f = File(dir, "score_$name.json"); if (!f.exists()) continue
            val rf = com.voicecomposer.engine.ml.RandomForest.fromJson(f.readText())
            @Suppress("UNCHECKED_CAST") val xs = (v["x"] as List<List<Number>>).map { r -> r.map { it.toDouble() }.toDoubleArray() }
            @Suppress("UNCHECKED_CAST") val ps = (v["p"] as List<Number>).map { it.toDouble() }
            var worst = 0.0
            for (i in xs.indices) worst = max(worst, abs(rf.probability(xs[i]) - ps[i]))
            println("parity $name: ${xs.size} rows, ${rf.size} trees, max diff $worst")
            assertTrue("$name differs by $worst", worst < 2e-3)
            checked++
        }
        assertTrue(checked > 0)
    }

    /** Whole chain from audio: tunes sung by a synthetic voice, network + note forest + score models. */
    @Test fun audioEndToEnd() {
        val net = com.voicecomposer.engine.ml.PythonOnnxModel.create()
        assumeTrue(System.getenv("SCORE_TUNES")?.let { File(it).exists() } == true && models != null && net != null)
        val forest = findUp("app/src/main/assets/note_rf.json")?.let { com.voicecomposer.engine.ml.RandomForest.fromJson(it.readText()) }
        val rulesEngine = com.voicecomposer.engine.ml.MlTranscriptionEngine(net!!, classifier = { forest })
        val mlEngine = com.voicecomposer.engine.ml.MlTranscriptionEngine(net, classifier = { forest }, scoreModels = { models })
        val tunes = Tune.load(File(System.getenv("SCORE_TUNES"))).filter { ScoreDataGen.splitOf(it.id) == "val" }
        var n = 0; val r = IntArray(4); val l = IntArray(4)
        for (tune in tunes) {
            val rnd = Random(tune.id.hashCode().toLong() + 5)
            val p = PerformanceSim.perform(tune, rnd, PerformanceSim.NORMAL) ?: continue
            if (n >= 14) break
            val voice = com.voicecomposer.engine.SyntheticVoice.render(
                p.notes.map { com.voicecomposer.engine.SyntheticVoice.N(it.midi.toDouble(), it.startSec, it.endSec - it.startSec) },
                tailSec = 0.6, vibratoCents = 20.0, seed = 3)
            val cfg = AnalysisConfig(InputType.SINGING)
            val tk = KeySignature(p.key.first, if (p.key.second) Mode.MINOR else Mode.MAJOR)
            for ((e, a) in listOf(rulesEngine to r, mlEngine to l)) {
                val tr = e.analyze(voice, cfg).transcription
                if (abs(tr.tempoMap.averageBpm / p.bpmAvg - 1) < 0.04) a[0]++
                if (tr.timeSignature == p.meter) a[1]++
                if (tr.key.tonic == tk.tonic && tr.key.mode == tk.mode) a[2]++
                if (tr.key.fifths == tk.fifths) a[3]++
            }
            n++
        }
        fun f(a: IntArray) = "tempo ${a[0]}/$n  meter ${a[1]}/$n  key exact ${a[2]}/$n  signature ${a[3]}/$n"
        println("audio end-to-end on $n sung tunes (synthetic voice, real network):\n  rules   ${f(r)}\n  learned ${f(l)}")
        assertTrue(l[0] + l[1] + l[2] >= r[0] + r[1] + r[2])
    }
}
