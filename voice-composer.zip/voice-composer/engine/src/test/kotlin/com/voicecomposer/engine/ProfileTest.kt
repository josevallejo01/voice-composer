package com.voicecomposer.engine

import com.voicecomposer.engine.ml.DecoderParams
import com.voicecomposer.engine.profile.Contribution
import com.voicecomposer.engine.profile.ContributionBuilder
import com.voicecomposer.engine.profile.VoiceProfile
import com.voicecomposer.engine.profile.looksReal
import com.voicecomposer.model.EventSource
import com.voicecomposer.model.EventType
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TimeSignature
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.ValidationState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class ProfileTest {
    private fun note(id: Int, midi: Int, start: Double, dur: Double, conf: Double, v: ValidationState = ValidationState.AUTO) = MusicalEvent(
        "n$id", EventType.NOTE, midi, null, start, start + dur, start * 2, dur * 2, conf, EventSource.DETECTED, v,
    )

    private fun tr(vararg n: MusicalEvent) = Transcription(n.toList(), TempoMap.constant(120.0), TimeSignature.FOUR_FOUR, KeySignature(0, Mode.MAJOR))

    @Test fun deletedAndKeptNotesAreCounted() {
        val engine = tr(note(1, 60, 0.0, 0.5, 0.9), note(2, 62, 0.6, 0.5, 0.9), note(3, 70, 1.2, 0.08, 0.4), note(4, 64, 2.0, 0.5, 0.9))
        // user deletes the short ghost, fixes the pitch of note 4 and adds one the engine missed
        val final = tr(note(1, 60, 0.0, 0.5, 0.9, ValidationState.VALIDATED), note(2, 62, 0.6, 0.5, 0.9), note(4, 65, 2.0, 0.5, 0.9), note(9, 67, 3.0, 0.5, 1.0))
        val c = ContributionBuilder.build("p", engine, final)
        assertEquals(1, c.falsePositives)
        assertEquals(1, c.missed)
        assertEquals(4, c.rows.size)
        assertEquals(1.0, c.rows[0].weight, 1e-9)
        assertEquals(0.3, c.rows[1].weight, 1e-9) // unreviewed: weak evidence
        assertEquals(0.0, c.rows[2].label, 1e-9)
    }

    @Test fun mergesAndSplitsAreDetected() {
        val engine = tr(note(1, 60, 0.0, 0.3, 0.9), note(2, 60, 0.3, 0.3, 0.9), note(3, 64, 1.0, 1.0, 0.9))
        val final = tr(note(1, 60, 0.0, 0.6, 0.9), note(3, 64, 1.0, 0.5, 0.9), note(4, 64, 1.5, 0.5, 0.9))
        val c = ContributionBuilder.build("p", engine, final)
        assertEquals(1, c.merges)
        assertEquals(1, c.splits)
    }

    @Test fun contributionSurvivesJson() {
        val c = ContributionBuilder.build("p", tr(note(1, 60, 0.0, 0.5, 0.9)), tr(note(1, 60, 0.0, 0.5, 0.9)))
        val back = Contribution.fromJson(c.toJson())
        assertNotNull(back)
        assertEquals(c.rows.size, back!!.rows.size)
        assertEquals(c.pitchCounts[60 - 21], back.pitchCounts[60 - 21])
        assertEquals(c.rows[0].x.toList(), back.rows[0].x.toList())
    }

    @Test fun anEmptyProfileChangesNothing() {
        val p = VoiceProfile.build(emptyList())
        assertEquals(DecoderParams(), p.decoder)
        assertNull(p.weights)
    }

    /** A singer whose engine output has many short ghost notes: with a few sessions of corrections the profile learns to distrust them. */
    private fun session(seed: Long, ghostRate: Double): Contribution {
        val r = Random(seed)
        val eng = ArrayList<MusicalEvent>(); val fin = ArrayList<MusicalEvent>()
        var t = 0.0
        for (i in 0 until 30) {
            val midi = 55 + r.nextInt(8)
            eng.add(note(i * 2, midi, t, 0.4 + r.nextDouble() * 0.4, 0.8 + r.nextDouble() * 0.15))
            fin.add(note(i * 2, midi, t, 0.5, 0.9, ValidationState.VALIDATED))
            t += 0.9
            if (r.nextDouble() < ghostRate) eng.add(note(i * 2 + 1, 70 + r.nextInt(5), t - 0.35, 0.07 + r.nextDouble() * 0.05, 0.5 + r.nextDouble() * 0.15)) // ghost, user deletes it
        }
        return ContributionBuilder.build("s$seed", tr(*eng.toTypedArray()), tr(*fin.toTypedArray()))
    }

    @Test fun profileLearnsToDistrustGhostNotes() {
        val few = VoiceProfile.build(listOf(session(1, 0.5)))
        val many = VoiceProfile.build((1L..8L).map { session(it, 0.5) })
        val ghost = note(1, 71, 1.0, 0.09, 0.55)
        val real = note(2, 60, 2.0, 0.6, 0.85)
        println("maturity few ${"%.2f".format(few.maturity)} many ${"%.2f".format(many.maturity)}; restBias many ${"%.2f".format(many.decoder.restBias)}")
        assertTrue("real note must be accepted", many.looksReal(real))
        assertTrue("ghost must be rejected after learning", !many.looksReal(ghost))
        assertTrue(many.maturity > few.maturity)
        assertTrue("silence gets more likely when ghosts keep being deleted", many.decoder.restBias > few.decoder.restBias)
    }

    @Test fun pitchRangePriorFollowsTheSingerAndNeedsEvidence() {
        val little = VoiceProfile.build(listOf(session(1, 0.0).let { c -> Contribution("x", emptyList(), IntArray(88).also { it[10] = 3 }, 3, 0, 0, 0, 0, 3) }))
        assertNull(little.decoder.keyLogPrior)
        val p = VoiceProfile.build((1L..4L).map { session(it, 0.0) })
        val prior = p.decoder.keyLogPrior!!
        assertTrue("used pitch ${prior[60 - 21]} vs far pitch ${prior[90 - 21]}", prior[60 - 21] > prior[90 - 21] + 0.5)
    }

    @Test fun overSplittingMakesCutsRarer() {
        val engine = tr(*(0 until 40).map { note(it, 60, it * 0.3, 0.3, 0.9) }.toTypedArray())
        // user merges every pair
        val final = tr(*(0 until 20).map { note(it, 60, it * 1.2, 0.6, 0.9) }.toTypedArray())
        val p = VoiceProfile.build(List(4) { ContributionBuilder.build("m$it", engine, final) })
        assertTrue("strong ${p.decoder.strongOnset}", p.decoder.strongOnset > DecoderParams().strongOnset)
    }
}
