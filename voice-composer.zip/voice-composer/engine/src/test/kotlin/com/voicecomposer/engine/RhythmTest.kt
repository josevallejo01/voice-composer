package com.voicecomposer.engine

import com.voicecomposer.engine.rhythm.RhythmGrid
import com.voicecomposer.engine.rhythm.TempoEstimator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random
import kotlin.math.abs

class RhythmTest {
    private fun truthStarts(): List<Double> {
        // Eighths and quarters with a few sixteenths; positions in beats.
        val steps = listOf(1.0, 0.5, 0.5, 1.0, 0.5, 0.5, 0.25, 0.25, 0.5, 1.0, 1.0, 0.5, 0.5, 2.0, 1.0, 0.5, 0.5, 1.0, 1.0)
        val out = ArrayList<Double>(); var t = 0.0
        for (s in steps) { out.add(t); t += s }
        return out
    }

    @Test fun jointPlacementBeatsIndependentRounding() {
        val rnd = Random(5)
        val bpm = 100.0
        var dp = 0; var plain = 0; var total = 0
        repeat(40) {
            val truth = truthStarts()
            // A performer who is 55 ms random and sometimes drifts late: the realistic hard case.
            val raw = truth.map { it + (rnd.nextGaussian() * 0.055 + 0.01) * bpm / 60.0 }
            val placed = RhythmGrid.place(raw, bpm, 4.0)
            for (i in truth.indices) {
                total++
                if (abs(placed[i] - truth[i]) < 1e-9) dp++
                if (abs(RhythmGrid.snap(raw[i]) - truth[i]) < 1e-9) plain++
            }
        }
        println("placement accuracy: DP ${"%.3f".format(dp.toDouble() / total)} vs rounding ${"%.3f".format(plain.toDouble() / total)}")
        assertTrue("DP $dp vs rounding $plain", dp >= plain)
        assertTrue(dp.toDouble() / total > 0.85)
    }

    @Test fun phaseIsFoundDespiteSoundLatency() {
        val bpm = 90.0; val beat = 60.0 / bpm
        val nominal = 4 * beat           // count-in of one bar
        val latency = 0.11               // the click reached the singer (and the recording) later than scheduled
        val onsets = truthStarts().map { nominal + latency + it * beat + 0.01 }
        val e = TempoEstimator.withKnownTempo(onsets, bpm, nominal)
        println("origin ${e.map.originSec} expected ${nominal + latency + 0.01}")
        assertEquals(nominal + latency + 0.01, e.map.originSec, 0.02)
        assertEquals(bpm, e.bpm, 1e-9)
        assertTrue(e.map.isConstant)
    }

    @Test fun phaseWithoutHintKeepsFirstNoteInFirstBeat() {
        val bpm = 120.0; val beat = 0.5
        val onsets = truthStarts().map { 1.37 + it * beat }
        val e = TempoEstimator.withKnownTempo(onsets, bpm, null)
        val b = e.map.secToBeat(onsets[0])
        assertTrue("first onset at beat $b", b > -0.2 && b < 1.0)
        val frac = e.map.secToBeat(onsets[3]) - b
        assertEquals(truthStarts()[3], frac, 0.06)
    }

    @Test fun knownTempoPipelineGivesExactBeatPositions() {
        val spec = listOf(60 to 1.0, 62 to 0.5, 64 to 0.5, 65 to 1.0, 67 to 2.0, 64 to 1.0, 60 to 1.0, 62 to 1.0, 55 to 2.0)
        val bpm = 84.0
        val notes = SyntheticVoice.melody(spec, bpm, startSec = 4 * 60.0 / bpm + 0.08, gap = 0.05, jitterSec = 0.03)
        val audio = SyntheticVoice.render(notes, noise = 0.002)
        val cfg = AnalysisConfig(forcedBpm = bpm, beatOriginHintSec = 4 * 60.0 / bpm, forcedTimeSignature = com.voicecomposer.model.TimeSignature.FOUR_FOUR)
        val r = DefaultTranscriptionEngine().analyze(audio, cfg)
        val starts = r.transcription.notes.map { it.startBeat }
        var t = 0.0; val expected = ArrayList<Double>()
        for ((_, b) in spec) { expected.add(t); t += b }
        println("beats $starts")
        val hits = starts.zip(expected).count { abs(it.first - it.second) < 0.01 }
        assertTrue("only $hits of ${expected.size} on the right beat: $starts", hits >= expected.size - 1)
        assertEquals("4/4", r.transcription.timeSignature.toString())
    }
}
