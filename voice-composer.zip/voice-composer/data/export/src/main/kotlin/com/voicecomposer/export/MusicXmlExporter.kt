package com.voicecomposer.export

import com.voicecomposer.model.Clef
import com.voicecomposer.model.Mode
import com.voicecomposer.model.NotationBuilder
import com.voicecomposer.model.NotationNote
import com.voicecomposer.model.NotationRest
import com.voicecomposer.model.Syllabic
import com.voicecomposer.model.TICKS_PER_QUARTER
import com.voicecomposer.model.Transcription
import kotlin.math.floor

/**
 * MusicXML 3.1 (score-partwise) export of the transcription: notes, durations (with ties across barlines), rests,
 * clef, key, time signature, tempo (including tempo changes) and lyrics.
 */
object MusicXmlExporter {
    fun export(t: Transcription, title: String = "Untitled", composer: String? = null): String {
        val n = NotationBuilder.build(t)
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<!DOCTYPE score-partwise PUBLIC \"-//Recordare//DTD MusicXML 3.1 Partwise//EN\" \"http://www.musicxml.org/dtds/partwise.dtd\">\n")
        sb.append("<score-partwise version=\"3.1\">\n")
        sb.append("  <work><work-title>").append(esc(title)).append("</work-title></work>\n")
        sb.append("  <identification>\n")
        if (!composer.isNullOrBlank()) sb.append("    <creator type=\"composer\">").append(esc(composer)).append("</creator>\n")
        sb.append("    <encoding><software>Voice Composer</software></encoding>\n")
        sb.append("  </identification>\n")
        sb.append("  <part-list><score-part id=\"P1\"><part-name>Melody</part-name></score-part></part-list>\n")
        sb.append("  <part id=\"P1\">\n")

        val mTicks = n.measureTicks
        // Tempo directions by measure: (tick inside measure, bpm).
        val tempoByMeasure = HashMap<Int, MutableList<Pair<Int, Double>>>()
        for ((beat, bpm) in n.tempoChanges) {
            val tick = Math.round(beat * TICKS_PER_QUARTER).toInt()
            val m = (tick / mTicks).coerceAtMost(n.measures.size - 1)
            tempoByMeasure.getOrPut(m) { ArrayList() }.add((tick - m * mTicks).coerceAtLeast(0) to bpm)
        }
        if (n.tempoChanges.isEmpty()) tempoByMeasure.getOrPut(0) { ArrayList() }.add(0 to n.bpm)

        for ((mi, m) in n.measures.withIndex()) {
            sb.append("    <measure number=\"").append(mi + 1).append("\">\n")
            if (mi == 0) {
                sb.append("      <attributes>\n")
                sb.append("        <divisions>").append(TICKS_PER_QUARTER).append("</divisions>\n")
                sb.append("        <key><fifths>").append(n.key.fifths).append("</fifths><mode>")
                    .append(if (n.key.mode == Mode.MINOR) "minor" else "major").append("</mode></key>\n")
                sb.append("        <time><beats>").append(n.timeSignature.numerator).append("</beats><beat-type>")
                    .append(n.timeSignature.denominator).append("</beat-type></time>\n")
                if (n.clef == Clef.BASS) sb.append("        <clef><sign>F</sign><line>4</line></clef>\n")
                else sb.append("        <clef><sign>G</sign><line>2</line></clef>\n")
                sb.append("      </attributes>\n")
            }
            val pending = (tempoByMeasure[mi] ?: mutableListOf<Pair<Int, Double>>()).sortedBy { it.first }.toMutableList()
            for (item in m.items) {
                while (pending.isNotEmpty() && pending.first().first <= item.startTick) tempo(sb, pending.removeAt(0).second)
                when (item) {
                    is NotationRest -> {
                        sb.append("      <note><rest/><duration>").append(item.ticks).append("</duration><voice>1</voice><type>")
                            .append(item.type.xmlName).append("</type>")
                        repeat(item.dots) { sb.append("<dot/>") }
                        sb.append("</note>\n")
                    }
                    is NotationNote -> note(sb, item)
                }
            }
            for (p in pending) tempo(sb, p.second)
            if (mi == n.measures.size - 1) sb.append("      <barline location=\"right\"><bar-style>light-heavy</bar-style></barline>\n")
            sb.append("    </measure>\n")
        }
        sb.append("  </part>\n</score-partwise>\n")
        return sb.toString()
    }

    private fun tempo(sb: StringBuilder, bpm: Double) {
        val v = Math.round(bpm * 10) / 10.0
        sb.append("      <direction placement=\"above\"><direction-type><metronome><beat-unit>quarter</beat-unit><per-minute>")
            .append(fmt(v)).append("</per-minute></metronome></direction-type><sound tempo=\"").append(fmt(v)).append("\"/></direction>\n")
    }

    private fun note(sb: StringBuilder, nn: NotationNote) {
        sb.append("      <note><pitch><step>").append(nn.spelling.step).append("</step>")
        if (nn.spelling.alter != 0) sb.append("<alter>").append(nn.spelling.alter).append("</alter>")
        sb.append("<octave>").append(nn.spelling.octave).append("</octave></pitch>")
        sb.append("<duration>").append(nn.ticks).append("</duration>")
        if (nn.tieFromPrevious) sb.append("<tie type=\"stop\"/>")
        if (nn.tieToNext) sb.append("<tie type=\"start\"/>")
        sb.append("<voice>1</voice><type>").append(nn.type.xmlName).append("</type>")
        repeat(nn.dots) { sb.append("<dot/>") }
        if (nn.tieFromPrevious || nn.tieToNext) {
            sb.append("<notations>")
            if (nn.tieFromPrevious) sb.append("<tied type=\"stop\"/>")
            if (nn.tieToNext) sb.append("<tied type=\"start\"/>")
            sb.append("</notations>")
        }
        val l = nn.lyric
        if (l != null) {
            val syl = when (l.syllabic) {
                Syllabic.SINGLE -> "single"; Syllabic.BEGIN -> "begin"; Syllabic.MIDDLE -> "middle"; Syllabic.END -> "end"
            }
            sb.append("<lyric number=\"1\"><syllabic>").append(syl).append("</syllabic><text>").append(esc(l.text)).append("</text></lyric>")
        }
        sb.append("</note>\n")
    }

    private fun fmt(v: Double) = if (v == floor(v)) v.toInt().toString() else v.toString()

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
}
