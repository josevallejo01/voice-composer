package com.voicecomposer.export

import com.voicecomposer.model.Arrangement
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.NotationBuilder
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import com.voicecomposer.model.Transcription
import java.io.ByteArrayOutputStream

/**
 * Standard MIDI File (format 1, 480 PPQ): a conductor track with tempo changes, time and key signature, plus one track
 * per melody / arrangement track with program changes. Tempo changes of the tempo map are preserved.
 */
object MidiExporter {
    const val PPQ = 480

    fun export(t: Transcription, arrangement: Arrangement? = null, title: String = "Voice Composer"): ByteArray {
        val tracks: List<Track> = arrangement?.tracks?.filter { it.enabled }
            ?: listOf(Track("melody", "Melody", Instrument.PIANO, TrackRole.MELODY, t.notes))
        val chunks = ArrayList<ByteArray>()
        chunks.add(conductor(t, title))
        var channel = 0
        for (tr in tracks) {
            if (channel == 9) channel++
            chunks.add(noteTrack(tr, channel.coerceAtMost(15)))
            channel++
        }
        val out = ByteArrayOutputStream()
        out.write("MThd".toByteArray()); out.write(int32(6)); out.write(int16(1)); out.write(int16(chunks.size)); out.write(int16(PPQ))
        for (c in chunks) { out.write("MTrk".toByteArray()); out.write(int32(c.size)); out.write(c) }
        return out.toByteArray()
    }

    private fun conductor(t: Transcription, title: String): ByteArray {
        val o = ByteArrayOutputStream()
        meta(o, 0, 0x03, title.toByteArray(Charsets.UTF_8))
        val ts = t.timeSignature
        val dd = when (ts.denominator) { 2 -> 1; 4 -> 2; 8 -> 3; 16 -> 4; else -> 2 }
        meta(o, 0, 0x58, byteArrayOf(ts.numerator.toByte(), dd.toByte(), 24, 8))
        meta(o, 0, 0x59, byteArrayOf(t.key.fifths.toByte(), if (t.key.mode == com.voicecomposer.model.Mode.MINOR) 1 else 0))
        var last = 0
        for ((beat, bpm) in t.tempoMap.changes) {
            val tick = Math.round(beat * PPQ).toInt()
            val us = Math.round(60_000_000.0 / bpm).toInt()
            meta(o, (tick - last).coerceAtLeast(0), 0x51, byteArrayOf((us shr 16).toByte(), (us shr 8).toByte(), us.toByte()))
            last = maxOf(last, tick)
        }
        meta(o, 0, 0x2F, ByteArray(0))
        return o.toByteArray()
    }

    private data class Msg(val tick: Int, val order: Int, val status: Int, val d1: Int, val d2: Int)

    private fun noteTrack(tr: Track, channel: Int): ByteArray {
        val msgs = ArrayList<Msg>()
        val vel = (95 * tr.volume).toInt().coerceIn(1, 127)
        for (e: MusicalEvent in tr.events) {
            if (!e.isNote || e.midiPitch == null) continue
            val on = Math.round(e.startBeat * PPQ).toInt()
            val off = Math.round(e.endBeat * PPQ).toInt().coerceAtLeast(on + 1)
            msgs.add(Msg(on, 1, 0x90 or channel, e.midiPitch!!, vel))
            msgs.add(Msg(off, 0, 0x80 or channel, e.midiPitch!!, 0))
        }
        msgs.sortWith(compareBy({ it.tick }, { it.order }))
        val o = ByteArrayOutputStream()
        meta(o, 0, 0x03, tr.name.toByteArray(Charsets.UTF_8))
        vlq(o, 0); o.write(0xC0 or channel); o.write(tr.instrument.gmProgram)
        var last = 0
        for (m in msgs) {
            vlq(o, m.tick - last); o.write(m.status); o.write(m.d1); o.write(m.d2)
            last = m.tick
        }
        meta(o, 0, 0x2F, ByteArray(0))
        return o.toByteArray()
    }

    private fun meta(o: ByteArrayOutputStream, delta: Int, type: Int, data: ByteArray) {
        vlq(o, delta); o.write(0xFF); o.write(type); vlq(o, data.size); o.write(data)
    }

    private fun vlq(o: ByteArrayOutputStream, value: Int) {
        var v = value.coerceAtLeast(0)
        val bytes = ArrayList<Int>()
        bytes.add(v and 0x7F)
        v = v shr 7
        while (v > 0) { bytes.add((v and 0x7F) or 0x80); v = v shr 7 }
        for (i in bytes.indices.reversed()) o.write(bytes[i])
    }

    private fun int32(v: Int) = byteArrayOf((v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte())
    private fun int16(v: Int) = byteArrayOf((v shr 8).toByte(), v.toByte())

    @Suppress("unused")
    private fun measureTicks(t: Transcription) = NotationBuilder.measureTicks(t.timeSignature)
}
