package com.voicecomposer.export

import com.voicecomposer.model.Arrangement
import com.voicecomposer.model.ArrangementStyle
import com.voicecomposer.model.EventSource
import com.voicecomposer.model.EventType
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import com.voicecomposer.model.MusicalEvent
import com.voicecomposer.model.Pitch
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TempoPoint
import com.voicecomposer.model.TimeSignature
import com.voicecomposer.model.Track
import com.voicecomposer.model.TrackRole
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.TranscriptionEditor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.w3c.dom.Element
import org.w3c.dom.Node
import javax.xml.parsers.DocumentBuilderFactory

private fun note(id: String, midi: Int, start: Double, dur: Double, map: TempoMap) = MusicalEvent(
    id, EventType.NOTE, midi, Pitch.midiToHz(midi), map.beatToSec(start), map.beatToSec(start + dur), start, dur, 1.0, EventSource.USER,
)

private fun sample(ts: TimeSignature = TimeSignature.FOUR_FOUR, key: KeySignature = KeySignature(7, Mode.MAJOR), map: TempoMap = TempoMap.constant(96.0)): Transcription {
    val ns = listOf(
        note("a", 67, 0.0, 1.0, map), note("b", 69, 1.0, 1.0, map), note("c", 66, 2.0, 2.5, map), // F# crosses the barline
        note("d", 71, 5.0, 0.5, map), note("e", 74, 6.0, 3.0, map),
    )
    var t = Transcription(ns, map, ts, key).normalized()
    t = TranscriptionEditor.setLyric(t, "a", "A & B")
    return t
}

private fun parse(xml: String) = DocumentBuilderFactory.newInstance().also {
    it.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
}.newDocumentBuilder().parse(xml.byteInputStream())

private fun Element.kids(name: String): List<Element> {
    val out = ArrayList<Element>()
    var c: Node? = firstChild
    while (c != null) { if (c is Element && c.tagName == name) out.add(c); c = c.nextSibling }
    return out
}

private fun Element.text(name: String): String? = getElementsByTagName(name).item(0)?.textContent

class MusicXmlTest {
    @Test fun wellFormedAndComplete() {
        val t = sample()
        val doc = parse(MusicXmlExporter.export(t, "Test <song>", "Me & You"))
        val root = doc.documentElement
        assertEquals("score-partwise", root.tagName)
        assertEquals("Test <song>", root.text("work-title"))
        val part = root.kids("part").single()
        val measures = part.kids("measure")
        assertTrue(measures.size >= 3)
        // key, time, clef, divisions, tempo
        val attrs = measures[0].kids("attributes").single()
        assertEquals("1", attrs.text("fifths"))
        assertEquals("major", attrs.text("mode"))
        assertEquals("4", attrs.text("beats"))
        assertEquals("G", attrs.text("sign"))
        assertEquals("4", attrs.text("divisions"))
        assertEquals("96", measures[0].getElementsByTagName("per-minute").item(0).textContent)
        // every measure is exactly full
        for (m in measures) {
            val total = m.kids("note").sumOf { it.text("duration")!!.toInt() }
            assertEquals(16, total)
        }
        // pitches: F# in G major is spelled F# with alter 1 and appears tied across the barline
        val notes = measures.flatMap { it.kids("note") }.filter { it.getElementsByTagName("rest").length == 0 }
        val fSharps = notes.filter { it.text("step") == "F" }
        assertTrue(fSharps.isNotEmpty() && fSharps.all { it.text("alter") == "1" })
        val tieStarts = notes.count { n -> n.kids("tie").any { it.getAttribute("type") == "start" } }
        val tieStops = notes.count { n -> n.kids("tie").any { it.getAttribute("type") == "stop" } }
        assertTrue(tieStarts >= 1)
        assertEquals(tieStarts, tieStops)
        // lyric
        assertEquals("A & B", notes.first().text("text"))
        // number of sounding pitches after merging ties equals the number of notes
        assertEquals(5, notes.size - tieStops)
    }

    @Test fun threeFourAndMinorKeyAndBassClef() {
        val map = TempoMap.constant(80.0)
        val ns = listOf(note("a", 43, 0.0, 3.0, map), note("b", 45, 3.0, 1.0, map), note("c", 47, 4.0, 2.0, map))
        val t = Transcription(ns, map, TimeSignature.THREE_FOUR, KeySignature(9, Mode.MINOR)).normalized()
        val root = parse(MusicXmlExporter.export(t)).documentElement
        val m = root.kids("part").single().kids("measure")
        assertEquals("F", m[0].text("sign"))
        assertEquals("minor", m[0].text("mode"))
        for (x in m) assertEquals(12, x.kids("note").sumOf { it.text("duration")!!.toInt() })
        assertEquals("1", m[0].kids("note")[0].getElementsByTagName("dot").length.toString())
    }

    @Test fun tempoChangesAreExported() {
        val map = TempoMap(listOf(TempoPoint(0.0, 0.0), TempoPoint(8.0, 5.0)), 120.0) // 96 bpm then 120 bpm
        val t = sample(map = map)
        val xml = MusicXmlExporter.export(t)
        val doc = parse(xml)
        val tempos = doc.getElementsByTagName("per-minute")
        assertEquals(2, tempos.length)
        assertEquals("96", tempos.item(0).textContent)
        assertEquals("120", tempos.item(1).textContent)
    }
}

class MidiTest {
    private data class Parsed(val format: Int, val tracks: Int, val ppq: Int, val chunks: List<ByteArray>)

    private fun parse(b: ByteArray): Parsed {
        fun i32(p: Int) = ((b[p].toInt() and 255) shl 24) or ((b[p + 1].toInt() and 255) shl 16) or ((b[p + 2].toInt() and 255) shl 8) or (b[p + 3].toInt() and 255)
        fun i16(p: Int) = ((b[p].toInt() and 255) shl 8) or (b[p + 1].toInt() and 255)
        assertEquals("MThd", String(b, 0, 4))
        val n = i16(10)
        var p = 14
        val chunks = ArrayList<ByteArray>()
        repeat(n) {
            assertEquals("MTrk", String(b, p, 4))
            val len = i32(p + 4)
            chunks.add(b.copyOfRange(p + 8, p + 8 + len))
            p += 8 + len
        }
        assertEquals(b.size, p)
        return Parsed(i16(8), n, i16(12), chunks)
    }

    /** Returns absolute tick of each note-on with its pitch, plus tempo meta events (tick, microseconds). */
    private fun events(chunk: ByteArray): Pair<List<Pair<Int, Int>>, List<Pair<Int, Int>>> {
        var p = 0
        var tick = 0
        val ons = ArrayList<Pair<Int, Int>>()
        val tempos = ArrayList<Pair<Int, Int>>()
        while (p < chunk.size) {
            var delta = 0
            while (true) { val x = chunk[p++].toInt() and 255; delta = (delta shl 7) or (x and 0x7F); if (x < 0x80) break }
            tick += delta
            val st = chunk[p++].toInt() and 255
            when {
                st == 0xFF -> {
                    val type = chunk[p++].toInt() and 255
                    var len = 0
                    while (true) { val x = chunk[p++].toInt() and 255; len = (len shl 7) or (x and 0x7F); if (x < 0x80) break }
                    if (type == 0x51) tempos.add(tick to (((chunk[p].toInt() and 255) shl 16) or ((chunk[p + 1].toInt() and 255) shl 8) or (chunk[p + 2].toInt() and 255)))
                    p += len
                }
                (st and 0xF0) == 0x90 -> { ons.add(tick to (chunk[p].toInt() and 255)); p += 2 }
                (st and 0xF0) == 0x80 -> p += 2
                (st and 0xF0) == 0xC0 -> p += 1
                else -> error("unexpected status $st")
            }
        }
        return ons to tempos
    }

    @Test fun melodyOnlyFile() {
        val t = sample()
        val m = parse(MidiExporter.export(t))
        assertEquals(1, m.format)
        assertEquals(480, m.ppq)
        assertEquals(2, m.tracks) // conductor + melody
        val (ons, _) = events(m.chunks[1])
        assertEquals(listOf(67, 69, 66, 71, 74), ons.map { it.second })
        assertEquals(listOf(0, 480, 960, 2400, 2880), ons.map { it.first })
        val (_, tempos) = events(m.chunks[0])
        assertEquals(listOf(0 to 625000), tempos) // 96 bpm
    }

    @Test fun arrangementAndTempoChanges() {
        val map = TempoMap(listOf(TempoPoint(0.0, 0.0), TempoPoint(8.0, 5.0)), 120.0)
        val t = sample(map = map)
        val bass = Track("bass", "Bass", Instrument.ELECTRIC_BASS, TrackRole.BASS, listOf(note("x", 43, 0.0, 4.0, map)))
        val off = bass.copy(id = "off", enabled = false)
        val arr = Arrangement("a", 1, ArrangementStyle.POP, 1, emptyList(), listOf(Track("melody", "Melody", Instrument.LEAD, TrackRole.MELODY, t.notes), bass, off))
        val m = parse(MidiExporter.export(t, arr))
        assertEquals(3, m.tracks) // conductor + melody + bass (disabled track skipped)
        val (_, tempos) = events(m.chunks[0])
        assertEquals(listOf(0 to 625000, 3840 to 500000), tempos)
        assertTrue(events(m.chunks[2]).first.single().second == 43)
    }
}
