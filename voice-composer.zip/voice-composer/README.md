# Voice Composer

Turn a sung, hummed or whistled melody into an **editable score**, then optionally let the app add an accompaniment.
Android (Kotlin, Jetpack Compose), offline-first: recordings and scores never leave the device.

The app is **English by default**, with a French translation (`values-fr`). Language follows the system or the
per-app language setting.

> **Status: first working version (0.1.0).** The analysis engine, music model and exporters are covered by 55 JVM
> unit tests. The Android UI layer was written without access to an Android SDK and has **not been compiled or run
> yet**: expect to fix a few compile errors on the first build. See [docs/STATUS.md](docs/STATUS.md).

## What it does

1. **Capture**: record with the microphone (48 kHz mono, pause/resume, live waveform) or import WAV/MP3/AAC/FLAC.
2. **Analyse** (on device, cancellable, runs in the background): pitch tracking, note segmentation, tempo and beat
   tracking, quantisation, time signature and key estimation. Notes the engine is unsure about are flagged.
3. **Edit**: tap a note to change pitch/length, split, merge, delete, add lyrics, draw notes on the staff, use a
   virtual keyboard, undo/redo (200 steps), compare the recording with the synthesised melody. Tempo, time
   signature, key and quantisation mode can all be overridden. Every edit is autosaved.
4. **Arrange** (optional): chords, bass and accompaniment in three styles and three complexity levels. The melody is
   never modified; each arrangement is a separate saved version.
5. **Export**: PDF (A4, paginated), MusicXML 3.1, MIDI (format 1, with tempo changes).

## Build

Requirements: JDK 17, Android SDK (compileSdk 35). Android Studio Ladybug or newer works out of the box.

```bash
./gradlew test            # JVM tests: music model, engine, exporters
./gradlew assembleDebug   # app/build/outputs/apk/debug/app-debug.apk
./gradlew connectedAndroidTest   # Room DAO tests (device or emulator needed)
```

Pushing to GitHub runs [.github/workflows/android.yml](.github/workflows/android.yml), which runs the tests and
uploads the debug APK as a build artifact.

## Project layout

| Module | Kind | Content |
|---|---|---|
| `:core:music-model` | pure Kotlin | Notes, tempo map, key/meter, notation builder, edit operations with undo/redo, JSON persistence, score layout |
| `:engine` | pure Kotlin | WAV I/O, resampling, YIN pitch tracker, segmentation, tempo/beat tracking, quantiser, meter and key estimation, synthesiser, arrangement |
| `:data:export` | pure Kotlin | MusicXML and MIDI writers |
| `:app` | Android | Compose UI, Room, DataStore, Hilt, recorder, importer, playback, PDF export |

The three pure-Kotlin modules have no Android dependency, so the whole analysis pipeline is unit-tested on the JVM
with synthetic voices (known pitches, tempos, vibrato, detuning, tempo drift, noise). More in
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Privacy

No `INTERNET` permission, no analytics, no crash reporting, no ads. Recordings are stored in the app's private
directory and excluded from Android backups. Settings → Privacy deletes all recordings or all data.

## Known limits

Read [docs/STATUS.md](docs/STATUS.md) for the full list. The main ones: sixteenth-note grid only (no triplets,
no beams), monophonic input only, no automatic lyrics recognition, synthesised sounds rather than sampled
instruments, no library search/tags, no subscription/billing code.

## Licence

No licence has been chosen yet. Add a `LICENSE` file before publishing; until then the default is
"all rights reserved".
