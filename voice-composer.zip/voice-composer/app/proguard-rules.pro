# Room / Hilt ship their own consumer rules. Nothing app specific is needed:
# the persistence layer stores JSON written by the music model, no reflection is involved.

# ONNX Runtime calls back into its Java classes from native code.
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**
