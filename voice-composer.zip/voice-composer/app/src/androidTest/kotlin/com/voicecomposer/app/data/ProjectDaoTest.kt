package com.voicecomposer.app.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProjectDaoTest {
    private lateinit var db: AppDatabase

    @Before fun open() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries().build()
    }

    @After fun close() = db.close()

    private fun project(id: String, status: String = ProjectStatus.RECORDED) = ProjectEntity(
        id = id, title = "t$id", createdAt = 1, modifiedAt = 1, inputType = "HUMMING", audioPath = "/x/$id.wav",
        sampleRate = 44100, channels = 1, durationMs = 1000, audioFormat = "WAV", status = status, lastError = null,
        workingJson = null, version = 0,
    )

    @Test fun insertAndReadBack() = runBlocking {
        db.projects().upsert(project("a"))
        assertEquals("ta", db.projects().get("a")?.title)
        assertEquals(1, db.projects().observeAll().first().size)
    }

    @Test fun interruptedAnalysisBecomesRestartable() = runBlocking {
        db.projects().upsert(project("a", ProjectStatus.ANALYZING))
        db.projects().upsert(project("b", ProjectStatus.ANALYZED))
        db.projects().resetInterrupted()
        assertEquals(ProjectStatus.RECORDED, db.projects().get("a")?.status)
        assertEquals(ProjectStatus.ANALYZED, db.projects().get("b")?.status)
    }

    @Test fun deletingProjectCascadesToRunsAndArrangements() = runBlocking {
        db.projects().upsert(project("a"))
        db.analyses().insert(AnalysisRunEntity("r1", "a", "dsp-1.0", 1, "ENGINE", "{}", 0.9, "{}"))
        db.arrangements().upsert(ArrangementEntity("x1", "a", 1, 1, "POP", "{}"))
        db.projects().delete("a")
        assertNull(db.projects().get("a"))
        assertEquals(0, db.analyses().forProject("a").size)
        assertNull(db.arrangements().get("x1"))
    }

    @Test fun workingVersionIsSavedAndRenamed() = runBlocking {
        db.projects().upsert(project("a"))
        db.projects().saveWorking("a", "{\"v\":1}", 5)
        db.projects().rename("a", "New name", 6)
        val p = db.projects().get("a")!!
        assertEquals("{\"v\":1}", p.workingJson)
        assertEquals("New name", p.title)
        assertEquals(6L, p.modifiedAt)
    }
}
