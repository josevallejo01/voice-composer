package com.voicecomposer.app.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import com.voicecomposer.engine.io.StreamingWavWriter
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs
import kotlin.math.max

enum class RecorderState { IDLE, RECORDING, PAUSED }

enum class RecorderError { NO_PERMISSION, INIT_FAILED, READ_FAILED }

data class RecorderUiState(
    val state: RecorderState = RecorderState.IDLE,
    val elapsedMs: Long = 0,
    /** Rolling peak levels 0..1 for the live waveform. */
    val levels: List<Float> = emptyList(),
    val error: RecorderError? = null,
    /** True when the recording was paused by the system (call, other app took audio focus). */
    val interrupted: Boolean = false,
)

data class RecordingResult(val file: File, val sampleRate: Int, val durationMs: Long)

/**
 * Captures the microphone with AudioRecord (spec 5.1): 48 kHz mono PCM16 when the device allows it, otherwise the best
 * available rate. Samples are streamed to a WAV file on an IO coroutine, never on the main thread, and the original
 * is never processed or overwritten. Audio focus loss (phone call, another app) pauses the recording.
 */
@Singleton
class AudioRecorder @Inject constructor(@ApplicationContext private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _ui = MutableStateFlow(RecorderUiState())
    val ui: StateFlow<RecorderUiState> = _ui

    private var record: AudioRecord? = null
    private var writer: StreamingWavWriter? = null
    private var job: Job? = null
    private var file: File? = null
    private var rate = 48000
    @Volatile private var paused = false
    @Volatile private var stopRequested = false
    private var samplesWritten = 0L
    private var focusRequest: AudioFocusRequest? = null

    companion object { const val MAX_BINS = 240 }

    private val audioManager get() = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @SuppressLint("MissingPermission") // the screen requests RECORD_AUDIO before calling start()
    @Synchronized
    fun start(target: File): Boolean {
        if (_ui.value.state != RecorderState.IDLE) return false
        var created: AudioRecord? = null
        var chosen = 0
        for (r in intArrayOf(48000, 44100, 32000, 16000)) {
            val min = AudioRecord.getMinBufferSize(r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) continue
            val buf = max(min, r / 5 * 2)
            for (src in sources()) {
                val rec = runCatching {
                    AudioRecord(src, r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf)
                }.getOrNull() ?: continue
                if (rec.state == AudioRecord.STATE_INITIALIZED) { created = rec; chosen = r; break } else rec.release()
            }
            if (created != null) break
        }
        val rec = created ?: run {
            _ui.value = RecorderUiState(error = RecorderError.INIT_FAILED)
            return false
        }
        rate = chosen
        record = rec
        file = target
        writer = StreamingWavWriter(target, rate)
        samplesWritten = 0
        paused = false
        stopRequested = false
        requestFocus()
        rec.startRecording()
        _ui.value = RecorderUiState(state = RecorderState.RECORDING)
        job = scope.launch { captureLoop(rec) }
        return true
    }

    private fun sources(): List<Int> {
        val list = ArrayList<Int>()
        val unprocessed = audioManager.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"
        if (unprocessed) list.add(MediaRecorder.AudioSource.UNPROCESSED)
        list.add(MediaRecorder.AudioSource.VOICE_RECOGNITION)
        list.add(MediaRecorder.AudioSource.MIC)
        return list
    }

    private suspend fun captureLoop(rec: AudioRecord) {
        val buf = ShortArray(rate / 50) // 20 ms
        // The waveform always shows the whole take: at most MAX_BINS bars, merged pairwise (bar width doubles) when full.
        val levels = ArrayList<Float>()
        var binSamples = rate / 20 // 50 ms per bar to start with
        var peak = 0
        var acc = 0
        var lastFlush = System.currentTimeMillis()
        while (scopeActive() && !stopRequested) {
            if (paused) { delay(30); continue }
            val n = rec.read(buf, 0, buf.size)
            if (n < 0) {
                _ui.update { it.copy(error = RecorderError.READ_FAILED) }
                break
            }
            if (n == 0) continue
            writer?.write(buf, n)
            samplesWritten += n
            for (i in 0 until n) peak = max(peak, abs(buf[i].toInt()))
            acc += n
            if (acc >= binSamples) {
                levels.add((peak / 32768f).coerceIn(0f, 1f))
                if (levels.size > MAX_BINS) {
                    val merged = ArrayList<Float>(MAX_BINS / 2 + 1)
                    var i = 0
                    while (i < levels.size) { merged.add(if (i + 1 < levels.size) max(levels[i], levels[i + 1]) else levels[i]); i += 2 }
                    levels.clear(); levels.addAll(merged)
                    binSamples *= 2
                }
                peak = 0; acc = 0
                val snapshot = levels.toList()
                val elapsed = samplesWritten * 1000L / rate
                _ui.update { it.copy(elapsedMs = elapsed, levels = snapshot) }
            }
            val now = System.currentTimeMillis()
            if (now - lastFlush > 2000) { writer?.flushHeader(); lastFlush = now }
        }
    }

    private suspend fun scopeActive(): Boolean = kotlin.coroutines.coroutineContext[Job]?.isActive != false

    fun pause() {
        if (_ui.value.state != RecorderState.RECORDING) return
        paused = true
        runCatching { record?.stop() }
        _ui.update { it.copy(state = RecorderState.PAUSED) }
    }

    fun resume() {
        if (_ui.value.state != RecorderState.PAUSED) return
        runCatching { record?.startRecording() }
        paused = false
        _ui.update { it.copy(state = RecorderState.RECORDING, interrupted = false) }
    }

    /** Stops and finalises the file. The recording is complete and decodable when this returns. */
    suspend fun stop(): RecordingResult? {
        if (_ui.value.state == RecorderState.IDLE) return null
        stopRequested = true
        job?.join()
        val f = file
        val duration = samplesWritten * 1000L / rate
        release()
        _ui.value = RecorderUiState()
        return if (f != null && samplesWritten > 0) RecordingResult(f, rate, duration) else null
    }

    /** Stops and deletes the file (restart / leaving the screen). */
    suspend fun cancel() {
        if (_ui.value.state == RecorderState.IDLE) return
        stopRequested = true
        job?.join()
        val f = file
        release()
        f?.delete()
        _ui.value = RecorderUiState()
    }

    private fun release() {
        runCatching { record?.stop() }
        runCatching { record?.release() }
        runCatching { writer?.close() }
        record = null
        writer = null
        abandonFocus()
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            .setOnAudioFocusChangeListener { change ->
                if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    pause()
                    _ui.update { it.copy(interrupted = true) }
                }
            }
            .build()
        focusRequest = req
        audioManager.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    fun clearError() = _ui.update { it.copy(error = null) }
}
