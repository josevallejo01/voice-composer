package com.voicecomposer.app.ui.common

import java.util.Locale

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.ROOT, "%d:%02d", total / 60, total % 60)
}

fun formatTimeFine(ms: Long): String {
    val t = ms.coerceAtLeast(0)
    return String.format(Locale.ROOT, "%d:%02d.%d", t / 60000, (t / 1000) % 60, (t % 1000) / 100)
}
