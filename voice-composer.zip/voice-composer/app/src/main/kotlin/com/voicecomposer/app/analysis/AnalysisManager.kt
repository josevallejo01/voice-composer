package com.voicecomposer.app.analysis

import com.voicecomposer.app.data.AppSettings
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.data.ProjectStatus
import com.voicecomposer.app.data.SettingsStore
import com.voicecomposer.engine.AnalysisCancelled
import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.Stage
import com.voicecomposer.engine.TranscriptionEngine
import com.voicecomposer.engine.preprocessing.InputType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

data class AnalysisProgress(val stage: Stage, /** Overall progress 0..1. */ val fraction: Float)

/**
 * Runs analyses in an application scope: leaving the analysis screen does not lose or stop the work, and a cancelled
 * or interrupted analysis leaves the project in RECORDED state so it can simply be started again (spec 3.3).
 */
@Singleton
class AnalysisManager @Inject constructor(
    private val repository: ProjectRepository,
    private val engine: TranscriptionEngine,
    private val settings: SettingsStore,
    private val profileStore: com.voicecomposer.app.data.ProfileStore,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val jobs = ConcurrentHashMap<String, Job>()

    val progress = MutableStateFlow<Map<String, AnalysisProgress>>(emptyMap())

    fun isRunning(projectId: String) = jobs[projectId]?.isActive == true

    fun cancel(projectId: String) {
        jobs[projectId]?.cancel()
    }

    fun start(projectId: String, override: AnalysisConfig? = null) {
        if (isRunning(projectId)) return
        val job = scope.launch {
            val self = coroutineContext[Job]
            try {
                val project = repository.get(projectId) ?: return@launch
                val audio = repository.loadAudio(projectId)
                if (audio == null) {
                    repository.setStatus(projectId, ProjectStatus.FAILED, "NO_AUDIO")
                    return@launch
                }
                repository.setStatus(projectId, ProjectStatus.ANALYZING)
                val s: AppSettings = settings.settings.first()
                val meta = repository.loadMeta(projectId)
                val profile = if (s.voiceLearning) profileStore.current().takeIf { it.engineNotes > 0 } else null
                val config = override ?: AnalysisConfig(
                    inputType = runCatching { InputType.valueOf(project.inputType) }.getOrDefault(s.inputType),
                    quantization = s.quantization,
                    tuningCompensation = s.tuningCompensation,
                    useNeural = s.neuralEngine,
                    decoder = profile?.decoder ?: com.voicecomposer.engine.ml.DecoderParams(),
                    profile = profile,
                    forcedBpm = meta?.bpm,
                    beatOriginHintSec = meta?.originSec,
                    forcedTimeSignature = meta?.let { com.voicecomposer.model.TimeSignature(it.beatsPerBar, 4) },
                )
                val result = engine.analyze(
                    audio, config,
                    onProgress = { stage, f -> progress.update { it + (projectId to AnalysisProgress(stage, overall(stage, f))) } },
                    isCancelled = { self?.isActive == false },
                )
                repository.saveAnalysis(projectId, result, config)
            } catch (_: AnalysisCancelled) {
                repository.setStatus(projectId, ProjectStatus.RECORDED)
            } catch (e: kotlinx.coroutines.CancellationException) {
                repository.setStatus(projectId, ProjectStatus.RECORDED)
                throw e
            } catch (e: Throwable) {
                repository.setStatus(projectId, ProjectStatus.FAILED, e.message ?: e.javaClass.simpleName)
            } finally {
                progress.update { it - projectId }
                jobs.remove(projectId)
            }
        }
        jobs[projectId] = job
    }

    private fun overall(stage: Stage, f: Float): Float {
        val (from, span) = when (stage) {
            Stage.PREPROCESSING -> 0f to 0.05f
            Stage.PITCH -> 0.05f to 0.65f
            Stage.SEGMENTATION -> 0.70f to 0.10f
            Stage.TEMPO -> 0.80f to 0.08f
            Stage.RHYTHM -> 0.88f to 0.06f
            Stage.KEY -> 0.94f to 0.05f
            Stage.DONE -> 1f to 0f
        }
        return from + span * f
    }
}
