package com.voicecomposer.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.voicecomposer.app.ui.analysis.AnalysisScreen
import com.voicecomposer.app.ui.arrange.ArrangeScreen
import com.voicecomposer.app.ui.calibration.CalibrationScreen
import com.voicecomposer.app.ui.home.HomeScreen
import com.voicecomposer.app.ui.record.RecordScreen
import com.voicecomposer.app.ui.result.ResultScreen
import com.voicecomposer.app.ui.settings.SettingsScreen

object Routes {
    const val HOME = "home"
    const val RECORD = "record"
    const val SETTINGS = "settings"
    const val CALIBRATION = "calibration"
    const val ANALYSIS = "analysis/{id}"
    const val RESULT = "result/{id}"
    const val ARRANGE = "arrange/{id}"
    fun analysis(id: String) = "analysis/$id"
    fun result(id: String) = "result/$id"
    fun arrange(id: String) = "arrange/$id"
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val idArg = listOf(navArgument("id") { type = NavType.StringType })
    NavHost(nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onRecord = { nav.navigate(Routes.RECORD) },
                onOpen = { id, analyzed -> nav.navigate(if (analyzed) Routes.result(id) else Routes.analysis(id)) },
                onSettings = { nav.navigate(Routes.SETTINGS) },
            )
        }
        composable(Routes.RECORD) {
            RecordScreen(
                onBack = { nav.popBackStack() },
                onAnalyze = { id -> nav.navigate(Routes.analysis(id)) { popUpTo(Routes.HOME) } },
            )
        }
        composable(Routes.ANALYSIS, idArg) {
            AnalysisScreen(
                onBack = { nav.popBackStack(Routes.HOME, false) },
                onDone = { id -> nav.navigate(Routes.result(id)) { popUpTo(Routes.HOME) } },
            )
        }
        composable(Routes.RESULT, idArg) {
            ResultScreen(
                onBack = { nav.popBackStack() },
                onReanalyze = { id -> nav.navigate(Routes.analysis(id)) { popUpTo(Routes.HOME) } },
                onArrange = { id -> nav.navigate(Routes.arrange(id)) },
            )
        }
        composable(Routes.ARRANGE, idArg) { ArrangeScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.SETTINGS) { SettingsScreen(onBack = { nav.popBackStack() }, onCalibrate = { nav.navigate(Routes.CALIBRATION) }) }
        composable(Routes.CALIBRATION) { CalibrationScreen(onBack = { nav.popBackStack() }) }
    }
}
