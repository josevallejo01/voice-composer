package com.voicecomposer.app.export

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.voicecomposer.app.ui.score.ScorePainter
import com.voicecomposer.app.ui.score.ScorePalette
import com.voicecomposer.export.MidiExporter
import com.voicecomposer.export.MusicXmlExporter
import com.voicecomposer.model.Arrangement
import com.voicecomposer.model.NotationBuilder
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.layout.ScoreLayoutEngine
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

enum class ExportFormat(val extension: String, val mime: String) {
    PDF("pdf", "application/pdf"),
    MUSICXML("musicxml", "application/vnd.recordare.musicxml+xml"),
    MIDI("mid", "audio/midi"),
}

/**
 * Writes exports to the app cache (they are temporary copies) and hands them to the system share sheet through a
 * FileProvider. Nothing is uploaded by the app; where the file goes is the user's choice in the share sheet.
 */
@Singleton
class ExportService @Inject constructor(@ApplicationContext private val context: Context) {

    suspend fun export(format: ExportFormat, title: String, t: Transcription, arrangement: Arrangement? = null): Uri =
        withContext(Dispatchers.IO) {
            val dir = File(context.cacheDir, "exports").also { it.mkdirs() }
            // Old exports are only temporary copies.
            dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 3_600_000 }?.forEach { it.delete() }
            val file = File(dir, safeName(title) + "." + format.extension)
            when (format) {
                ExportFormat.PDF -> writePdf(file, title, t)
                ExportFormat.MUSICXML -> file.writeText(MusicXmlExporter.export(t, title), Charsets.UTF_8)
                ExportFormat.MIDI -> file.writeBytes(MidiExporter.export(t, arrangement, title))
            }
            FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        }

    fun share(context: Context, uri: Uri, format: ExportFormat, title: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = format.mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = android.content.ClipData.newRawUri(title, uri)
        }
        val chooser = Intent.createChooser(send, title)
        if (context !is android.app.Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    private fun safeName(title: String): String =
        title.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().replace(' ', '_').ifEmpty { "score" }.take(60)

    /** A4 pages, systems are never split across pages. */
    private fun writePdf(file: File, title: String, t: Transcription) {
        val pageW = 595
        val pageH = 842
        val margin = 40f
        val s = 5.2f
        val notation = NotationBuilder.build(t)
        val layout = ScoreLayoutEngine.layout(notation, pageW - 2 * margin, s)
        val painter = ScorePainter(ScorePalette(Color.BLACK, Color.BLACK, Color.BLACK, Color.BLACK, Color.DKGRAY))
        val doc = PdfDocument()
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 20f; isFakeBoldText = true; textAlign = Paint.Align.CENTER; color = Color.BLACK }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; color = Color.DKGRAY }

        var index = 0
        var pageNo = 1
        val systems = layout.systems
        if (systems.isEmpty()) {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
            page.canvas.drawText(title, pageW / 2f, 60f, titlePaint)
            doc.finishPage(page)
        }
        while (index < systems.size) {
            val first = pageNo == 1
            val top = if (first) 100f else margin
            val pitch = systems[0].regionBottom - systems[0].regionTop
            val perPage = ((pageH - margin - top) / pitch).toInt().coerceAtLeast(1)
            val chunk = systems.subList(index, minOf(systems.size, index + perPage))
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            val c = page.canvas
            if (first) {
                c.drawText(title, pageW / 2f, 55f, titlePaint)
                c.drawText("Tempo: ${Math.round(notation.bpm)} BPM", margin, 88f, smallPaint)
            }
            c.save()
            c.translate(margin, top - chunk[0].regionTop)
            painter.draw(c, layout, notation, systems = chunk)
            c.restore()
            c.drawText("$pageNo", pageW / 2f, pageH - 18f, smallPaint.apply { textAlign = Paint.Align.CENTER })
            doc.finishPage(page)
            index += chunk.size
            pageNo++
        }
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }
}
