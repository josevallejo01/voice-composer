package com.voicecomposer.app.data

import org.json.JSONObject

/** What was played to the singer while recording: the analysis uses it instead of guessing. */
data class RecordingMeta(
    val bpm: Double,
    val beatsPerBar: Int,
    val countInBeats: Int,
) {
    /** Nominal position of beat 0 on the recording (end of the count-in). */
    val originSec: Double get() = countInBeats * 60.0 / bpm

    fun toJson(): String = JSONObject().put("bpm", bpm).put("beatsPerBar", beatsPerBar).put("countIn", countInBeats).toString()

    companion object {
        fun fromJson(s: String): RecordingMeta? = runCatching {
            val o = JSONObject(s)
            RecordingMeta(o.getDouble("bpm"), o.getInt("beatsPerBar"), o.getInt("countIn"))
        }.getOrNull()
    }
}
