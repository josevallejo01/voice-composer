package com.voicecomposer.app.audio

import com.voicecomposer.engine.synth.Synth
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.coroutineContext

/** Audio ready for the player: 16-bit PCM, interleaved when [channels] is 2. */
class RenderedAudio(val pcm: ShortArray, val sampleRate: Int, val channels: Int) {
    /** Mono floats for the waveform display. */
    fun monoFloats(): FloatArray {
        if (channels == 1) return FloatArray(pcm.size) { pcm[it] / 32768f }
        return FloatArray(pcm.size / 2) { (pcm[2 * it] + pcm[2 * it + 1]) / 65536f }
    }
}

/**
 * The one place that turns tracks into sound: the SoundFont orchestra when a bank is available, and the old additive
 * synthesizer otherwise (so playback never fails because of a missing or broken bank).
 */
@Singleton
class Orchestra @Inject constructor(private val bank: SoundBankStore) {
    suspend fun render(tracks: List<Track>, map: TempoMap, beatsPerMeasure: Double = 4.0, minLengthSec: Double = 1.0): RenderedAudio {
        val engine = bank.engine()
        val job = coroutineContext[Job]
        return withContext(Dispatchers.Default) {
            if (engine != null) {
                val b = runCatching { engine.render(tracks, map, beatsPerMeasure, minLengthSec, isCancelled = { job?.isActive == false }) }.getOrNull()
                if (b != null && b.frames > 0) return@withContext RenderedAudio(b.toPcm16Interleaved(), b.sampleRate, 2)
            }
            RenderedAudio(Synth.toPcm16(Synth.render(tracks, map, minLengthSec = minLengthSec)), Synth.SAMPLE_RATE, 1)
        }
    }

    suspend fun renderNote(instrument: Instrument, midi: Int, durationSec: Double = 0.7): RenderedAudio = withContext(Dispatchers.Default) {
        val engine = bank.engine()
        if (engine != null) {
            val b = runCatching { engine.renderNote(instrument, midi, durationSec) }.getOrNull()
            if (b != null && b.frames > 0) return@withContext RenderedAudio(b.toPcm16Interleaved(), b.sampleRate, 2)
        }
        RenderedAudio(Synth.toPcm16(Synth.renderNote(midi, durationSec, instrument)), Synth.SAMPLE_RATE, 1)
    }
}
