package com.voicecomposer.app.data

import android.content.Context
import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.AnalysisResult
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.io.WavIO
import com.voicecomposer.model.Arrangement
import com.voicecomposer.model.Ids
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import com.voicecomposer.model.ModelJson
import com.voicecomposer.model.TempoMap
import com.voicecomposer.model.TimeSignature
import com.voicecomposer.model.Transcription
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single entry point for persistence. Recordings live in the app-private directory (never in shared storage),
 * structured data in Room. Nothing here talks to the network.
 */
@Singleton
class ProjectRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val db: AppDatabase,
    private val profile: ProfileStore,
) {
    private val projects get() = db.projects()

    val allProjects: Flow<List<ProjectEntity>> get() = projects.observeAll()

    fun observe(id: String): Flow<ProjectEntity?> = projects.observe(id)

    suspend fun get(id: String): ProjectEntity? = projects.get(id)

    fun audioFile(projectId: String): File = File(File(context.filesDir, "audio").also { it.mkdirs() }, "$projectId.wav")

    /** An analysis cannot survive a process death: such projects become restartable again. */
    suspend fun recoverInterrupted() = projects.resetInterrupted()

    suspend fun createFromRecording(
        id: String, title: String, inputType: String, sampleRate: Int, durationMs: Long, format: String = "WAV PCM16",
    ): ProjectEntity {
        val now = System.currentTimeMillis()
        val p = ProjectEntity(
            id = id, title = title, createdAt = now, modifiedAt = now, inputType = inputType,
            audioPath = audioFile(id).absolutePath, sampleRate = sampleRate, channels = 1, durationMs = durationMs,
            audioFormat = format, status = ProjectStatus.RECORDED, lastError = null, workingJson = null, version = 0,
        )
        projects.upsert(p)
        return p
    }

    /** "New musical project": an empty score the user fills in with the editor, no audio involved. */
    suspend fun createEmpty(title: String): ProjectEntity {
        val now = System.currentTimeMillis()
        val empty = Transcription(emptyList(), TempoMap.constant(100.0), TimeSignature.FOUR_FOUR, KeySignature(0, Mode.MAJOR))
        val p = ProjectEntity(
            id = Ids.newId("p"), title = title, createdAt = now, modifiedAt = now, inputType = "NONE", audioPath = null,
            sampleRate = 0, channels = 0, durationMs = 0, audioFormat = "", status = ProjectStatus.ANALYZED, lastError = null,
            workingJson = ModelJson.encode(empty), version = 1,
        )
        projects.upsert(p)
        return p
    }

    suspend fun loadAudio(projectId: String): AudioBuffer? = withContext(Dispatchers.IO) {
        val f = audioFile(projectId)
        if (f.exists()) runCatching { WavIO.read(f) }.getOrNull() else null
    }

    fun metaFile(projectId: String): File = File(audioFile(projectId).parentFile, "$projectId.meta.json")
    suspend fun saveMeta(projectId: String, meta: RecordingMeta) = withContext(Dispatchers.IO) { metaFile(projectId).writeText(meta.toJson()) }
    suspend fun loadMeta(projectId: String): RecordingMeta? = withContext(Dispatchers.IO) {
        metaFile(projectId).takeIf { it.exists() }?.let { RecordingMeta.fromJson(it.readText()) }
    }

    suspend fun hasAudio(projectId: String): Boolean = audioFile(projectId).exists()

    fun loadTranscription(p: ProjectEntity): Transcription? = p.workingJson?.let { runCatching { ModelJson.decodeTranscription(it) }.getOrNull() }

    /** Autosave of the edited working version. */
    suspend fun saveWorking(id: String, t: Transcription) {
        projects.saveWorking(id, ModelJson.encode(t), System.currentTimeMillis())
    }

    suspend fun setStatus(id: String, status: String, error: String? = null) =
        projects.setStatus(id, status, error, System.currentTimeMillis())

    /**
     * Stores an engine result as a new versioned analysis run and makes it the working version.
     * If the user had edited the previous working version it is first kept as a SNAPSHOT run, so a re-analysis never
     * destroys manual corrections (spec 11.3).
     */
    suspend fun saveAnalysis(projectId: String, result: AnalysisResult, config: AnalysisConfig) {
        val p = projects.get(projectId) ?: return
        val now = System.currentTimeMillis()
        val analyses = db.analyses()
        p.workingJson?.let { old ->
            analyses.insert(AnalysisRunEntity(Ids.newId("s"), projectId, "snapshot", now - 1, "SNAPSHOT", "{}", 1.0, old))
        }
        val json = ModelJson.encode(result.transcription)
        val params = "{\"inputType\":\"${config.inputType}\",\"quantization\":\"${config.quantization}\",\"tuning\":${config.tuningCompensation},\"neural\":${config.useNeural}}"
        analyses.insert(
            AnalysisRunEntity(
                Ids.newId("r"), projectId, result.transcription.analysis?.engineVersion ?: "unknown", now, "ENGINE", params,
                result.transcription.analysis?.overallConfidence ?: 0.0, json,
            )
        )
        projects.upsert(p.copy(workingJson = json, status = ProjectStatus.ANALYZED, lastError = null, version = p.version + 1, modifiedAt = now))
    }

    /** The last transcription produced by the engine (before any manual correction), used by "restore detected version". */
    suspend fun latestEngineTranscription(projectId: String): Transcription? =
        db.analyses().forProject(projectId).firstOrNull { it.kind == "ENGINE" }
            ?.let { runCatching { ModelJson.decodeTranscription(it.transcriptionJson) }.getOrNull() }

    suspend fun rename(id: String, title: String) = projects.rename(id, title.trim().ifEmpty { "Untitled" }, System.currentTimeMillis())

    // Arrangements
    fun arrangements(projectId: String): Flow<List<Pair<ArrangementEntity, Arrangement>>> =
        db.arrangements().observeForProject(projectId).map { list ->
            list.mapNotNull { e -> runCatching { e to ModelJson.decodeArrangement(e.json) }.getOrNull() }
        }

    suspend fun saveArrangement(projectId: String, a: Arrangement) {
        db.arrangements().upsert(ArrangementEntity(a.id, projectId, a.sourceVersion, System.currentTimeMillis(), a.style.name, ModelJson.encode(a)))
    }

    suspend fun deleteArrangement(id: String) = db.arrangements().delete(id)

    // Privacy: recordings and projects can be deleted at any time.
    suspend fun deleteAudio(projectId: String) = withContext(Dispatchers.IO) {
        audioFile(projectId).delete()
        metaFile(projectId).delete()
        projects.clearAudio(projectId, System.currentTimeMillis())
    }

    suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        audioFile(projectId).delete()
        metaFile(projectId).delete()
        profile.delete(projectId)
        projects.delete(projectId)
    }

    /** Deletes every recording but keeps the scores (privacy setting). */
    suspend fun deleteAllRecordings() = withContext(Dispatchers.IO) {
        projects.all().forEach { audioFile(it.id).delete(); metaFile(it.id).delete(); projects.clearAudio(it.id, System.currentTimeMillis()) }
        File(context.filesDir, "audio").deleteRecursively()
    }

    suspend fun deleteEverything() = withContext(Dispatchers.IO) {
        File(context.filesDir, "audio").deleteRecursively()
        profile.reset()
        projects.deleteAll()
    }
}
