package com.voicecomposer.app.data

import android.content.Context
import com.voicecomposer.engine.score.MlSpeller
import com.voicecomposer.engine.score.ScoreModels
import com.voicecomposer.model.NoteSpeller
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The learned score decisions (tempo, meter and bar lines, rhythm, written lengths, key, spelling), read once from
 * the app's assets. Also installs the learned speller for the score view and the exports.
 */
@Singleton
class ScoreForests @Inject constructor(@ApplicationContext private val context: Context) {
    @Volatile private var loaded: ScoreModels? = null
    @Volatile private var attempted = false

    /** Null when the files are missing or unreadable: the engine then uses its rules. */
    fun models(): ScoreModels? {
        if (attempted) return loaded
        synchronized(this) {
            if (attempted) return loaded
            val m = ScoreModels.load { name -> runCatching { context.assets.open(name).use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull() }
            loaded = m.takeIf { it.complete }
            m.spell?.let { NoteSpeller.current = MlSpeller(it) }
            attempted = true
            return loaded
        }
    }

    val available: Boolean get() = models() != null
}
