package com.voicecomposer.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

object ProjectStatus {
    /** Audio saved, not analysed (or analysis was interrupted and can be restarted). */
    const val RECORDED = "RECORDED"
    const val ANALYZING = "ANALYZING"
    const val ANALYZED = "ANALYZED"
    const val FAILED = "FAILED"
}

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long,
    val modifiedAt: Long,
    val inputType: String,
    val audioPath: String?,
    val sampleRate: Int,
    val channels: Int,
    val durationMs: Long,
    val audioFormat: String,
    val status: String,
    val lastError: String?,
    /** Current editable transcription as JSON (autosaved after every edit). */
    val workingJson: String?,
    /** Incremented each time a new analysis result becomes the working version. */
    val version: Int,
)

/** Versioned analysis results (kind ENGINE) and safety copies of corrected versions (kind SNAPSHOT). */
@Entity(
    tableName = "analysis_runs",
    foreignKeys = [ForeignKey(ProjectEntity::class, ["id"], ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId")],
)
data class AnalysisRunEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val engineVersion: String,
    val createdAt: Long,
    val kind: String,
    val paramsJson: String,
    val confidence: Double,
    val transcriptionJson: String,
)

@Entity(
    tableName = "arrangements",
    foreignKeys = [ForeignKey(ProjectEntity::class, ["id"], ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId")],
)
data class ArrangementEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val sourceVersion: Int,
    val createdAt: Long,
    val style: String,
    val json: String,
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY modifiedAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun observe(id: String): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun get(id: String): ProjectEntity?

    @Query("SELECT * FROM projects")
    suspend fun all(): List<ProjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: ProjectEntity)

    @Query("UPDATE projects SET workingJson = :json, modifiedAt = :now WHERE id = :id")
    suspend fun saveWorking(id: String, json: String, now: Long)

    @Query("UPDATE projects SET status = :status, lastError = :error, modifiedAt = :now WHERE id = :id")
    suspend fun setStatus(id: String, status: String, error: String?, now: Long)

    @Query("UPDATE projects SET title = :title, modifiedAt = :now WHERE id = :id")
    suspend fun rename(id: String, title: String, now: Long)

    @Query("UPDATE projects SET audioPath = NULL, modifiedAt = :now WHERE id = :id")
    suspend fun clearAudio(id: String, now: Long)

    @Query("UPDATE projects SET status = 'RECORDED' WHERE status = 'ANALYZING'")
    suspend fun resetInterrupted()

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM projects")
    suspend fun deleteAll()
}

@Dao
interface AnalysisDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(run: AnalysisRunEntity)

    @Query("SELECT * FROM analysis_runs WHERE projectId = :projectId ORDER BY createdAt DESC")
    suspend fun forProject(projectId: String): List<AnalysisRunEntity>
}

@Dao
interface ArrangementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(a: ArrangementEntity)

    @Query("SELECT * FROM arrangements WHERE projectId = :projectId ORDER BY createdAt DESC")
    fun observeForProject(projectId: String): Flow<List<ArrangementEntity>>

    @Query("SELECT * FROM arrangements WHERE id = :id")
    suspend fun get(id: String): ArrangementEntity?

    @Query("DELETE FROM arrangements WHERE id = :id")
    suspend fun delete(id: String)
}

@Database(entities = [ProjectEntity::class, AnalysisRunEntity::class, ArrangementEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projects(): ProjectDao
    abstract fun analyses(): AnalysisDao
    abstract fun arrangements(): ArrangementDao
}
