package com.voicecomposer.app.ml

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import com.voicecomposer.engine.ml.BP
import com.voicecomposer.engine.ml.BasicPitchModel
import com.voicecomposer.engine.ml.WindowOutput
import java.nio.FloatBuffer

/**
 * Runs Basic Pitch (Spotify, Apache-2.0; see NOTICE) with ONNX Runtime on the device CPU. The 230 KB model ships in
 * the APK assets and everything stays offline. The session is created lazily on the first analysis and kept, so
 * following analyses start immediately.
 */
class OnnxBasicPitchModel(private val context: Context) : BasicPitchModel {
    private val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }
    private var session: OrtSession? = null
    private var inputName = ""
    private var outputs: List<String> = emptyList()

    @Synchronized
    private fun session(): OrtSession {
        session?.let { return it }
        val bytes = context.assets.open(MODEL_ASSET).use { it.readBytes() }
        val opts = OrtSession.SessionOptions().apply {
            // Pro devices have many cores, but the model is tiny: more than 4 threads only adds overhead.
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 4))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val s = env.createSession(bytes, opts)
        inputName = s.inputNames.first()
        // Output names are StatefulPartitionedCall:0 (contour), :1 (note), :2 (onset).
        outputs = s.outputNames.sorted()
        require(outputs.size == 3) { "Unexpected model outputs: $outputs" }
        session = s
        return s
    }

    @Synchronized
    override fun inferBatch(windows: List<FloatArray>): List<WindowOutput> {
        val s = session()
        val n = windows.size
        val buf = FloatBuffer.allocate(n * BP.WINDOW_SAMPLES)
        for (w in windows) buf.put(w, 0, BP.WINDOW_SAMPLES)
        buf.rewind()
        val input = OnnxTensor.createTensor(env, buf, longArrayOf(n.toLong(), BP.WINDOW_SAMPLES.toLong(), 1L))
        val result = try { s.run(mapOf(inputName to input)) } catch (e: Throwable) { input.close(); throw e }
        try {
            fun read(name: String, perWindow: Int): List<FloatArray> {
                val fb = (result.get(name).get() as OnnxTensor).floatBuffer
                return List(n) { FloatArray(perWindow).also { a -> fb.get(a) } }
            }
            val contour = read(outputs[0], BP.WINDOW_FRAMES * BP.CONTOUR_BINS)
            val note = read(outputs[1], BP.WINDOW_FRAMES * BP.NOTES)
            val onset = read(outputs[2], BP.WINDOW_FRAMES * BP.NOTES)
            return List(n) { WindowOutput(note[it], onset[it], contour[it]) }
        } finally {
            result.close()
            input.close()
        }
    }

    @Synchronized
    fun close() {
        runCatching { session?.close() }
        session = null
    }

    companion object { const val MODEL_ASSET = "nmp.onnx" }
}
