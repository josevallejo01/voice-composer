package com.voicecomposer.app.ui.result

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.voicecomposer.model.Pitch
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.voicecomposer.app.R
import com.voicecomposer.app.audio.PlaybackMode
import com.voicecomposer.app.data.ProjectEntity
import com.voicecomposer.app.export.ExportFormat
import com.voicecomposer.app.ui.common.WaveformView
import com.voicecomposer.app.ui.common.formatTimeFine
import com.voicecomposer.app.ui.score.ScoreView
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.app.ui.common.instrumentLabel
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.ValidationState

private enum class Dlg { TEMPO, METER, KEY, LYRIC, RENAME, REANALYZE, RESTORE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    onBack: () -> Unit,
    onReanalyze: (String) -> Unit,
    onArrange: (String) -> Unit,
    vm: ResultViewModel = hiltViewModel(),
) {
    val ctx = LocalContext.current
    val project by vm.project.collectAsState()
    val t by vm.transcription.collectAsState()
    val selected by vm.selectedId.collectAsState()
    val drawMode by vm.drawMode.collectAsState()
    val mode by vm.mode.collectAsState()
    val hasAudio by vm.hasAudio.collectAsState()
    val peaks by vm.peaks.collectAsState()
    val melodyInstrument by vm.melodyInstrument.collectAsState()
    val rendering by vm.rendering.collectAsState()
    val play by vm.playback.state.collectAsState()
    val (canUndo, canRedo) = vm.history.collectAsState().value
    val busy by vm.busy.collectAsState()
    val listening by vm.listening.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    var menu by remember { mutableStateOf(false) }
    var keyboard by remember { mutableStateOf(false) }
    var octave by remember { mutableIntStateOf(4) }
    val scroll = rememberScrollState()

    val exportFailed = stringResource(R.string.export_failed)
    val restored = stringResource(R.string.restored_detected)
    val nothingToRestore = stringResource(R.string.nothing_to_restore)
    val nothingHeard = stringResource(R.string.sing_nothing_heard)
    val micFailed = stringResource(R.string.sing_mic_failed)
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) vm.singSelected() }
    val onSing = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.singSelected()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }
    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            when (e) {
                is ResultEvent.Exported -> vm.share(ctx, e)
                ResultEvent.ExportFailed -> snackbar.showSnackbar(exportFailed)
                ResultEvent.Reanalyze -> onReanalyze(vm.projectId)
                ResultEvent.Restored -> snackbar.showSnackbar(restored)
                ResultEvent.NothingToRestore -> snackbar.showSnackbar(nothingToRestore)
                ResultEvent.NothingHeard -> snackbar.showSnackbar(nothingHeard)
                ResultEvent.MicFailed -> snackbar.showSnackbar(micFailed)
            }
        }
    }

    val title = project?.title ?: ""
    val score = t

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
                actions = {
                    IconButton(onClick = vm::undo, enabled = canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, stringResource(R.string.undo)) }
                    IconButton(onClick = vm::redo, enabled = canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, stringResource(R.string.redo)) }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, stringResource(R.string.more)) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.arrange)) }, onClick = { menu = false; onArrange(vm.projectId) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.export_pdf)) }, onClick = { menu = false; vm.export(ExportFormat.PDF, title) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.export_musicxml)) }, onClick = { menu = false; vm.export(ExportFormat.MUSICXML, title) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.export_midi)) }, onClick = { menu = false; vm.export(ExportFormat.MIDI, title) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.rename)) }, onClick = { menu = false; dialog = Dlg.RENAME })
                        DropdownMenuItem(text = { Text(stringResource(R.string.restore_detected)) }, onClick = { menu = false; dialog = Dlg.RESTORE })
                        if (hasAudio) DropdownMenuItem(text = { Text(stringResource(R.string.reanalyze)) }, onClick = { menu = false; dialog = Dlg.REANALYZE })
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (score != null) EditBar(
                vm = vm, t = score, selected = selected, drawMode = drawMode, keyboard = keyboard, octave = octave,
                onKeyboard = { keyboard = it }, onOctave = { octave = it }, onLyric = { dialog = Dlg.LYRIC },
                listening = listening, onSing = onSing,
            )
        },
    ) { pad ->
        if (score == null) return@Scaffold
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            // The player stays in view while the score scrolls (and follows the playback) underneath it.
            PlayerCard(
                hasAudio = hasAudio, mode = mode, peaks = peaks, positionMs = play.positionMs, durationMs = play.durationMs, playing = play.playing,
                onMode = vm::setMode, onToggle = vm::togglePlay, onSeek = vm::seekFraction,
                melodyInstrument = melodyInstrument, rendering = rendering, onInstrument = vm::setMelodyInstrument,
            )

            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll)) {
                // What the analysis decided, each value editable.
                AnalysisCard(score, project, vm,
                    onTempo = { dialog = Dlg.TEMPO }, onMeter = { dialog = Dlg.METER }, onKey = { dialog = Dlg.KEY })

                if (score.notes.isEmpty()) {
                    Text(stringResource(R.string.score_empty), Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                ScoreView(
                    transcription = score, selectedId = selected, drawMode = drawMode,
                    cursorBeat = { if (play.positionMs > 0 || play.playing) vm.beatAt(play.positionMs) else null },
                    scroll = scroll,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                    onSelect = vm::select, onAddNote = vm::addNote, onSetPitch = vm::setPitch,
                )
                // Room below the last line so that it can be scrolled up to the top of the view.
                Spacer(Modifier.size(280.dp))
            }
        }
    }

    when (dialog) {
        Dlg.TEMPO -> score?.let { TempoDialog(it.tempoMap.averageBpm, { dialog = null }) { bpm -> vm.setTempo(bpm); dialog = null } }
        Dlg.METER -> score?.let { MeterDialog(it.timeSignature, { dialog = null }) { ts -> vm.setMeter(ts); dialog = null } }
        Dlg.KEY -> score?.let { KeyDialog(it.key, { dialog = null }) { tonic, minor -> vm.setKey(tonic, minor); dialog = null } }
        Dlg.LYRIC -> score?.let { s ->
            val current = selected?.let { s.lyricFor(it)?.text } ?: ""
            TextDialog(stringResource(R.string.lyric), current, { dialog = null }) { vm.setLyric(it); dialog = null }
        }
        Dlg.RENAME -> TextDialog(stringResource(R.string.rename), title, { dialog = null }) { vm.rename(it); dialog = null }
        Dlg.REANALYZE -> ConfirmDialog(
            stringResource(R.string.reanalyze), stringResource(R.string.reanalyze_body), stringResource(R.string.reanalyze),
            { dialog = null }, { dialog = null; vm.reanalyze() },
        )
        Dlg.RESTORE -> ConfirmDialog(
            stringResource(R.string.restore_detected), stringResource(R.string.restore_detected_body), stringResource(R.string.restore),
            { dialog = null }, { dialog = null; vm.restoreDetected() },
        )
        null -> Unit
    }
}

@Composable
private fun PlayerCard(
    hasAudio: Boolean, mode: PlaybackMode, peaks: List<Float>, positionMs: Long, durationMs: Long, playing: Boolean,
    onMode: (PlaybackMode) -> Unit, onToggle: () -> Unit, onSeek: (Float) -> Unit,
    melodyInstrument: Instrument, rendering: Boolean, onInstrument: (Instrument) -> Unit,
) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledIconButton(onClick = onToggle, Modifier.size(48.dp)) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, stringResource(if (playing) R.string.pause else R.string.play))
                }
                Text(formatTimeFine(positionMs) + " / " + formatTimeFine(durationMs), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.weight(1f))
                if (hasAudio) {
                    FilterChip(mode == PlaybackMode.ORIGINAL, { onMode(PlaybackMode.ORIGINAL) }, label = { Text(stringResource(R.string.mode_original)) })
                    FilterChip(mode == PlaybackMode.MELODY, { onMode(PlaybackMode.MELODY) }, label = { Text(stringResource(R.string.mode_melody)) })
                }
            }
            // Always the waveform of the sound that is playing (recording or synthesised melody).
            WaveformView(peaks, height = 48.dp, progress = if (durationMs > 0) positionMs.toFloat() / durationMs else 0f, onSeek = onSeek)
            if (mode == PlaybackMode.MELODY) {
                if (rendering) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(stringResource(R.string.sound_rendering), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.hScroll()) {
                    for (i in Instrument.melodyChoices) FilterChip(melodyInstrument == i, { onInstrument(i) }, label = { Text(instrumentLabel(i)) })
                }
            }
        }
    }
}

@Composable
private fun AnalysisCard(
    t: Transcription, project: ProjectEntity?, vm: ResultViewModel,
    onTempo: () -> Unit, onMeter: () -> Unit, onKey: () -> Unit,
) {
    val uncertain = t.notes.count { it.validation == ValidationState.UNCERTAIN }
    Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.hScroll()) {
                AssistChip(onClick = onTempo, label = { Text(stringResource(R.string.tempo_value, Math.round(t.tempoMap.averageBpm).toInt())) })
                AssistChip(onClick = onMeter, label = { Text(t.timeSignature.toString()) })
                AssistChip(onClick = onKey, label = { Text(keyLabel(t)) })
            }
            if (project?.inputType != "NONE") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (q in QuantizationMode.entries) {
                        FilterChip(t.quantization == q, { vm.setQuantization(q) }, label = { Text(stringResource(quantLabel(q))) })
                    }
                }
            }
            t.analysis?.let { a ->
                Text(
                    stringResource(R.string.confidence_value, Math.round(a.overallConfidence * 100).toInt()) + " · " + a.engineVersion,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                for (w in a.warnings) Text(warningLabel(w), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            if (uncertain > 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.uncertain_count, uncertain), color = com.voicecomposer.app.ui.theme.UncertainColor, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.jumpToUncertain(false) }) { Text(stringResource(R.string.previous)) }
                    TextButton(onClick = { vm.jumpToUncertain(true) }) { Text(stringResource(R.string.next)) }
                }
            }
        }
    }
}

@Composable
private fun warningLabel(code: String): String = when {
    code.startsWith("NEURAL_FAILED:") -> stringResource(R.string.warn_neural_failed, code.removePrefix("NEURAL_FAILED:"))
    else -> warningLabelBasic(code)
}

@Composable
private fun warningLabelBasic(code: String): String = when (code) {
    "TOO_QUIET" -> stringResource(R.string.warn_too_quiet)
    "CLIPPING" -> stringResource(R.string.warn_clipping)
    "TOO_SHORT" -> stringResource(R.string.warn_too_short)
    "NO_PITCH_FOUND" -> stringResource(R.string.warn_no_pitch)
    "TOO_LONG" -> stringResource(R.string.warn_too_long)
    else -> code
}

private fun quantLabel(q: QuantizationMode) = when (q) {
    QuantizationMode.AUTOMATIC -> R.string.quant_automatic
    QuantizationMode.SOFT -> R.string.quant_soft
    QuantizationMode.FREE -> R.string.quant_free
}

@Composable
private fun keyLabel(t: Transcription): String {
    val names = if (t.key.fifths < 0) listOf("C", "D♭", "D", "E♭", "E", "F", "G♭", "G", "A♭", "A", "B♭", "B")
    else listOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
    val mode = stringResource(if (t.key.mode == com.voicecomposer.model.Mode.MINOR) R.string.minor else R.string.major)
    return names[t.key.tonic] + " " + mode
}

private fun noteName(midi: Int, fifths: Int): String {
    val sp = Pitch.spell(midi, fifths)
    val fr = java.util.Locale.getDefault().language == "fr"
    val base = if (fr) mapOf('C' to "Do", 'D' to "Ré", 'E' to "Mi", 'F' to "Fa", 'G' to "Sol", 'A' to "La", 'B' to "Si")[sp.step] ?: sp.step.toString() else sp.step.toString()
    val acc = when { sp.alter > 0 -> "♯"; sp.alter < 0 -> "♭"; else -> "" }
    return base + acc + sp.octave
}

@Composable
private fun EditBar(
    vm: ResultViewModel, t: Transcription, selected: String?, drawMode: Boolean, keyboard: Boolean, octave: Int,
    onKeyboard: (Boolean) -> Unit, onOctave: (Int) -> Unit, onLyric: () -> Unit,
    listening: Boolean, onSing: () -> Unit,
) {
    val duration by vm.noteDuration.collectAsState()
    val note = selected?.let { id -> t.notes.firstOrNull { it.id == id } }
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.navigationBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp)) {
            if (note != null) {
                // Quick correction of the selected note: big touch targets; tap the staff, press the arrows or sing it.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(onClick = { vm.shiftPitch(-1) }, Modifier.size(52.dp)) { Icon(Icons.Default.ArrowDownward, stringResource(R.string.pitch_down)) }
                    Text(
                        note.midiPitch?.let { noteName(it, t.key.fifths) } ?: "–",
                        style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 6.dp),
                    )
                    FilledTonalIconButton(onClick = { vm.shiftPitch(1) }, Modifier.size(52.dp)) { Icon(Icons.Default.ArrowUpward, stringResource(R.string.pitch_up)) }
                    Spacer(Modifier.weight(1f))
                    FilledIconButton(onClick = onSing, enabled = !listening, modifier = Modifier.size(52.dp)) {
                        if (listening) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        else Icon(Icons.Default.Mic, stringResource(R.string.sing_note))
                    }
                    FilledTonalIconButton(onClick = vm::playSelected, Modifier.size(52.dp)) { Icon(Icons.Default.Hearing, stringResource(R.string.listen)) }
                    FilledTonalIconButton(onClick = { vm.select(null) }, Modifier.size(52.dp)) { Icon(Icons.Default.Check, stringResource(R.string.done)) }
                }
                Text(
                    stringResource(if (listening) R.string.sing_now else R.string.correct_hint),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(Modifier.fillMaxWidth().hScroll(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistChip(onClick = { vm.shiftPitch(12) }, label = { Text(stringResource(R.string.octave_up)) })
                    AssistChip(onClick = { vm.shiftPitch(-12) }, label = { Text(stringResource(R.string.octave_down)) })
                    AssistChip(onClick = vm::halveDuration, label = { Text(stringResource(R.string.shorter)) })
                    AssistChip(onClick = vm::doubleDuration, label = { Text(stringResource(R.string.longer)) })
                    AssistChip(onClick = vm::split, label = { Text(stringResource(R.string.split)) })
                    AssistChip(onClick = vm::mergeNext, label = { Text(stringResource(R.string.merge)) })
                    AssistChip(onClick = onLyric, label = { Text(stringResource(R.string.lyric)) })
                    if (note.validation != ValidationState.VALIDATED) {
                        AssistChip(onClick = vm::validateSelected, label = { Text(stringResource(R.string.validate)) })
                    }
                    AssistChip(onClick = vm::deleteSelected, label = { Text(stringResource(R.string.delete)) })
                }
            } else {
                Row(Modifier.fillMaxWidth().hScroll(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(drawMode, { vm.setDrawMode(!drawMode) }, label = { Text(stringResource(R.string.draw_mode)) })
                    FilterChip(keyboard, { onKeyboard(!keyboard) }, label = { Text(stringResource(R.string.keys)) })
                    if (drawMode) {
                        for (d in NOTE_DURATIONS) FilterChip(duration == d, { vm.setNoteDuration(d) }, label = { Text(durationLabel(d)) })
                    }
                }
            }
            if (keyboard) PianoKeyboard(octave, onOctave, vm::pressKey)
        }
    }
}

@Composable
private fun durationLabel(beats: Double): String = when (beats) {
    0.25 -> stringResource(R.string.dur_sixteenth)
    0.5 -> stringResource(R.string.dur_eighth)
    1.0 -> stringResource(R.string.dur_quarter)
    2.0 -> stringResource(R.string.dur_half)
    else -> stringResource(R.string.dur_whole)
}

@Composable
private fun Modifier.hScroll(): Modifier = this.horizontalScroll(rememberScrollState())
