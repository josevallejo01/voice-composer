package com.voicecomposer.app.data

import android.content.Context
import com.voicecomposer.engine.calibration.CalibrationJson
import com.voicecomposer.engine.calibration.CalibrationOutcome
import com.voicecomposer.engine.ml.DecoderParams
import com.voicecomposer.engine.ml.forInput
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.engine.profile.Contribution
import com.voicecomposer.engine.profile.ContributionBuilder
import com.voicecomposer.engine.profile.VoiceProfile
import com.voicecomposer.model.Transcription
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class ProfileStats(
    val projects: Int = 0,
    val notes: Int = 0,
    val maturity: Double = 0.0,
    /** Kinds of sound (InputType names) that went through the initial voice setup. */
    val calibrated: Set<String> = emptySet(),
)

/**
 * On-device storage of what the app learned about the user's voice, kept separately for singing, humming and
 * whistling: one small JSON file per project (recomputed from "engine result vs. corrected score"), plus the result of
 * the initial voice setup. Nothing leaves the phone; deleting a project deletes what it taught, and the whole profile
 * can be reset at any time.
 */
@Singleton
class ProfileStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val dir get() = File(context.filesDir, "profile").also { it.mkdirs() }
    private val _stats = MutableStateFlow(ProfileStats())
    val stats: StateFlow<ProfileStats> = _stats
    private val cache = HashMap<String, VoiceProfile>()

    private fun key(t: InputType) = if (t == InputType.VOCALISE) InputType.SINGING.name else t.name
    private fun file(projectId: String) = File(dir, "$projectId.json")
    private fun calibrationFile(t: InputType) = File(dir, "calibration_${key(t)}.cal")

    suspend fun record(projectId: String, engine: Transcription, final: Transcription, type: InputType) = withContext(Dispatchers.IO) {
        if (engine.notes.isEmpty()) return@withContext
        runCatching { file(projectId).writeText(ContributionBuilder.build(projectId, engine, final, key(type)).toJson()) }
        synchronized(cache) { cache.clear() }
    }

    /** The profile of one kind of sound: calibrated starting point + everything learned from corrections. */
    suspend fun current(type: InputType): VoiceProfile = withContext(Dispatchers.IO) {
        synchronized(cache) { cache[key(type)] }?.let { return@withContext it }
        val all = dir.listFiles { f -> f.extension == "json" }.orEmpty().mapNotNull { Contribution.fromJson(it.readText()) }
        val base = calibrationFile(type).takeIf { it.exists() }?.let { CalibrationJson.read(it.readText(), type) } ?: DecoderParams.forInput(type)
        val p = VoiceProfile.build(all, type, base)
        synchronized(cache) { cache[key(type)] = p }
        refreshStats(all)
        p
    }

    private fun refreshStats(all: List<Contribution>) {
        val n = all.sumOf { it.engineNotes }
        val cal = dir.listFiles { f -> f.extension == "cal" }.orEmpty().map { it.nameWithoutExtension.removePrefix("calibration_") }.toSet()
        _stats.value = ProfileStats(all.size, n, n / (n + 200.0), cal)
    }

    /** Stores the outcome of the guided voice setup for [type]. Replaces an earlier setup of the same kind. */
    suspend fun saveCalibration(type: InputType, outcome: CalibrationOutcome) = withContext(Dispatchers.IO) {
        calibrationFile(type).writeText(CalibrationJson.write(outcome.decoder))
        File(dir, "calibration-${key(type)}.json").writeText(outcome.contribution.toJson())
        synchronized(cache) { cache.clear() }
        refreshStats(dir.listFiles { f -> f.extension == "json" }.orEmpty().mapNotNull { Contribution.fromJson(it.readText()) })
    }

    suspend fun delete(projectId: String) = withContext(Dispatchers.IO) { file(projectId).delete(); synchronized(cache) { cache.clear() }; Unit }

    suspend fun reset() = withContext(Dispatchers.IO) {
        File(context.filesDir, "profile").deleteRecursively()
        synchronized(cache) { cache.clear() }
        _stats.value = ProfileStats()
    }
}
