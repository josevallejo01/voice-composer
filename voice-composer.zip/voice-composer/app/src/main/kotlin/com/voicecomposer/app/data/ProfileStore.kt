package com.voicecomposer.app.data

import android.content.Context
import com.voicecomposer.engine.profile.Contribution
import com.voicecomposer.engine.profile.ContributionBuilder
import com.voicecomposer.engine.profile.VoiceProfile
import com.voicecomposer.model.Transcription
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class ProfileStats(val projects: Int = 0, val notes: Int = 0, val maturity: Double = 0.0)

/**
 * On-device storage of what the app learned about the user's voice: one small JSON file per project, recomputed
 * from "engine result vs. corrected score". Nothing leaves the phone; deleting a project deletes what it taught,
 * and the whole profile can be reset at any time.
 */
@Singleton
class ProfileStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val dir get() = File(context.filesDir, "profile").also { it.mkdirs() }
    private val _stats = MutableStateFlow(ProfileStats())
    val stats: StateFlow<ProfileStats> = _stats
    @Volatile private var cached: VoiceProfile? = null

    private fun file(projectId: String) = File(dir, "$projectId.json")

    suspend fun record(projectId: String, engine: Transcription, final: Transcription) = withContext(Dispatchers.IO) {
        if (engine.notes.isEmpty()) return@withContext
        runCatching { file(projectId).writeText(ContributionBuilder.build(projectId, engine, final).toJson()) }
        cached = null
    }

    /** The profile built from all contributions (cached until a contribution changes). */
    suspend fun current(): VoiceProfile = withContext(Dispatchers.IO) {
        cached ?: run {
            val list = dir.listFiles { f -> f.extension == "json" }.orEmpty().mapNotNull { Contribution.fromJson(it.readText()) }
            VoiceProfile.build(list).also {
                cached = it
                _stats.value = ProfileStats(it.projects, it.engineNotes, it.maturity)
            }
        }
    }

    suspend fun delete(projectId: String) = withContext(Dispatchers.IO) { file(projectId).delete(); cached = null; Unit }

    suspend fun reset() = withContext(Dispatchers.IO) {
        File(context.filesDir, "profile").deleteRecursively()
        cached = null
        _stats.value = ProfileStats()
    }
}
