package com.voicecomposer.app.audio

import android.content.Context
import android.net.Uri
import com.voicecomposer.engine.sound.SoundEngine
import com.voicecomposer.engine.sound.SoundFont
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.nio.channels.FileChannel
import javax.inject.Inject
import javax.inject.Singleton

enum class SoundBankState { NOT_LOADED, LOADING, READY, MISSING, ERROR }

data class SoundBankStatus(val state: SoundBankState = SoundBankState.NOT_LOADED, val name: String = "", val custom: Boolean = false, val sizeMb: Int = 0)

/**
 * Finds, opens and keeps the orchestral SoundFont. The bank that ships with the app (an asset, added by the build) is
 * copied once to the app's files and memory-mapped, so the 30 MB are not held on the Java heap. A bank imported by the
 * user (any SoundFont 2 file) takes precedence. When there is none, [engine] returns null and callers use the simple
 * built-in synthesizer.
 */
@Singleton
class SoundBankStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val _status = MutableStateFlow(SoundBankStatus())
    val status: StateFlow<SoundBankStatus> = _status
    private val mutex = Mutex()
    private var cached: SoundEngine? = null

    private val dir get() = File(context.filesDir, "soundbank").also { it.mkdirs() }
    private val userFile get() = File(dir, "user.sf2")
    private val bundledFile get() = File(dir, "bundled.sf2")

    suspend fun engine(): SoundEngine? = mutex.withLock {
        cached?.let { return it }
        withContext(Dispatchers.IO) {
            _status.value = _status.value.copy(state = SoundBankState.LOADING)
            val found = runCatching { open(userFile, custom = true) }.getOrNull() ?: runCatching { openBundled() }.getOrNull()
            if (found == null) {
                _status.value = SoundBankStatus(if (hasBundledAsset() || userFile.exists()) SoundBankState.ERROR else SoundBankState.MISSING)
                null
            } else {
                cached = found
                found
            }
        }
    }

    private fun hasBundledAsset(): Boolean = runCatching { context.assets.list("soundbank")?.any { it.endsWith(".sf2") } == true }.getOrDefault(false)

    private fun open(f: File, custom: Boolean): SoundEngine? {
        if (!f.exists() || f.length() < 1024) return null
        val channel = RandomAccessFile(f, "r").channel
        val font = SoundFont(channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size()))
        val engine = SoundEngine(font)
        _status.value = SoundBankStatus(SoundBankState.READY, name = if (custom) "SoundFont" else "GeneralUser GS", custom = custom, sizeMb = (f.length() / 1_048_576).toInt())
        return engine
    }

    private fun openBundled(): SoundEngine? {
        val name = context.assets.list("soundbank")?.firstOrNull { it.endsWith(".sf2") } ?: return null
        val size = runCatching { context.assets.openFd("soundbank/$name").use { it.length } }.getOrDefault(-1L)
        if (!bundledFile.exists() || bundledFile.length() < 1024 || (size > 0 && bundledFile.length() != size)) {
            val tmp = File(dir, "bundled.tmp")
            context.assets.open("soundbank/$name").use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 16) } }
            tmp.renameTo(bundledFile)
        }
        return open(bundledFile, custom = false)
    }

    /** Copies a SoundFont chosen by the user and switches to it. Returns false (and keeps the previous bank) if the file is not a usable SoundFont 2. */
    suspend fun importBank(uri: Uri): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            val tmp = File(dir, "import.tmp")
            val ok = runCatching {
                context.contentResolver.openInputStream(uri)!!.use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 16) } }
                RandomAccessFile(tmp, "r").channel.use { ch -> SoundFont(ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size())) }
                true
            }.getOrDefault(false)
            if (!ok) { tmp.delete(); return@withContext false }
            userFile.delete()
            tmp.renameTo(userFile)
            cached = null
            true
        }
    }

    suspend fun removeCustomBank() = mutex.withLock {
        withContext(Dispatchers.IO) { userFile.delete(); cached = null; _status.value = SoundBankStatus() }
    }
}
