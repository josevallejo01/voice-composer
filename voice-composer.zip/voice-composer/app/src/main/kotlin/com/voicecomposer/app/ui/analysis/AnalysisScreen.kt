package com.voicecomposer.app.ui.analysis

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.voicecomposer.app.R
import com.voicecomposer.app.analysis.AnalysisManager
import com.voicecomposer.app.analysis.AnalysisProgress
import com.voicecomposer.app.data.ProjectEntity
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.data.ProjectStatus
import com.voicecomposer.engine.Stage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

@HiltViewModel
class AnalysisViewModel @Inject constructor(
    handle: SavedStateHandle,
    private val manager: AnalysisManager,
    repository: ProjectRepository,
) : ViewModel() {
    val projectId: String = checkNotNull(handle["id"])
    val project: Flow<ProjectEntity?> = repository.observe(projectId)
    val progress: Flow<AnalysisProgress?> = manager.progress.map { it[projectId] }

    /** Starts the analysis when the project has a recording that has not been analysed yet. */
    fun startIfNeeded(project: ProjectEntity) {
        // Automatic start happens once per visit, so cancelling does not immediately restart the analysis.
        if (autoStarted) return
        if (project.status == ProjectStatus.RECORDED && !manager.isRunning(projectId)) { autoStarted = true; manager.start(projectId) }
    }
    private var autoStarted = false

    fun retry() = manager.start(projectId)
    fun cancel() = manager.cancel(projectId)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalysisScreen(onBack: () -> Unit, onDone: (String) -> Unit, vm: AnalysisViewModel = hiltViewModel()) {
    val project by vm.project.collectAsState(initial = null)
    val progress by vm.progress.collectAsState(initial = null)
    val p = project

    LaunchedEffect(p?.status) {
        if (p == null) return@LaunchedEffect
        if (p.status == ProjectStatus.ANALYZED) onDone(p.id) else vm.startIfNeeded(p)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.analysis_title)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            when (p?.status) {
                ProjectStatus.FAILED -> {
                    Text(stringResource(R.string.analysis_failed), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
                    Text(
                        stringResource(if (p?.lastError == "NO_AUDIO") R.string.analysis_no_audio else R.string.analysis_failed_body),
                        modifier = Modifier.padding(vertical = 12.dp),
                    )
                    if (p?.lastError != "NO_AUDIO") Button(onClick = { vm.retry() }) { Text(stringResource(R.string.retry)) }
                }
                ProjectStatus.RECORDED -> {
                    if (progress == null) {
                        // Interrupted or cancelled analysis: it can simply be started again.
                        Text(stringResource(R.string.analysis_not_started), modifier = Modifier.padding(bottom = 12.dp))
                        Button(onClick = { vm.retry() }) { Text(stringResource(R.string.analysis_start)) }
                    } else Running(progress, vm)
                }
                else -> Running(progress, vm)
            }
        }
    }
}

@Composable
private fun Running(progress: AnalysisProgress?, vm: AnalysisViewModel) {
    val fraction = progress?.fraction ?: 0f
    Text(stringResource(stageLabel(progress?.stage ?: Stage.PREPROCESSING)), style = MaterialTheme.typography.titleMedium)
    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp))
    Text("${(fraction * 100).toInt()} %", style = MaterialTheme.typography.bodyMedium)
    Text(
        stringResource(R.string.analysis_offline_note),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 16.dp),
    )
    OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
}

private fun stageLabel(s: Stage): Int = when (s) {
    Stage.PREPROCESSING -> R.string.stage_preprocessing
    Stage.PITCH -> R.string.stage_pitch
    Stage.SEGMENTATION -> R.string.stage_segmentation
    Stage.TEMPO -> R.string.stage_tempo
    Stage.RHYTHM -> R.string.stage_rhythm
    Stage.KEY -> R.string.stage_key
    Stage.DONE -> R.string.stage_done
}
