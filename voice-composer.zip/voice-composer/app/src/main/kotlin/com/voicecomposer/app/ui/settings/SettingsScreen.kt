package com.voicecomposer.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.voicecomposer.app.BuildConfig
import com.voicecomposer.app.R
import com.voicecomposer.app.data.AppSettings
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.data.SettingsStore
import com.voicecomposer.app.ui.record.inputTypeLabel
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.QuantizationMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val store: SettingsStore,
    private val repository: ProjectRepository,
    private val profileStore: com.voicecomposer.app.data.ProfileStore,
) : ViewModel() {
    val settings: StateFlow<AppSettings> = store.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())
    fun setInputType(t: InputType) = viewModelScope.launch { store.setInputType(t) }
    fun setQuantization(q: QuantizationMode) = viewModelScope.launch { store.setQuantization(q) }
    fun setTuning(on: Boolean) = viewModelScope.launch { store.setTuning(on) }
    fun setNeural(on: Boolean) = viewModelScope.launch { store.setNeuralEngine(on) }
    val profileStats: StateFlow<com.voicecomposer.app.data.ProfileStats> = profileStore.stats
    init { viewModelScope.launch { profileStore.current(com.voicecomposer.engine.preprocessing.InputType.SINGING) } }
    fun setVoiceLearning(on: Boolean) = viewModelScope.launch { store.setVoiceLearning(on) }
    fun resetProfile() = viewModelScope.launch { profileStore.reset() }
    fun deleteRecordings() = viewModelScope.launch { repository.deleteAllRecordings() }
    fun deleteEverything() = viewModelScope.launch { repository.deleteEverything() }
}

private enum class Confirm { RECORDINGS, EVERYTHING }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onCalibrate: () -> Unit = {}, vm: SettingsViewModel = hiltViewModel()) {
    val s by vm.settings.collectAsState()
    var confirm by remember { mutableStateOf<Confirm?>(null) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.settings)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(R.string.settings_defaults), style = MaterialTheme.typography.titleMedium)

            Text(stringResource(R.string.input_type_label), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for (t in InputType.entries) FilterChip(s.inputType == t, { vm.setInputType(t) }, label = { Text(inputTypeLabel(t)) })
            }
            Text(stringResource(R.string.quantization), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (q in QuantizationMode.entries) {
                    FilterChip(s.quantization == q, { vm.setQuantization(q) }, label = {
                        Text(stringResource(when (q) {
                            QuantizationMode.AUTOMATIC -> R.string.quant_automatic
                            QuantizationMode.SOFT -> R.string.quant_soft
                            QuantizationMode.FREE -> R.string.quant_free
                        }))
                    })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.tuning_compensation))
                    Text(stringResource(R.string.tuning_compensation_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(s.tuningCompensation, vm::setTuning)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.neural_engine))
                    Text(stringResource(R.string.neural_engine_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(s.neuralEngine, vm::setNeural)
            }

            HorizontalDivider()
            val stats by vm.profileStats.collectAsState()
            Text(stringResource(R.string.voice_profile), style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.voice_learning))
                    Text(stringResource(R.string.voice_learning_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(s.voiceLearning, vm::setVoiceLearning)
            }
            Text(
                stringResource(R.string.voice_profile_status, stats.projects, stats.notes, (stats.maturity * 100).toInt()),
                style = MaterialTheme.typography.bodyMedium,
            )
            Button(onClick = onCalibrate, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_open)) }
            if (stats.calibrated.isNotEmpty()) Text(stringResource(R.string.cal_calibrated, stats.calibrated.joinToString()), style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { vm.resetProfile() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.voice_profile_reset)) }

            HorizontalDivider()
            Text(stringResource(R.string.privacy), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.privacy_body), style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = { confirm = Confirm.RECORDINGS }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.delete_all_recordings)) }
            OutlinedButton(onClick = { confirm = Confirm.EVERYTHING }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.delete_everything)) }

            HorizontalDivider()
            Text(stringResource(R.string.about), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.version_value, BuildConfig.VERSION_NAME), style = MaterialTheme.typography.bodyMedium)
            Text(stringResource(R.string.about_body), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(stringResource(if (c == Confirm.RECORDINGS) R.string.delete_all_recordings else R.string.delete_everything)) },
            text = { Text(stringResource(if (c == Confirm.RECORDINGS) R.string.delete_recordings_body else R.string.delete_everything_body)) },
            confirmButton = {
                TextButton(onClick = {
                    if (c == Confirm.RECORDINGS) vm.deleteRecordings() else vm.deleteEverything()
                    confirm = null
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}
