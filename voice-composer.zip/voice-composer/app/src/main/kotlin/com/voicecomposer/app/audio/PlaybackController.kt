package com.voicecomposer.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

enum class PlaybackMode { ORIGINAL, MELODY, ARRANGEMENT }

data class PlaybackState(
    val playing: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val loopStartMs: Long? = null,
    val loopEndMs: Long? = null,
    val loaded: Boolean = false,
)

/**
 * One player for the three playback modes. The whole piece is rendered to a PCM buffer in memory; playback is a
 * streaming AudioTrack fed by a small writer coroutine, started at an exact sample. Every start (play, resume, seek)
 * builds a fresh track, so there is no state to get stuck in (a static track that reached its end, a head position that
 * cannot be set, a buffer too large for the device). Pausing remembers the sample and drops the track.
 *
 * The position shown is the position of the audio actually leaving the device (the track's head position plus the
 * sample it started at), polled every ~30 ms; it is also what keeps the score cursor and the waveform in step.
 */
@Singleton
class PlaybackController @Inject constructor() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state

    private var pcm: ShortArray = ShortArray(0)
    private var rate = 44100
    private var track: AudioTrack? = null
    private var startFrame = 0
    private var pausedFrame = 0
    private var writer: Job? = null
    private var poller: Job? = null
    private var stopAtMs: Long? = null

    private val frames get() = pcm.size
    private fun msToFrame(ms: Long) = (ms.coerceAtLeast(0) * rate / 1000).toInt().coerceIn(0, maxOf(0, frames - 1))
    private fun frameToMs(f: Int) = f.toLong() * 1000L / rate

    fun load(samples: ShortArray, sampleRate: Int) {
        release()
        if (samples.isEmpty()) return
        pcm = samples
        rate = sampleRate
        pausedFrame = 0
        _state.value = PlaybackState(durationMs = frameToMs(frames), loaded = true)
    }

    fun play() {
        if (frames == 0) return
        if (_state.value.playing) return
        var from = pausedFrame
        if (from >= frames - rate / 50) from = 0
        startAt(from)
    }

    fun pause() {
        if (!_state.value.playing) return
        val f = currentFrame()
        stopTrack()
        pausedFrame = f
        stopAtMs = null
        _state.update { it.copy(playing = false, positionMs = frameToMs(f)) }
    }

    fun toggle() = if (_state.value.playing) pause() else play()

    fun seekTo(ms: Long) {
        if (frames == 0) return
        val f = msToFrame(ms)
        if (_state.value.playing) startAt(f)
        else {
            pausedFrame = f
            _state.update { it.copy(positionMs = frameToMs(f)) }
        }
    }

    /** Plays a passage once (e.g. the audio of a selected note) and stops at its end. */
    fun playRange(startMs: Long, endMs: Long) {
        if (frames == 0) return
        startAt(msToFrame(startMs))
        stopAtMs = endMs
    }

    fun setLoop(startMs: Long?, endMs: Long?) = _state.update { it.copy(loopStartMs = startMs, loopEndMs = endMs) }

    fun stop() {
        stopTrack()
        pausedFrame = 0
        stopAtMs = null
        _state.update { it.copy(playing = false, positionMs = 0) }
    }

    fun release() {
        stopTrack()
        pcm = ShortArray(0)
        pausedFrame = 0
        stopAtMs = null
        _state.value = PlaybackState()
    }

    // ---- internals -------------------------------------------------------------------------------------------

    private fun currentFrame(): Int {
        val t = track ?: return pausedFrame
        // The head position is an unsigned 32-bit counter of the frames played since this track started.
        val played = t.playbackHeadPosition.toLong() and 0xFFFFFFFFL
        return (startFrame + played).coerceAtMost(frames.toLong()).toInt()
    }

    private fun stopTrack() {
        writer?.cancel(); writer = null
        poller?.cancel(); poller = null
        val t = track
        track = null
        if (t != null) {
            runCatching { t.pause() }
            runCatching { t.flush() }
            runCatching { t.release() }
        }
    }

    private fun startAt(frame: Int) {
        stopTrack()
        stopAtMs = null
        val minBytes = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bytes = maxOf(minBytes.coerceAtLeast(0) * 2, rate / 4 * 2) // about 250 ms
        val t = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(bytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        }.getOrNull()
        if (t == null || t.state != AudioTrack.STATE_INITIALIZED) {
            runCatching { t?.release() }
            _state.update { it.copy(playing = false) }
            return
        }
        track = t
        startFrame = frame
        pausedFrame = frame
        val data = pcm
        // Prefill so that the audio starts at once, then keep the buffer topped up from a background coroutine.
        var next = frame
        next += t.write(data, next, minOf(data.size - next, bytes / 2), AudioTrack.WRITE_NON_BLOCKING).coerceAtLeast(0)
        t.play()
        _state.update { it.copy(playing = true, positionMs = frameToMs(frame)) }
        writer = scope.launch(Dispatchers.IO) {
            var pos = next
            while (isActive && pos < data.size) {
                val n = t.write(data, pos, minOf(4096, data.size - pos), AudioTrack.WRITE_NON_BLOCKING)
                if (n < 0) break
                if (n == 0) delay(8) else pos += n
            }
        }
        poller = scope.launch {
            while (isActive) {
                delay(30)
                val f = currentFrame()
                val pos = frameToMs(f)
                val s = _state.value
                val stopAt = stopAtMs
                val loopStart = s.loopStartMs
                val loopEnd = s.loopEndMs
                when {
                    stopAt != null && pos >= stopAt -> { pause(); return@launch }
                    loopStart != null && loopEnd != null && pos >= loopEnd -> { startAt(msToFrame(loopStart)); return@launch }
                    f >= frames - 1 -> {
                        stopTrack()
                        pausedFrame = 0
                        _state.update { it.copy(playing = false, positionMs = 0) }
                        return@launch
                    }
                    else -> _state.update { it.copy(positionMs = pos) }
                }
            }
        }
    }

    /** Fire-and-forget note preview (virtual keyboard); independent of the main player. */
    fun playPreview(samples: ShortArray, sampleRate: Int) {
        if (samples.isEmpty()) return
        val t = runCatching {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
        }.getOrNull() ?: return
        t.write(samples, 0, samples.size)
        t.play()
        scope.launch {
            delay(samples.size * 1000L / sampleRate + 100)
            runCatching { t.release() }
        }
    }
}
