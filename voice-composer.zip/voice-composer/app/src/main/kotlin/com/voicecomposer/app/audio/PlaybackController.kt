package com.voicecomposer.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

enum class PlaybackMode { ORIGINAL, MELODY, ARRANGEMENT }

data class PlaybackState(
    val playing: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val loopStartMs: Long? = null,
    val loopEndMs: Long? = null,
    val loaded: Boolean = false,
)

/**
 * One player for the three playback modes. The whole piece is rendered to a PCM buffer and played through a static
 * AudioTrack, so all tracks of an arrangement are sample aligned (no drift between tracks) and seeking is exact.
 * Position is polled every 20 ms, which is also what keeps the score cursor synchronized.
 */
@Singleton
class PlaybackController @Inject constructor() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state

    private var track: AudioTrack? = null
    private var rate = 44100
    private var frames = 0
    private var poller: Job? = null
    private var stopAtMs: Long? = null

    fun load(pcm: ShortArray, sampleRate: Int) {
        release()
        if (pcm.isEmpty()) return
        rate = sampleRate
        frames = pcm.size
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        track = t
        _state.value = PlaybackState(durationMs = frames * 1000L / rate, loaded = true)
    }

    fun play() {
        val t = track ?: return
        if (_state.value.positionMs >= _state.value.durationMs - 20) seekTo(0)
        t.play()
        _state.update { it.copy(playing = true) }
        startPolling()
    }

    fun pause() {
        track?.pause()
        poller?.cancel()
        _state.update { it.copy(playing = false, positionMs = currentMs()) }
        stopAtMs = null
    }

    fun toggle() = if (_state.value.playing) pause() else play()

    fun seekTo(ms: Long) {
        val t = track ?: return
        val wasPlaying = _state.value.playing
        t.pause()
        val frame = (ms.coerceIn(0, _state.value.durationMs) * rate / 1000).toInt().coerceAtMost(frames - 1)
        t.playbackHeadPosition = frame
        _state.update { it.copy(positionMs = ms.coerceIn(0, it.durationMs)) }
        if (wasPlaying) t.play()
    }

    /** Plays a passage once (e.g. the audio of a selected note) and stops at its end. */
    fun playRange(startMs: Long, endMs: Long) {
        seekTo(startMs.coerceAtLeast(0))
        stopAtMs = endMs
        play()
    }

    fun setLoop(startMs: Long?, endMs: Long?) = _state.update { it.copy(loopStartMs = startMs, loopEndMs = endMs) }

    private fun currentMs(): Long = track?.let { it.playbackHeadPosition.toLong() * 1000L / rate } ?: 0L

    private fun startPolling() {
        poller?.cancel()
        poller = scope.launch {
            while (isActive) {
                val pos = currentMs()
                val s = _state.value
                val loopEnd = s.loopEndMs
                val loopStart = s.loopStartMs
                val stopAt = stopAtMs
                when {
                    stopAt != null && pos >= stopAt -> { pause(); return@launch }
                    loopEnd != null && loopStart != null && pos >= loopEnd -> seekTo(loopStart)
                    pos >= s.durationMs - 15 -> {
                        track?.pause()
                        track?.playbackHeadPosition = 0
                        _state.update { it.copy(playing = false, positionMs = 0) }
                        return@launch
                    }
                    else -> _state.update { it.copy(positionMs = pos) }
                }
                delay(20)
            }
        }
    }

    fun stop() {
        track?.pause()
        poller?.cancel()
        track?.playbackHeadPosition = 0
        stopAtMs = null
        _state.update { it.copy(playing = false, positionMs = 0) }
    }

    fun release() {
        poller?.cancel()
        runCatching { track?.pause() }
        runCatching { track?.release() }
        track = null
        stopAtMs = null
        _state.value = PlaybackState()
    }

    /** Fire-and-forget note preview (virtual keyboard); independent of the main player. */
    fun playPreview(pcm: ShortArray, sampleRate: Int) {
        if (pcm.isEmpty()) return
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t.play()
        scope.launch {
            delay(pcm.size * 1000L / sampleRate + 100)
            runCatching { t.release() }
        }
    }
}
