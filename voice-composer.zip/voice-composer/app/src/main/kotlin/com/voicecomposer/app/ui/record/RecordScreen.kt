package com.voicecomposer.app.ui.record

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewModelScope
import com.voicecomposer.app.R
import com.voicecomposer.app.audio.AudioRecorder
import com.voicecomposer.app.audio.PlaybackController
import com.voicecomposer.app.audio.RecorderError
import com.voicecomposer.app.audio.RecorderState
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.data.SettingsStore
import com.voicecomposer.app.ui.common.WaveformView
import com.voicecomposer.app.ui.common.formatTimeFine
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.Ids
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RecordReview(val projectId: String, val durationMs: Long)

@HiltViewModel
class RecordViewModel @Inject constructor(
    private val recorder: AudioRecorder,
    private val repository: ProjectRepository,
    private val settings: SettingsStore,
    val playback: PlaybackController,
) : ViewModel() {
    val recorderState = recorder.ui
    val inputType: StateFlow<InputType> = MutableStateFlow(InputType.HUMMING).also { flow ->
        viewModelScope.launch { settings.settings.collect { s -> flow.value = s.inputType } }
    }
    private val _review = MutableStateFlow<RecordReview?>(null)
    val review: StateFlow<RecordReview?> = _review
    private var pendingId: String? = null

    fun setInputType(t: InputType) = viewModelScope.launch { settings.setInputType(t) }

    fun start() {
        val id = Ids.newId("p")
        pendingId = id
        recorder.start(repository.audioFile(id))
    }

    fun pause() = recorder.pause()
    fun resume() = recorder.resume()

    fun stop(title: String) {
        viewModelScope.launch {
            val result = recorder.stop() ?: return@launch
            val id = pendingId ?: return@launch
            val type = settings.settings.first().inputType.name
            repository.createFromRecording(id, title, type, result.sampleRate, result.durationMs)
            val audio = repository.loadAudio(id)
            if (audio != null) {
                val pcm = ShortArray(audio.samples.size) { (audio.samples[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
                playback.load(pcm, audio.sampleRate)
            }
            _review.value = RecordReview(id, result.durationMs)
        }
    }

    /** Discards the recording in progress (or the one being reviewed). */
    fun discard() {
        viewModelScope.launch {
            recorder.cancel()
            _review.value?.let { repository.deleteProject(it.projectId) }
            _review.value = null
            playback.release()
        }
    }

    fun leaveReview() { playback.release() }

    fun clearError() = recorder.clearError()

    override fun onCleared() {
        playback.release()
        if (recorder.ui.value.state != RecorderState.IDLE) CoroutineScope(Dispatchers.IO).launch { recorder.cancel() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordScreen(onBack: () -> Unit, onAnalyze: (String) -> Unit, vm: RecordViewModel = hiltViewModel()) {
    val ctx = LocalContext.current
    val ui by vm.recorderState.collectAsState()
    val review by vm.review.collectAsState()
    val input by vm.inputType.collectAsState()
    val play by vm.playback.state.collectAsState()
    val title = stringResource(R.string.default_recording_title, java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date()))
    var permissionDenied by remember { mutableStateOf(false) }
    // null = no dialog, false = restart (stay on the screen), true = leave the screen
    var confirmDiscard by remember { mutableStateOf<Boolean?>(null) }
    val active = ui.state != RecorderState.IDLE

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionDenied = !granted
        if (granted) vm.start()
    }
    fun startRecording() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.start()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Android restricts microphone access for apps in the background, so a recording is paused rather than lost.
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) vm.pause() }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    // Keep the screen on while recording.
    val view = LocalView.current
    DisposableEffect(active) {
        view.keepScreenOn = active
        onDispose { view.keepScreenOn = false }
    }
    BackHandler(enabled = active || review != null) { confirmDiscard = true }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.record)) },
            navigationIcon = {
                IconButton(onClick = { if (active || review != null) confirmDiscard = true else onBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
                }
            },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (review == null) {
                Text(stringResource(R.string.input_type_label), style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (t in InputType.entries) {
                        FilterChip(
                            selected = t == input, enabled = !active, onClick = { vm.setInputType(t) },
                            label = { Text(inputTypeLabel(t)) },
                        )
                    }
                }
                Text(stringResource(R.string.record_tip), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                WaveformView(ui.levels, height = 120.dp, live = true)
                Text(formatTimeFine(ui.elapsedMs), style = MaterialTheme.typography.displaySmall)

                if (ui.interrupted) Text(stringResource(R.string.record_interrupted), color = MaterialTheme.colorScheme.error)
                if (ui.error != null) {
                    Text(
                        stringResource(if (ui.error == RecorderError.INIT_FAILED) R.string.record_error_init else R.string.record_error_read),
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (permissionDenied) Text(stringResource(R.string.record_permission_denied), color = MaterialTheme.colorScheme.error)

                when (ui.state) {
                    RecorderState.IDLE -> LargeFloatingActionButton(onClick = { vm.clearError(); startRecording() }) {
                        Icon(Icons.Default.Mic, stringResource(R.string.record), Modifier.size(36.dp))
                    }
                    RecorderState.RECORDING, RecorderState.PAUSED -> Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledIconButton(onClick = { confirmDiscard = false }, Modifier.size(48.dp)) { Icon(Icons.Default.Refresh, stringResource(R.string.restart)) }
                        if (ui.state == RecorderState.RECORDING) {
                            LargeFloatingActionButton(onClick = { vm.pause() }) { Icon(Icons.Default.Pause, stringResource(R.string.pause), Modifier.size(36.dp)) }
                        } else {
                            LargeFloatingActionButton(onClick = { vm.resume() }) { Icon(Icons.Default.Mic, stringResource(R.string.resume), Modifier.size(36.dp)) }
                        }
                        FilledIconButton(onClick = { vm.stop(title) }, Modifier.size(48.dp)) { Icon(Icons.Default.Stop, stringResource(R.string.stop)) }
                    }
                }
            } else {
                val r = review!!
                Text(stringResource(R.string.record_review_title), style = MaterialTheme.typography.titleLarge)
                WaveformView(emptyList(), height = 8.dp)
                Text(formatTimeFine(play.positionMs) + " / " + formatTimeFine(r.durationMs), style = MaterialTheme.typography.headlineSmall)
                FilledIconButton(onClick = { vm.playback.toggle() }, Modifier.size(64.dp)) {
                    Icon(if (play.playing) Icons.Default.Pause else Icons.Default.PlayArrow, stringResource(R.string.play), Modifier.size(32.dp))
                }
                Button(onClick = { vm.leaveReview(); onAnalyze(r.projectId) }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Check, null, Modifier.size(18.dp)); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.analyze))
                }
                OutlinedButton(onClick = { vm.discard() }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Refresh, null, Modifier.size(18.dp)); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.record_again))
                }
            }
        }
    }

    confirmDiscard?.let { leave ->
        AlertDialog(
            onDismissRequest = { confirmDiscard = null },
            title = { Text(stringResource(R.string.discard_title)) },
            text = { Text(stringResource(R.string.discard_body)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDiscard = null
                    vm.discard()
                    if (leave) onBack()
                }) { Text(stringResource(R.string.discard)) }
            },
            dismissButton = { TextButton(onClick = { confirmDiscard = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
fun inputTypeLabel(t: InputType): String = stringResource(
    when (t) {
        InputType.SINGING -> R.string.input_singing
        InputType.HUMMING -> R.string.input_humming
        InputType.WHISTLING -> R.string.input_whistling
        InputType.VOCALISE -> R.string.input_vocalise
    }
)
