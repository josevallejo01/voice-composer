package com.voicecomposer.app.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.voicecomposer.engine.io.StreamingWavWriter
import com.voicecomposer.engine.io.WavIO
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteOrder
import javax.inject.Inject
import javax.inject.Singleton

data class ImportedAudio(val sampleRate: Int, val durationMs: Long, val format: String)

class UnsupportedAudioException(message: String) : Exception(message)

/**
 * Imports WAV, MP3, AAC/M4A and FLAC files (whatever the device codecs decode) and stores them as mono 16-bit WAV in
 * the private project folder. WAV is decoded directly, other formats go through MediaExtractor + MediaCodec.
 * The formats supported on a given device are those of its platform codecs; they are documented in the README.
 */
@Singleton
class AudioImporter @Inject constructor(@ApplicationContext private val context: Context) {
    companion object { const val MAX_MINUTES = 10 }

    suspend fun import(uri: Uri, target: File): ImportedAudio = withContext(Dispatchers.IO) {
        val head = ByteArray(12)
        val read = context.contentResolver.openInputStream(uri)?.use { it.read(head) } ?: throw UnsupportedAudioException("Cannot open file")
        val isWav = read == 12 && String(head, 0, 4) == "RIFF" && String(head, 8, 4) == "WAVE"
        if (isWav) importWav(uri, target) else importWithCodec(uri, target)
    }

    private fun importWav(uri: Uri, target: File): ImportedAudio {
        val bytes = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val audio = try { WavIO.decode(bytes) } catch (e: IllegalArgumentException) { throw UnsupportedAudioException(e.message ?: "WAV") }
        val limit = audio.sampleRate * 60 * MAX_MINUTES
        val samples = if (audio.samples.size > limit) audio.samples.copyOf(limit) else audio.samples
        WavIO.write(target, samples, audio.sampleRate)
        return ImportedAudio(audio.sampleRate, samples.size * 1000L / audio.sampleRate, "WAV")
    }

    private fun importWithCodec(uri: Uri, target: File): ImportedAudio {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; format = f; break }
            }
            if (track < 0 || format == null) throw UnsupportedAudioException("No audio track")
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val tmp = File(target.parentFile, target.name + ".tmp")
            // The output rate may differ from the container rate (e.g. HE-AAC): collect PCM first, then write.
            val pcm = java.io.ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val maxBytes = 2L * 48000 * 60 * MAX_MINUTES * 2
            while (!outputDone) {
                if (!inputDone) {
                    val idx = codec.dequeueInputBuffer(10_000)
                    if (idx >= 0) {
                        val buf = codec.getInputBuffer(idx)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(idx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val out = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    out >= 0 -> {
                        val buf = codec.getOutputBuffer(out)!!
                        if (info.size > 0) {
                            val chunk = ByteArray(info.size)
                            buf.position(info.offset); buf.get(chunk, 0, info.size)
                            pcm.write(chunk)
                        }
                        codec.releaseOutputBuffer(out, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0 || pcm.size() > maxBytes) outputDone = true
                    }
                    out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
            codec.stop(); codec.release()

            val bytes = pcm.toByteArray()
            val shorts = java.nio.ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val frames = shorts.remaining() / channels
            val mono = ShortArray(frames)
            for (i in 0 until frames) {
                var sum = 0
                for (c in 0 until channels) sum += shorts.get(i * channels + c).toInt()
                mono[i] = (sum / channels).toShort()
            }
            StreamingWavWriter(tmp, rate).use { w -> w.write(mono, mono.size) }
            if (!tmp.renameTo(target)) { tmp.copyTo(target, overwrite = true); tmp.delete() }
            return ImportedAudio(rate, frames * 1000L / rate, mime.removePrefix("audio/").uppercase())
        } catch (e: UnsupportedAudioException) {
            throw e
        } catch (e: Exception) {
            throw UnsupportedAudioException(e.message ?: "Cannot decode this file")
        } finally {
            extractor.release()
        }
    }
}
