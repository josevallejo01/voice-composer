package com.voicecomposer.app.ui.arrange

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.voicecomposer.app.R
import com.voicecomposer.app.audio.PlaybackController
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.export.ExportFormat
import com.voicecomposer.app.export.ExportService
import com.voicecomposer.app.ui.common.formatTimeFine
import com.voicecomposer.engine.arrangement.ArrangementEngine
import com.voicecomposer.engine.synth.Synth
import com.voicecomposer.model.Arrangement as Arr
import com.voicecomposer.model.ArrangementStyle
import com.voicecomposer.model.Transcription
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

data class ArrangeUi(
    val source: Transcription? = null,
    val style: ArrangementStyle = ArrangementStyle.POP,
    val complexity: Int = 2,
    val current: Arr? = null,
    val generating: Boolean = false,
    val title: String = "",
)

/**
 * The arrangement is generated from the validated melody and stored as its own version; the source melody is never
 * modified (spec 11). Several versions can be kept and compared.
 */
@HiltViewModel
class ArrangeViewModel @Inject constructor(
    handle: SavedStateHandle,
    private val repository: ProjectRepository,
    private val engine: ArrangementEngine,
    private val exporter: ExportService,
    val playback: PlaybackController,
) : ViewModel() {
    val projectId: String = checkNotNull(handle["id"])
    private val _ui = MutableStateFlow(ArrangeUi())
    val ui: StateFlow<ArrangeUi> = _ui
    val versions: StateFlow<List<Arr>> = repository.arrangements(projectId)
        .map { list -> list.map { it.second } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var renderJob: Job? = null
    private var version = 0

    init {
        viewModelScope.launch {
            val p = repository.get(projectId) ?: return@launch
            version = p.version
            _ui.value = _ui.value.copy(source = repository.loadTranscription(p), title = p.title)
        }
    }

    fun setStyle(s: ArrangementStyle) { _ui.value = _ui.value.copy(style = s) }
    fun setComplexity(c: Int) { _ui.value = _ui.value.copy(complexity = c) }

    fun generate() {
        val s = _ui.value.source ?: return
        if (s.notes.isEmpty() || _ui.value.generating) return
        viewModelScope.launch {
            _ui.value = _ui.value.copy(generating = true)
            val a = withContext(Dispatchers.Default) { engine.arrange(s, _ui.value.style, _ui.value.complexity, version) }
            repository.saveArrangement(projectId, a)
            select(a)
            _ui.value = _ui.value.copy(generating = false)
        }
    }

    fun select(a: Arr) {
        _ui.value = _ui.value.copy(current = a, style = a.style, complexity = a.complexity)
        render()
    }

    fun delete(a: Arr) {
        viewModelScope.launch {
            repository.deleteArrangement(a.id)
            if (_ui.value.current?.id == a.id) { _ui.value = _ui.value.copy(current = null); playback.release() }
        }
    }

    fun toggleTrack(id: String) = updateTracks { t -> if (t.id == id) t.copy(enabled = !t.enabled) else t }
    fun setVolume(id: String, v: Float) = updateTracks { t -> if (t.id == id) t.copy(volume = v) else t }

    private fun updateTracks(f: (com.voicecomposer.model.Track) -> com.voicecomposer.model.Track) {
        val a = _ui.value.current ?: return
        val updated = a.copy(tracks = a.tracks.map(f))
        _ui.value = _ui.value.copy(current = updated)
        render()
        viewModelScope.launch { repository.saveArrangement(projectId, updated) }
    }

    /** Re-renders the mix shortly after the last change (volume sliders fire often). */
    private fun render() {
        val a = _ui.value.current ?: return
        val src = _ui.value.source ?: return
        renderJob?.cancel()
        renderJob = viewModelScope.launch {
            delay(250)
            val before = playback.state.value
            val pcm = withContext(Dispatchers.Default) { Synth.toPcm16(Synth.render(a.tracks, src.tempoMap, minLengthSec = 1.0)) }
            playback.load(pcm, Synth.SAMPLE_RATE)
            playback.seekTo(before.positionMs)
            if (before.playing) playback.play()
        }
    }

    fun exportMidi(onDone: (android.net.Uri) -> Unit, onError: () -> Unit) {
        val s = _ui.value.source ?: return
        viewModelScope.launch {
            try { onDone(exporter.export(ExportFormat.MIDI, _ui.value.title, s, _ui.value.current)) } catch (e: Exception) { onError() }
        }
    }

    fun share(context: android.content.Context, uri: android.net.Uri) = exporter.share(context, uri, ExportFormat.MIDI, _ui.value.title)

    override fun onCleared() { playback.release() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArrangeScreen(onBack: () -> Unit, vm: ArrangeViewModel = hiltViewModel()) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsState()
    val versions by vm.versions.collectAsState()
    val play by vm.playback.state.collectAsState()
    var exportError by remember { mutableStateOf(false) }
    val current = ui.current

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.arrange)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (ui.source != null && ui.source!!.notes.isEmpty()) {
                Text(stringResource(R.string.arrange_empty), color = MaterialTheme.colorScheme.error)
            }
            Text(stringResource(R.string.arrange_intro), style = MaterialTheme.typography.bodyMedium)

            Text(stringResource(R.string.style), style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (s in ArrangementStyle.entries) FilterChip(ui.style == s, { vm.setStyle(s) }, label = { Text(styleLabel(s)) })
            }
            Text(stringResource(R.string.complexity, ui.complexity), style = MaterialTheme.typography.titleSmall)
            Slider(ui.complexity.toFloat(), { vm.setComplexity(Math.round(it)) }, valueRange = 1f..3f, steps = 1)

            Button(onClick = vm::generate, enabled = !ui.generating && (ui.source?.notes?.isNotEmpty() == true), modifier = Modifier.fillMaxWidth()) {
                if (ui.generating) { CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Text("  " + stringResource(R.string.generating)) }
                else Text(stringResource(R.string.generate))
            }

            if (current != null) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FilledIconButton(onClick = { vm.playback.toggle() }, Modifier.size(44.dp)) {
                                Icon(if (play.playing) Icons.Default.Pause else Icons.Default.PlayArrow, stringResource(R.string.play))
                            }
                            Text(formatTimeFine(play.positionMs) + " / " + formatTimeFine(play.durationMs))
                        }
                        Text(stringResource(R.string.chords), style = MaterialTheme.typography.titleSmall)
                        Text(current.chords.joinToString("  ") { it.symbol }, style = MaterialTheme.typography.bodyMedium)

                        Text(stringResource(R.string.tracks), style = MaterialTheme.typography.titleSmall)
                        for (t in current.tracks) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(t.enabled, { vm.toggleTrack(t.id) })
                                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                    Text(t.name + " · " + t.instrument.label, style = MaterialTheme.typography.bodyMedium)
                                    Slider(t.volume, { vm.setVolume(t.id, it) }, valueRange = 0f..1f, enabled = t.enabled)
                                }
                            }
                        }
                        Text(stringResource(R.string.arrange_source_untouched), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = { vm.exportMidi({ vm.share(ctx, it) }, { exportError = true }) }, Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.export_midi_arrangement))
                        }
                        if (exportError) Text(stringResource(R.string.export_failed), color = MaterialTheme.colorScheme.error)
                    }
                }
            }

            if (versions.isNotEmpty()) {
                Text(stringResource(R.string.versions), style = MaterialTheme.typography.titleSmall)
                for ((i, v) in versions.withIndex()) {
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(stringResource(R.string.version_label, versions.size - i, styleLabel(v.style), v.complexity))
                                if (v.id == current?.id) Text(stringResource(R.string.selected), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                            OutlinedButton(onClick = { vm.select(v) }) { Text(stringResource(R.string.open)) }
                            IconButton(onClick = { vm.delete(v) }) { Icon(Icons.Default.Delete, stringResource(R.string.delete)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun styleLabel(s: ArrangementStyle): String = stringResource(
    when (s) {
        ArrangementStyle.POP -> R.string.style_pop
        ArrangementStyle.FOLK -> R.string.style_folk
        ArrangementStyle.CLASSICAL -> R.string.style_classical
    }
)
