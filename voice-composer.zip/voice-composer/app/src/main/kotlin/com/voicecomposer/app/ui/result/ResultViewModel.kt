package com.voicecomposer.app.ui.result

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.voicecomposer.app.audio.Orchestra
import com.voicecomposer.app.audio.PlaybackController
import com.voicecomposer.app.audio.RenderedAudio
import com.voicecomposer.app.audio.PlaybackMode
import com.voicecomposer.app.data.ProjectEntity
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.data.ProjectStatus
import com.voicecomposer.app.export.ExportFormat
import com.voicecomposer.app.export.ExportService
import com.voicecomposer.app.ui.common.peakEnvelope
import com.voicecomposer.model.EditSession
import com.voicecomposer.model.Instrument
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.QuantizationMode
import com.voicecomposer.model.TimeSignature
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.TrackRole
import com.voicecomposer.model.Track
import com.voicecomposer.model.TranscriptionEditor
import com.voicecomposer.model.ValidationState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

sealed interface ResultEvent {
    data class Exported(val format: ExportFormat, val uri: android.net.Uri, val title: String) : ResultEvent
    data object ExportFailed : ResultEvent
    data object Reanalyze : ResultEvent
    data object Restored : ResultEvent
    data object NothingToRestore : ResultEvent
    data object NothingHeard : ResultEvent
    data object MicFailed : ResultEvent
}

/** Note durations offered in the toolbar, in beats (quarter note = 1). */
val NOTE_DURATIONS = listOf(0.25, 0.5, 1.0, 2.0, 4.0)

@OptIn(FlowPreview::class)
@HiltViewModel
class ResultViewModel @Inject constructor(
    handle: SavedStateHandle,
    private val repository: ProjectRepository,
    private val exporter: ExportService,
    val playback: PlaybackController,
    private val noteListener: com.voicecomposer.app.audio.NoteListener,
    private val profileStore: com.voicecomposer.app.data.ProfileStore,
    private val settingsStore: com.voicecomposer.app.data.SettingsStore,
    private val orchestra: Orchestra,
) : ViewModel() {
    val projectId: String = checkNotNull(handle["id"])

    val project: StateFlow<ProjectEntity?> = repository.observe(projectId).stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private var session: EditSession? = null
    private val _transcription = MutableStateFlow<Transcription?>(null)
    val transcription: StateFlow<Transcription?> = _transcription

    private val _history = MutableStateFlow(false to false)
    /** (canUndo, canRedo) */
    val history: StateFlow<Pair<Boolean, Boolean>> = _history

    private val _selected = MutableStateFlow<String?>(null)
    val selectedId: StateFlow<String?> = _selected

    private val _drawMode = MutableStateFlow(false)
    val drawMode: StateFlow<Boolean> = _drawMode

    private val _noteDuration = MutableStateFlow(1.0)
    val noteDuration: StateFlow<Double> = _noteDuration

    private val _mode = MutableStateFlow(PlaybackMode.MELODY)
    val mode: StateFlow<PlaybackMode> = _mode

    /** The instrument that plays the melody when you listen to it. */
    val melodyInstrument: StateFlow<Instrument> = settingsStore.settings.map { it.melodyInstrument }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Instrument.VIOLIN)

    private val _rendering = MutableStateFlow(false)
    /** True while the orchestra is being rendered (a second or two after an edit). */
    val rendering: StateFlow<Boolean> = _rendering

    fun setMelodyInstrument(i: Instrument) {
        viewModelScope.launch {
            settingsStore.setMelodyInstrument(i)
            melodyAudio = null
            if (_mode.value == PlaybackMode.MELODY) loadMode(PlaybackMode.MELODY, keepPosition = true)
        }
    }

    private val _hasAudio = MutableStateFlow(false)
    val hasAudio: StateFlow<Boolean> = _hasAudio

    private val _peaks = MutableStateFlow<List<Float>>(emptyList())
    val peaks: StateFlow<List<Float>> = _peaks

    private val _listening = MutableStateFlow(false)
    /** The microphone is open to hear the note the person sings to correct the selected note. */
    val listening: StateFlow<Boolean> = _listening

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy

    private val _events = MutableSharedFlow<ResultEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<ResultEvent> = _events

    private var originalPcm: ShortArray? = null
    private var originalRate = 44100
    private var melodyAudio: RenderedAudio? = null
    private var melodyJob: Job? = null
    private var lastSaved: Transcription? = null

    init {
        viewModelScope.launch {
            val p = repository.get(projectId) ?: return@launch
            val t = repository.loadTranscription(p) ?: return@launch
            session = EditSession(t)
            lastSaved = t
            _transcription.value = t
            val audio = repository.loadAudio(projectId)
            if (audio != null) {
                withContext(Dispatchers.Default) {
                    originalPcm = ShortArray(audio.samples.size) { (audio.samples[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
                    originalRate = audio.sampleRate
                }
                _hasAudio.value = true
                _mode.value = PlaybackMode.ORIGINAL
            }
            loadMode(_mode.value, keepPosition = false)
        }
        // Autosave: every edit is persisted shortly after it is made (spec 7.5).
        viewModelScope.launch {
            _transcription.filterNotNull().drop(1).debounce(600).collect { saveNow(it) }
        }
    }

    private suspend fun saveNow(t: Transcription) {
        if (t == lastSaved) return
        repository.saveWorking(projectId, t)
        lastSaved = t
        learnFrom(t)
    }

    private var engineOriginal: Transcription? = null
    private var engineLoaded = false

    /** Every saved correction refines the singer's profile (when learning is on); the file is rewritten, never accumulated. */
    private suspend fun learnFrom(final: Transcription) {
        if (!settingsStore.settings.first().voiceLearning) return
        if (!engineLoaded) { engineOriginal = repository.latestEngineTranscription(projectId); engineLoaded = true }
        val type = runCatching { com.voicecomposer.engine.preprocessing.InputType.valueOf(project.value?.inputType ?: "SINGING") }.getOrDefault(com.voicecomposer.engine.preprocessing.InputType.SINGING)
        engineOriginal?.let { profileStore.record(projectId, it, final, type) }
    }

    // ---- editing ---------------------------------------------------------------------------------------------

    private fun edit(label: String, op: (Transcription) -> Transcription) {
        val s = session ?: return
        _transcription.value = s.apply(label, op)
        refresh()
    }

    private fun refresh() {
        val s = session ?: return
        _history.value = s.canUndo to s.canRedo
        val t = s.current
        if (_selected.value != null && t.events.none { it.id == _selected.value }) _selected.value = null
        melodyAudio = null
        if (_mode.value == PlaybackMode.MELODY) scheduleMelodyReload()
    }

    fun undo() { session?.let { _transcription.value = it.undo(); refresh() } }
    fun redo() { session?.let { _transcription.value = it.redo(); refresh() } }

    fun select(id: String?) { _selected.value = id }
    fun setDrawMode(on: Boolean) { _drawMode.value = on }
    fun setNoteDuration(beats: Double) { _noteDuration.value = beats }

    fun shiftPitch(semitones: Int) { _selected.value?.let { id -> edit("Pitch") { TranscriptionEditor.shiftPitch(it, id, semitones) } }; preview(selectedMidi()) }
    fun setPitch(id: String, midi: Int) { edit("Pitch") { TranscriptionEditor.setPitch(it, id, midi) }; preview(midi) }
    /** Hears one sung note and gives it to the selected note (the person's voice is the quickest way to say which note it is). */
    fun singSelected() {
        val id = _selected.value ?: return
        if (_listening.value) return
        playback.pause()
        viewModelScope.launch {
            _listening.value = true
            try {
                val audio = noteListener.listen()
                if (audio == null) { _events.emit(ResultEvent.MicFailed); return@launch }
                val type = runCatching { com.voicecomposer.engine.preprocessing.InputType.valueOf(project.value?.inputType ?: "SINGING") }
                    .getOrDefault(com.voicecomposer.engine.preprocessing.InputType.SINGING)
                val midi = withContext(Dispatchers.Default) {
                    com.voicecomposer.engine.pitch.SungNoteReader.read(audio, com.voicecomposer.app.audio.NoteListener.RATE, type)
                }
                if (midi == null) _events.emit(ResultEvent.NothingHeard)
                else if (_transcription.value?.events?.any { it.id == id } == true) setPitch(id, midi)
            } finally {
                _listening.value = false
            }
        }
    }

    fun halveDuration() = changeDuration(0.5)
    fun doubleDuration() = changeDuration(2.0)
    private fun changeDuration(factor: Double) {
        val id = _selected.value ?: return
        val n = _transcription.value?.events?.firstOrNull { it.id == id } ?: return
        edit("Duration") { TranscriptionEditor.setDuration(it, id, (n.durationBeats * factor).coerceIn(0.25, 8.0)) }
    }
    fun split() { _selected.value?.let { id -> edit("Split") { TranscriptionEditor.splitNote(it, id) } } }
    fun mergeNext() { _selected.value?.let { id -> edit("Merge") { TranscriptionEditor.mergeWithNext(it, id) } } }
    fun deleteSelected() { _selected.value?.let { id -> edit("Delete") { TranscriptionEditor.deleteNote(it, id) }; _selected.value = null } }
    fun validateSelected() { _selected.value?.let { id -> edit("Validate") { TranscriptionEditor.validate(it, id) } } }
    fun setLyric(text: String) {
        val id = _selected.value ?: return
        edit("Lyric") { TranscriptionEditor.setLyric(it, id, text.trim()) }
    }
    fun addNote(startBeat: Double, midi: Int) {
        edit("Add note") { TranscriptionEditor.addNote(it, startBeat, _noteDuration.value, midi) }
        preview(midi)
        // Select the new note so it can be adjusted right away.
        _transcription.value?.notes?.minByOrNull { kotlin.math.abs(it.startBeat - startBeat) }?.let { _selected.value = it.id }
    }

    /** Virtual keyboard: changes the selected note, or appends a note after the last one. */
    fun pressKey(midi: Int) {
        val id = _selected.value
        if (id != null) setPitch(id, midi)
        else if (_drawMode.value) {
            val end = _transcription.value?.notes?.maxOfOrNull { it.endBeat } ?: 0.0
            addNote(end, midi)
        } else preview(midi)
    }

    fun setTempo(bpm: Double) = edit("Tempo") { TranscriptionEditor.setTempo(it, bpm) }
    fun setMeter(ts: TimeSignature) = edit("Time signature") { TranscriptionEditor.setTimeSignature(it, ts) }
    fun setKey(tonic: Int, minor: Boolean) = edit("Key") {
        TranscriptionEditor.setKey(it, KeySignature(tonic, if (minor) com.voicecomposer.model.Mode.MINOR else com.voicecomposer.model.Mode.MAJOR))
    }
    fun setQuantization(m: QuantizationMode) = edit("Quantization") { TranscriptionEditor.setQuantization(it, m) }

    fun rename(title: String) = viewModelScope.launch { repository.rename(projectId, title) }

    /** Drops manual corrections and goes back to what the engine detected (the corrected version stays undoable). */
    fun restoreDetected() {
        viewModelScope.launch {
            val original = repository.latestEngineTranscription(projectId)
            if (original == null) { _events.emit(ResultEvent.NothingToRestore); return@launch }
            edit("Restore detected version") { original }
            _events.emit(ResultEvent.Restored)
        }
    }

    // ---- uncertain notes -------------------------------------------------------------------------------------

    fun uncertainCount(t: Transcription) = t.notes.count { it.validation == ValidationState.UNCERTAIN }

    fun jumpToUncertain(forward: Boolean) {
        val t = _transcription.value ?: return
        val list = t.notes.filter { it.validation == ValidationState.UNCERTAIN }.sortedBy { it.startBeat }
        if (list.isEmpty()) return
        val cur = _selected.value?.let { id -> t.notes.firstOrNull { it.id == id } }
        val target = if (cur == null) (if (forward) list.first() else list.last()) else {
            if (forward) list.firstOrNull { it.startBeat > cur.startBeat + 1e-6 } ?: list.first()
            else list.lastOrNull { it.startBeat < cur.startBeat - 1e-6 } ?: list.last()
        }
        _selected.value = target.id
    }

    // ---- playback --------------------------------------------------------------------------------------------

    fun setMode(m: PlaybackMode) {
        if (m == _mode.value) return
        _mode.value = m
        viewModelScope.launch { loadMode(m, keepPosition = true) }
    }

    fun togglePlay() = playback.toggle()
    fun seekFraction(f: Float) = playback.seekTo((playback.state.value.durationMs * f).toLong())

    /** Plays the selected note (from the recording or the synthesised melody, depending on the mode). */
    fun playSelected() {
        val t = _transcription.value ?: return
        val n = t.notes.firstOrNull { it.id == _selected.value } ?: return
        if (_mode.value == PlaybackMode.ORIGINAL) {
            playback.playRange((n.startSec * 1000).toLong() - 150, (n.endSec * 1000).toLong() + 150)
        } else {
            playback.playRange((t.tempoMap.beatToSec(n.startBeat) * 1000).toLong() - 50, (t.tempoMap.beatToSec(n.endBeat) * 1000).toLong() + 100)
        }
    }

    /** Cursor position in beats for the score, or null when nothing has started playing. */
    fun beatAt(ms: Long): Double? {
        val t = _transcription.value ?: return null
        return t.tempoMap.secToBeat(ms / 1000.0).coerceAtLeast(0.0)
    }

    private suspend fun loadMode(m: PlaybackMode, keepPosition: Boolean) {
        val before = playback.state.value
        val audio = when (m) {
            PlaybackMode.ORIGINAL -> RenderedAudio(originalPcm ?: return, originalRate, 1)
            else -> renderMelody()
        }
        playback.load(audio.pcm, audio.sampleRate, audio.channels)
        // The waveform always shows the sound that is playing, so the cursor and the audio agree.
        _peaks.value = withContext(Dispatchers.Default) { peakEnvelope(audio.monoFloats(), 320).toList() }
        if (keepPosition) {
            playback.seekTo(before.positionMs)
            if (before.playing) playback.play()
        }
    }

    private suspend fun renderMelody(): RenderedAudio {
        melodyAudio?.let { return it }
        val t = _transcription.value ?: return RenderedAudio(ShortArray(0), 44100, 1)
        _rendering.value = true
        try {
            val track = Track("melody", "Melody", melodyInstrument.value, TrackRole.MELODY, t.notes)
            val audio = orchestra.render(listOf(track), t.tempoMap, t.timeSignature.beatsPerMeasure)
            melodyAudio = audio
            return audio
        } finally {
            _rendering.value = false
        }
    }

    private fun scheduleMelodyReload() {
        melodyJob?.cancel()
        melodyJob = viewModelScope.launch {
            delay(350)
            if (_mode.value == PlaybackMode.MELODY) loadMode(PlaybackMode.MELODY, keepPosition = true)
        }
    }

    private fun selectedMidi(): Int? =
        _transcription.value?.notes?.firstOrNull { it.id == _selected.value }?.midiPitch

    /** Short note in the melody instrument when a pitch is chosen, so the user hears what they are entering. */
    private fun preview(midi: Int?) {
        if (midi == null) return
        viewModelScope.launch {
            val audio = orchestra.renderNote(melodyInstrument.value, midi, 0.6)
            playback.playPreview(audio.pcm, audio.sampleRate, audio.channels)
        }
    }

    // ---- export / re-analysis --------------------------------------------------------------------------------

    fun export(format: ExportFormat, title: String) {
        val t = _transcription.value ?: return
        viewModelScope.launch {
            _busy.value = true
            try {
                val uri = exporter.export(format, title, t)
                _events.emit(ResultEvent.Exported(format, uri, title))
            } catch (e: Exception) {
                _events.emit(ResultEvent.ExportFailed)
            } finally {
                _busy.value = false
            }
        }
    }

    fun share(context: Context, e: ResultEvent.Exported) = exporter.share(context, e.uri, e.format, e.title)

    fun reanalyze() {
        viewModelScope.launch {
            _transcription.value?.let { saveNow(it) }
            repository.setStatus(projectId, ProjectStatus.RECORDED)
            engineLoaded = false
            _events.emit(ResultEvent.Reanalyze)
        }
    }

    override fun onCleared() {
        playback.release()
        // The debounce may not have fired yet: make sure the last edit is not lost.
        val t = _transcription.value
        if (t != null && t != lastSaved) CoroutineScope(Dispatchers.IO).launch { repository.saveWorking(projectId, t) }
    }
}
