package com.voicecomposer.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val Light = lightColorScheme(
    primary = Color(0xFF3F51B5), secondary = Color(0xFF00897B), tertiary = Color(0xFFE65100),
)
private val Dark = darkColorScheme(
    primary = Color(0xFFB4BEFF), secondary = Color(0xFF7FD8CB), tertiary = Color(0xFFFFB27A),
)

/** Colour used for notes the engine is unsure about. Always orange so it never blends with the selection colour. */
val UncertainColor = Color(0xFFE67E22)

@Composable
fun VoiceComposerTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val ctx = LocalContext.current
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) Dark else Light
    MaterialTheme(colorScheme = scheme, content = content)
}
