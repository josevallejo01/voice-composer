package com.voicecomposer.app.data

import android.content.Context
import com.voicecomposer.engine.ml.BlendedClassifier
import com.voicecomposer.engine.ml.ForestLearning
import com.voicecomposer.engine.ml.ForestTrainer
import com.voicecomposer.engine.ml.NoteClassifier
import com.voicecomposer.engine.ml.RandomForest
import com.voicecomposer.engine.preprocessing.InputType
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The note classifiers: the random forest shipped in the app (scikit-learn, trained on noise-augmented data) and, per
 * kind of sound, a second forest trained on this singer's own labelled examples (voice setup takes + corrections),
 * blended with the shipped one. Nothing here leaves the phone.
 */
@Singleton
class NoteForests @Inject constructor(@ApplicationContext private val context: Context) {
    private val dir get() = File(context.filesDir, "profile/rf").also { it.mkdirs() }
    private val cache = HashMap<String, NoteClassifier>()

    private val shipped: RandomForest? by lazy {
        runCatching { context.assets.open("note_rf.json").use { RandomForest.fromJson(it.readBytes().toString(Charsets.UTF_8)) } }.getOrNull()
    }

    val available: Boolean get() = shipped != null

    /** Joins the pieces of a note the detector cut in two (the voice wanders); null -> notes stay as decoded. */
    private val merger: RandomForest? by lazy {
        runCatching { context.assets.open("note_merge.json").use { RandomForest.fromJson(it.readBytes().toString(Charsets.UTF_8)) } }.getOrNull()
    }
    fun merger(@Suppress("UNUSED_PARAMETER") type: InputType): RandomForest? = merger

    private fun key(t: InputType) = if (t == InputType.VOCALISE) InputType.SINGING.name else t.name
    fun calibrationRowsFile(t: InputType) = File(dir, "cal_${key(t)}.json")
    fun projectRowsFile(t: InputType, projectId: String) = File(dir, "p_${key(t)}_$projectId.json")

    /** Classifier for one kind of sound; null (-> hand-written rules) when the shipped forest could not be loaded. */
    fun classifier(type: InputType): NoteClassifier? {
        val base = shipped ?: return null
        val k = key(type)
        synchronized(cache) { cache[k]?.let { return it } }
        val rows = ownRows(type)
        val user = if (rows.size >= 30) runCatching { ForestTrainer.train(rows.map { it.first }, IntArray(rows.size) { rows[it].second }) }.getOrNull() else null
        val c: NoteClassifier = if (user == null) base else BlendedClassifier(base, user, ForestTrainer.userWeight(rows.size))
        synchronized(cache) { cache[k] = c }
        return c
    }

    fun ownExamples(type: InputType): Int = ownRows(type).size

    /** Number of personal data sets (voice setups + corrected projects) the singer's own forests are built from. */
    fun ownSources(): Int = dir.listFiles().orEmpty().size

    private fun ownRows(type: InputType): List<Pair<DoubleArray, Int>> {
        val files = ArrayList<File>()
        calibrationRowsFile(type).takeIf { it.exists() }?.let { files.add(it) }
        // Newest projects last, so that the cap below drops the oldest corrections first.
        files.addAll(dir.listFiles { f -> f.name.startsWith("p_${key(type)}_") }.orEmpty().sortedBy { it.lastModified() })
        val rows = ArrayList<Pair<DoubleArray, Int>>()
        for (f in files) rows.addAll(runCatching { ForestLearning.rowsFromJson(f.readText()) }.getOrDefault(emptyList()))
        return if (rows.size > MAX_ROWS) rows.subList(rows.size - MAX_ROWS, rows.size).toList() else rows
    }

    fun invalidate() = synchronized(cache) { cache.clear() }

    companion object { const val MAX_ROWS = 6000 }
}
