package com.voicecomposer.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Click track for recording. With a known tempo the analysis no longer has to guess it from the singing, which is the
 * single biggest improvement for rhythm. One bar of clicks is rendered once and looped by a static AudioTrack, so the
 * clicks stay sample accurate for as long as the recording lasts. Recording and click are started together; the small
 * output latency between them is measured away afterwards by the phase search of the analysis.
 */
@Singleton
class Metronome @Inject constructor() {
    private var track: AudioTrack? = null

    /**
     * [countInBeats] beats are always played; after them the click continues only if [continues] is set.
     * The click is played at [volume] (0..1).
     */
    fun start(bpm: Double, beatsPerBar: Int, countInBeats: Int, continues: Boolean, volume: Float = 0.8f) {
        stop()
        val rate = RATE
        val beatFrames = (rate * 60.0 / bpm).toInt()
        val bar = renderBar(beatFrames, beatsPerBar, rate)
        val pcm: ShortArray
        var loop = true
        if (continues) {
            // Count-in then the same bar repeating: one bar buffer looped is enough when the count-in is whole bars.
            pcm = bar
        } else {
            val total = ShortArray(beatFrames * countInBeats)
            for (b in 0 until countInBeats) {
                val src = bar
                val from = (b % beatsPerBar) * beatFrames
                System.arraycopy(src, from, total, b * beatFrames, beatFrames)
            }
            pcm = total
            loop = false
        }
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        t.write(pcm, 0, pcm.size)
        t.setVolume(volume.coerceIn(0f, 1f))
        if (loop) t.setLoopPoints(0, pcm.size, -1)
        t.play()
        track = t
    }

    fun stop() {
        track?.let { runCatching { it.stop() }; runCatching { it.release() } }
        track = null
    }

    private fun renderBar(beatFrames: Int, beatsPerBar: Int, rate: Int): ShortArray {
        val out = ShortArray(beatFrames * beatsPerBar)
        val clickLen = (rate * 0.03).toInt()
        for (b in 0 until beatsPerBar) {
            val freq = if (b == 0) 1500.0 else 1000.0 // accented first beat
            val amp = if (b == 0) 0.9 else 0.6
            for (i in 0 until minOf(clickLen, beatFrames)) {
                val env = exp(-i / (rate * 0.006))
                out[b * beatFrames + i] = (sin(2 * PI * freq * i / rate) * env * amp * 32767).toInt().toShort()
            }
        }
        return out
    }

    companion object { const val RATE = 44100 }
}
