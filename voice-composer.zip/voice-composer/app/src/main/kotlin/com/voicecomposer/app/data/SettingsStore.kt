package com.voicecomposer.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.QuantizationMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("voice_composer_settings")

data class AppSettings(
    val inputType: InputType = InputType.HUMMING,
    val quantization: QuantizationMode = QuantizationMode.AUTOMATIC,
    val tuningCompensation: Boolean = true,
)

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val inputKey = stringPreferencesKey("input_type")
    private val quantKey = stringPreferencesKey("quantization")
    private val tuningKey = booleanPreferencesKey("tuning")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            inputType = p[inputKey]?.let { runCatching { InputType.valueOf(it) }.getOrNull() } ?: InputType.HUMMING,
            quantization = p[quantKey]?.let { runCatching { QuantizationMode.valueOf(it) }.getOrNull() } ?: QuantizationMode.AUTOMATIC,
            tuningCompensation = p[tuningKey] ?: true,
        )
    }

    suspend fun setInputType(t: InputType) = context.dataStore.edit { it[inputKey] = t.name }
    suspend fun setQuantization(q: QuantizationMode) = context.dataStore.edit { it[quantKey] = q.name }
    suspend fun setTuning(on: Boolean) = context.dataStore.edit { it[tuningKey] = on }
}
