package com.voicecomposer.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.QuantizationMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("voice_composer_settings")

data class AppSettings(
    val inputType: InputType = InputType.HUMMING,
    val quantization: QuantizationMode = QuantizationMode.AUTOMATIC,
    val tuningCompensation: Boolean = true,
    val neuralEngine: Boolean = true,
    val metronomeOn: Boolean = false,
    val metronomeBpm: Int = 100,
    val beatsPerBar: Int = 4,
    val clickContinues: Boolean = true,
    val voiceLearning: Boolean = true,
)

@Singleton
class SettingsStore @Inject constructor(@ApplicationContext private val context: Context) {
    private val inputKey = stringPreferencesKey("input_type")
    private val quantKey = stringPreferencesKey("quantization")
    private val tuningKey = booleanPreferencesKey("tuning")
    private val neuralKey = booleanPreferencesKey("neural_engine")
    private val metOnKey = booleanPreferencesKey("metronome_on")
    private val metBpmKey = intPreferencesKey("metronome_bpm")
    private val metBarKey = intPreferencesKey("beats_per_bar")
    private val metContKey = booleanPreferencesKey("click_continues")
    private val learnKey = booleanPreferencesKey("voice_learning")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            inputType = p[inputKey]?.let { runCatching { InputType.valueOf(it) }.getOrNull() } ?: InputType.HUMMING,
            quantization = p[quantKey]?.let { runCatching { QuantizationMode.valueOf(it) }.getOrNull() } ?: QuantizationMode.AUTOMATIC,
            tuningCompensation = p[tuningKey] ?: true,
            neuralEngine = p[neuralKey] ?: true,
            metronomeOn = p[metOnKey] ?: false,
            metronomeBpm = (p[metBpmKey] ?: 100).coerceIn(40, 220),
            beatsPerBar = (p[metBarKey] ?: 4).coerceIn(2, 7),
            clickContinues = p[metContKey] ?: true,
            voiceLearning = p[learnKey] ?: true,
        )
    }

    suspend fun setInputType(t: InputType) = context.dataStore.edit { it[inputKey] = t.name }
    suspend fun setQuantization(q: QuantizationMode) = context.dataStore.edit { it[quantKey] = q.name }
    suspend fun setTuning(on: Boolean) = context.dataStore.edit { it[tuningKey] = on }
    suspend fun setNeuralEngine(on: Boolean) = context.dataStore.edit { it[neuralKey] = on }
    suspend fun setMetronome(on: Boolean) = context.dataStore.edit { it[metOnKey] = on }
    suspend fun setMetronomeBpm(bpm: Int) = context.dataStore.edit { it[metBpmKey] = bpm.coerceIn(40, 220) }
    suspend fun setBeatsPerBar(n: Int) = context.dataStore.edit { it[metBarKey] = n.coerceIn(2, 7) }
    suspend fun setClickContinues(on: Boolean) = context.dataStore.edit { it[metContKey] = on }
    suspend fun setVoiceLearning(on: Boolean) = context.dataStore.edit { it[learnKey] = on }
}
