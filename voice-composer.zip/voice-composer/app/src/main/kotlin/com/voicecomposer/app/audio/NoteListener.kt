package com.voicecomposer.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

/**
 * Listens for one sung, hummed or whistled note ("sing the right note" to correct a note of the score).
 * Records until the person has made a sound for about 0.6 s and then stopped, or [maxSec] have passed. Mono, 16 kHz.
 */
@Singleton
class NoteListener @Inject constructor() {
    companion object { const val RATE = 16000 }

    /** Null when the microphone could not be opened. An empty array means nothing was heard. */
    @SuppressLint("MissingPermission") // the screen asks for RECORD_AUDIO before calling listen()
    suspend fun listen(maxSec: Double = 4.5): FloatArray? = withContext(Dispatchers.IO) {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return@withContext null
        val chunk = RATE / 10 // 100 ms
        val rec = runCatching {
            AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, chunk * 4))
        }.getOrNull() ?: return@withContext null
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@withContext null }
        val out = ArrayList<FloatArray>()
        try {
            rec.startRecording()
            val buf = ShortArray(chunk)
            var floor = Double.MAX_VALUE
            var loud = 0
            var quietAfter = 0
            var elapsed = 0.0
            while (currentCoroutineContext().isActive && elapsed < maxSec) {
                var got = 0
                while (got < chunk) {
                    val n = rec.read(buf, got, chunk - got)
                    if (n <= 0) return@withContext if (out.isEmpty()) null else flatten(out)
                    got += n
                }
                val f = FloatArray(chunk) { buf[it] / 32768f }
                out.add(f)
                elapsed += 0.1
                var e = 0.0
                for (v in f) e += v * v
                val rms = sqrt(e / chunk)
                if (rms < floor) floor = rms
                val thr = maxOf(0.012, floor * 3.0)
                if (rms > thr) { loud++; quietAfter = 0 } else if (loud > 0) quietAfter++
                if (loud >= 6 && quietAfter >= 3) break
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
        flatten(out)
    }

    private fun flatten(chunks: List<FloatArray>): FloatArray {
        val a = FloatArray(chunks.sumOf { it.size })
        var o = 0
        for (c in chunks) { System.arraycopy(c, 0, a, o, c.size); o += c.size }
        return a
    }
}
