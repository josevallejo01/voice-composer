package com.voicecomposer.app.ui.home

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.voicecomposer.app.R
import com.voicecomposer.app.audio.AudioImporter
import com.voicecomposer.app.audio.UnsupportedAudioException
import com.voicecomposer.app.data.ProjectEntity
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.data.ProjectStatus
import com.voicecomposer.app.data.SettingsStore
import com.voicecomposer.app.ui.common.formatTime
import com.voicecomposer.model.Ids
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import javax.inject.Inject

sealed interface HomeEvent {
    data class Open(val id: String, val analyzed: Boolean) : HomeEvent
    data object ImportFailed : HomeEvent
}

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: ProjectRepository,
    private val importer: AudioImporter,
    private val settings: SettingsStore,
) : ViewModel() {
    val projects: StateFlow<List<ProjectEntity>?> =
        repository.allProjects.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _events = MutableSharedFlow<HomeEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<HomeEvent> = _events

    fun importAudio(uri: Uri, fallbackTitle: String) {
        viewModelScope.launch {
            val id = Ids.newId("p")
            try {
                val title = displayName(uri) ?: fallbackTitle
                val info = importer.import(uri, repository.audioFile(id))
                val type = settings.settings.first().inputType.name
                repository.createFromRecording(id, title, type, info.sampleRate, info.durationMs, info.format)
                _events.emit(HomeEvent.Open(id, analyzed = false))
            } catch (e: UnsupportedAudioException) {
                repository.audioFile(id).delete()
                _events.emit(HomeEvent.ImportFailed)
            }
        }
    }

    fun createEmpty(title: String) {
        viewModelScope.launch {
            val p = repository.createEmpty(title)
            _events.emit(HomeEvent.Open(p.id, analyzed = true))
        }
    }

    fun rename(id: String, title: String) = viewModelScope.launch { repository.rename(id, title) }
    fun delete(id: String) = viewModelScope.launch { repository.deleteProject(id) }

    private fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.') else null
        }
    }.getOrNull()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onRecord: () -> Unit,
    onOpen: (id: String, analyzed: Boolean) -> Unit,
    onSettings: () -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val projects by vm.projects.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val importFailed = stringResource(R.string.import_failed)
    val importTitle = stringResource(R.string.default_import_title)
    val emptyTitle = stringResource(R.string.default_empty_title)
    var renaming by remember { mutableStateOf<ProjectEntity?>(null) }
    var deleting by remember { mutableStateOf<ProjectEntity?>(null) }

    LaunchedEffect(Unit) {
        vm.events.collect {
            when (it) {
                is HomeEvent.Open -> onOpen(it.id, it.analyzed)
                HomeEvent.ImportFailed -> snackbar.showSnackbar(importFailed)
            }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importAudio(uri, importTitle)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, stringResource(R.string.settings)) }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onRecord, icon = { Icon(Icons.Default.Mic, null) }, text = { Text(stringResource(R.string.record)) })
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Default.FileOpen, null, Modifier.size(18.dp)); Spacer(Modifier.size(6.dp)); Text(stringResource(R.string.import_audio))
                }
                FilledTonalButton(onClick = { vm.createEmpty(emptyTitle) }) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.size(6.dp)); Text(stringResource(R.string.new_score))
                }
            }
            val list = projects
            when {
                list == null -> Unit
                list.isEmpty() -> Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.GraphicEq, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.size(16.dp))
                    Text(stringResource(R.string.home_empty_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.home_empty_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.id }) { p ->
                        ProjectCard(p, onClick = { onOpen(p.id, p.status == ProjectStatus.ANALYZED) }, onRename = { renaming = p }, onDelete = { deleting = p })
                    }
                }
            }
        }
    }

    renaming?.let { p ->
        var text by remember(p.id) { mutableStateOf(p.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text(stringResource(R.string.rename)) },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(p.id, text); renaming = null }) { Text(stringResource(R.string.ok)) } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(stringResource(R.string.delete_project_title)) },
            text = { Text(stringResource(R.string.delete_project_body, p.title)) },
            confirmButton = { TextButton(onClick = { vm.delete(p.id); deleting = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun ProjectCard(p: ProjectEntity, onClick: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (p.inputType == "NONE") Icons.Default.MusicNote else Icons.Default.Mic, null, tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(p.title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                val date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(p.modifiedAt))
                val status = when (p.status) {
                    ProjectStatus.ANALYZED -> stringResource(R.string.status_analyzed)
                    ProjectStatus.ANALYZING -> stringResource(R.string.status_analyzing)
                    ProjectStatus.FAILED -> stringResource(R.string.status_failed)
                    else -> stringResource(R.string.status_recorded)
                }
                val dur = if (p.durationMs > 0) " · " + formatTime(p.durationMs) else ""
                Text("$status$dur · $date", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onRename) { Icon(Icons.Default.Edit, stringResource(R.string.rename)) }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, stringResource(R.string.delete)) }
        }
    }
}
