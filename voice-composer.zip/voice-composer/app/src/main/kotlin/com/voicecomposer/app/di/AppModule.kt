package com.voicecomposer.app.di

import android.content.Context
import androidx.room.Room
import com.voicecomposer.app.data.AppDatabase
import com.voicecomposer.app.ml.OnnxBasicPitchModel
import com.voicecomposer.engine.DefaultTranscriptionEngine
import com.voicecomposer.engine.SelectableEngine
import com.voicecomposer.engine.ml.MlTranscriptionEngine
import com.voicecomposer.engine.TranscriptionEngine
import com.voicecomposer.engine.arrangement.ArrangementEngine
import com.voicecomposer.engine.arrangement.HarmonicArrangementEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun database(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "voice_composer.db").build()

    /** Engines are provided behind interfaces so a model can be swapped without touching the UI (spec 4.3). */
    @Provides @Singleton
    fun transcriptionEngine(ml: MlTranscriptionEngine, scores: com.voicecomposer.app.data.ScoreForests): TranscriptionEngine =
        SelectableEngine(ml, DefaultTranscriptionEngine { scores.models() })

    /** The neural engine itself, also used directly by the voice setup. If the model or its runtime is unavailable it falls back by itself. */
    @Provides @Singleton
    fun mlEngine(
        @ApplicationContext ctx: Context,
        forests: com.voicecomposer.app.data.NoteForests,
        scores: com.voicecomposer.app.data.ScoreForests,
    ): MlTranscriptionEngine =
        MlTranscriptionEngine(
            OnnxBasicPitchModel(ctx), DefaultTranscriptionEngine { scores.models() },
            classifier = { forests.classifier(it) }, scoreModels = { scores.models() },
        )

    @Provides @Singleton
    fun arrangementEngine(): ArrangementEngine = HarmonicArrangementEngine()
}
