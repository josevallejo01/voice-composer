package com.voicecomposer.app.ui.calibration

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.voicecomposer.app.R
import com.voicecomposer.app.audio.AudioRecorder
import com.voicecomposer.app.audio.PlaybackController
import com.voicecomposer.app.data.ProfileStore
import com.voicecomposer.app.ui.common.WaveformView
import com.voicecomposer.app.ui.record.inputTypeLabel
import com.voicecomposer.engine.AnalysisConfig
import com.voicecomposer.engine.calibration.CalibrationReport
import com.voicecomposer.engine.calibration.CalibrationTake
import com.voicecomposer.engine.calibration.CalibrationTuner
import com.voicecomposer.engine.io.AudioBuffer
import com.voicecomposer.engine.io.WavIO
import com.voicecomposer.engine.ml.MlTranscriptionEngine
import com.voicecomposer.engine.preprocessing.InputType
import com.voicecomposer.model.Pitch
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import kotlin.math.PI
import kotlin.math.sin

enum class CalStep { CHOOSE, SILENCE, PROMPT, RECORDING, ANALYZING, CONFIRM, TUNING, DONE, ERROR }

data class CalState(
    val type: InputType = InputType.HUMMING,
    /** 0 low, 1 medium, 2 high; ignored for whistling. */
    val register: Int = 1,
    val step: CalStep = CalStep.CHOOSE,
    val targets: List<Int> = emptyList(),
    val index: Int = 0,
    val remainingMs: Long = 0,
    val detected: Int? = null,
    val report: CalibrationReport? = null,
    val error: String? = null,
    val recorded: Int = 0,
)

/**
 * Guided voice setup. The app asks for one take of silence (the room as it is) and a handful of notes; the user says
 * which note was really sung. The takes whose content is known are what the decoder is fitted to (CalibrationTuner),
 * and they become the first labelled examples of the user's profile for that kind of sound.
 */
@HiltViewModel
class CalibrationViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val recorder: AudioRecorder,
    private val playback: PlaybackController,
    private val engine: MlTranscriptionEngine,
    private val profileStore: ProfileStore,
) : ViewModel() {
    val recorderUi = recorder.ui
    private val _s = MutableStateFlow(CalState())
    val state: StateFlow<CalState> = _s

    private val takes = ArrayList<CalibrationTake>()
    private var pending: MlTranscriptionEngine.Prepared? = null
    private var job: Job? = null

    private fun config() = AnalysisConfig(inputType = _s.value.type)

    fun setType(t: InputType) = _s.update { it.copy(type = t) }
    fun setRegister(r: Int) = _s.update { it.copy(register = r) }

    fun targetsFor(type: InputType, register: Int): List<Int> =
        if (type == InputType.WHISTLING) listOf(72, 76, 79, 84, 88, 91, 96, 100)
        else (intArrayOf(45, 52, 60)[register.coerceIn(0, 2)]).let { base -> intArrayOf(0, 2, 4, 5, 7, 9, 11, 12).map { base + it } }

    fun begin() {
        takes.clear()
        _s.update { it.copy(targets = targetsFor(it.type, it.register), index = 0, recorded = 0, report = null, error = null, detected = null) }
        capture(SILENCE_MS, CalStep.SILENCE) { audio -> analyzeTake(audio, silence = true) }
    }

    fun record() = capture(NOTE_MS, CalStep.RECORDING) { audio -> analyzeTake(audio, silence = false) }

    fun playReference() {
        val s = _s.value
        val midi = s.targets.getOrNull(s.index) ?: return
        val rate = 44100
        val n = (rate * 1.2).toInt()
        val f = Pitch.midiToHz(midi)
        val pcm = ShortArray(n) { i ->
            val env = minOf(1.0, i / (rate * 0.03), (n - i) / (rate * 0.1))
            (sin(2 * PI * f * i / rate) * env * 0.5 * 32767).toInt().toShort()
        }
        playback.playPreview(pcm, rate)
    }

    private fun capture(durationMs: Long, step: CalStep, onAudio: suspend (AudioBuffer) -> Unit) {
        job?.cancel()
        job = viewModelScope.launch {
            val file = File(context.cacheDir, "calibration_take.wav")
            if (!recorder.start(file)) { fail(context.getString(R.string.cal_error_mic)); return@launch }
            _s.update { it.copy(step = step, remainingMs = durationMs) }
            val t0 = SystemClock.elapsedRealtime()
            while (true) {
                val left = durationMs - (SystemClock.elapsedRealtime() - t0)
                if (left <= 0) break
                _s.update { it.copy(remainingMs = left) }
                delay(80)
            }
            val res = recorder.stop()
            if (res == null) { fail(context.getString(R.string.cal_error_mic)); return@launch }
            _s.update { it.copy(step = CalStep.ANALYZING) }
            val audio = withContext(Dispatchers.IO) { runCatching { WavIO.decode(file.readBytes()) }.getOrNull().also { file.delete() } }
            if (audio == null) { fail(context.getString(R.string.cal_error_mic)); return@launch }
            onAudio(audio)
        }
    }

    private suspend fun analyzeTake(audio: AudioBuffer, silence: Boolean) {
        val cfg = config()
        val prepared = try {
            withContext(Dispatchers.Default) { engine.prepare(audio, cfg) }
        } catch (e: Throwable) {
            fail(context.getString(R.string.cal_error_model, "${e.javaClass.simpleName}: ${e.message}".take(160))); return
        }
        if (silence) {
            takes.add(CalibrationTake(prepared, null))
            _s.update { it.copy(step = CalStep.PROMPT) }
        } else {
            pending = prepared
            val notes = withContext(Dispatchers.Default) { engine.detect(prepared, cfg) }
            val dominant = notes.maxByOrNull { it.endSec - it.startSec }?.midi
            _s.update { it.copy(step = CalStep.CONFIRM, detected = dominant) }
        }
    }

    /** The detected note is what was sung. */
    fun confirmDetected() { _s.value.detected?.let { addTake(it) } }

    /** The detection is wrong: the note that was sung is the target. */
    fun confirmTarget() { _s.value.targets.getOrNull(_s.value.index)?.let { addTake(it) } }

    private fun addTake(truth: Int) {
        pending?.let { takes.add(CalibrationTake(it, truth)) }
        pending = null
        _s.update { it.copy(recorded = it.recorded + 1) }
        next()
    }

    fun redo() { pending = null; _s.update { it.copy(step = CalStep.PROMPT, detected = null) } }
    fun skip() { next() }

    private fun next() {
        val s = _s.value
        if (s.index + 1 >= s.targets.size) finish() else _s.update { it.copy(index = it.index + 1, step = CalStep.PROMPT, detected = null) }
    }

    private fun finish() {
        _s.update { it.copy(step = CalStep.TUNING) }
        viewModelScope.launch {
            if (takes.none { it.truthMidi != null }) { fail(context.getString(R.string.cal_error_no_notes)); return@launch }
            val type = _s.value.type
            try {
                val out = withContext(Dispatchers.Default) { CalibrationTuner.tune(engine, AnalysisConfig(inputType = type), type, takes) }
                profileStore.saveCalibration(type, out)
                _s.update { it.copy(step = CalStep.DONE, report = out.report) }
            } catch (e: Throwable) {
                fail(context.getString(R.string.cal_error_model, "${e.javaClass.simpleName}: ${e.message}".take(160)))
            }
        }
    }

    private fun fail(msg: String) { _s.update { it.copy(step = CalStep.ERROR, error = msg) } }

    fun restart() { job?.cancel(); pending = null; takes.clear(); _s.update { CalState(type = it.type, register = it.register) } }

    override fun onCleared() {
        job?.cancel()
        CoroutineScope(Dispatchers.IO).launch { recorder.cancel() }
        super.onCleared()
    }

    companion object { const val SILENCE_MS = 3000L; const val NOTE_MS = 3500L }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalibrationScreen(onBack: () -> Unit, vm: CalibrationViewModel = hiltViewModel()) {
    val s by vm.state.collectAsState()
    val rec by vm.recorderUi.collectAsState()
    val ctx = LocalContext.current
    var denied by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        denied = !granted
        if (granted) vm.begin()
    }
    fun start() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.begin()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.cal_title)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            when (s.step) {
                CalStep.CHOOSE -> {
                    Text(stringResource(R.string.cal_intro), style = MaterialTheme.typography.bodyMedium)
                    Text(stringResource(R.string.input_type_label), style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (t in listOf(InputType.HUMMING, InputType.WHISTLING, InputType.SINGING)) {
                            FilterChip(s.type == t, { vm.setType(t) }, label = { Text(inputTypeLabel(t)) })
                        }
                    }
                    if (s.type != InputType.WHISTLING) {
                        Text(stringResource(R.string.cal_register), style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(s.register == 0, { vm.setRegister(0) }, label = { Text(stringResource(R.string.cal_register_low)) })
                            FilterChip(s.register == 1, { vm.setRegister(1) }, label = { Text(stringResource(R.string.cal_register_mid)) })
                            FilterChip(s.register == 2, { vm.setRegister(2) }, label = { Text(stringResource(R.string.cal_register_high)) })
                        }
                    }
                    Text(stringResource(R.string.cal_headphones), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (denied) Text(stringResource(R.string.cal_error_mic), color = MaterialTheme.colorScheme.error)
                    Button(onClick = { start() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_start)) }
                }
                CalStep.SILENCE -> {
                    Text(stringResource(R.string.cal_silence_title), style = MaterialTheme.typography.titleLarge)
                    Text(stringResource(R.string.cal_silence_text))
                    Countdown(s.remainingMs, CalibrationViewModel.SILENCE_MS)
                    WaveformView(rec.levels, height = 72.dp, live = true)
                }
                CalStep.PROMPT, CalStep.RECORDING, CalStep.CONFIRM -> {
                    val target = s.targets.getOrNull(s.index)
                    Text(stringResource(R.string.cal_note_of, s.index + 1, s.targets.size), style = MaterialTheme.typography.titleMedium)
                    if (target != null) Text(Pitch.name(target), style = MaterialTheme.typography.displayMedium)
                    when (s.step) {
                        CalStep.PROMPT -> {
                            Text(stringResource(R.string.cal_prompt_text, inputTypeLabel(s.type)))
                            OutlinedButton(onClick = { vm.playReference() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_play_ref)) }
                            Button(onClick = { vm.record() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_record)) }
                            OutlinedButton(onClick = { vm.skip() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_skip)) }
                        }
                        CalStep.RECORDING -> {
                            Text(stringResource(R.string.cal_recording_now, inputTypeLabel(s.type)), style = MaterialTheme.typography.titleMedium)
                            Countdown(s.remainingMs, CalibrationViewModel.NOTE_MS)
                            WaveformView(rec.levels, height = 72.dp, live = true)
                        }
                        else -> {
                            val d = s.detected
                            Text(
                                if (d != null) stringResource(R.string.cal_heard, Pitch.name(d)) else stringResource(R.string.cal_heard_none),
                                style = MaterialTheme.typography.titleLarge,
                            )
                            if (d != null) {
                                Button(onClick = { vm.confirmDetected() }, Modifier.fillMaxWidth()) {
                                    Text(if (d == target) stringResource(R.string.cal_right) else stringResource(R.string.cal_sang_detected, Pitch.name(d)))
                                }
                            }
                            if (target != null && d != target) {
                                OutlinedButton(onClick = { vm.confirmTarget() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_sang_target, Pitch.name(target))) }
                            }
                            OutlinedButton(onClick = { vm.redo() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_redo)) }
                        }
                    }
                }
                CalStep.ANALYZING, CalStep.TUNING -> {
                    CircularProgressIndicator()
                    Text(stringResource(if (s.step == CalStep.TUNING) R.string.cal_tuning else R.string.cal_analyzing))
                }
                CalStep.DONE -> {
                    val r = s.report
                    Text(stringResource(R.string.cal_done), style = MaterialTheme.typography.titleLarge)
                    if (r != null) {
                        Text(stringResource(R.string.cal_report, r.notesCorrect, r.notesTotal, r.silenceClean, r.silenceTakes))
                        if (r.pitchOffset != 0) Text(stringResource(R.string.cal_report_offset, r.pitchOffset))
                        Text(stringResource(R.string.cal_report_score, Math.round(r.scoreBefore * 100).toInt(), Math.round(r.scoreAfter * 100).toInt()))
                    }
                    Button(onClick = onBack, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_finish)) }
                    OutlinedButton(onClick = { vm.restart() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_again)) }
                }
                CalStep.ERROR -> {
                    Text(s.error ?: "", color = MaterialTheme.colorScheme.error)
                    Button(onClick = { vm.restart() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.cal_again)) }
                }
            }
        }
    }
}

@Composable
private fun Countdown(remainingMs: Long, totalMs: Long) {
    LinearProgressIndicator(progress = { (1f - remainingMs.toFloat() / totalMs).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
}
