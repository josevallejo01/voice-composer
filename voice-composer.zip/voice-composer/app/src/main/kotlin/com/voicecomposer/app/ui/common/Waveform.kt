package com.voicecomposer.app.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Peak envelope of an audio signal, [bins] values between 0 and 1. */
fun peakEnvelope(samples: FloatArray, bins: Int): FloatArray {
    if (samples.isEmpty() || bins <= 0) return FloatArray(0)
    val out = FloatArray(bins)
    val per = samples.size.toDouble() / bins
    for (b in 0 until bins) {
        val from = (b * per).toInt()
        val to = ((b + 1) * per).toInt().coerceIn(from + 1, samples.size)
        var peak = 0f
        for (i in from until to) { val a = kotlin.math.abs(samples[i]); if (a > peak) peak = a }
        out[b] = peak
    }
    val max = out.max().coerceAtLeast(1e-4f)
    for (i in out.indices) out[i] = out[i] / max
    return out
}

/**
 * Waveform with an optional playback cursor ([progress] 0..1), a highlighted region and tap-to-seek.
 * [live] draws newest values on the right, as used while recording.
 */
@Composable
fun WaveformView(
    peaks: List<Float>,
    modifier: Modifier = Modifier,
    height: Dp = 72.dp,
    progress: Float? = null,
    region: ClosedFloatingPointRange<Float>? = null,
    live: Boolean = false,
    onSeek: ((Float) -> Unit)? = null,
) {
    val color = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.outlineVariant
    val cursor = MaterialTheme.colorScheme.tertiary
    val seekModifier = if (onSeek != null) Modifier.pointerInput(Unit) {
        detectTapGestures { o -> onSeek((o.x / size.width).coerceIn(0f, 1f)) }
    } else Modifier
    Canvas(modifier.fillMaxWidth().height(height).then(seekModifier)) {
        val mid = size.height / 2f
        if (peaks.isEmpty()) {
            drawLine(dim, Offset(0f, mid), Offset(size.width, mid), strokeWidth = 2f)
            return@Canvas
        }
        val barW = size.width / (if (live) 240f else peaks.size.toFloat())
        val stroke = (barW * 0.7f).coerceAtLeast(1f)
        region?.let {
            drawRect(color.copy(alpha = 0.16f), Offset(it.start * size.width, 0f), androidx.compose.ui.geometry.Size((it.endInclusive - it.start) * size.width, size.height))
        }
        for ((i, p) in peaks.withIndex()) {
            val x = if (live) size.width - (peaks.size - i) * barW + barW / 2 else (i + 0.5f) * barW
            val h = (p.coerceIn(0f, 1f) * size.height * 0.92f).coerceAtLeast(2f)
            val played = progress != null && x / size.width <= progress
            drawLine(if (played) color else color.copy(alpha = 0.45f), Offset(x, mid - h / 2), Offset(x, mid + h / 2), strokeWidth = stroke, cap = StrokeCap.Round)
        }
        if (progress != null) {
            val x = progress * size.width
            drawLine(cursor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 3f)
        }
    }
}
