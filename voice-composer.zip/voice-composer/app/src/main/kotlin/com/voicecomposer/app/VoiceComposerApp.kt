package com.voicecomposer.app

import android.app.Application
import com.voicecomposer.app.data.ProjectRepository
import com.voicecomposer.app.data.ScoreForests
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class VoiceComposerApp : Application() {
    @Inject lateinit var repository: ProjectRepository
    @Inject lateinit var scoreForests: ScoreForests

    override fun onCreate() {
        super.onCreate()
        // An analysis interrupted by a process death can be restarted by the user, never stays "running" forever.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch { repository.recoverInterrupted() }
        // Reads the learned score models and installs the learned note speller before the first score is drawn.
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch { scoreForests.models() }
    }
}
