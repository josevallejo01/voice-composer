package com.voicecomposer.app

import android.app.Application
import com.voicecomposer.app.data.ProjectRepository
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class VoiceComposerApp : Application() {
    @Inject lateinit var repository: ProjectRepository

    override fun onCreate() {
        super.onCreate()
        // An analysis interrupted by a process death can be restarted by the user, never stays "running" forever.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch { repository.recoverInterrupted() }
    }
}
