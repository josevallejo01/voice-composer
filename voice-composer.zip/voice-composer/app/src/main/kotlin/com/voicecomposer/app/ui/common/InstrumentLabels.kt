package com.voicecomposer.app.ui.common

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.voicecomposer.app.R
import com.voicecomposer.model.Instrument

/** Name of an instrument in the app's language. */
@Composable
fun instrumentLabel(i: Instrument): String = stringResource(
    when (i) {
        Instrument.LEAD -> R.string.instr_lead
        Instrument.PIANO -> R.string.instr_piano
        Instrument.ACOUSTIC_GUITAR -> R.string.instr_steel_guitar
        Instrument.ELECTRIC_BASS -> R.string.instr_bass
        Instrument.STRINGS -> R.string.instr_strings
        Instrument.PAD -> R.string.instr_pad
        Instrument.FLUTE -> R.string.instr_flute
        Instrument.VIOLIN -> R.string.instr_violin
        Instrument.VIOLA -> R.string.instr_viola
        Instrument.CELLO -> R.string.instr_cello
        Instrument.DOUBLE_BASS -> R.string.instr_double_bass
        Instrument.HARP -> R.string.instr_harp
        Instrument.NYLON_GUITAR -> R.string.instr_nylon_guitar
        Instrument.UPRIGHT_BASS -> R.string.instr_upright_bass
        Instrument.OBOE -> R.string.instr_oboe
        Instrument.CLARINET -> R.string.instr_clarinet
        Instrument.FRENCH_HORN -> R.string.instr_french_horn
        Instrument.TRUMPET -> R.string.instr_trumpet
        Instrument.CHOIR -> R.string.instr_choir
    }
)
