package com.voicecomposer.app.ui.score

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.voicecomposer.model.Clef
import com.voicecomposer.model.Notation
import com.voicecomposer.model.NoteType
import com.voicecomposer.model.NotationNote
import com.voicecomposer.model.NotationRest
import com.voicecomposer.model.layout.ItemLayout
import com.voicecomposer.model.layout.ScoreLayout
import com.voicecomposer.model.layout.SystemLayout

class ScorePalette(val ink: Int, val selected: Int, val uncertain: Int, val cursor: Int, val muted: Int)

/** A note head shown while the user drags a note to another pitch. */
class GhostNote(val system: Int, val x: Float, val staffPos: Int)

/**
 * Draws a [ScoreLayout] on a plain android.graphics.Canvas. The same code paints the on-screen score (through
 * Compose's nativeCanvas) and the PDF export, so what the user sees is what gets printed. Only glyphs that are
 * missing from the device font fall back to drawn shapes; everything else is vector drawing.
 */
class ScorePainter(private val palette: ScorePalette) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val path = Path()
    private val rect = RectF()

    private val hasTreble by lazy { text.hasGlyph("𝄞") }
    private val hasBass by lazy { text.hasGlyph("𝄢") }
    private val hasSharp by lazy { text.hasGlyph("♯") }
    private val hasFlat by lazy { text.hasGlyph("♭") }
    private val hasNatural by lazy { text.hasGlyph("♮") }

    fun draw(
        canvas: Canvas,
        layout: ScoreLayout,
        notation: Notation,
        selectedId: String? = null,
        cursorBeat: Double? = null,
        ghost: GhostNote? = null,
        systems: List<SystemLayout> = layout.systems,
    ) {
        val s = layout.staffSpace
        for (sys in systems) {
            drawStaff(canvas, layout, notation, sys)
            for (m in sys.measures) {
                for (it in m.items) drawItem(canvas, layout, sys, it, selectedId)
                // closing barline
                line.color = palette.ink; line.strokeWidth = s * 0.1f
                val bx = m.x + m.width
                canvas.drawLine(bx, sys.top, bx, sys.top + 4 * s, line)
            }
            if (sys.isLast) {
                val end = sys.measures.last().let { it.x + it.width }
                line.strokeWidth = s * 0.35f
                canvas.drawLine(end - s * 0.2f, sys.top, end - s * 0.2f, sys.top + 4 * s, line)
            }
        }
        if (ghost != null) {
            val sys = layout.systems.getOrNull(ghost.system)
            if (sys != null) {
                val y = layout.yForPos(sys, ghost.staffPos)
                head(canvas, ghost.x, y, s, filled = true, color = palette.selected, alpha = 140)
                ledger(canvas, layout, sys, ghost.x, ghost.staffPos, palette.selected)
            }
        }
        if (cursorBeat != null) {
            layout.locate(cursorBeat)?.let { (sys, x) ->
                if (sys in systems) {
                    line.color = palette.cursor; line.strokeWidth = s * 0.14f
                    canvas.drawLine(x, sys.top - 1.6f * s, x, sys.top + 5.6f * s, line)
                }
            }
        }
    }

    // ---- staff, clef, key and time signature -------------------------------------------------------------------

    private fun drawStaff(canvas: Canvas, layout: ScoreLayout, notation: Notation, sys: SystemLayout) {
        val s = layout.staffSpace
        val end = sys.measures.last().let { it.x + it.width }
        line.color = palette.ink; line.strokeWidth = s * 0.08f
        for (i in 0..4) canvas.drawLine(0f, sys.top + i * s, end, sys.top + i * s, line)
        line.strokeWidth = s * 0.1f
        canvas.drawLine(0f, sys.top, 0f, sys.top + 4 * s, line)

        fill.color = palette.ink
        text.color = palette.ink
        text.typeface = null
        // clef
        if (notation.clef == Clef.TREBLE) {
            if (hasTreble) {
                text.textSize = s * 6.6f
                canvas.drawText("𝄞", 1.9f * s, sys.top + 3f * s, text)
            } else {
                text.textSize = s * 4.2f; text.isFakeBoldText = true
                canvas.drawText("G", 1.7f * s, sys.top + 3.9f * s, text); text.isFakeBoldText = false
            }
        } else {
            if (hasBass) {
                text.textSize = s * 4.2f
                canvas.drawText("𝄢", 1.9f * s, sys.top + 1f * s + s * 0.2f, text)
            } else {
                text.textSize = s * 4.2f; text.isFakeBoldText = true
                canvas.drawText("F", 1.7f * s, sys.top + 3.0f * s, text); text.isFakeBoldText = false
            }
        }
        // key signature
        var x = 3.4f * s
        val fifths = notation.key.fifths
        if (fifths != 0) {
            val sharps = fifths > 0
            val base = if (notation.clef == Clef.TREBLE) 0 else -12
            val positions = if (sharps) intArrayOf(38, 35, 39, 36, 33, 37, 34) else intArrayOf(34, 37, 33, 36, 32, 35, 31)
            for (k in 0 until kotlin.math.abs(fifths)) {
                val pos = positions[k] + base
                val y = layout.yForPos(sys, pos)
                accidentalGlyph(canvas, x + 0.5f * s, y, s, if (sharps) 1 else -1, palette.ink)
                x += 1.15f * s
            }
        }
        // time signature (first system only)
        if (sys.showTimeSignature) {
            val cx = sys.prefixWidth - 1.9f * s
            text.textSize = s * 2.5f; text.isFakeBoldText = true; text.color = palette.ink
            canvas.drawText(notation.timeSignature.numerator.toString(), cx, sys.top + 1.95f * s, text)
            canvas.drawText(notation.timeSignature.denominator.toString(), cx, sys.top + 3.95f * s, text)
            text.isFakeBoldText = false
        }
    }

    // ---- notes and rests --------------------------------------------------------------------------------------

    private fun drawItem(canvas: Canvas, layout: ScoreLayout, sys: SystemLayout, it: ItemLayout, selectedId: String?) {
        val s = layout.staffSpace
        when (val item = it.item) {
            is NotationNote -> {
                val y = it.y ?: return
                val color = when {
                    item.eventId == selectedId -> palette.selected
                    item.uncertain -> palette.uncertain
                    else -> palette.ink
                }
                if (item.eventId == selectedId) {
                    fill.color = palette.selected; fill.alpha = 36
                    canvas.drawCircle(it.x, y, 1.5f * s, fill)
                    fill.alpha = 255
                }
                ledger(canvas, layout, sys, it.x, it.staffPos!!, color)
                it.accidental?.let { a -> accidentalGlyph(canvas, it.x - 1.35f * s, y, s, a, color) }
                val hollow = item.type == NoteType.HALF || item.type == NoteType.WHOLE
                head(canvas, it.x, y, s, filled = !hollow, color = color)
                if (item.type != NoteType.WHOLE) stem(canvas, it, item.type, s, color)
                dots(canvas, it.x, y, s, item.dots, it.staffPos!! - layout.bottomLinePos, color)
                if (item.tieToNext && it.tieEndX != null) tie(canvas, it, s, color)
                item.lyric?.let { l ->
                    text.color = palette.ink; text.textSize = s * 1.45f
                    val label = when (l.syllabic) {
                        com.voicecomposer.model.Syllabic.BEGIN, com.voicecomposer.model.Syllabic.MIDDLE -> l.text + "-"
                        else -> l.text
                    }
                    canvas.drawText(label, it.x, sys.top + 4f * s + 4.6f * s, text)
                }
            }
            is NotationRest -> drawRest(canvas, sys, it.x, item, s)
        }
    }

    private fun head(canvas: Canvas, x: Float, y: Float, s: Float, filled: Boolean, color: Int, alpha: Int = 255) {
        canvas.save()
        canvas.rotate(-20f, x, y)
        rect.set(x - 0.68f * s, y - 0.47f * s, x + 0.68f * s, y + 0.47f * s)
        if (filled) {
            fill.color = color; fill.alpha = alpha
            canvas.drawOval(rect, fill); fill.alpha = 255
        } else {
            line.color = color; line.alpha = alpha; line.strokeWidth = s * 0.17f
            canvas.drawOval(rect, line); line.alpha = 255
        }
        canvas.restore()
    }

    private fun stem(canvas: Canvas, it: ItemLayout, type: NoteType, s: Float, color: Int) {
        val y = it.y!!
        line.color = color; line.strokeWidth = s * 0.11f
        line.strokeCap = Paint.Cap.BUTT
        val up = it.stemUp
        val sx = if (up) it.x + 0.64f * s else it.x - 0.64f * s
        val ey = if (up) y - 3.4f * s else y + 3.4f * s
        canvas.drawLine(sx, y, sx, ey, line)
        val flags = when (type) { NoteType.EIGHTH -> 1; NoteType.SIXTEENTH -> 2; else -> 0 }
        val dir = if (up) 1f else -1f // flags hang down from an up-stem and rise from a down-stem
        for (f in 0 until flags) {
            val fy = ey + dir * f * 0.85f * s
            path.reset()
            path.moveTo(sx, fy)
            path.cubicTo(sx + 0.2f * s, fy + dir * 0.9f * s, sx + 1.3f * s, fy + dir * 1.2f * s, sx + 1.0f * s, fy + dir * 2.4f * s)
            line.strokeWidth = s * 0.2f
            canvas.drawPath(path, line)
        }
    }

    private fun dots(canvas: Canvas, x: Float, y: Float, s: Float, count: Int, offsetFromBottom: Int, color: Int) {
        if (count == 0) return
        fill.color = color
        // A dot sits in the space above a note that is on a line.
        val dy = if (offsetFromBottom % 2 == 0) -0.5f * s else 0f
        for (k in 0 until count) canvas.drawCircle(x + 1.25f * s + k * 0.65f * s, y + dy, 0.2f * s, fill)
    }

    private fun ledger(canvas: Canvas, layout: ScoreLayout, sys: SystemLayout, x: Float, pos: Int, color: Int) {
        val off = pos - layout.bottomLinePos
        line.color = color; line.strokeWidth = layout.staffSpace * 0.1f
        val s = layout.staffSpace
        if (off <= -2) {
            var o = -2
            while (o >= off) {
                val y = layout.yForPos(sys, layout.bottomLinePos + o)
                canvas.drawLine(x - 1.1f * s, y, x + 1.1f * s, y, line)
                o -= 2
            }
        } else if (off >= 10) {
            var o = 10
            while (o <= off) {
                val y = layout.yForPos(sys, layout.bottomLinePos + o)
                canvas.drawLine(x - 1.1f * s, y, x + 1.1f * s, y, line)
                o += 2
            }
        }
    }

    private fun tie(canvas: Canvas, it: ItemLayout, s: Float, color: Int) {
        val y = it.y!!
        val dir = if (it.stemUp) 1f else -1f
        val x0 = it.x + 0.6f * s
        val x1 = (it.tieEndX ?: return) - 0.6f * s
        if (x1 <= x0) return
        path.reset()
        path.moveTo(x0, y + dir * 0.75f * s)
        path.quadTo((x0 + x1) / 2f, y + dir * 1.9f * s, x1, y + dir * 0.75f * s)
        line.color = color; line.strokeWidth = s * 0.16f
        canvas.drawPath(path, line)
    }

    private fun accidentalGlyph(canvas: Canvas, x: Float, y: Float, s: Float, alter: Int, color: Int) {
        text.color = color
        text.textSize = s * 3.0f
        val (glyph, ok, fallback) = when {
            alter > 0 -> Triple("♯", hasSharp, "#")
            alter < 0 -> Triple("♭", hasFlat, "b")
            else -> Triple("♮", hasNatural, "n")
        }
        text.isFakeBoldText = !ok
        canvas.drawText(if (ok) glyph else fallback, x, y + s * 0.55f, text)
        text.isFakeBoldText = false
    }

    private fun drawRest(canvas: Canvas, sys: SystemLayout, x: Float, r: NotationRest, s: Float) {
        val top = sys.top
        fill.color = palette.ink
        line.color = palette.ink
        when (r.type) {
            NoteType.WHOLE -> canvas.drawRect(x - 0.7f * s, top + s, x + 0.7f * s, top + 1.5f * s, fill)
            NoteType.HALF -> canvas.drawRect(x - 0.7f * s, top + 1.5f * s, x + 0.7f * s, top + 2f * s, fill)
            NoteType.QUARTER -> {
                path.reset()
                path.moveTo(x - 0.35f * s, top + 0.6f * s)
                path.lineTo(x + 0.4f * s, top + 1.35f * s)
                path.lineTo(x - 0.35f * s, top + 2.2f * s)
                path.lineTo(x + 0.4f * s, top + 3.0f * s)
                path.quadTo(x - 0.5f * s, top + 3.0f * s, x - 0.2f * s, top + 3.6f * s)
                line.strokeWidth = s * 0.26f
                canvas.drawPath(path, line)
            }
            NoteType.EIGHTH, NoteType.SIXTEENTH -> {
                val n = if (r.type == NoteType.EIGHTH) 1 else 2
                line.strokeWidth = s * 0.14f
                canvas.drawLine(x + 0.5f * s, top + 0.9f * s, x - 0.3f * s, top + 3.1f * s + (n - 1) * 0.8f * s, line)
                for (k in 0 until n) canvas.drawCircle(x - 0.2f * s + k * (-0.2f * s), top + (1.15f + k * 0.8f) * s, 0.32f * s, fill)
            }
        }
        for (k in 0 until r.dots) canvas.drawCircle(x + 1.1f * s + k * 0.6f * s, top + 1.6f * s, 0.2f * s, fill)
    }
}
