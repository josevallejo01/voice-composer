package com.voicecomposer.app.ui.score

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.voicecomposer.app.ui.theme.UncertainColor
import com.voicecomposer.model.NotationBuilder
import com.voicecomposer.model.Spelling
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.layout.ScoreLayoutEngine

/**
 * The score. Touch coordinates are converted back to musical positions by the layout (never stored), so zooming,
 * rotating or changing the key never invalidates an edit.
 *
 * - tap a note: select it; tap empty space: deselect (or add a note when [drawMode] is on)
 * - long press a note and drag vertically: change its pitch (applied once, when the finger is lifted)
 */
@Composable
fun ScoreView(
    transcription: Transcription,
    selectedId: String?,
    drawMode: Boolean,
    cursorBeat: () -> Double?,
    scroll: ScrollState,
    modifier: Modifier = Modifier,
    onSelect: (String?) -> Unit,
    onAddNote: (startBeat: Double, midi: Int) -> Unit,
    onSetPitch: (id: String, midi: Int) -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val palette = remember(colors) {
        ScorePalette(colors.onSurface.toArgb(), colors.primary.toArgb(), UncertainColor.toArgb(), colors.tertiary.toArgb(), colors.outline.toArgb())
    }
    val painter = remember(palette) { ScorePainter(palette) }
    val density = LocalDensity.current
    val staffPx = with(density) { 7.dp.toPx() }
    val notation = remember(transcription) { NotationBuilder.build(transcription) }

    BoxWithConstraints(modifier.fillMaxWidth().clipToBounds()) {
        val widthPx = with(density) { maxWidth.toPx() }
        val layout = remember(notation, widthPx) { ScoreLayoutEngine.layout(notation, widthPx, staffPx) }
        val heightDp = with(density) { layout.height.toDp() }
        var top by remember { mutableFloatStateOf(0f) }
        var ghost by remember { mutableStateOf<GhostNote?>(null) }
        var dragId by remember { mutableStateOf<String?>(null) }

        val select = rememberUpdatedState(onSelect)
        val add = rememberUpdatedState(onAddNote)
        val setPitch = rememberUpdatedState(onSetPitch)
        val fifths = notation.key.fifths

        // Keep the selected note and the playback cursor on screen.
        val selectedSystem = selectedId?.let { id -> layout.noteBoxes.firstOrNull { it.eventId == id }?.system }
        LaunchedEffect(selectedSystem) {
            val sys = selectedSystem?.let { layout.systems.getOrNull(it) } ?: return@LaunchedEffect
            scroll.animateScrollTo((top + sys.regionTop - with(density) { 160.dp.toPx() }).toInt().coerceAtLeast(0))
        }
        val cursorSystem by remember(layout) { derivedStateOf { cursorBeat()?.let { b -> layout.locate(b)?.first?.index } } }
        LaunchedEffect(cursorSystem) {
            val sys = cursorSystem?.let { layout.systems.getOrNull(it) } ?: return@LaunchedEffect
            scroll.animateScrollTo((top + sys.regionTop - with(density) { 160.dp.toPx() }).toInt().coerceAtLeast(0))
        }

        Canvas(
            Modifier.fillMaxWidth().height(heightDp)
                .onGloballyPositioned { top = it.positionInParent().y }
                .pointerInput(layout, drawMode) {
                    detectTapGestures { o ->
                        val hit = layout.hitNote(o.x, o.y)
                        when {
                            hit != null -> select.value(hit.eventId)
                            drawMode -> {
                                val p = layout.positionAt(o.x, o.y)
                                if (p != null) {
                                    val midi = Spelling.fromDiatonicIndex(p.staffPos, fifths).toMidi()
                                    val beat = (p.measure * layout.measureTicks + p.tickInMeasure) / 4.0
                                    add.value(beat, midi)
                                }
                            }
                            else -> select.value(null)
                        }
                    }
                }
                .pointerInput(layout) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { o ->
                            val hit = layout.hitNote(o.x, o.y)
                            if (hit != null) {
                                dragId = hit.eventId
                                select.value(hit.eventId)
                                ghost = GhostNote(hit.system, hit.x, hit.staffPos)
                            }
                        },
                        onDrag = { change, _ ->
                            val g = ghost ?: return@detectDragGesturesAfterLongPress
                            val sys = layout.systems.getOrNull(g.system) ?: return@detectDragGesturesAfterLongPress
                            ghost = GhostNote(g.system, g.x, layout.posForY(sys, change.position.y).coerceIn(10, 50))
                            change.consume()
                        },
                        onDragEnd = {
                            val g = ghost
                            val id = dragId
                            if (g != null && id != null) setPitch.value(id, Spelling.fromDiatonicIndex(g.staffPos, fifths).toMidi())
                            ghost = null; dragId = null
                        },
                        onDragCancel = { ghost = null; dragId = null },
                    )
                },
        ) {
            drawIntoCanvas { c -> painter.draw(c.nativeCanvas, layout, notation, selectedId, cursorBeat(), ghost) }
        }
    }
}
