package com.voicecomposer.app.ui.score

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.voicecomposer.app.ui.theme.UncertainColor
import com.voicecomposer.model.NotationBuilder
import com.voicecomposer.model.Spelling
import com.voicecomposer.model.Transcription
import com.voicecomposer.model.layout.ScoreLayoutEngine

/**
 * The score. Touch coordinates are converted back to musical positions by the layout (never stored), so zooming,
 * rotating or changing the key never invalidates an edit.
 *
 * - tap a note: select it; with a note selected, tapping the staff moves that note to the tapped pitch (the quickest
 *   touch correction; the Done button of the edit bar deselects); tap empty space with nothing selected: nothing
 *   (or add a note when [drawMode] is on)
 * - long press a note and drag vertically: change its pitch (applied once, when the finger is lifted)
 */
@Composable
fun ScoreView(
    transcription: Transcription,
    selectedId: String?,
    drawMode: Boolean,
    cursorBeat: () -> Double?,
    scroll: ScrollState,
    modifier: Modifier = Modifier,
    onSelect: (String?) -> Unit,
    onAddNote: (startBeat: Double, midi: Int) -> Unit,
    onSetPitch: (id: String, midi: Int) -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val palette = remember(colors) {
        ScorePalette(colors.onSurface.toArgb(), colors.primary.toArgb(), UncertainColor.toArgb(), colors.tertiary.toArgb(), colors.outline.toArgb())
    }
    val painter = remember(palette) { ScorePainter(palette) }
    val density = LocalDensity.current
    val staffPx = with(density) { 7.dp.toPx() }
    val notation = remember(transcription) { NotationBuilder.build(transcription) }

    // Where the score starts inside the scrolling column: scroll targets are computed from it.
    var top by remember { mutableFloatStateOf(0f) }
    BoxWithConstraints(modifier.fillMaxWidth().clipToBounds().onGloballyPositioned { top = it.positionInParent().y }) {
        val widthPx = with(density) { maxWidth.toPx() }
        val layout = remember(notation, widthPx) { ScoreLayoutEngine.layout(notation, widthPx, staffPx) }
        val heightDp = with(density) { layout.height.toDp() }
        var ghost by remember { mutableStateOf<GhostNote?>(null) }
        var dragId by remember { mutableStateOf<String?>(null) }

        val select = rememberUpdatedState(onSelect)
        val add = rememberUpdatedState(onAddNote)
        val setPitch = rememberUpdatedState(onSetPitch)
        val selectedNow = rememberUpdatedState(selectedId)
        val margin = with(density) { 8.dp.toPx() }
        val fifths = notation.key.fifths

        // Keep the selected note and the playback cursor on screen: the system being played goes to the top of the
        // visible area, so the next one is already in view below it when the cursor gets there.
        fun target(sysIndex: Int): Int? {
            val sys = layout.systems.getOrNull(sysIndex) ?: return null
            return (top + sys.regionTop - margin).toInt().coerceAtLeast(0)
        }
        val selectedSystem = selectedId?.let { id -> layout.noteBoxes.firstOrNull { it.eventId == id }?.system }
        LaunchedEffect(selectedSystem, top) {
            val y = selectedSystem?.let { target(it) } ?: return@LaunchedEffect
            val vis = scroll.value
            // Only move when the system is not already fully in the top part of the view.
            if (kotlin.math.abs(vis - y) > with(density) { 24.dp.toPx() }) scroll.animateScrollTo(y)
        }
        val cursorSystem by remember(layout) { derivedStateOf { cursorBeat()?.let { b -> layout.locate(b)?.first?.index } } }
        LaunchedEffect(cursorSystem, top) {
            val y = cursorSystem?.let { target(it) } ?: return@LaunchedEffect
            scroll.animateScrollTo(y)
        }

        Canvas(
            Modifier.fillMaxWidth().height(heightDp)
                .pointerInput(layout, drawMode) {
                    detectTapGestures { o ->
                        val hit = layout.hitNote(o.x, o.y)
                        when {
                            hit != null -> select.value(hit.eventId)
                            !drawMode && selectedNow.value != null -> {
                                // Move the selected note to the tapped line or space.
                                val p = layout.positionAt(o.x, o.y)
                                if (p != null) setPitch.value(selectedNow.value!!, Spelling.fromDiatonicIndex(p.staffPos.coerceIn(10, 50), fifths).toMidi())
                            }
                            drawMode -> {
                                val p = layout.positionAt(o.x, o.y)
                                if (p != null) {
                                    val midi = Spelling.fromDiatonicIndex(p.staffPos, fifths).toMidi()
                                    val beat = (p.measure * layout.measureTicks + p.tickInMeasure) / 4.0
                                    add.value(beat, midi)
                                }
                            }
                            else -> Unit
                        }
                    }
                }
                .pointerInput(layout) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { o ->
                            val hit = layout.hitNote(o.x, o.y)
                            if (hit != null) {
                                dragId = hit.eventId
                                select.value(hit.eventId)
                                ghost = GhostNote(hit.system, hit.x, hit.staffPos)
                            }
                        },
                        onDrag = { change, _ ->
                            val g = ghost ?: return@detectDragGesturesAfterLongPress
                            val sys = layout.systems.getOrNull(g.system) ?: return@detectDragGesturesAfterLongPress
                            ghost = GhostNote(g.system, g.x, layout.posForY(sys, change.position.y).coerceIn(10, 50))
                            change.consume()
                        },
                        onDragEnd = {
                            val g = ghost
                            val id = dragId
                            if (g != null && id != null) setPitch.value(id, Spelling.fromDiatonicIndex(g.staffPos, fifths).toMidi())
                            ghost = null; dragId = null
                        },
                        onDragCancel = { ghost = null; dragId = null },
                    )
                },
        ) {
            drawIntoCanvas { c -> painter.draw(c.nativeCanvas, layout, notation, selectedId, cursorBeat(), ghost) }
        }
    }
}
