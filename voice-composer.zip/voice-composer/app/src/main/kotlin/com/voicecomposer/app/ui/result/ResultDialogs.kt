package com.voicecomposer.app.ui.result

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.voicecomposer.app.R
import com.voicecomposer.model.KeySignature
import com.voicecomposer.model.Mode
import com.voicecomposer.model.TimeSignature

private val TONICS = listOf("C", "C♯/D♭", "D", "E♭", "E", "F", "F♯/G♭", "G", "A♭", "A", "B♭", "B")

@Composable
fun TempoDialog(current: Double, onDismiss: () -> Unit, onConfirm: (Double) -> Unit) {
    var text by remember { mutableStateOf(Math.round(current).toString()) }
    val value = text.toDoubleOrNull()
    val valid = value != null && value in 20.0..300.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.tempo)) },
        text = {
            OutlinedTextField(
                text, { text = it.filter { c -> c.isDigit() || c == '.' }.take(6) }, singleLine = true,
                label = { Text(stringResource(R.string.bpm_label)) }, isError = !valid,
                supportingText = { Text(stringResource(R.string.bpm_range)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            )
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onConfirm(value!!) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun MeterDialog(current: TimeSignature, onDismiss: () -> Unit, onConfirm: (TimeSignature) -> Unit) {
    val options = listOf(TimeSignature.TWO_FOUR, TimeSignature.THREE_FOUR, TimeSignature.FOUR_FOUR, TimeSignature.SIX_EIGHT)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.meter)) },
        text = {
            Column {
                for (o in options) {
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = o == current, role = Role.RadioButton, onClick = { onConfirm(o) }).padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) { RadioButton(selected = o == current, onClick = null); Spacer(Modifier.size(12.dp)); Text(o.toString(), style = MaterialTheme.typography.titleMedium) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun KeyDialog(current: KeySignature, onDismiss: () -> Unit, onConfirm: (tonic: Int, minor: Boolean) -> Unit) {
    var tonic by remember { mutableIntStateOf(current.tonic) }
    var minor by remember { mutableStateOf(current.mode == Mode.MINOR) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.key)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(!minor, { minor = false }, label = { Text(stringResource(R.string.major)) })
                    FilterChip(minor, { minor = true }, label = { Text(stringResource(R.string.minor)) })
                }
                Spacer(Modifier.height(8.dp))
                for (row in TONICS.indices.chunked(4)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (i in row) FilterChip(tonic == i, { tonic = i }, label = { Text(TONICS[i]) })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(tonic, minor) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun TextDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it.take(60) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
fun ConfirmDialog(title: String, body: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

/** One-octave piano (C to C). Tapping a key plays it and applies it to the selected note, or appends a note. */
@Composable
fun PianoKeyboard(octave: Int, onOctave: (Int) -> Unit, onKey: (Int) -> Unit, modifier: Modifier = Modifier) {
    val base = (octave + 1) * 12
    val whites = intArrayOf(0, 2, 4, 5, 7, 9, 11, 12)
    // black keys sit on the boundary after white key 0,1,3,4,5 (C#, D#, F#, G#, A#)
    val blackAfter = intArrayOf(1, 2, 4, 5, 6)
    val blackOffset = intArrayOf(1, 3, 6, 8, 10)
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { onOctave((octave - 1).coerceAtLeast(1)) }) { Text("−") }
            Text(stringResource(R.string.octave_label, octave), style = MaterialTheme.typography.labelLarge)
            TextButton(onClick = { onOctave((octave + 1).coerceAtMost(7)) }) { Text("+") }
        }
        Box(Modifier.fillMaxWidth().height(96.dp)) {
            Row(Modifier.fillMaxSize()) {
                for (w in whites) {
                    Box(
                        Modifier.weight(1f).fillMaxSize().border(0.5.dp, MaterialTheme.colorScheme.outline)
                            .background(Color.White).clickable { onKey(base + w) },
                        contentAlignment = Alignment.BottomCenter,
                    ) { if (w == 0 || w == 12) Text("C${octave + if (w == 12) 1 else 0}", color = Color.DarkGray, style = MaterialTheme.typography.labelSmall) }
                }
            }
            Row(Modifier.fillMaxWidth().height(58.dp)) {
                var cursor = 0f
                for (k in blackAfter.indices) {
                    val start = blackAfter[k] - 0.3f
                    Spacer(Modifier.weight(start - cursor))
                    Box(Modifier.weight(0.6f).fillMaxSize().clip(androidx.compose.foundation.shape.RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp)).background(Color(0xFF222222)).clickable { onKey(base + blackOffset[k]) })
                    cursor = start + 0.6f
                }
                Spacer(Modifier.weight(8f - cursor))
            }
        }
    }
}
