#!/usr/bin/env python3
"""
Trains the note merger (random forest, scikit-learn): for two neighbouring detected notes, are they one sung note that the
detector cut in two (label 1) or two notes (label 0)? Exports app/src/main/assets/note_merge.json (same flat-tree format as
the note classifier, read by RandomForest.fromJson).

Input : CSVs from engine/src/test/.../ml/MergeDataGen.kt (tools/gen_merge_data.sh): one row per joint.
Noise regularisation as for the note classifier: noisy, wobbling synthetic voices; Gaussian jitter on the continuous
features; shallow trees with large leaves; hyper-parameters chosen on val and on the unseen-conditions 'hard' split.
"""
import argparse, csv, json, os
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, precision_recall_fscore_support

ap = argparse.ArgumentParser()
ap.add_argument("--train", nargs="+", required=True)
ap.add_argument("--val", required=True)
ap.add_argument("--hard", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--parity", default=None)
ap.add_argument("--trees", type=int, default=80)
ap.add_argument("--jitter", type=float, default=0.05)
ap.add_argument("--seed", type=int, default=7)
a = ap.parse_args()

def load(paths):
    X, y, meta = [], [], []
    feat = None
    for p in paths:
        with open(p) as f:
            rd = csv.reader(f)
            head = next(rd)
            n0 = head.index("gap")
            feat = head[n0:]
            for row in rd:
                if len(row) != len(head): continue
                v = [float(t) for t in row[n0:]]
                if not all(np.isfinite(v)): continue  # (rare) non-finite feature: skip the row
                X.append(v); y.append(int(row[5])); meta.append((row[2], row[3]))
    return np.array(X, dtype=np.float32), np.array(y), meta, feat

Xtr, ytr, _, FEAT = load(a.train)
Xva, yva, mva, _ = load([a.val])
Xha, yha, mha, _ = load([a.hard])
print(f"rows train={len(ytr)} (merge {ytr.mean():.2f}) val={len(yva)} ({yva.mean():.2f}) hard={len(yha)} ({yha.mean():.2f}); features {len(FEAT)}")
rng = np.random.default_rng(a.seed)
CONT = [i for i, n in enumerate(FEAT) if n not in ("isSing", "isHum", "isWhistle", "stepIdx", "slopeAgree", "dKey")]
sd = Xtr.std(axis=0) + 1e-9

def jitter(X, y, copies):
    if a.jitter <= 0 or copies == 0: return X, y
    Xs, ys = [X], [y]
    for _ in range(copies):
        Z = X.copy(); Z[:, CONT] += rng.normal(0, 1, (len(X), len(CONT))).astype(np.float32) * (sd[CONT] * a.jitter)
        Xs.append(Z); ys.append(y)
    return np.vstack(Xs), np.concatenate(ys)

def prf(y, p, th=0.5):
    pr, rc, f1, _ = precision_recall_fscore_support(y, p >= th, average="binary", zero_division=0); return pr, rc, f1

def report(name, y, p):
    auc = roc_auc_score(y, p) if len(set(y)) > 1 else float("nan"); pr, rc, f1 = prf(y, p)
    print(f"{name:30s} AUC {auc:.3f}  P {pr:.3f} R {rc:.3f} F1 {f1:.3f}")

best = None
grid = [dict(max_depth=d, min_samples_leaf=l, max_features=f) for d in (8, 12, 16) for l in (4, 10, 20) for f in ("sqrt", 0.5)]
for jc in (0, 2):
    Xj, yj = jitter(Xtr, ytr, jc)
    for g in grid:
        rf = RandomForestClassifier(n_estimators=40, class_weight="balanced_subsample", n_jobs=2, random_state=a.seed, **g).fit(Xj, yj)
        sv = roc_auc_score(yva, rf.predict_proba(Xva)[:, 1]); sh = roc_auc_score(yha, rf.predict_proba(Xha)[:, 1])
        if best is None or sv + sh > best[0]: best = (sv + sh, jc, g, sv, sh)
        print(f"  jitter x{jc} {g} valAUC {sv:.4f} hardAUC {sh:.4f}", flush=True)
_, jc, g, sv, sh = best
print(f"\nchosen jitter={jc} {g} (val AUC {sv:.4f}, hard AUC {sh:.4f})")
Xj, yj = jitter(Xtr, ytr, jc)
rf = RandomForestClassifier(n_estimators=a.trees, class_weight="balanced_subsample", n_jobs=2, random_state=a.seed, **g).fit(Xj, yj)
pv = rf.predict_proba(Xva)[:, 1]; ph = rf.predict_proba(Xha)[:, 1]
print("\n=== joint level ===")
report("val", yva, pv); report("hard", yha, ph)
for t in ("SINGING", "HUMMING", "WHISTLING"):
    i = [k for k, m in enumerate(mha) if m[0] == t]
    if len(i) > 30 and len(set(yha[i])) > 1: report(f"hard {t}", yha[i], ph[i])
ths = np.linspace(0.2, 0.8, 25); f1s = [prf(yva, pv, t)[2] for t in ths]
print(f"best val threshold {ths[int(np.argmax(f1s))]:.2f} (F1 {max(f1s):.3f}); at 0.5: {prf(yva, pv, .5)[2]:.3f}")
imp = sorted(zip(rf.feature_importances_, FEAT), reverse=True)
print("importances:", ", ".join(f"{n} {v:.3f}" for v, n in imp[:12]))

def f32s(v): return float(np.format_float_positional(np.float32(v), unique=True))
trees = []
for est in rf.estimators_:
    t = est.tree_; feat = t.feature.astype(int).tolist()
    trees.append({"f": feat, "t": [f32s(v) if f >= 0 else 0.0 for v, f in zip(t.threshold, feat)],
                  "l": [int(x) for x in t.children_left], "r": [int(x) for x in t.children_right],
                  "v": [round(float(t.value[i][0][1] / t.value[i][0].sum()), 4) if t.value[i][0].sum() > 0 else 0.0 for i in range(t.node_count)]})
os.makedirs(os.path.dirname(a.out), exist_ok=True)
json.dump({"dim": len(FEAT), "features": FEAT, "trees": trees}, open(a.out, "w"), separators=(",", ":"))
print(f"wrote {a.out}: {os.path.getsize(a.out)/1024:.0f} KiB, {len(trees)} trees")
if a.parity:
    idx = rng.choice(len(Xva), size=min(300, len(Xva)), replace=False)
    os.makedirs(os.path.dirname(a.parity), exist_ok=True)
    json.dump({"x": [[float(v) for v in r] for r in Xva[idx]], "p": [float(v) for v in rf.predict_proba(Xva[idx])[:, 1]]}, open(a.parity, "w"))
