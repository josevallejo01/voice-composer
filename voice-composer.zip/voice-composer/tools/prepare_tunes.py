#!/usr/bin/env python3
"""
Parses the Nottingham ABC folk-tune collection (ABC_cleaned/*.abc) into the notated ground truth used to train the score
models (tempo, meter, rhythm, key, spelling). Output: JSON lines, one tune per line:
  {"id","title","num","den","fifths","minor","tonic","pickup","tuplets","notes":[[midi,start,dur,step,alter],...]}
Times are in quarter notes from the start of the tune; "pickup" is the length (quarter notes) of an incomplete first bar.
Repeat signs are ignored (each written bar is played once). Tunes with chords-in-body, meter changes or unreadable text
are dropped. Usage: prepare_tunes.py <ABC_cleaned dir> <out.jsonl>
"""
import re, sys, json, glob, os
from fractions import Fraction as F

STEP_PC = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}
SHARP_ORDER = "FCGDAEB"          # order of sharps; flats are the reverse
MAJOR_TONIC_FIFTHS = {'C': 0, 'G': 1, 'D': 2, 'A': 3, 'E': 4, 'B': 5, 'F#': 6, 'F': -1, 'Bb': -2, 'Eb': -3, 'Ab': -4, 'Db': -5}
PC_NAMES = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}


def key_info(k):
    k = k.strip()
    m = re.match(r"^([A-G])([#b]?)\s*(m|min|minor|maj|major|mix|dor|lyd|phr|loc)?", k, re.I)
    if not m:
        return None
    letter, acc, mode = m.group(1).upper(), m.group(2), (m.group(3) or "").lower()
    tonic = PC_NAMES[letter] + (1 if acc == '#' else -1 if acc == 'b' else 0)
    tonic %= 12
    minor = mode in ("m", "min", "minor")
    # relative major's fifths
    major_pc = (tonic + 3) % 12 if minor else tonic
    table = {0: 0, 7: 1, 2: 2, 9: 3, 4: 4, 11: 5, 6: 6, 5: -1, 10: -2, 3: -3, 8: -4, 1: -5}
    if mode in ("dor",): major_pc = (tonic - 2) % 12
    elif mode in ("mix",): major_pc = (tonic - 7) % 12
    elif mode in ("lyd",): major_pc = (tonic - 5) % 12
    elif mode in ("phr",): major_pc = (tonic - 4) % 12
    elif mode in ("loc",): major_pc = (tonic - 11) % 12
    fifths = table[major_pc % 12]
    return fifths, minor, tonic


def key_accidentals(fifths):
    acc = {}
    if fifths > 0:
        for s in SHARP_ORDER[:fifths]: acc[s] = 1
    elif fifths < 0:
        for s in SHARP_ORDER[::-1][:-fifths]: acc[s] = -1
    return acc


def parse_len(s, i):
    """Reads an ABC length multiplier at s[i:], returns (Fraction, new i)."""
    num = ""; 
    while i < len(s) and s[i].isdigit(): num += s[i]; i += 1
    mult = F(int(num)) if num else F(1)
    if i < len(s) and s[i] == '/':
        den = ""; slashes = 0
        while i < len(s) and s[i] == '/': slashes += 1; i += 1
        while i < len(s) and s[i].isdigit(): den += s[i]; i += 1
        if den: mult = mult / int(den)
        else: mult = mult / (2 ** slashes)
    return mult, i


NOTE_RE = re.compile(r"(\^\^|\^|__|_|=)?([A-Ga-g])([',]*)")


def parse_tune(block):
    head, body = {}, []
    in_body = False
    for raw in block.split("\n"):
        line = raw.split("%")[0].rstrip()
        if not line.strip():
            continue
        m = re.match(r"^([A-Za-z]):\s*(.*)$", line)
        if m and not in_body:
            head[m.group(1)] = m.group(2)
            if m.group(1) == "K": in_body = True
            continue
        if m and in_body:
            if m.group(1) == "M": return None          # meter change inside the tune
            if m.group(1) in ("L", "K"): return None
            continue                                    # lyrics / part labels
        body.append(line)
    if "M" not in head or "K" not in head: return None
    mm = re.match(r"^(\d+)/(\d+)$", head["M"].strip())
    if not mm: return None
    num, den = int(mm.group(1)), int(mm.group(2))
    ki = key_info(head["K"])
    if ki is None: return None
    fifths, minor, tonic = ki
    unit = F(1, 8) if num / den >= 0.75 else F(1, 16)
    if "L" in head:
        lm = re.match(r"^(\d+)/(\d+)", head["L"].strip())
        if lm: unit = F(int(lm.group(1)), int(lm.group(2)))
    unit_q = unit * 4                                   # in quarter notes
    bar_q = F(num * 4, den)
    base_acc = key_accidentals(fifths)

    text = " ".join(body).replace("\\", " ")
    text = re.sub(r'"[^"]*"', "", text)                  # chord symbols
    text = re.sub(r"!\w+!|\+\w+\+", "", text)            # decorations
    text = re.sub(r"\{[^}]*\}", "", text)                # grace notes
    text = text.replace("~", "").replace(".", "")
    text = re.sub(r"\[\d", "", text)                     # volta [1 [2
    text = re.sub(r"\|\]|\|\|", "|", text)
    if "[" in text or "]" in text: return None           # chords in the melody: skip
    t = F(0); notes = []; tuplets = False
    bar_acc = {}; bars = []; bar_start = F(0)
    i = 0; pending_tie = False; trip_left = 0; trip_scale = F(1); broken = None
    first_bar_len = None
    def end_bar():
        nonlocal bar_start, bar_acc, first_bar_len
        if first_bar_len is None and t > 0: first_bar_len = t - bar_start
        bar_start = t; bar_acc = {}
    last_idx = None
    while i < len(text):
        c = text[i]
        if c in " \t": i += 1; continue
        if c in "|:": 
            if c == "|": end_bar()
            i += 1; continue
        if c in "()":
            if c == "(" and i + 1 < len(text) and text[i + 1].isdigit():
                n = int(text[i + 1]); tuplets = True
                trip_left = n; trip_scale = F(2, 3) if n == 3 else F(3, 2) if n == 2 else F(2, n)  # rough
                i += 2
                if i < len(text) and text[i] == ":":     # (p:q:r form
                    j = i
                    while j < len(text) and (text[j].isdigit() or text[j] == ":"): j += 1
                    i = j
                continue
            i += 1; continue
        if c == "-": pending_tie = True; i += 1; continue
        if c in "><":
            broken = c; i += 1; continue
        if c in "zZxX":
            i += 1
            mult, i = parse_len(text, i)
            d = unit_q * mult * (trip_scale if trip_left else 1)
            if trip_left: trip_left -= 1
            t += d; last_idx = None; pending_tie = False
            continue
        m = NOTE_RE.match(text, i)
        if not m: return None
        acc, letter, octs = m.group(1), m.group(2), m.group(3)
        i = m.end()
        mult, i = parse_len(text, i)
        d = unit_q * mult * (trip_scale if trip_left else 1)
        if trip_left: trip_left -= 1
        if broken == "<": d = d * F(1, 2)
        elif broken == ">": d = d * F(3, 2)
        # a note following '>' is shortened, following '<' lengthened: handle by looking at the previous token
        if broken is None and notes and getattr(parse_tune, "_pb", None): pass
        up = letter.islower(); L = letter.upper()
        octave = 5 if up else 4
        octave += octs.count("'") - octs.count(",")
        key = (L, octave)
        if acc:
            alter = {"^^": 2, "^": 1, "=": 0, "__": -2, "_": -1}[acc]
            bar_acc[key] = alter
        elif key in bar_acc: alter = bar_acc[key]
        else: alter = base_acc.get(L, 0)
        midi = 12 * (octave + 1) + STEP_PC[L] + alter
        if pending_tie and last_idx is not None and notes[last_idx][0] == midi:
            notes[last_idx][2] = float(F(notes[last_idx][2]).limit_denominator(1000) + d)
        else:
            notes.append([midi, float(t), float(d), L, alter]); last_idx = len(notes) - 1
        pending_tie = False
        t += d
        if broken == "<" or broken == ">":
            # following note takes the complement: handled below
            pass
        broken = None
    if len(notes) < 12: return None
    # broken rhythm ('>' / '<') was approximated above only for the note after the sign; accept the small error.
    pickup = 0.0
    if first_bar_len is not None and first_bar_len < bar_q - F(1, 8) and first_bar_len > 0:
        pickup = float(first_bar_len)
    return {"num": num, "den": den, "fifths": fifths, "minor": minor, "tonic": tonic, "pickup": pickup,
            "tuplets": tuplets, "notes": notes, "title": head.get("T", "")}


def main():
    src, out = sys.argv[1], sys.argv[2]
    n_all = n_ok = 0
    with open(out, "w") as fo:
        for path in sorted(glob.glob(os.path.join(src, "*.abc"))):
            txt = open(path, encoding="latin-1").read()
            for k, block in enumerate(re.split(r"\n(?=X:\s*\d+)", "\n" + txt)):
                if not block.strip() or not re.search(r"^X:", block, re.M): continue
                n_all += 1
                try: tune = parse_tune(block)
                except Exception as e: tune = None
                if tune is None: continue
                tune["id"] = f"{os.path.basename(path)}#{k}"
                fo.write(json.dumps(tune) + "\n"); n_ok += 1
    print(f"parsed {n_ok}/{n_all} tunes")

main()
