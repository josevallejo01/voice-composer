#!/bin/bash
# Generates training rows for the score models (see tools/train_score_models.py) from notated tunes.
# Needs the compiled engine + test classes (./gradlew :engine:testClasses) and tools/tunes.jsonl from tools/prepare_tunes.py.
#   tools/gen_score_data.sh <tunes.jsonl> <outdir> <split> <performances-per-tune>
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
CP="$ROOT/engine/build/classes/kotlin/main:$ROOT/engine/build/classes/kotlin/test:$ROOT/core/music-model/build/classes/kotlin/main"
CP="$CP:$(find ~/.gradle -name 'kotlin-stdlib-2*.jar' | head -1)"
java -Xmx2g -cp "$CP" com.voicecomposer.engine.score.ScoreDataGen "$@"
