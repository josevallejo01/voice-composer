#!/bin/bash
# Generates training rows for the note merger (see tools/train_merge_model.py).
#   tools/gen_merge_data.sh <out.csv> <first-seed> <clips> <train|val|hard> [note_rf.json]
# Needs what tools/gen_data.sh needs (compiled engine and test classes, python3 with onnxruntime numpy, nmp.onnx).
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
CP="$ROOT/engine/build/classes/kotlin/main:$ROOT/engine/build/classes/kotlin/test:$ROOT/core/music-model/build/classes/kotlin/main"
CP="$CP:$(find ~/.gradle -name 'kotlin-stdlib-2*.jar' | head -1)"
RF=${5:-$ROOT/app/src/main/assets/note_rf.json}
java -Xmx1500m -cp "$CP" com.voicecomposer.engine.ml.MergeDataGen "$1" "$2" "$3" "$4" "$RF"
