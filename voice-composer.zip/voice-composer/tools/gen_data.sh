#!/bin/bash
# Generates training rows for the note forest (see tools/train_note_forest.py).
# Needs the compiled engine + its test classes (e.g. from ./gradlew :engine:testClasses), python3 with onnxruntime numpy,
# and the Basic Pitch model at app/src/main/assets/nmp.onnx.
#   tools/gen_data.sh <out.csv> <first-seed> <clips> <train|val|hard>
# Typical: 900 train clips x 2 seeds, 300 val, 450 hard (about 100 clips/min per core). Output is appended every 20 clips.
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
CP="$ROOT/engine/build/classes/kotlin/main:$ROOT/engine/build/classes/kotlin/test:$ROOT/core/music-model/build/classes/kotlin/main"
CP="$CP:$(find ~/.gradle -name 'kotlin-stdlib-2*.jar' | head -1)"
java -Xmx1500m -cp "$CP" com.voicecomposer.engine.ml.DataGen "$@"
