#!/usr/bin/env python3
"""
Trains the note classifier (random forest, scikit-learn) and exports it for the app.

Input : CSVs written by engine/src/test/.../ml/DataGen.kt (one row per candidate note, label 1 = real note with the
        right pitch). Splits: train / val (same conditions, new seeds) / hard (conditions never seen in training).
Output: app/src/main/assets/note_rf.json   forest, flat arrays, read by RandomForest.fromJson
        engine/src/test/resources/rf_parity.json   rows + sklearn probabilities for the Kotlin parity test
        a metrics report on stdout (and --report file)

Noise regularisation (the point of this script):
  1. data: every clip is degraded with random noise types, SNR 3-30 dB, gain, AGC, reverb, band limiting, clipping;
  2. features: the training set is replicated with Gaussian jitter on the continuous features (--jitter), so splits
     cannot hinge on tiny differences that noise moves around;
  3. trees: shallow-ish depth, large leaves, sqrt feature subsampling, bootstrap, balanced classes;
  4. model choice: hyper-parameters picked on val; the reported number that matters is the 'hard' split.
"""
import argparse, csv, json, sys, os
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, precision_recall_fscore_support

ap = argparse.ArgumentParser()
ap.add_argument("--train", nargs="+", required=True)
ap.add_argument("--val", required=True)
ap.add_argument("--hard", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--parity", default=None)
ap.add_argument("--report", default=None)
ap.add_argument("--trees", type=int, default=80)
ap.add_argument("--jitter", type=float, default=0.05)
ap.add_argument("--seed", type=int, default=7)
a = ap.parse_args()

NAMES = None
def load(paths):
    global NAMES
    X, y, meta = [], [], []
    for p in paths:
        with open(p) as f:
            r = csv.DictReader(f)
            if NAMES is None:
                NAMES = [c for c in r.fieldnames if c not in ("clip", "split", "type", "tags", "snr", "label", "ruleKeep", "start", "midi") or c == "midi"]
                # 'midi' appears twice (metadata and feature): keep only the feature part below
            for row in r:
                vals = list(row.values())
                X.append(vals); y.append(int(row["label"])); meta.append((row["clip"], row["type"], row["tags"], float(row["snr"]), int(row["ruleKeep"])))
    return X, y, meta

def split_cols(paths):
    """Reads rows with positional columns: 9 metadata columns then the features (feature 'midi' shares a name with metadata)."""
    X, y, meta = [], [], []
    for p in paths:
        with open(p) as f:
            rd = csv.reader(f)
            head = next(rd)
            nmeta = head.index("dur")
            feat = head[nmeta:]
            for row in rd:
                X.append([float(v) for v in row[nmeta:]])
                y.append(int(row[5]))
                meta.append((row[0], row[2], row[3], float(row[4]), int(row[6])))
    return np.array(X, dtype=np.float32), np.array(y), meta, feat

Xtr, ytr, mtr, FEAT = split_cols(a.train)
Xva, yva, mva, _ = split_cols([a.val])
Xha, yha, mha, _ = split_cols([a.hard])
print(f"rows train={len(ytr)} (pos {ytr.mean():.2f}) val={len(yva)} (pos {yva.mean():.2f}) hard={len(yha)} (pos {yha.mean():.2f})")
print("features:", len(FEAT))

rng = np.random.default_rng(a.seed)
CONT = [i for i, n in enumerate(FEAT) if n not in ("isSing", "isHum", "isWhistle")]
sd = Xtr.std(axis=0) + 1e-9

def jitter(X, y, copies):
    if a.jitter <= 0 or copies == 0:
        return X, y
    Xs = [X]; ys = [y]
    for _ in range(copies):
        Z = X.copy()
        Z[:, CONT] += rng.normal(0, 1, (len(X), len(CONT))).astype(np.float32) * (sd[CONT] * a.jitter)
        Xs.append(Z); ys.append(y)
    return np.vstack(Xs), np.concatenate(ys)

def prf(y, p, th=0.5):
    pr, rc, f1, _ = precision_recall_fscore_support(y, p >= th, average="binary", zero_division=0)
    return pr, rc, f1

def report(name, y, p, meta, rule=None):
    auc = roc_auc_score(y, p) if len(set(y)) > 1 else float("nan")
    pr, rc, f1 = prf(y, p)
    line = f"{name:28s} AUC {auc:.3f}  P {pr:.3f} R {rc:.3f} F1 {f1:.3f}"
    if rule is not None:
        rp, rr, rf = prf(y, np.array(rule, dtype=float), 0.5)
        line += f"   | rules P {rp:.3f} R {rr:.3f} F1 {rf:.3f}"
    print(line); return line

lines = []
best = None
grid = [dict(max_depth=d, min_samples_leaf=l, max_features=f) for d in (8, 12, 16) for l in (4, 10, 20) for f in ("sqrt", 0.5)]
for jit_copies in (0, 2):
    Xj, yj = jitter(Xtr, ytr, jit_copies)
    for g in grid:
        rf = RandomForestClassifier(n_estimators=40, class_weight="balanced_subsample", n_jobs=2, random_state=a.seed, **g)
        rf.fit(Xj, yj)
        pv = rf.predict_proba(Xva)[:, 1]; ph = rf.predict_proba(Xha)[:, 1]
        sv = roc_auc_score(yva, pv); sh = roc_auc_score(yha, ph)
        score = 0.5 * sv + 0.5 * sh   # val for fit, hard for robustness
        if best is None or score > best[0]:
            best = (score, jit_copies, g, sv, sh)
        print(f"  jitter x{jit_copies} {g}  valAUC {sv:.4f} hardAUC {sh:.4f}", flush=True)
score, jit_copies, g, sv, sh = best
print(f"\nchosen: jitter copies={jit_copies} params={g} (val AUC {sv:.4f}, hard AUC {sh:.4f})")

Xj, yj = jitter(Xtr, ytr, jit_copies)
rf = RandomForestClassifier(n_estimators=a.trees, class_weight="balanced_subsample", n_jobs=2, random_state=a.seed, **g).fit(Xj, yj)
# Same forest without noise regularisation (no jitter, unlimited depth, leaf 1) for the report.
raw = RandomForestClassifier(n_estimators=a.trees, class_weight="balanced_subsample", n_jobs=2, random_state=a.seed).fit(Xtr, ytr)

pv = rf.predict_proba(Xva)[:, 1]; ph = rf.predict_proba(Xha)[:, 1]
print("\n=== results (candidate-level) ===")
lines.append(report("val  regularised forest", yva, pv, mva, [m[4] for m in mva]))
lines.append(report("val  unregularised forest", yva, raw.predict_proba(Xva)[:, 1], mva))
lines.append(report("hard regularised forest", yha, ph, mha, [m[4] for m in mha]))
lines.append(report("hard unregularised forest", yha, raw.predict_proba(Xha)[:, 1], mha))

print("\n=== per input type on the hard split (regularised forest vs rules) ===")
for t in ("SINGING", "HUMMING", "WHISTLING"):
    idx = [i for i, m in enumerate(mha) if m[1] == t]
    lines.append(report(f"hard {t}", yha[idx], ph[idx], [mha[i] for i in idx], [mha[i][4] for i in idx]))
print("\n=== by noise tag on the hard split ===")
tags = sorted({tg for m in mha for tg in m[2].split("+")})
for tg in tags:
    idx = [i for i, m in enumerate(mha) if tg in m[2].split("+")]
    if len(idx) >= 50 and len(set(yha[idx])) > 1:
        lines.append(report(f"hard tag {tg}", yha[idx], ph[idx], [mha[i] for i in idx], [mha[i][4] for i in idx]))

# F1-optimal threshold on val (the app starts at 0.5 and calibration moves it)
ths = np.linspace(0.2, 0.8, 25)
f1s = [prf(yva, pv, t)[2] for t in ths]
print(f"\nbest val threshold {ths[int(np.argmax(f1s))]:.2f} (F1 {max(f1s):.3f}); at 0.5: {prf(yva, pv, .5)[2]:.3f}")
imp = sorted(zip(rf.feature_importances_, FEAT), reverse=True)
print("importances:", ", ".join(f"{n} {v:.3f}" for v, n in imp[:12]))

# ---------------------------------------------------------------- export
def f32s(v):
    return float(np.format_float_positional(np.float32(v), unique=True))

trees = []
for est in rf.estimators_:
    t = est.tree_
    feat = t.feature.astype(int).tolist()
    thr = [f32s(v) if f >= 0 else 0.0 for v, f in zip(t.threshold, feat)]
    val = []
    for i in range(t.node_count):
        v = t.value[i][0]
        val.append(round(float(v[1] / v.sum()), 4) if v.sum() > 0 else 0.0)
    cw = [int(x) for x in t.children_left]; cr = [int(x) for x in t.children_right]
    # leaves have children -1; Kotlin only follows children of nodes with feature >= 0
    trees.append({"f": feat, "t": thr, "l": cw, "r": cr, "v": val})
os.makedirs(os.path.dirname(a.out), exist_ok=True)
with open(a.out, "w") as f:
    json.dump({"dim": len(FEAT), "features": FEAT, "trees": trees}, f, separators=(",", ":"))
print(f"wrote {a.out}: {os.path.getsize(a.out)/1024:.0f} KiB, {len(trees)} trees, {sum(len(t['f']) for t in trees)} nodes")

if a.parity:
    idx = rng.choice(len(Xva), size=min(300, len(Xva)), replace=False)
    Xp = Xva[idx]
    pp = rf.predict_proba(Xp)[:, 1]
    os.makedirs(os.path.dirname(a.parity), exist_ok=True)
    json.dump({"x": [[float(v) for v in r] for r in Xp], "p": [float(v) for v in pp]}, open(a.parity, "w"))
    print("wrote parity", a.parity)
if a.report:
    open(a.report, "w").write("\n".join(lines) + f"\n\nchosen: jitter copies={jit_copies} params={g}\n")
