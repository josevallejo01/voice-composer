#!/usr/bin/env python3
"""
Decides which models ship. Reads the evaluation JSON of the four combinations on real val and real test:
  old   shipped note forest + shipped merger          (the baseline)
  nn    new note forest + new merger
  no    new note forest + shipped merger
  on    shipped note forest + new merger
The winner is chosen on VAL; it ships only if it beats the baseline on val by MIN_GAIN and does not lose on the untouched
TEST split. Writes report.md (what was measured, honestly) and prints the winner's name ("old" = keep the shipped models).
"""
import json, sys
val = json.load(open(sys.argv[1])); test = json.load(open(sys.argv[2])); out = sys.argv[3]
MIN_GAIN = float(sys.argv[4]) if len(sys.argv) > 4 else 0.005
names = [n for n in ("old", "nn", "no", "on") if n in val]
def score(r, scope="all"):
    b = r.get(scope)
    return None if not b else (b["on50"]["f1"] + b["on100"]["f1"]) / 2
sv = {n: score(val[n]) for n in names}
cand = [n for n in names if n != "old" and sv[n] is not None]
win = max(cand, key=lambda n: sv[n]) if cand else "old"
ship = win != "old" and sv[win] >= sv["old"] + MIN_GAIN and score(test[win]) >= score(test["old"]) - 0.002
rows = []
def fmt(r, k): return "-" if not r or k not in r else f'{r[k]["p"]:.3f} / {r[k]["r"]:.3f} / {r[k]["f1"]:.3f}'
lines = ["# Real-data training report", "",
         f"val clips: {val['clips']} ({val['refNotes']} reference notes) - test clips: {test['clips']} ({test['refNotes']} reference notes)", "",
         "Onset F1 = a detected note counts when its pitch matches (at the best octave shift of the clip) and its onset is within the tolerance. Cells: precision / recall / F1.", "",
         "| split | model | on50 (all) | on100 (all) | note count / reference |", "|---|---|---|---|---|"]
for split, d in (("val", val), ("test", test)):
    for n in names:
        r = d[n]; lines.append(f"| {split} | {n} | {fmt(r.get('all'), 'on50')} | {fmt(r.get('all'), 'on100')} | {r['noteRatio']:.2f} |")
lines += ["", "Per kind of sound, test split, F1 on50 / on100:", ""]
for t in ("HUMMING", "SINGING", "WHISTLING"):
    cells = [f"{n}: " + (f'{test[n][t]["on50"]["f1"]:.3f} / {test[n][t]["on100"]["f1"]:.3f}' if t in test[n] else "-") for n in names]
    lines.append(f"* {t}: " + "; ".join(cells))
lines += ["", f"Winner on val: **{win}** (score {sv.get(win, float('nan')):.4f} vs baseline {sv['old']:.4f}).",
          f"Decision: **{'SHIP the new models' if ship else 'KEEP the shipped models'}** (needs +{MIN_GAIN} on val and no loss on test)."]
open(out, "w").write("\n".join(lines) + "\n")
print(win if ship else "old")
