#!/usr/bin/env python3
"""
Builds the training manifest (see engine/src/test/.../ml/RealTools.kt) from public corpora of REAL recordings with
reference notes. Meant for CI (GitHub Actions has the Internet; the build sandbox I develop in does not), so the
download code could not be run where it was written: every step prints what it found, and a failing corpus is skipped
with a clear message instead of stopping the others.

  HumTrans  (Hugging Face dadinghh2/HumTrans, ~56 h of hummed melodies, MIDI notes; official valid/test keys come from
             github.com/TencentARC-QQ/HumTrans)       -> HUMMING
  vocadito  (Zenodo, via mirdata; 40 solo vocal clips with note annotations)                           -> SINGING

Usage: prepare_real.py --out DIR [--max-train 4000 --max-val 600 --max-test 900 --max-gb 25] [--only humtrans|vocadito]
"""
import argparse, glob, hashlib, json, os, random, re, shutil, subprocess, sys, tarfile, zipfile

ap = argparse.ArgumentParser()
ap.add_argument("--out", required=True)
ap.add_argument("--max-train", type=int, default=4000)
ap.add_argument("--max-val", type=int, default=600)
ap.add_argument("--max-test", type=int, default=900)
ap.add_argument("--max-gb", type=float, default=25)
ap.add_argument("--only", default=None)
ap.add_argument("--min-notes", type=int, default=3)
ap.add_argument("--max-sec", type=float, default=45)
a = ap.parse_args()
OUT = os.path.abspath(a.out); os.makedirs(OUT, exist_ok=True)
RAW = os.path.join(OUT, "raw"); WAV = os.path.join(OUT, "wav"); NOTES = os.path.join(OUT, "notes")
for d in (RAW, WAV, NOTES): os.makedirs(d, exist_ok=True)
rng = random.Random(1234)
AUDIO_EXT = (".wav", ".mp3", ".flac", ".ogg", ".m4a", ".aac")
MIDI_EXT = (".mid", ".midi")
ARCH_EXT = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2")
summary = []

def log(*s):
    print(*s, flush=True)

def to_wav(src, dst):
    r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", src, "-ac", "1", "-ar", "44100", "-sample_fmt", "s16", dst], capture_output=True, text=True)
    return r.returncode == 0 and os.path.exists(dst) and os.path.getsize(dst) > 2000

def wav_seconds(p):
    return max(0, os.path.getsize(p) - 44) / (44100 * 2)

def midi_notes(path):
    import pretty_midi
    pm = pretty_midi.PrettyMIDI(path)
    ns = [(n.start, n.end, n.pitch) for i in pm.instruments if not i.is_drum for n in i.notes]
    return sorted(ns)

def extract(archive, dest):
    os.makedirs(dest, exist_ok=True)
    if archive.endswith(".zip"):
        with zipfile.ZipFile(archive) as z: z.extractall(dest)
    else:
        with tarfile.open(archive) as t: t.extractall(dest)

def free_gb(p): return shutil.disk_usage(p).free / 1e9

def stem(p):
    b = os.path.basename(p)
    for e in AUDIO_EXT + MIDI_EXT: 
        if b.lower().endswith(e): return b[: -len(e)]
    return b

# --------------------------------------------------------------------------------------------------- HumTrans
def humtrans():
    from huggingface_hub import HfApi, snapshot_download, hf_hub_download
    repo = "dadinghh2/HumTrans"
    api = HfApi()
    info = api.dataset_info(repo, files_metadata=True)
    files = [(s.rfilename, s.size or 0) for s in info.siblings]
    log(f"HumTrans: {len(files)} files, {sum(s for _, s in files) / 1e9:.1f} GB. First entries:")
    for f, s in files[:30]: log("   ", f, s)
    keys = {}
    gh = os.path.join(RAW, "humtrans_github")
    if not os.path.isdir(gh):
        subprocess.run(["git", "clone", "--depth", "1", "https://github.com/TencentARC-QQ/HumTrans", gh], check=False)
    for k in ("valid", "test"):
        p = os.path.join(gh, f"{k}_keys.txt")
        keys[k] = set(l.strip() for l in open(p)) if os.path.exists(p) else set()
    log("official keys: valid", len(keys["valid"]), "test", len(keys["test"]))

    audio = [f for f, _ in files if f.lower().endswith(AUDIO_EXT)]
    midis = [f for f, _ in files if f.lower().endswith(MIDI_EXT)]
    archives = [(f, s) for f, s in files if f.lower().endswith(ARCH_EXT)]
    local = os.path.join(RAW, "humtrans")
    os.makedirs(local, exist_ok=True)
    budget = a.max_gb * 1e9
    if audio and midis:
        # Individual files: take a sample of stems (all val/test stems first, then a random train sample).
        sa = {stem(f): f for f in audio}; sm = {stem(f): f for f in midis}
        common = sorted(set(sa) & set(sm))
        log(f"individual files: {len(sa)} audio, {len(sm)} midi, {len(common)} paired")
        val = [k for k in common if k in keys["valid"]][: a.max_val]; test = [k for k in common if k in keys["test"]][: a.max_test]
        train = [k for k in common if k not in keys["valid"] and k not in keys["test"]]; rng.shuffle(train); train = train[: a.max_train]
        chosen = val + test + train
        pats = [sa[k] for k in chosen] + [sm[k] for k in chosen]
        snapshot_download(repo_id=repo, repo_type="dataset", local_dir=local, allow_patterns=pats, max_workers=8)
    elif archives:
        log("archives:", archives[:10])
        got = 0
        for f, s in sorted(archives, key=lambda t: t[1]):
            if got + s > budget: log("skipping (budget)", f); continue
            if free_gb(RAW) < s / 1e9 * 2.2 + 3: log("skipping (disk)", f); continue
            p = hf_hub_download(repo_id=repo, repo_type="dataset", filename=f, local_dir=local)
            try: extract(p, os.path.join(local, "x_" + hashlib.md5(f.encode()).hexdigest()[:6]))
            except Exception as e: log("extract failed", f, e)
            os.remove(p); got += s
    else:
        log("HumTrans: no audio/midi/archives found in the repository listing"); return []

    aud = {}; mid = {}
    for root, _, fs in os.walk(local):
        for f in fs:
            p = os.path.join(root, f)
            if f.lower().endswith(AUDIO_EXT): aud[stem(f)] = p
            elif f.lower().endswith(MIDI_EXT): mid[stem(f)] = p
    common = sorted(set(aud) & set(mid))
    log(f"HumTrans on disk: {len(aud)} audio, {len(mid)} midi, {len(common)} paired")
    rows = []
    for k in common:
        split = "val" if k in keys["valid"] else "test" if k in keys["test"] else "train"
        group = "_".join(k.split("_")[:2])
        rows.append((k, aud[k], mid[k], "HUMMING", split, "ht_" + group))
    return rows

# --------------------------------------------------------------------------------------------------- vocadito
def vocadito():
    import mirdata, numpy as np
    home = os.path.join(RAW, "mirdata")
    ds = mirdata.initialize("vocadito", data_home=home)
    ds.download(cleanup=True)
    rows = []
    tracks = ds.load_tracks()
    singers = sorted({str(getattr(t, "singer_id", t.track_id)) for t in tracks.values()})
    rng.shuffle(singers)
    split_of = {s: ("test" if i % 4 == 3 else "val" if i % 4 == 2 else "train") for i, s in enumerate(singers)}
    for tid, t in tracks.items():
        nd = None
        for attr in ("notes_a1", "notes_a2", "notes"):
            nd = getattr(t, attr, None)
            if nd is not None: break
        if nd is None: continue
        iv = np.array(nd.intervals); pitch = np.array(nd.pitches, dtype=float)
        unit = str(getattr(nd, "pitch_unit", "hz")).lower()
        midi = pitch if "midi" in unit else 69 + 12 * np.log2(np.maximum(pitch, 1e-3) / 440.0)
        np_path = os.path.join(NOTES, f"vocadito_{tid}.txt")
        with open(np_path, "w") as f:
            for (s, e), m in zip(iv, midi): f.write(f"{s:.4f},{e:.4f},{m:.3f}\n")
        sg = str(getattr(t, "singer_id", tid))
        rows.append((f"vocadito_{tid}", t.audio_path, np_path, "SINGING", split_of.get(sg, "train"), "vc_" + sg))
    log(f"vocadito: {len(rows)} clips")
    return rows

# --------------------------------------------------------------------------------------------------- manifest
def finish(rows):
    # (id, audio, notes_or_midi, type, split, group) -> convert to wav + notes text.
    out = []; caps = {"train": a.max_train, "val": a.max_val, "test": a.max_test}; n = {"train": 0, "val": 0, "test": 0}
    rng.shuffle(rows); last = 0
    for k, au, nt, ty, sp, gr in rows:
        if n[sp] >= caps[sp]: continue
        try:
            wav = os.path.join(WAV, k + ".wav")
            if not os.path.exists(wav) and not to_wav(au, wav): continue
            if wav_seconds(wav) > a.max_sec or wav_seconds(wav) < 1.0: os.remove(wav); continue
            if nt.lower().endswith(MIDI_EXT):
                ns = midi_notes(nt); np_path = os.path.join(NOTES, k + ".txt")
                if len(ns) < a.min_notes: continue
                with open(np_path, "w") as f:
                    for s, e, p in ns: f.write(f"{s:.4f},{e:.4f},{p}\n")
            else:
                np_path = nt
                if sum(1 for _ in open(np_path)) < a.min_notes: continue
            out.append((k, wav, np_path, ty, sp, gr)); n[sp] += 1
        except Exception as e:
            log("skip", k, e)
        tot = sum(n.values())
        if tot // 200 > last // 200: log("converted", n)
        last = tot
    return out

all_rows = []
for name, fn in (("humtrans", humtrans), ("vocadito", vocadito)):
    if a.only and a.only != name: continue
    try:
        r = fn(); log(f"{name}: {len(r)} candidate clips"); summary.append(f"{name}: {len(r)} candidate clips"); all_rows += r
    except Exception as e:
        import traceback; traceback.print_exc()
        summary.append(f"{name}: FAILED ({type(e).__name__}: {e})")
final = finish(all_rows)
# A group never spans two splits: groups seen in val/test are removed from train.
held = {g for (_, _, _, _, sp, g) in final if sp != "train"}
final = [r for r in final if r[4] != "train" or r[5] not in held]
with open(os.path.join(OUT, "manifest.tsv"), "w") as f:
    for r in final: f.write("\t".join(r) + "\n")
counts = {s: sum(1 for r in final if r[4] == s) for s in ("train", "val", "test")}
types = {t: sum(1 for r in final if r[3] == t) for t in ("HUMMING", "SINGING")}
summary.append(f"manifest: {counts}, by type {types}")
open(os.path.join(OUT, "corpus_summary.txt"), "w").write("\n".join(summary) + "\n")
log("\n".join(summary))
if counts["train"] < 200 or counts["val"] < 30 or counts["test"] < 30:
    log("NOT ENOUGH DATA"); sys.exit(2)
