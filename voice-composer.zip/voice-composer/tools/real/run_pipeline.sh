#!/bin/bash
# Real-data training pipeline (runs in CI, or locally on any manifest; see RealTools.kt for the manifest format).
#   MANIFEST=<manifest.tsv> tools/real/run_pipeline.sh
# Optional env: WORK (default build/real), MAX_TRAIN (clips, default 3000), MAX_VAL (500), MAX_TEST (800),
#   SIM_CSV (simulated note rows to mix in), RT_CP (JVM classpath of the compiled engine + test classes).
# Output: $WORK/out/{note_rf.json,note_merge.json} (only the ones that ship) and $WORK/report.md; exit 0 either way,
#   $WORK/SHIP contains the winner name ("old" when nothing should change).
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
WORK=${WORK:-$ROOT/build/real}; MANIFEST=${MANIFEST:?set MANIFEST}
MAX_TRAIN=${MAX_TRAIN:-3000}; MAX_VAL=${MAX_VAL:-500}; MAX_TEST=${MAX_TEST:-800}
A=$ROOT/app/src/main/assets
# The JVM tools look for the Basic Pitch model upward from the working directory; give the path explicitly
# (the project can sit in a sub-folder, e.g. when it was unpacked from a zip).
export BASIC_PITCH_ONNX=${BASIC_PITCH_ONNX:-$A/nmp.onnx}
[ -f "$BASIC_PITCH_ONNX" ] || { echo "Basic Pitch model not found at $BASIC_PITCH_ONNX"; exit 1; }
python3 -I -c "import onnxruntime, numpy; print('onnxruntime', onnxruntime.__version__)" || { echo "python3 cannot import onnxruntime/numpy"; exit 1; }
CP=${RT_CP:-"$ROOT/engine/build/classes/kotlin/main:$ROOT/engine/build/classes/kotlin/test:$ROOT/core/music-model/build/classes/kotlin/main:$(find ~/.gradle -name 'kotlin-stdlib-2*.jar' | head -1)"}
rt() { java -Xmx3g -cp "$CP" com.voicecomposer.engine.ml.RealTools "$@"; }
mkdir -p "$WORK/out"; rm -f "$WORK/SHIP"
echo "== clips per split"; for s in train val test; do printf "%s: " $s; awk -F'\t' -v s=$s '$5==s' "$MANIFEST" | wc -l; done

echo "== 1/6 rows from real clips (note forest)"
rt gen "$MANIFEST" "$WORK/rows_train.csv" train "$MAX_TRAIN"
rt gen "$MANIFEST" "$WORK/rows_val.csv" val "$MAX_VAL"

echo "== 2/6 train the note forest"
SIM=(); [ -n "${SIM_CSV:-}" ] && [ -f "${SIM_CSV:-}" ] && SIM=(--sim "$SIM_CSV")
set +e
python3 "$ROOT/tools/real/train_real_forest.py" --kind note --real-train "$WORK/rows_train.csv" --real-val "$WORK/rows_val.csv" \
  "${SIM[@]}" --baseline "$A/note_rf.json" --out "$WORK/out/note_rf.json" --report "$WORK/train_note.txt"
rc=$?; set -e
if [ $rc -ne 0 ]; then echo "note forest not trained (code $rc)"; echo old > "$WORK/SHIP"; echo "Not enough usable real rows to train." > "$WORK/report.md"; exit 0; fi

echo "== 3/6 rows for the merger (with the new note forest)"
rt genmerge "$MANIFEST" "$WORK/merge_train.csv" train "$WORK/out/note_rf.json" "$MAX_TRAIN"
rt genmerge "$MANIFEST" "$WORK/merge_val.csv" val "$WORK/out/note_rf.json" "$MAX_VAL"

echo "== 4/6 train the merger"
set +e
python3 "$ROOT/tools/real/train_real_forest.py" --kind merge --real-train "$WORK/merge_train.csv" --real-val "$WORK/merge_val.csv" \
  --baseline "$A/note_merge.json" --out "$WORK/out/note_merge.json" --report "$WORK/train_merge.txt"
rc=$?; set -e
if [ $rc -ne 0 ]; then cp "$A/note_merge.json" "$WORK/out/note_merge.json"; echo "merger kept as shipped (code $rc)"; fi

echo "== 5/6 evaluate the four combinations on val and test"
N="$WORK/out/note_rf.json"; M="$WORK/out/note_merge.json"
COMBOS=(old="$A/note_rf.json":"$A/note_merge.json" nn="$N":"$M" no="$N":"$A/note_merge.json" on="$A/note_rf.json":"$M")
rt eval "$MANIFEST" val "$A" "$MAX_VAL" "${COMBOS[@]}" > "$WORK/eval_val.json"
rt eval "$MANIFEST" test "$A" "$MAX_TEST" "${COMBOS[@]}" > "$WORK/eval_test.json"

echo "== 6/6 decision"
WIN=$(python3 "$ROOT/tools/real/gate.py" "$WORK/eval_val.json" "$WORK/eval_test.json" "$WORK/report.md" "${MIN_GAIN:-0.005}")
echo "$WIN" > "$WORK/SHIP"
case "$WIN" in
  nn) ;;
  no) cp "$A/note_merge.json" "$WORK/out/note_merge.json" ;;
  on) rm -f "$WORK/out/note_rf.json" ;;
  *) rm -f "$WORK/out/note_rf.json" "$WORK/out/note_merge.json" ;;
esac
cat "$WORK/report.md"; echo "winner: $WIN"
