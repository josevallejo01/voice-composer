#!/usr/bin/env python3
"""
Trains a note forest or a note merger on REAL recordings (rows from RealTools gen / genmerge), optionally mixed with the
simulated rows the earlier models were trained on, and exports the same flat-tree JSON the app reads.

  --kind note|merge          which feature block / file format
  --real-train a.csv ...     rows from real clips (train split)
  --real-val b.csv           rows from real clips (val split) - hyper-parameters are chosen here
  --sim c.csv ...            optional simulated rows (kept as a low-weight regulariser: they teach noise robustness)
  --baseline model.json      the currently shipped forest, scored on the same real val rows for comparison

Why mixing: the simulator knows exactly which notes are real, covers noise conditions a corpus does not, and costs nothing;
the real rows say what real voices look like. Weights (real x1/x3/x10 against the simulated rows) are chosen on real val.
"""
import argparse, csv, json, os, sys
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, precision_recall_fscore_support

ap = argparse.ArgumentParser()
ap.add_argument("--kind", choices=["note", "merge"], required=True)
ap.add_argument("--real-train", nargs="+", required=True)
ap.add_argument("--real-val", required=True)
ap.add_argument("--sim", nargs="*", default=[])
ap.add_argument("--baseline", default=None)
ap.add_argument("--out", required=True)
ap.add_argument("--report", default=None)
ap.add_argument("--trees", type=int, default=100)
ap.add_argument("--jitter", type=float, default=0.05)
ap.add_argument("--seed", type=int, default=7)
ap.add_argument("--max-sim", type=int, default=400000)
a = ap.parse_args()
FIRST = "dur" if a.kind == "note" else "gap"

def load(paths):
    X, y, T = [], [], []
    feat = None
    for p in paths:
        with open(p) as f:
            rd = csv.reader(f)
            try: head = next(rd)
            except StopIteration: continue
            n0 = head.index(FIRST); feat = head[n0:]
            for row in rd:
                if len(row) != len(head): continue
                try: v = [float(t) for t in row[n0:]]
                except ValueError: continue
                if not all(np.isfinite(v)): continue
                X.append(v); y.append(int(row[5])); T.append(row[2])
    return np.array(X, dtype=np.float32), np.array(y), np.array(T), feat

Xr, yr, Tr, FEAT = load(a.real_train)
Xv, yv, Tv, F2 = load([a.real_val])
Xs, ys, Ts, F3 = load(a.sim) if a.sim else (np.zeros((0, len(FEAT)), np.float32), np.zeros(0, int), np.zeros(0), FEAT)
if Xs.shape[0] > a.max_sim:
    idx = np.random.default_rng(a.seed).choice(Xs.shape[0], a.max_sim, replace=False); Xs, ys, Ts = Xs[idx], ys[idx], Ts[idx]
print(f"{a.kind}: real train {len(yr)} rows (pos {yr.mean() if len(yr) else 0:.2f}), real val {len(yv)} (pos {yv.mean() if len(yv) else 0:.2f}), sim {len(ys)}")
if len(yr) < 200 or len(yv) < 50 or len(set(yr)) < 2 or len(set(yv)) < 2:
    print("NOT ENOUGH REAL ROWS: keeping the shipped model"); sys.exit(3)

rng = np.random.default_rng(a.seed)
CONT = [i for i, n in enumerate(FEAT) if n not in ("isSing", "isHum", "isWhistle", "stepIdx", "slopeAgree", "dKey")]
sd = np.vstack([Xr, Xs]).std(axis=0) + 1e-9

def jitter(X, y, w, copies):
    if a.jitter <= 0 or copies == 0: return X, y, w
    Xs_, ys_, ws_ = [X], [y], [w]
    for _ in range(copies):
        Z = X.copy(); Z[:, CONT] += rng.normal(0, 1, (len(X), len(CONT))).astype(np.float32) * (sd[CONT] * a.jitter)
        Xs_.append(Z); ys_.append(y); ws_.append(w)
    return np.vstack(Xs_), np.concatenate(ys_), np.concatenate(ws_)

def prf(y, p, th=0.5):
    pr, rc, f1, _ = precision_recall_fscore_support(y, p >= th, average="binary", zero_division=0); return pr, rc, f1

def predict_json(model, X):
    """Scores rows with an exported forest (same traversal as the app)."""
    out = np.zeros(len(X))
    for t in model["trees"]:
        f, th, l, r, v = t["f"], t["t"], t["l"], t["r"], t["v"]
        for i in range(len(X)):
            n = 0
            while f[n] >= 0: n = l[n] if X[i][f[n]] <= th[n] else r[n]
            out[i] += v[n]
    return out / len(model["trees"])

lines = []
def log(s): print(s, flush=True); lines.append(s)

if a.baseline and os.path.exists(a.baseline):
    base = json.load(open(a.baseline))
    if base.get("dim") == len(FEAT):
        pb = predict_json(base, Xv)
        auc_b = roc_auc_score(yv, pb); _, _, f1_b = prf(yv, pb)
        log(f"shipped model on real val: AUC {auc_b:.4f}  F1@0.5 {f1_b:.4f}")
    else:
        auc_b = None; log("shipped model has another feature layout: not comparable")
else:
    auc_b = None

grid = [dict(max_depth=d, min_samples_leaf=l, max_features=f) for d in (10, 16, None) for l in (3, 8, 20) for f in ("sqrt", 0.5)]
best = None
for sim_w in ([0.0, 0.2] if len(ys) else [0.0]):
    for real_w in (1.0, 3.0):
        X = np.vstack([Xr, Xs]) if sim_w > 0 else Xr
        y = np.concatenate([yr, ys]) if sim_w > 0 else yr
        w = np.concatenate([np.full(len(yr), real_w), np.full(len(ys), sim_w)]) if sim_w > 0 else np.full(len(yr), real_w)
        for jc in (0, 1):
            Xj, yj, wj = jitter(X, y, w, jc)
            for g in grid:
                rf = RandomForestClassifier(n_estimators=40, class_weight="balanced_subsample", n_jobs=-1, random_state=a.seed, **g)
                rf.fit(Xj, yj, sample_weight=wj)
                s = roc_auc_score(yv, rf.predict_proba(Xv)[:, 1])
                if best is None or s > best[0]: best = (s, sim_w, real_w, jc, g)
    print(f"  sim_w={sim_w}: best so far {best[0]:.4f}", flush=True)
s, sim_w, real_w, jc, g = best
log(f"chosen: sim weight {sim_w}, real weight {real_w}, jitter copies {jc}, {g}  (real val AUC {s:.4f})")

X = np.vstack([Xr, Xs]) if sim_w > 0 else Xr
y = np.concatenate([yr, ys]) if sim_w > 0 else yr
w = np.concatenate([np.full(len(yr), real_w), np.full(len(ys), sim_w)]) if sim_w > 0 else np.full(len(yr), real_w)
Xj, yj, wj = jitter(X, y, w, jc)
rf = RandomForestClassifier(n_estimators=a.trees, class_weight="balanced_subsample", n_jobs=-1, random_state=a.seed, **g).fit(Xj, yj, sample_weight=wj)
pv = rf.predict_proba(Xv)[:, 1]
auc = roc_auc_score(yv, pv); pr, rc, f1 = prf(yv, pv)
log(f"new model on real val: AUC {auc:.4f}  P {pr:.3f} R {rc:.3f} F1@0.5 {f1:.3f}")
for t in sorted(set(Tv)):
    i = Tv == t
    if i.sum() > 50 and len(set(yv[i])) > 1: log(f"  {t}: AUC {roc_auc_score(yv[i], pv[i]):.4f} (rows {int(i.sum())})")
imp = sorted(zip(rf.feature_importances_, FEAT), reverse=True)
log("importances: " + ", ".join(f"{n} {v:.3f}" for v, n in imp[:10]))

def f32s(v): return float(np.format_float_positional(np.float32(v), unique=True))
trees = []
for est in rf.estimators_:
    t = est.tree_; feat = t.feature.astype(int).tolist()
    trees.append({"f": feat, "t": [f32s(v) if f >= 0 else 0.0 for v, f in zip(t.threshold, feat)],
                  "l": [int(x) for x in t.children_left], "r": [int(x) for x in t.children_right],
                  "v": [round(float(t.value[i][0][1] / t.value[i][0].sum()), 4) if t.value[i][0].sum() > 0 else 0.0 for i in range(t.node_count)]})
os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
json.dump({"dim": len(FEAT), "features": FEAT, "trees": trees}, open(a.out, "w"), separators=(",", ":"))
log(f"wrote {a.out}: {os.path.getsize(a.out)/1024:.0f} KiB, {len(trees)} trees")
if a.report: open(a.report, "w").write("\n".join(lines) + "\n")
