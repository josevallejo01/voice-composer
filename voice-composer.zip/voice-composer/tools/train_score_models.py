#!/usr/bin/env python3
"""
Trains the learned score decisions (scikit-learn random forests) and exports them for the app.

Input : CSVs written by engine/src/test/.../score/ScoreDataGen.kt (one file per model and split). Rows are candidates of
        one decision (grp = the decision they compete in); label 1 = the candidate that agrees with the notation.
Output: app/src/main/assets/score_<model>.json   flat trees read by RandomForest.fromJson
        engine/src/test/resources/score_parity.json   rows + sklearn probabilities for the Kotlin parity test
Models: tempo (tempo + beat phase), bar (meter + bar lines), drift (steady/followed tempo), onset (rhythmic position,
        pairwise), duration (written length), key (24 keys), spell (sharp or flat).

Noise regularisation: (1) the simulated performances carry timing noise, drift, articulation changes and detector errors
(the "hard" split has much sloppier ones, on tunes never seen); (2) feature jitter where the training set is small;
(3) bounded trees (max_leaf_nodes, min_samples_leaf, sqrt features, bootstrap); (4) choice made on val and hard.
"""
import argparse, csv, json, os, sys
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--parity", default=None)
ap.add_argument("--report", default=None)
ap.add_argument("--only", nargs="*", default=None)
ap.add_argument("--seed", type=int, default=5)
a = ap.parse_args()

# name: (trees, max_leaf_nodes, min_samples_leaf, max_samples, label column)
CFG = {
    "tempo":    (80, 700, 5, 0.6, "label"),
    "bar":      (80, 900, 4, 0.6, "label"),
    "drift":    (60, 40, 5, None, "label"),
    "onset":    (50, 700, 8, 0.5, "label"),
    "duration": (60, 600, 6, 0.6, "label"),
    "key":      (80, 500, 4, 0.6, "label"),
    "spell":    (60, 40, 4, None, "label"),
}


def load(name, split):
    path = os.path.join(a.data, f"score_{name}_{split}.csv")
    with open(path) as f:
        rd = csv.reader(f)
        head = next(rd)
        nmeta = head.index("label2") + 1
        rows = [r for r in rd]
    X = np.array([r[nmeta:] for r in rows], dtype=np.float32)
    y = np.array([int(r[head.index("label")]) for r in rows])
    y2 = np.array([int(r[head.index("label2")]) for r in rows])
    g = np.array([int(r[head.index("grp")]) for r in rows])
    return X, y, y2, g, head[nmeta:]


def top1(p, y, g):
    """Share of decisions (groups with a correct candidate) where the best-scored candidate is a correct one."""
    ok = tot = 0
    order = np.argsort(g, kind="stable")
    gs = g[order]; ps = p[order]; ys = y[order]
    bounds = np.flatnonzero(np.diff(gs)) + 1
    for pp, yy in zip(np.split(ps, bounds), np.split(ys, bounds)):
        if yy.sum() == 0: continue
        tot += 1; ok += int(yy[int(np.argmax(pp))] == 1)
    return ok / max(1, tot), tot


def f32s(v):
    return float(np.format_float_positional(np.float32(v), unique=True))


def export(rf, feat, path):
    trees = []
    for est in rf.estimators_:
        t = est.tree_
        f = t.feature.astype(int).tolist()
        thr = [f32s(v) if k >= 0 else 0.0 for v, k in zip(t.threshold, f)]
        val = []
        for i in range(t.node_count):
            v = t.value[i][0]
            val.append(round(float(v[1] / v.sum()), 4) if v.sum() > 0 else 0.0)
        trees.append({"f": f, "t": thr, "l": [int(x) for x in t.children_left], "r": [int(x) for x in t.children_right], "v": val})
    json.dump({"dim": len(feat), "features": feat, "trees": trees}, open(path, "w"), separators=(",", ":"))
    return os.path.getsize(path), sum(len(t["f"]) for t in trees)


rng = np.random.default_rng(a.seed)
lines = []
parity = {}
os.makedirs(a.out, exist_ok=True)
for name, (ntrees, leaves, msl, maxs, lab) in CFG.items():
    if a.only and name not in a.only: continue
    Xtr, ytr, y2tr, gtr, feat = load(name, "train")
    Xva, yva, y2va, gva, _ = load(name, "val")
    Xha, yha, y2ha, gha, _ = load(name, "hard")
    print(f"\n== {name}: train {len(ytr)} (pos {ytr.mean():.3f})  val {len(yva)}  hard {len(yha)}", flush=True)
    binary = [bool(set(np.unique(Xtr[:, i])) <= {0.0, 1.0}) for i in range(Xtr.shape[1])]
    sd = Xtr.std(axis=0) + 1e-9

    def fit(copies, jit=0.05):
        X, y = Xtr, ytr
        if copies:
            Xs = [Xtr]; ys = [ytr]
            for _ in range(copies):
                Z = Xtr.copy()
                for i in range(Z.shape[1]):
                    if not binary[i]: Z[:, i] += rng.normal(0, 1, len(Z)).astype(np.float32) * sd[i] * jit
                Xs.append(Z); ys.append(ytr)
            X, y = np.vstack(Xs), np.concatenate(ys)
        rf = RandomForestClassifier(n_estimators=ntrees, max_leaf_nodes=leaves, min_samples_leaf=msl, max_features="sqrt",
                                    max_samples=maxs, n_jobs=2, random_state=a.seed).fit(X, y)
        return rf

    best = None
    for copies in ((0, 1) if len(ytr) < 200_000 else (0,)):
        rf = fit(copies)
        v, nv = top1(rf.predict_proba(Xva)[:, 1], yva, gva); h, nh = top1(rf.predict_proba(Xha)[:, 1], yha, gha)
        print(f"   jitter copies {copies}: val top-1 {v:.3f} hard top-1 {h:.3f}", flush=True)
        score = 0.5 * v + 0.5 * h
        if best is None or score > best[0]: best = (score, copies, rf)
    _, copies, rf = best
    pv = rf.predict_proba(Xva)[:, 1]; ph = rf.predict_proba(Xha)[:, 1]
    v, nv = top1(pv, yva, gva); h, nh = top1(ph, yha, gha)
    # group baseline: random choice among candidates
    def rand_base(g, y):
        _, counts = np.unique(g, return_counts=True)
        return float(np.mean(1.0 / counts))
    auc_v = roc_auc_score(yva, pv) if len(set(yva)) > 1 else float("nan"); auc_h = roc_auc_score(yha, ph) if len(set(yha)) > 1 else float("nan")
    extra = ""
    if name == "key":
        v2, _ = top1(pv, y2va, gva)   # signature-level: any key with the right signature counts
        # recompute with label2 as the target set
        ok = tot = 0
        for gg in np.unique(gva):
            m = gva == gg
            if y2va[m].sum() == 0: continue
            tot += 1; ok += int(y2va[m][int(np.argmax(pv[m]))] == 1)
        extra = f"  [signature-level val {ok / max(1, tot):.3f}]"
    line = f"{name:9s} val top-1 {v:.3f} (n={nv}) hard top-1 {h:.3f} (n={nh})  AUC val {auc_v:.3f} hard {auc_h:.3f}  chance~{rand_base(gva, yva):.3f}{extra}  jitter copies {copies}"
    print(line); lines.append(line)
    size, nodes = export(rf, feat, os.path.join(a.out, f"score_{name}.json"))
    print(f"   wrote score_{name}.json: {size / 1024:.0f} KiB, {nodes} nodes")
    idx = rng.choice(len(Xva), size=min(150, len(Xva)), replace=False)
    parity[name] = {"x": [[float(v) for v in r] for r in Xva[idx]], "p": [float(v) for v in rf.predict_proba(Xva[idx])[:, 1]]}

if a.parity:
    os.makedirs(os.path.dirname(a.parity), exist_ok=True)
    if os.path.exists(a.parity):
        old = json.load(open(a.parity)); old.update(parity); parity = old
    json.dump(parity, open(a.parity, "w"))
if a.report:
    open(a.report, "w").write("\n".join(lines) + "\n")
