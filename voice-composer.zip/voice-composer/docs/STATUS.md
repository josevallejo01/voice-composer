# Implementation status

Legend: ✅ done and tested on the JVM · 🟡 written but not compiled or run (Android layer) · ❌ not done

## 0.5.0: every score decision made by a learned model

Requested: "everything that can go in a score must be decided by ML", not only the notes. Each decision is now a
random forest (scikit-learn, exported to JSON, read by pure Kotlin; `engine/.../score/`) that ranks candidates built from
features; the hand-written rules stay only as a fallback when a model file is missing or the melody has fewer than 4 notes.

| decision | candidates ranked | model |
|---|---|---|
| tempo and beat phase | BPM (comb peaks and their octave relatives) x phase, 27 features | `score_tempo.json` |
| steady or drifting tempo | residual features against a constant vs a tracked tempo map | `score_drift.json` |
| meter and bar lines (incl. pick-up) | 2/4, 3/4, 4/4, 6/8 x bar offset in half beats, 45 features | `score_bar.json` |
| rhythmic position of every note | five sixteenth slots per note, joint (DP) choice, 34 features | `score_onset.json` |
| written length and rests | 8 standard lengths + legato to the next note | `score_duration.json` |
| key | 24 keys, 36 features (Krumhansl correlation is only one feature) | `score_key.json` |
| sharp or flat spelling | per chromatic note | `score_spell.json` |

Training data: 915 notated folk tunes (Nottingham dataset, ABC) played back by a simulator (tempo, drift, rubato,
timing jitter, articulation, detector errors; normal and sloppier performers), split by tune. Measured on tunes never
used for training (simulated performances):

| | rules (before) | learned |
|---|---|---|
| validation: tempo / meter / key exact | 42% / 47% / 64% | 91% / 87% / 85% |
| validation: start positions (bar-aligned) / written lengths | 17% / 55% | 65% / 94% |
| hard (sloppy) tunes: tempo / meter / key exact | 23% / 48% / 66% | 60% / 64% / 87% |
| hard: start positions (bar-aligned) / lengths | 6% / 40% | 30% / 78% |
| audio end-to-end, 14 sung synthetic tunes: tempo / meter / key | 7 / 7 / 7 of 14 | 12 / 14 / 11 of 14 |

Kotlin and scikit-learn probabilities agree to 1.1e-5 on all seven models (test). Forced tempo, forced signature, free
timing and the short-melody fallback are tested (`ScoreConstraintsTest`).

**What this does not prove.** The "performances" are simulated, not recordings of people; the tunes are folk tunes
(no pop, classical, swing, triplets, 9/8, 12/8), so the figures are an upper bound for other music. The rule baseline is
weak on this distribution, which flatters the comparison. On sloppy performers the results fall a lot (bar-aligned
starts 30%). Written-length accuracy is optimistic (the simulator's articulation is regular). The clef is still chosen
by a rule. Nothing here was run on a phone, and the Android wiring (`ScoreForests`, settings line) is not compiled.
**Licence:** the corpus is from a GPL-3.0 repository; it is used offline for training only and is not shipped, but whether
models trained on it carry obligations is a question to settle before publishing the app (retraining on public-domain
tunes is possible with the same scripts).

## 0.4.0: random-forest note filter (scikit-learn) with noise regularisation

Requested after 0.3.0 still gave wrong notes on device. The hand-written validation rules are replaced, when the
forest is present, by a classifier that decides for every *candidate* note whether it is a real note with the right
pitch.

* Candidates: permissive Viterbi decoding of the Basic Pitch output (little silence bias, short notes allowed) plus notes
  the classical pitch trace sees where the network decoded nothing. Each candidate gets 27 features: network evidence
  (activation, onset, dominance over other keys), independent pitch-trace evidence (support, voiced fraction, confidence,
  octave alternatives, deviation), level (above the recording's floor and the local room, below the loudest part, dynamic
  range), spectrum (zero crossings, flatness, harmonicity, share of the fundamental), context (interval, gaps), input type.
* Training (`tools/train_note_forest.py`, scikit-learn `RandomForestClassifier`, 80 trees): about 19 000 labelled
  candidates from 1 800 synthetic sung / hummed / whistled clips run through the real network, degraded with white,
  pink, fan, 50/60 Hz mains hum, babble, breaths, clicks, keyboard, hiss and street noise at 3-30 dB SNR, very low gain,
  AGC compression, phone-style band limiting, reverb and clipping (`DataGen.kt` makes the data).
* Noise regularisation: (1) the noise-augmented data above; (2) feature jitter (training set replicated with Gaussian
  noise on the continuous features); (3) depth 12, leaves of at least 4 samples, half the features per split, bootstrap,
  balanced classes; (4) hyper-parameters chosen on a validation set *and* on a "hard" set of conditions never seen in
  training (SNR 0-12 dB, street noise, other noise mixes).
* Export: flat JSON (`app/src/main/assets/note_rf.json`, 1.6 MB), read by pure Kotlin code; no native library. Kotlin and
  scikit-learn probabilities agree to 1e-5 on 300 rows (test).
* On the device: the voice setup now also (a) searches the forest threshold, and (b) trains a small forest of the
  singer's own on the confirmed takes (`ForestTrainer`, runs on the phone); corrections later add labelled candidates
  (only for scores the user actually changed or validated). The singer's forest is blended with the shipped one, with a
  weight that grows with the amount of own data (at most 0.6).

Measured (candidate level, F1; rules = the 0.3.0 validation):

| set | rules | forest |
|---|---|---|
| validation (same conditions as training) | 0.955 | 0.979 |
| hard (unseen noise, SNR 0-12 dB) | 0.879 | 0.940 |
| hard, singing / humming / whistling | 0.82 / 0.89 / 0.96 | 0.90 / 0.95 / 0.98 |

Note level on 54 fresh hard clips: rules F1 0.83, forest F1 0.87.

**What this does not prove.** All of it is synthetic data. On two real sung clips with noise added (no ground truth; the
reference is the notes both pipelines find on the clean clip) the forest has higher precision and lower recall than the
rules and about the same F1 (e.g. fan+keys 10 dB: 0.89 vs 0.84 on one clip, 0.81 vs 0.88 on the other; babble 8 dB: both
degrade, recall of the forest 0.36-0.53). I have no labelled real humming or whistling, so I cannot say yet that the
problems seen on the device are fixed. The personal forest and the threshold are the parts that adapt to the real
microphone. Also found while preparing the data: a pitch-shift step used for detuned voices overflowed an `Int` and could
throw (-> silent fallback to the classic engine) or resample with a wrong ratio; fixed. This may have been one cause of the
failures seen on the device, but it is not proven.

## Reported on device (0.2.1 -> 0.3.0): humming too noisy, whistling misses high notes

I could not reproduce either on synthetic signals (hum with breath, clicks, fan, weak fundamental; whistles C5-E7 with
noise: all found, no false notes), so the causes on real signals are not established. What 0.3.0 does instead:

* Voice setup (Settings): silence take + guided notes with user confirmation per kind of sound. `CalibrationTuner` fits
  the decoder thresholds (silence bias, noise-gate margin, periodicity requirement) to the confirmed takes, corrects a
  systematic key offset, and seeds the per-kind profile with labelled examples. On a simulated badly-behaved network
  (activations x0.3) agreement with the confirmed notes goes from 20% to 100%; with hallucinated notes in silence it
  stays at 100%.
* Note validation after the network: notes without periodicity in the independent pitch trace (breath, clicks, rumble),
  quieter than the room's noise floor, or too short are dropped; weakly supported notes are flagged. Octave ghosts are
  repaired when the pitch trace clearly disagrees. Humming and whistling have their own, stricter defaults.
* Whistling: notes the pitch trace is sure about and the network missed are added (flagged for review).
* Profiles (learned corrections) are now separate for singing, humming and whistling.
* On two real sung clips, singing results are unchanged by the new validation.

## Known issues reported on device (0.2.0 -> 0.2.1)

* Review screen after recording had an empty, non-interactive waveform -> real waveform, cursor, tap and drag to seek.
* The live waveform kept only the last 12 s (240 x 50 ms bars) -> it now shows the whole take (bars merge as it grows).
* If the neural model fails to run on a device, the app used to fall back to the classic engine silently -> the result now
  says so, with the cause, and shows the engine version next to the confidence.
* Cleaning (DC, rumble, level) before the network: on degraded copies of two real clips it recovered 30-60% of the
  notes the raw path lost.

## Verified (JVM, 85 tests)

* ✅ Music model, edit operations, undo/redo, JSON round trip, score layout (27 tests)
* ✅ WAV I/O, resampler, pitch tracker (accuracy, octave errors, whistling), segmentation (repeated notes, vibrato,
  rests, detuning), tempo (several tempos, drift 85→115 BPM), meter, key, quantisation modes, cancellation,
  progress, silence handling, synth round trip, arrangement (23 tests)
* ✅ MusicXML (well-formed, ties, lyrics, tempo changes, 3/4, minor, bass clef) and MIDI (tempo changes,
  arrangement tracks) export (5 tests)

* ✅ Neural engine: the real Basic Pitch model is run from the JVM tests (Python onnxruntime helper; tests skip
  themselves when it is unavailable). F1 = 1.0 on two synthetic melodies (vibrato 25 cents, detuned 40 cents) and 0.985
  on a larger synthetic benchmark (sung, hummed, whistled).
* ✅ Rhythm: known-tempo phase search with simulated click latency, joint quantiser (92% vs 81% exact positions on a
  simulated 55 ms performer), exact beat positions on a metronome-paced synthetic melody.
* ✅ Voice profile mechanics (counting of deletions, merges, splits; ghost-note rejection after a few sessions; range
  prior; no effect without data).

**What is not proven.** Everything above is on synthetic voices. On two real sung excerpts (vocadito, no labels) the
neural engine explained 77-79% of the voiced time (an independent YIN trace) with ~90% of its note time backed by YIN;
its default silence bias was tuned from that, which is a sanity check, not an accuracy figure. There is no labelled
real-voice benchmark yet, and the claim that the profile makes detection *better with time* is verified for its
mechanics, not for real users. Collect a small labelled set (your own singing with a known score) and measure
before trusting the numbers.

## Android app (written, not built)

The `:app` module was written in an environment without Android SDK or network access to Maven/Google
repositories, so it could not be compiled. Expect small API mismatches on the first `./gradlew assembleDebug`.

* 🟡 Recording, import, review before analysis
* 🟡 Background analysis with progress and cancel
* 🟡 Score editor: select, draw, drag pitch, split/merge/delete, lyrics, keyboard, undo/redo, uncertain-note navigation
* 🟡 Playback: recording / synthesised melody, listen to a note, seek, cursor on the score
* 🟡 Arrangement screen (style, complexity, per-track toggle and volume, versions)
* 🟡 Exports with the system share sheet (PDF, MusicXML, MIDI)
* 🟡 Settings, privacy actions (delete recordings / all data), English and French strings
* 🟡 Room DAO instrumented tests (`app/src/androidTest`)

## Not done

* ❌ Learning of tuning drift per singer and per-pitch confusions (only range, ghost notes, cutting and calibration are learned)
* ❌ Click bleed handling when recorded without headphones
* ❌ Sampled instruments (the synthesiser is additive/wavetable; FluidSynth or similar is the planned upgrade)
* ❌ Verovio or another engraving engine (own renderer: sixteenth grid, no beams, no triplets, no multiple voices)
* ❌ Lyrics recognition (lyrics are typed by hand)
* ❌ Polyphonic input
* ❌ Library search, tags, folders; onboarding and tutorial
* ❌ Foreground service for recording with the screen off (recording is paused when the app goes to background)
* ❌ Audio export (WAV/MP3) of the arrangement
* ❌ Loop range selection in the UI (the player supports it)
* ❌ UI for tempo changes inside a piece (the model and exporters support them; the UI edits one tempo)
* ❌ Adding empty measures by hand (the score grows when notes are added after the last one)
* ❌ Freemium: no billing, no limits, no account
* ❌ Accessibility audit (TalkBack labels exist on icon buttons; contrast and large-text layouts not checked)
* ❌ Release signing, Play Store listing, privacy policy page
