# Implementation status

Legend: ✅ done and tested on the JVM · 🟡 written but not compiled or run (Android layer) · ❌ not done

## Verified (JVM, 55 tests)

* ✅ Music model, edit operations, undo/redo, JSON round trip, score layout (27 tests)
* ✅ WAV I/O, resampler, pitch tracker (accuracy, octave errors, whistling), segmentation (repeated notes, vibrato,
  rests, detuning), tempo (several tempos, drift 85→115 BPM), meter, key, quantisation modes, cancellation,
  progress, silence handling, synth round trip, arrangement (23 tests)
* ✅ MusicXML (well-formed, ties, lyrics, tempo changes, 3/4, minor, bass clef) and MIDI (tempo changes,
  arrangement tracks) export (5 tests)

The engine was tested on **synthetic** voices only. Accuracy on real recordings (breathy humming, noisy rooms,
very unstable singers) has not been measured: collect a small labelled set and run it before trusting the numbers.

## Android app (written, not built)

The `:app` module was written in an environment without Android SDK or network access to Maven/Google
repositories, so it could not be compiled. Expect small API mismatches on the first `./gradlew assembleDebug`.

* 🟡 Recording, import, review before analysis
* 🟡 Background analysis with progress and cancel
* 🟡 Score editor: select, draw, drag pitch, split/merge/delete, lyrics, keyboard, undo/redo, uncertain-note navigation
* 🟡 Playback: recording / synthesised melody, listen to a note, seek, cursor on the score
* 🟡 Arrangement screen (style, complexity, per-track toggle and volume, versions)
* 🟡 Exports with the system share sheet (PDF, MusicXML, MIDI)
* 🟡 Settings, privacy actions (delete recordings / all data), English and French strings
* 🟡 Room DAO instrumented tests (`app/src/androidTest`)

## Not done

* ❌ Sampled instruments (the synthesiser is additive/wavetable; FluidSynth or similar is the planned upgrade)
* ❌ Verovio or another engraving engine (own renderer: sixteenth grid, no beams, no triplets, no multiple voices)
* ❌ Lyrics recognition (lyrics are typed by hand)
* ❌ Polyphonic input
* ❌ Library search, tags, folders; onboarding and tutorial
* ❌ Foreground service for recording with the screen off (recording is paused when the app goes to background)
* ❌ Audio export (WAV/MP3) of the arrangement
* ❌ Loop range selection in the UI (the player supports it)
* ❌ UI for tempo changes inside a piece (the model and exporters support them; the UI edits one tempo)
* ❌ Adding empty measures by hand (the score grows when notes are added after the last one)
* ❌ Freemium: no billing, no limits, no account
* ❌ Accessibility audit (TalkBack labels exist on icon buttons; contrast and large-text layouts not checked)
* ❌ Release signing, Play Store listing, privacy policy page
