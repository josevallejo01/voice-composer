# Implementation status

Legend: ✅ done and tested on the JVM · 🟡 written but not compiled or run (Android layer) · ❌ not done

## 0.6.1: humming and singing recognised badly -> retraining on real recordings (pipeline, not yet run)

Reported: "humming and singing are very bad; train the model on large databases from the Internet".

Diagnosis: every learned model so far (note forest, note merger, the seven score models) was trained on clips made by
`SyntheticVoice`, i.e. on my own simulation of a voice. A model that does well on the simulation can still miss what real
voices do (breath, glides, unstable pitch, room, phone microphone). That sim-to-real gap is the most likely cause, and
the only fix is real data. The Basic Pitch network itself (the acoustic front end) is already trained on large real
corpora and is not touched.

What is new (all under `tools/real/`, run by the workflow `.github/workflows/train-models.yml`):
* `prepare_real.py` downloads **HumTrans** (about 56 h of hummed melodies with MIDI, Hugging Face `dadinghh2/HumTrans`,
  official train/valid/test split) and **vocadito** (40 sung clips with note annotations, via mirdata), converts them to
  16-bit WAV and note lists, splits **by singer/recording group** (no leakage) and writes a manifest.
* `RealTools.kt` (engine test classes) runs each real clip through Basic Pitch and the engine, labels every candidate
  note against the reference notes (same pitch up to an octave shift, at least half overlapping) and writes feature rows
  with exactly the columns the app uses; `eval` measures the **whole detector** (onset F1 at 50 and 100 ms, exact pitch,
  octave-tolerant per clip, plus a strict no-shift score), split by humming / singing / whistling.
* `train_real_forest.py` retrains the note classifier and the note merger on real rows (optionally mixed with simulated
  ones, with noise jitter), picking hyper-parameters on real validation clips.
* `gate.py` evaluates old and new models on real **validation and test** clips: new models ship only if validation F1
  gains at least 0.005 and test is not worse by more than 0.002; otherwise the current models stay. The report
  (`report.md`, shown in the run summary) gives precision, recall and F1 for each combination.
* If the new models win, the workflow commits them to `trained-models/`; the normal APK build copies them into the app
  only when their feature layout matches the shipped one.

**What I could not verify:** this sandbox cannot reach Hugging Face or Zenodo, so the download, the real layout of the
HumTrans repository and the MIDI parsing have never run on real data (they are written defensively and report what they
found in `corpus_summary.txt`). The rest (row generation, training, evaluation, gate) was run end to end on a small fake
corpus. I do not know yet how much real data will improve things; the first run's report will say. Humming transcription is
a hard problem even for published systems (HumTrans papers report onset F1 well below 0.9), so expect a measured gain,
not perfection. The seven score models (tempo, bars, durations...) still learn from simulation.

## 0.6.0: real instruments instead of "MIDI" sounds (SoundFont orchestra, reverb, mastering)

Reported: playback sounds far too MIDI; it should have the quality of an orchestra and of real instruments.

The additive synthesizer (a few sine harmonics and an ADSR) could never get there, so playback is now rendered by a
sample-based engine written for this project (`engine/.../sound/`, pure Kotlin, tested on the JVM):

* **SoundFont 2 sampler** (`SoundFont.kt`, `SfSynth.kt`): reads the sample banks of real instruments (zones, key and
  velocity layers, loops) and plays them with the bank's own envelopes, filter, LFOs and modulators, 4-point cubic
  interpolation, resonant low-pass, stereo samples. Offline rendering: no polyphony limit.
* **Performance** (`Performer.kt`): a score says what to play, a musician decides how. Velocity follows metre and phrase
  shape, long notes swell and taper, strings/winds/voices add vibrato after a delay, string and brass notes get a small
  scoop, repeated notes are separated and legato notes joined, guitar/piano chords are rolled, the piano pedal lets notes
  ring, small deterministic humanisation. Same track -> same performance.
* **Instrument table** (`Patches.kt`): 19 instruments (violin, viola, cello, double bass, harp, flute, oboe, clarinet,
  horn, trumpet, choir, piano, two guitars, two basses, strings section of two stacked presets, pad, lead), each with its
  presets, vibrato, stage position, reverb send. Loudness of every instrument is **measured and matched automatically**
  (so a different bank does not unbalance the mix).
* **Mixing desk** (`Effects.kt`, `SoundEngine.kt`): per-track stems (cached: moving a fader re-mixes without replaying),
  8-line feedback-delay-network hall reverb with early reflections, ensemble/chorus for string and choir sections, master
  bus (rumble filter, gentle tone shaping, glue compressor, loudness matching to -19 dB RMS, look-ahead limiter at -1 dBFS).
* **Arrangements** now orchestrate: new style *Orchestral* (strings, double basses, cellos, harp, horns by complexity);
  Pop = piano + bass (+ strings at level 3), Folk = guitar + upright bass (+ cello), Classical = strings, piano figure,
  cello bass. The melody is played by a chosen solo instrument (violin by default; chooser in the player and in
  Arrange) instead of a square wave.
* **App**: stereo `PlaybackController`; `SoundBankStore` (bundled bank copied once and memory-mapped, or the user's own
  `.sf2`), `Orchestra` (renders with the bank, falls back to the old synthesizer if there is none), Settings section.

The bank (GeneralUser GS 2.0.3, 32 MB) is too large to upload from a phone: the GitHub Actions build fetches it from
the author's repository at a pinned commit and checks its SHA-256 (the build still succeeds without it; the app then
says so in Settings and uses the old synthesizer).

Verified on the JVM (76 engine tests pass, including the new `SfSynthTest`, `EffectsTest`, `PerformerTest`, `OrchestraTest`; the sound tests that need the bank skip themselves when it is absent):
* pitch of 78 rendered notes (13 presets x 6 keys) measured with the YIN tracker: all within 13 cents (one apparent
  octave error is the tracker's, not the sampler's);
* no NaN and no click at the loops of long sustained notes (largest jump / RMS under 2 for every preset tested);
* reverb RT60 measured against requested (1.2 / 2.0 / 3.5 s requested -> 1.21 / 1.96 / 3.41 s measured), stable on 20 s of noise;
* mastering peaks never exceed -1 dBFS whatever the input level (0.02 to 1.8 amplitude);
* every instrument renders a melody without NaN; the melody played by cello, viola, oboe, clarinet, flute, trumpet and horn
  is transcribed back by the engine with 30/30 pitches and onsets recovered; violin 27/30 (vibrato and scoops make the
  transcriber cut some notes: 48 notes for 30), nylon guitar 28/30, harp 26/30, choir 24/30, piano 23/30, steel guitar 22/30
  (decaying or soft attacks, so fewer onsets are found: this measures how readable the sound is for the transcriber, not its
  beauty);
* speed: 22 s of a six-instrument arrangement in about one second on this machine; a volume change re-mixes from cached
  stems in about 0.16 s.
* spectrogram of the new render vs the old: broadband harmonic and noise content up to the top of the band, visible
  vibrato and a reverb tail, against a hard cut-off near 7 kHz with pure partials.

**What I could not do:** listen. I cannot judge timbre, taste or balance by ear; the checks above prove pitch, level,
absence of artefacts and speed, not beauty. Demo MP3s were produced from the same code for you to judge. The Android
layer (stereo player, bank store, screens) is written but not compiled here. GeneralUser GS is a very good
General-MIDI bank, not a top-tier orchestral library: strings, winds and piano are clearly better than any synthesis but
below commercial libraries. Its author states he cannot be 100 % sure of the origin of every sample (see NOTICE); for a
commercial release, swap in a bank with a clear licence (the engine reads any SF2; SF3/compressed banks are not
supported) or replace it with VSCO-2 CE (CC0) converted to SF2. Phones render a 90 s piece in an estimated 10-30 s
(not measured on a device); a progress bar is shown.

## 0.5.2: notes cut into short pieces (voice wander) -> learned note merger

Reported: far too many very short notes (almost only eighths and sixteenths, no quarters or halves); a human voice may wander
a little without that becoming a change of note.

Reproduced on synthetic voices that wander (slow pitch drift, scoops, loudness flutter): a 10-note melody of quarters and
halves came out as 15-26 notes, and the extra notes also pulled the tempo off (111 BPM instead of 80), which made the
written values shorter still. Cause: the decoder reads every wander across a semitone boundary as a new note, and nothing
joined the pieces back (the note classifier's training data had no wander and short notes only).

Fix: a seventh learned decision at the note level, `NoteMerger` (random forest, scikit-learn, `note_merge.json`, 1.2 MB):
for each pair of neighbouring notes it asks "one note cut in two, or two notes?" from 28 features of the joint (loudness dip,
pitch step and slopes in the pitch trace, voicing through the gap, lengths against the recording's median, onset and
activation of the network, ...) and joins the pieces. Trained on 1400 simulated clips (3 input types, noise, channel
effects, wander, long notes), checked on val and on unseen conditions:

| joint level | AUC | precision | recall |
|---|---|---|---|
| val | 0.994 | 0.95 | 0.99 |
| hard (unseen noise, stronger wander) | 0.989 | 0.95 | 0.97 |

End to end on wobbling synthetic melodies (`WobbleTest`): notes per take before/after merging 15-26 -> 10 (truth 10) in
every wander condition, tempo 80 read as 80, written values back to quarters and halves; quarters/halves sung at 50, 60,
72, 90, 110 BPM are read at the right tempo (no doubling). Kotlin and scikit-learn agree to 1e-5.

**Not proven on real voices.** These clips come from the same simulator family as the training data. On the two real singing
clips I have, the merger joins 22 -> 15 and 30 -> 19 notes (median note 0.24 -> 0.31 s); I could not check those decisions
against a human annotation (the clips have none here). Merging two notes that really were sung on the same pitch without a
dip in loudness is the risk; splitting a note by hand stays one tap. Next step if it proves too eager: learn from the
singer's own splits and merges, as the note classifier already learns from corrections.

## 0.5.1: playback, follow-the-score and quick note correction (reported on device)

Reported after trying 0.5.0: the score did not follow the sound, the bottom menu hid the passage being played, the waveform
did not match the sound, the play button was unreliable (switching Recording/Melody was needed), no pauses in the score,
and correcting a note should be very simple by touch or by voice. All changes below are in the Android layer: **written
without a device or an SDK, not compiled, not run**.

* Follow the score: the scroll target ignored where the score starts inside the scrolling column (the cards above it were
  not counted), so the view scrolled to the wrong place and the bottom bar covered the passage. The offset is now measured,
  the playing system goes to the top of the visible area (the next one is already in view below it), the player is pinned
  above the scrolling score, and the scroll area ends exactly at the edit bar.
* Waveform: it always showed the original recording even in Melody mode (another length). It is now computed from the
  buffer that is playing, so cursor, waveform and sound agree; it is shown in both modes.
* Play button: the player used one static `AudioTrack` (stuck after reaching the end, large buffers can fail, head position
  cannot always be set). Replaced by a streaming track started at an exact sample on every play / resume / seek, fed by a
  background coroutine; pausing drops the track and remembers the sample. Position = samples really played.
* Correcting a note: tapping a note opens a panel with large buttons: semitone down / up with the note name, **sing the
  note** (the microphone listens, `SungNoteReader` takes the pitch the voice held longest; tested on synthetic voices with
  glide and vibrato), listen, done. Tapping a line or space of the staff moves the selected note there. Octave, length, split,
  merge, lyric, validate, delete are one row below.
* Pauses: a synthetic hummed tune with 1-beat pauses gives rests in the score with both pipelines (test `RestsTest`), so I
  could not reproduce "no pauses" on clean input. If it happens on a real recording, the likely cause is the note detector
  bridging a short pause (breath, room noise), not the score layout; a recording sample would settle it. (If "pause" meant the
  recorder's pause button: paused time is cut out of the recording on purpose, so it leaves no silence.)
* Also seen: on the same test tune the learned meter model put the first note on beat 3 (a two-beat leading rest); the
  training tunes often start with a pick-up. Not changed yet.

## 0.5.0: every score decision made by a learned model

Requested: "everything that can go in a score must be decided by ML", not only the notes. Each decision is now a
random forest (scikit-learn, exported to JSON, read by pure Kotlin; `engine/.../score/`) that ranks candidates built from
features; the hand-written rules stay only as a fallback when a model file is missing or the melody has fewer than 4 notes.

| decision | candidates ranked | model |
|---|---|---|
| tempo and beat phase | BPM (comb peaks and their octave relatives) x phase, 27 features | `score_tempo.json` |
| steady or drifting tempo | residual features against a constant vs a tracked tempo map | `score_drift.json` |
| meter and bar lines (incl. pick-up) | 2/4, 3/4, 4/4, 6/8 x bar offset in half beats, 45 features | `score_bar.json` |
| rhythmic position of every note | five sixteenth slots per note, joint (DP) choice, 34 features | `score_onset.json` |
| written length and rests | 8 standard lengths + legato to the next note | `score_duration.json` |
| key | 24 keys, 36 features (Krumhansl correlation is only one feature) | `score_key.json` |
| sharp or flat spelling | per chromatic note | `score_spell.json` |

Training data: 915 notated folk tunes (Nottingham dataset, ABC) played back by a simulator (tempo, drift, rubato,
timing jitter, articulation, detector errors; normal and sloppier performers), split by tune. Measured on tunes never
used for training (simulated performances):

| | rules (before) | learned |
|---|---|---|
| validation: tempo / meter / key exact | 42% / 47% / 64% | 91% / 87% / 85% |
| validation: start positions (bar-aligned) / written lengths | 17% / 55% | 65% / 94% |
| hard (sloppy) tunes: tempo / meter / key exact | 23% / 48% / 66% | 60% / 64% / 87% |
| hard: start positions (bar-aligned) / lengths | 6% / 40% | 30% / 78% |
| audio end-to-end, 14 sung synthetic tunes: tempo / meter / key | 7 / 7 / 7 of 14 | 12 / 14 / 11 of 14 |

Kotlin and scikit-learn probabilities agree to 1.1e-5 on all seven models (test). Forced tempo, forced signature, free
timing and the short-melody fallback are tested (`ScoreConstraintsTest`).

**What this does not prove.** The "performances" are simulated, not recordings of people; the tunes are folk tunes
(no pop, classical, swing, triplets, 9/8, 12/8), so the figures are an upper bound for other music. The rule baseline is
weak on this distribution, which flatters the comparison. On sloppy performers the results fall a lot (bar-aligned
starts 30%). Written-length accuracy is optimistic (the simulator's articulation is regular). The clef is still chosen
by a rule. Nothing here was run on a phone, and the Android wiring (`ScoreForests`, settings line) is not compiled.
**Licence:** the corpus is from a GPL-3.0 repository; it is used offline for training only and is not shipped, but whether
models trained on it carry obligations is a question to settle before publishing the app (retraining on public-domain
tunes is possible with the same scripts).

## 0.4.0: random-forest note filter (scikit-learn) with noise regularisation

Requested after 0.3.0 still gave wrong notes on device. The hand-written validation rules are replaced, when the
forest is present, by a classifier that decides for every *candidate* note whether it is a real note with the right
pitch.

* Candidates: permissive Viterbi decoding of the Basic Pitch output (little silence bias, short notes allowed) plus notes
  the classical pitch trace sees where the network decoded nothing. Each candidate gets 27 features: network evidence
  (activation, onset, dominance over other keys), independent pitch-trace evidence (support, voiced fraction, confidence,
  octave alternatives, deviation), level (above the recording's floor and the local room, below the loudest part, dynamic
  range), spectrum (zero crossings, flatness, harmonicity, share of the fundamental), context (interval, gaps), input type.
* Training (`tools/train_note_forest.py`, scikit-learn `RandomForestClassifier`, 80 trees): about 19 000 labelled
  candidates from 1 800 synthetic sung / hummed / whistled clips run through the real network, degraded with white,
  pink, fan, 50/60 Hz mains hum, babble, breaths, clicks, keyboard, hiss and street noise at 3-30 dB SNR, very low gain,
  AGC compression, phone-style band limiting, reverb and clipping (`DataGen.kt` makes the data).
* Noise regularisation: (1) the noise-augmented data above; (2) feature jitter (training set replicated with Gaussian
  noise on the continuous features); (3) depth 12, leaves of at least 4 samples, half the features per split, bootstrap,
  balanced classes; (4) hyper-parameters chosen on a validation set *and* on a "hard" set of conditions never seen in
  training (SNR 0-12 dB, street noise, other noise mixes).
* Export: flat JSON (`app/src/main/assets/note_rf.json`, 1.6 MB), read by pure Kotlin code; no native library. Kotlin and
  scikit-learn probabilities agree to 1e-5 on 300 rows (test).
* On the device: the voice setup now also (a) searches the forest threshold, and (b) trains a small forest of the
  singer's own on the confirmed takes (`ForestTrainer`, runs on the phone); corrections later add labelled candidates
  (only for scores the user actually changed or validated). The singer's forest is blended with the shipped one, with a
  weight that grows with the amount of own data (at most 0.6).

Measured (candidate level, F1; rules = the 0.3.0 validation):

| set | rules | forest |
|---|---|---|
| validation (same conditions as training) | 0.955 | 0.979 |
| hard (unseen noise, SNR 0-12 dB) | 0.879 | 0.940 |
| hard, singing / humming / whistling | 0.82 / 0.89 / 0.96 | 0.90 / 0.95 / 0.98 |

Note level on 54 fresh hard clips: rules F1 0.83, forest F1 0.87.

**What this does not prove.** All of it is synthetic data. On two real sung clips with noise added (no ground truth; the
reference is the notes both pipelines find on the clean clip) the forest has higher precision and lower recall than the
rules and about the same F1 (e.g. fan+keys 10 dB: 0.89 vs 0.84 on one clip, 0.81 vs 0.88 on the other; babble 8 dB: both
degrade, recall of the forest 0.36-0.53). I have no labelled real humming or whistling, so I cannot say yet that the
problems seen on the device are fixed. The personal forest and the threshold are the parts that adapt to the real
microphone. Also found while preparing the data: a pitch-shift step used for detuned voices overflowed an `Int` and could
throw (-> silent fallback to the classic engine) or resample with a wrong ratio; fixed. This may have been one cause of the
failures seen on the device, but it is not proven.

## Reported on device (0.2.1 -> 0.3.0): humming too noisy, whistling misses high notes

I could not reproduce either on synthetic signals (hum with breath, clicks, fan, weak fundamental; whistles C5-E7 with
noise: all found, no false notes), so the causes on real signals are not established. What 0.3.0 does instead:

* Voice setup (Settings): silence take + guided notes with user confirmation per kind of sound. `CalibrationTuner` fits
  the decoder thresholds (silence bias, noise-gate margin, periodicity requirement) to the confirmed takes, corrects a
  systematic key offset, and seeds the per-kind profile with labelled examples. On a simulated badly-behaved network
  (activations x0.3) agreement with the confirmed notes goes from 20% to 100%; with hallucinated notes in silence it
  stays at 100%.
* Note validation after the network: notes without periodicity in the independent pitch trace (breath, clicks, rumble),
  quieter than the room's noise floor, or too short are dropped; weakly supported notes are flagged. Octave ghosts are
  repaired when the pitch trace clearly disagrees. Humming and whistling have their own, stricter defaults.
* Whistling: notes the pitch trace is sure about and the network missed are added (flagged for review).
* Profiles (learned corrections) are now separate for singing, humming and whistling.
* On two real sung clips, singing results are unchanged by the new validation.

## Known issues reported on device (0.2.0 -> 0.2.1)

* Review screen after recording had an empty, non-interactive waveform -> real waveform, cursor, tap and drag to seek.
* The live waveform kept only the last 12 s (240 x 50 ms bars) -> it now shows the whole take (bars merge as it grows).
* If the neural model fails to run on a device, the app used to fall back to the classic engine silently -> the result now
  says so, with the cause, and shows the engine version next to the confidence.
* Cleaning (DC, rumble, level) before the network: on degraded copies of two real clips it recovered 30-60% of the
  notes the raw path lost.

## Verified (JVM, 91 tests)

* ✅ Music model, edit operations, undo/redo, JSON round trip, score layout (27 tests)
* ✅ WAV I/O, resampler, pitch tracker (accuracy, octave errors, whistling), segmentation (repeated notes, vibrato,
  rests, detuning), tempo (several tempos, drift 85→115 BPM), meter, key, quantisation modes, cancellation,
  progress, silence handling, synth round trip, arrangement (23 tests)
* ✅ MusicXML (well-formed, ties, lyrics, tempo changes, 3/4, minor, bass clef) and MIDI (tempo changes,
  arrangement tracks) export (5 tests)

* ✅ Neural engine: the real Basic Pitch model is run from the JVM tests (Python onnxruntime helper; tests skip
  themselves when it is unavailable). F1 = 1.0 on two synthetic melodies (vibrato 25 cents, detuned 40 cents) and 0.985
  on a larger synthetic benchmark (sung, hummed, whistled).
* ✅ Rhythm: known-tempo phase search with simulated click latency, joint quantiser (92% vs 81% exact positions on a
  simulated 55 ms performer), exact beat positions on a metronome-paced synthetic melody.
* ✅ Voice profile mechanics (counting of deletions, merges, splits; ghost-note rejection after a few sessions; range
  prior; no effect without data).

**What is not proven.** Everything above is on synthetic voices. On two real sung excerpts (vocadito, no labels) the
neural engine explained 77-79% of the voiced time (an independent YIN trace) with ~90% of its note time backed by YIN;
its default silence bias was tuned from that, which is a sanity check, not an accuracy figure. There is no labelled
real-voice benchmark yet, and the claim that the profile makes detection *better with time* is verified for its
mechanics, not for real users. Collect a small labelled set (your own singing with a known score) and measure
before trusting the numbers.

## Android app (written, not built)

The `:app` module was written in an environment without Android SDK or network access to Maven/Google
repositories, so it could not be compiled. Expect small API mismatches on the first `./gradlew assembleDebug`.

* 🟡 Recording, import, review before analysis
* 🟡 Background analysis with progress and cancel
* 🟡 Score editor: select, draw, drag pitch, split/merge/delete, lyrics, keyboard, undo/redo, uncertain-note navigation
* 🟡 Playback: recording / synthesised melody, listen to a note, seek, cursor on the score
* 🟡 Arrangement screen (style, complexity, per-track toggle and volume, versions)
* 🟡 Exports with the system share sheet (PDF, MusicXML, MIDI)
* 🟡 Settings, privacy actions (delete recordings / all data), English and French strings
* 🟡 Room DAO instrumented tests (`app/src/androidTest`)

## Not done

* ❌ Learning of tuning drift per singer and per-pitch confusions (only range, ghost notes, cutting and calibration are learned)
* ❌ Click bleed handling when recorded without headphones
* ❌ Sampled instruments (the synthesiser is additive/wavetable; FluidSynth or similar is the planned upgrade)
* ❌ Verovio or another engraving engine (own renderer: sixteenth grid, no beams, no triplets, no multiple voices)
* ❌ Lyrics recognition (lyrics are typed by hand)
* ❌ Polyphonic input
* ❌ Library search, tags, folders; onboarding and tutorial
* ❌ Foreground service for recording with the screen off (recording is paused when the app goes to background)
* ❌ Audio export (WAV/MP3) of the arrangement
* ❌ Loop range selection in the UI (the player supports it)
* ❌ UI for tempo changes inside a piece (the model and exporters support them; the UI edits one tempo)
* ❌ Adding empty measures by hand (the score grows when notes are added after the last one)
* ❌ Freemium: no billing, no limits, no account
* ❌ Accessibility audit (TalkBack labels exist on icon buttons; contrast and large-text layouts not checked)
* ❌ Release signing, Play Store listing, privacy policy page
