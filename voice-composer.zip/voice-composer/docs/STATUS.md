# Implementation status

Legend: ✅ done and tested on the JVM · 🟡 written but not compiled or run (Android layer) · ❌ not done

## Known issues reported on device (0.2.0 -> 0.2.1)

* Review screen after recording had an empty, non-interactive waveform -> real waveform, cursor, tap and drag to seek.
* The live waveform kept only the last 12 s (240 x 50 ms bars) -> it now shows the whole take (bars merge as it grows).
* If the neural model fails to run on a device, the app used to fall back to the classic engine silently -> the result now
  says so, with the cause, and shows the engine version next to the confidence.
* Cleaning (DC, rumble, level) before the network: on degraded copies of two real clips it recovered 30-60% of the
  notes the raw path lost.

## Verified (JVM, 70 tests)

* ✅ Music model, edit operations, undo/redo, JSON round trip, score layout (27 tests)
* ✅ WAV I/O, resampler, pitch tracker (accuracy, octave errors, whistling), segmentation (repeated notes, vibrato,
  rests, detuning), tempo (several tempos, drift 85→115 BPM), meter, key, quantisation modes, cancellation,
  progress, silence handling, synth round trip, arrangement (23 tests)
* ✅ MusicXML (well-formed, ties, lyrics, tempo changes, 3/4, minor, bass clef) and MIDI (tempo changes,
  arrangement tracks) export (5 tests)

* ✅ Neural engine: the real Basic Pitch model is run from the JVM tests (Python onnxruntime helper; tests skip
  themselves when it is unavailable). F1 = 1.0 on two synthetic melodies (vibrato 25 cents, detuned 40 cents) and 0.985
  on a larger synthetic benchmark (sung, hummed, whistled).
* ✅ Rhythm: known-tempo phase search with simulated click latency, joint quantiser (92% vs 81% exact positions on a
  simulated 55 ms performer), exact beat positions on a metronome-paced synthetic melody.
* ✅ Voice profile mechanics (counting of deletions, merges, splits; ghost-note rejection after a few sessions; range
  prior; no effect without data).

**What is not proven.** Everything above is on synthetic voices. On two real sung excerpts (vocadito, no labels) the
neural engine explained 77-79% of the voiced time (an independent YIN trace) with ~90% of its note time backed by YIN;
its default silence bias was tuned from that, which is a sanity check, not an accuracy figure. There is no labelled
real-voice benchmark yet, and the claim that the profile makes detection *better with time* is verified for its
mechanics, not for real users. Collect a small labelled set (your own singing with a known score) and measure
before trusting the numbers.

## Android app (written, not built)

The `:app` module was written in an environment without Android SDK or network access to Maven/Google
repositories, so it could not be compiled. Expect small API mismatches on the first `./gradlew assembleDebug`.

* 🟡 Recording, import, review before analysis
* 🟡 Background analysis with progress and cancel
* 🟡 Score editor: select, draw, drag pitch, split/merge/delete, lyrics, keyboard, undo/redo, uncertain-note navigation
* 🟡 Playback: recording / synthesised melody, listen to a note, seek, cursor on the score
* 🟡 Arrangement screen (style, complexity, per-track toggle and volume, versions)
* 🟡 Exports with the system share sheet (PDF, MusicXML, MIDI)
* 🟡 Settings, privacy actions (delete recordings / all data), English and French strings
* 🟡 Room DAO instrumented tests (`app/src/androidTest`)

## Not done

* ❌ Learning of tuning drift per singer and per-pitch confusions (only range, ghost notes, cutting and calibration are learned)
* ❌ Click bleed handling when recorded without headphones
* ❌ Sampled instruments (the synthesiser is additive/wavetable; FluidSynth or similar is the planned upgrade)
* ❌ Verovio or another engraving engine (own renderer: sixteenth grid, no beams, no triplets, no multiple voices)
* ❌ Lyrics recognition (lyrics are typed by hand)
* ❌ Polyphonic input
* ❌ Library search, tags, folders; onboarding and tutorial
* ❌ Foreground service for recording with the screen off (recording is paused when the app goes to background)
* ❌ Audio export (WAV/MP3) of the arrangement
* ❌ Loop range selection in the UI (the player supports it)
* ❌ UI for tempo changes inside a piece (the model and exporters support them; the UI edits one tempo)
* ❌ Adding empty measures by hand (the score grows when notes are added after the last one)
* ❌ Freemium: no billing, no limits, no account
* ❌ Accessibility audit (TalkBack labels exist on icon buttons; contrast and large-text layouts not checked)
* ❌ Release signing, Play Store listing, privacy policy page
