# Architecture

## Modules and dependencies

```
:app ──► :data:export ──► :core:music-model
  │                              ▲
  └────► :engine ────────────────┘
```

`:core:music-model`, `:engine` and `:data:export` are plain Kotlin/JVM modules. Everything that needs Android
(microphone, codecs, `AudioTrack`, Room, Compose, `PdfDocument`) lives in `:app`.

The specification asks for separate engine sub-modules. They are packages of one `:engine` module for now
(`io`, `preprocessing`, `pitch`, `segmentation`, `rhythm`, `synth`, `arrangement`). Each is already behind an interface
(`TranscriptionEngine`, `PitchTracker`, `ArrangementEngine`), so splitting them later is a mechanical change.

## Analysis pipeline (`DefaultTranscriptionEngine`, version `dsp-1.0`)

1. Resample to 16 kHz (windowed sinc).
2. Pre-process: DC removal, high-pass, normalisation, quality flags (too quiet, clipped, too short).
3. YIN pitch tracker (cumulative mean normalised difference, parabolic interpolation, search range per input type:
   singing, humming, whistling, vocalise), then octave-error correction.
4. Note segmentation: pitch split against a running median, energy-dip re-attack, gap detection, vibrato tolerance,
   tuning compensation (a consistently flat/sharp singer is read relative to their own reference).
5. Tempo: comb alignment with priors, then a phase-locked beat tracker. Sparse anchors form a piecewise-linear
   `TempoMap`; if the tempo is steady it collapses to one constant tempo.
6. Quantiser (automatic / soft / free), meter estimator (accent based: 2, 3 or 4 beats), key estimator
   (Krumhansl–Schmuckler).
7. Notes with confidence below 0.65 are marked `UNCERTAIN` and shown in orange in the editor.

## Neural pipeline (`MlTranscriptionEngine`, version `ml-1.0`, default)

1. YIN pass at 16 kHz: pitch frames for fine pitch and the singer's detuning (circular mean of the fractional pitch).
2. If the singer is consistently out of tune by 25 cents or more, the audio is resampled so that their tuning lands on
   the equal-tempered grid *before* the network sees it (the network's note identity degrades with large detuning);
   times are mapped back afterwards.
3. Basic Pitch (22.05 kHz, 2 s windows, 172 frames per window at 86 fps; note, onset and contour heads) on overlapping
   windows, stitched from the exact sample position of each frame (no drift on long recordings).
4. `NoteDecoder`: Viterbi path through {silence, 88 keys}; changing key is expensive unless the onset head agrees; a
   repeated attack on the same key is split from onset peaks, and weak peaks only when the energy dips (vibrato makes
   weak onsets). `DecoderParams` holds every threshold.
5. Exact pitch is the median of the YIN frames inside the note; confidence blends network activation, onset and
   agreement with YIN.
6. Shared tail (`PostNotePipeline`): tempo, quantisation, meter, key, uncertainty flags.

If the model or the runtime fails on a device, the engine falls back to the DSP pipeline above by itself.

## Rhythm

* Without a click: tempo from onset comb alignment and beat tracking (as above).
* With the metronome (`RecordingMeta` sidecar: BPM, beats per bar, count-in): tempo and meter are given, constant; the
  phase of the grid is searched around the nominal origin (absorbs click latency).
* `RhythmGrid.place`: all note starts are placed together by dynamic programming. Cost = timing error (about 60 ms)
  + metrical implausibility (bar line < beat < eighth < sixteenth) + deviation of the interval to the previous note.
  On a simulated 55 ms-jitter performer: 92% exact positions against 81% with independent rounding.

## Voice profile (`engine/profile`)

After each saved correction the app compares what the engine proposed with what the user kept
(`ContributionBuilder`) and writes one small file per project. `VoiceProfile.build` aggregates them into:
a logistic "is this a real note" model (confidence calibration), the silence bias of the decoder, the eagerness to cut
repeated notes, and a pitch-range prior over the 88 keys. Effects grow with evidence (`maturity = n / (n + 200)`);
with no data everything is the default. Plain statistics, inspectable, resettable, deleted with their project.

## Music model

* Every event stores **both** real time (seconds, from the recording) and musical time (beats). Quantisation never
  destroys the original timing, so changing the quantisation mode or the tempo re-derives the score.
* Events carry provenance (`DETECTED`, `USER`, `ARRANGEMENT`, `IMPORTED`) and a validation state
  (`AUTO`, `UNCERTAIN`, `VALIDATED`).
* `TempoMap` is piecewise linear with anchors, so notation stays aligned with the recording when the performer
  speeds up or slows down.
* The notation (`NotationBuilder`) is derived data: sixteenth grid, ties across barlines, standard and dotted
  values, key-aware spelling.
* Lyrics are separate segments attached to note ids, so they survive pitch and rhythm edits.
* Persistence is versioned JSON (`SCHEMA_VERSION = 1`).

## Score rendering

`ScoreLayoutEngine` computes positions (systems, measures, noteheads, accidentals, tie ends) independent of any
renderer. `ScorePainter` draws that layout on an `android.graphics.Canvas`; Compose uses it through `nativeCanvas`
and the PDF export uses it on a `PdfDocument` page, so screen and print are identical. Touches are converted back
to musical positions by the layout; notes are never stored as screen coordinates.

## App layer

* **Room**: `projects` (working version autosaved as JSON), `analysis_runs` (`ENGINE` results and `SNAPSHOT`
  copies of corrected versions, kept when a project is re-analysed), `arrangements`.
* **DataStore**: default input type, quantisation, tuning compensation.
* **AnalysisManager**: application-scoped, so leaving the screen does not cancel the work. A process death leaves
  the project restartable (`recoverInterrupted`).
* **AudioRecorder**: `AudioRecord` (UNPROCESSED → VOICE_RECOGNITION → MIC, 48/44.1/32/16 kHz fallback), streamed to
  a WAV file on an IO thread, audio-focus loss pauses.
* **PlaybackController**: one static `AudioTrack` for original, melody and arrangement playback, so seeking is exact
  and tracks cannot drift apart.
* **Hilt** wires engines behind their interfaces.
