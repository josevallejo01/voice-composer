# Architecture

## Modules and dependencies

```
:app ──► :data:export ──► :core:music-model
  │                              ▲
  └────► :engine ────────────────┘
```

`:core:music-model`, `:engine` and `:data:export` are plain Kotlin/JVM modules. Everything that needs Android
(microphone, codecs, `AudioTrack`, Room, Compose, `PdfDocument`) lives in `:app`.

The specification asks for separate engine sub-modules. They are packages of one `:engine` module for now
(`io`, `preprocessing`, `pitch`, `segmentation`, `rhythm`, `synth`, `arrangement`). Each is already behind an interface
(`TranscriptionEngine`, `PitchTracker`, `ArrangementEngine`), so splitting them later is a mechanical change.

## Analysis pipeline (`DefaultTranscriptionEngine`, version `dsp-1.0`)

1. Resample to 16 kHz (windowed sinc).
2. Pre-process: DC removal, high-pass, normalisation, quality flags (too quiet, clipped, too short).
3. YIN pitch tracker (cumulative mean normalised difference, parabolic interpolation, search range per input type:
   singing, humming, whistling, vocalise), then octave-error correction.
4. Note segmentation: pitch split against a running median, energy-dip re-attack, gap detection, vibrato tolerance,
   tuning compensation (a consistently flat/sharp singer is read relative to their own reference).
5. Tempo: comb alignment with priors, then a phase-locked beat tracker. Sparse anchors form a piecewise-linear
   `TempoMap`; if the tempo is steady it collapses to one constant tempo.
6. Quantiser (automatic / soft / free), meter estimator (accent based: 2, 3 or 4 beats), key estimator
   (Krumhansl–Schmuckler).
7. Notes with confidence below 0.65 are marked `UNCERTAIN` and shown in orange in the editor.

A neural pitch model can be plugged in behind `PitchTracker` if a benchmark shows it is worth the size.

## Music model

* Every event stores **both** real time (seconds, from the recording) and musical time (beats). Quantisation never
  destroys the original timing, so changing the quantisation mode or the tempo re-derives the score.
* Events carry provenance (`DETECTED`, `USER`, `ARRANGEMENT`, `IMPORTED`) and a validation state
  (`AUTO`, `UNCERTAIN`, `VALIDATED`).
* `TempoMap` is piecewise linear with anchors, so notation stays aligned with the recording when the performer
  speeds up or slows down.
* The notation (`NotationBuilder`) is derived data: sixteenth grid, ties across barlines, standard and dotted
  values, key-aware spelling.
* Lyrics are separate segments attached to note ids, so they survive pitch and rhythm edits.
* Persistence is versioned JSON (`SCHEMA_VERSION = 1`).

## Score rendering

`ScoreLayoutEngine` computes positions (systems, measures, noteheads, accidentals, tie ends) independent of any
renderer. `ScorePainter` draws that layout on an `android.graphics.Canvas`; Compose uses it through `nativeCanvas`
and the PDF export uses it on a `PdfDocument` page, so screen and print are identical. Touches are converted back
to musical positions by the layout; notes are never stored as screen coordinates.

## App layer

* **Room**: `projects` (working version autosaved as JSON), `analysis_runs` (`ENGINE` results and `SNAPSHOT`
  copies of corrected versions, kept when a project is re-analysed), `arrangements`.
* **DataStore**: default input type, quantisation, tuning compensation.
* **AnalysisManager**: application-scoped, so leaving the screen does not cancel the work. A process death leaves
  the project restartable (`recoverInterrupted`).
* **AudioRecorder**: `AudioRecord` (UNPROCESSED → VOICE_RECOGNITION → MIC, 48/44.1/32/16 kHz fallback), streamed to
  a WAV file on an IO thread, audio-focus loss pauses.
* **PlaybackController**: one static `AudioTrack` for original, melody and arrangement playback, so seeking is exact
  and tracks cannot drift apart.
* **Hilt** wires engines behind their interfaces.
